* ![GitHub Desktop](b3b3e6ca2637d11661fb6a167dedfd8ed5dd3945-io.github.shiftey.Desktop.png)
* ![GitHub](github-mark.svg)
* ![GitHub Desktop](github-desktop-prod.svg)
* ![GitHub Desktop Dev](github-desktop-dev.svg)
* ![Discourse](Discourse_icon.svg)
* ![](language-color.svg)
* ![Google Translate Language logo](Google_Translate_logo.svg.webp) [File](https://upload.wikimedia.org/wikipedia/commons/d/d7/Google_Translate_logo.svg?utm_source=commons.wikimedia.org&utm_campaign=index&utm_content=original) Google Inc., Public domain, via Wikimedia Commons
[Attribution](https://commons.wikimedia.org/wiki/File:Google_Translate_logo.svg): Google Inc., Public domain, via Wikimedia Commons
* ![](language-solid.png)
* ![](language-solid-full.svg)
* ![WordPress](Wordpress-Logo.svg)
* ![](MantisBT.svg)
* ![](MediaWiki-2020-icon.svg.webp) [File](https://commons.wikimedia.org/wiki/File:MediaWiki-2020-icon.svg)
Trademark of the Wikimedia Foundation, Inc. [use Guidelines](https://www.mediawiki.org/wiki/Special:MyLanguage/Manual:MediaWiki_logo_guidelines#Icon_sizes) [Serhio Magpie](https://commons.wikimedia.org/wiki/User:Serhio_Magpie) 23 November 2020
Attribution: `Serhio Magpie, CC BY-SA 4.0 <https://creativecommons.org/licenses/by-sa/4.0>, via Wikimedia Commons`
* ![](MediaWiki-2020-logo.svg) Trademark of the Wikimedia Foundation, Inc. [use Guidelines](https://www.mediawiki.org/wiki/Special:MyLanguage/Manual:MediaWiki_logo_guidelines#Icon_sizes) [Serhio Magpie](https://commons.wikimedia.org/wiki/User:Serhio_Magpie) 13 Mar 2021
* ![](sphinx-logo.svg)
* ![](sphinx-logoSm.svg)
* ![](Weblate_logo.png)
* ![](Weblate_logo.svg)
<!--
* ![]()
* ![]()
* ![]()
* ![]()
* ![]()
* ![]()
-->
