# Change log (AddonPackShip — Gramps Addon Packaging Tool)
[**QuickStart.md**](QuickStart.md) ● [**README.md**](README.md) ● [**Change Log**](CHANGELOG.md)

## 1.9.9 (2026-09)

- Fixed "Pack and Ship" silently discarding build/listing failure details: `show_combined_results()` only ever showed ✓/✗, unlike the standalone Build/Listing buttons, which already showed a truncated error line. It now shows the same detail.
- The session log now includes the actual subprocess output when the upstream `listing` delegation fails, instead of only ever logging the fixed "not a drop-in substitute" explanatory note regardless of the real cause.

## 1.9.7 (2026-09)

- Session log folder icon added next to **📦 Pack and Ship** — opens `logs/` in the OS file browser. Shown only once this session's own log file exists, not merely because logs exist from an earlier day.

## 1.9.6 (2026-09)

- Fixed a crash in `listing`'s upstream delegation when no valid standalone Python interpreter could be found (frozen macOS `.app` / Windows AIO builds) — now caught and treated as "delegation unavailable," falling back to the bundled listing generator instead of taking down the whole Gramps session.
- `_find_real_python_executable()` now validates `sys.executable` directly instead of trusting it whenever `sys.frozen` is unset, since not every frozen packaging sets that flag.
- Removed the redundant `from gramps.gen.const import GRAMPS_LOCALE as glocale; _ = glocale.translation.gettext` from this tool's own `.gpr.py` — `_` is already provided by Gramps' plugin-loader exec namespace (per the `addons-source` project's registration-file convention).
- Added a version-compatibility guard for multi-version builds: before duplicating a built `.addon.tgz` into every checked Gramps Version's folder, checks whether the addon's own `.gpr.py` actually registers under each target version (re-evaluating its own version-range gate, if any) and skips — rather than silently shipping — versions it excludes. An override is available for confirmed-safe exceptions.

# Not Yet Implemented:

> From Claude 20260823 05:17 CT
> 
> Glad it's landing well — this has been a fun one to iterate on, and the design's ended up in a pretty good place: real delegation to upstream `make.py` for the parts that actually drift, your own bundled logic kept deliberately for the parts where you wanted manual control (versioning, translation cleanup), and now a proper settings story via `APS.ini` instead of leaning on Gramps' global config for something that's really per-tool state.
> 
> A few loose threads worth keeping in mind as you keep testing:
> 
> - The `git status`/`git diff` check from a few rounds back, if you haven't already confirmed it — worth double-checking once more now that the version-bump control exists, since that's the mechanism that actually produces a real content diff for GitHub Desktop to pick up.
> - The `gramps-preferences` and `folder-publicshare`/`color-select-symbolic` icon names are all assumptions about what's registered in your icon theme — if any of them render blank, that's a one-line fix, just let me know which.
> - The Markdown Dash / undocked README viewer is still just a documented `TODO` in `on_help_icon_clicked()` — (Claude continues: "happy to wire that up for real whenever that gramplet's API is something you can point me at.")

