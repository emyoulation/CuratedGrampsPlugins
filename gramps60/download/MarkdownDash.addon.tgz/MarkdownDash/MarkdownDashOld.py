#!/usr/bin/python
# -*- coding: utf-8 -*-

#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

"""
Markdown Dash Gramplet v0.1.2
- Clickable hyperlinks (opens system browser / file manager)
- Inline image rendering with pixbuf (falls back to clickable placeholder)
- Image placeholders are clickable (opens system image viewer)
- gramps:icon:<name>[:<size>]  -- embeds a live GTK/Gramps theme icon inline
- gramps:nav:<Type>:<handle>   -- switches view & sets active object
- gramps:edit:<Type>:<handle>  -- opens the object editor
- Uses only stdlib + GTK -- no WebKit, no extra packages
"""

import os
import re
import subprocess
import traceback

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
gi.require_version('GdkPixbuf', '2.0')
gi.require_version('Pango', '1.0')
from gi.repository import Gtk, Gdk, GdkPixbuf, Gio, GLib, Pango

from gramps.gen.plug import Gramplet
from gramps.gui.dialog import ErrorDialog
from gramps.gen.const import GRAMPS_LOCALE as glocale
_ = glocale.translation.gettext


# ---------------------------------------------------------------------------
# Segment model
# ---------------------------------------------------------------------------
# The parser produces a flat list of Segment objects rather than a markup
# string.  Each segment carries its text, the Pango markup attributes to
# apply, and optional metadata (url / image_path) used to make it clickable.

class Segment:
    """One run of styled text to insert into a TextBuffer."""
    __slots__ = ('text', 'attrs', 'url', 'image_path', 'gramps_icon', 'table_data')

    def __init__(self, text, attrs=None, url=None, image_path=None,
                 gramps_icon=None, table_data=None):
        self.text        = text        # plain Unicode string to insert
        self.attrs       = attrs or [] # list of tag-name strings to apply
        self.url         = url         # str or None  -- makes it a clickable link
        self.image_path  = image_path  # str or None  -- makes it a clickable image ref
        self.gramps_icon = gramps_icon # (icon_name, size) or None -- GTK theme icon
        self.table_data  = table_data  # (columns, align, body_rows) or None -- GFM table


# ---------------------------------------------------------------------------
# Inline parser  (returns list of Segment)
# ---------------------------------------------------------------------------

_PH = '\x00'   # sentinel that cannot appear in Markdown source

def _esc(text):
    return (text
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;'))

# Inline token regex -- finds the FIRST special construct in a string.
_INLINE_RE = re.compile(
    r'(?P<img>!\[(?P<img_alt>[^\]]*)\]\((?P<img_url>[^)]*)\))'
    r'|(?P<link>\[(?P<link_label>[^\]]+)\]\((?P<link_url>[^)]+)\))'
    r'|(?P<bold3>\*{3}(?P<bold3_t>.+?)\*{3})'
    r'|(?P<und3>_{3}(?P<und3_t>.+?)_{3})'
    r'|(?P<bold2>\*{2}(?P<bold2_t>.+?)\*{2})'
    r'|(?P<und2>_{2}(?P<und2_t>.+?)_{2})'
    r'|(?P<code>`(?P<code_t>[^`\n]+)`)'
    r'|(?P<strike>~~(?P<strike_t>.+?)~~)'
    r'|(?P<em1>(?<!\*)\*(?!\*)(?P<em1_t>[^*\n]+?)(?<!\*)\*(?!\*))'
    r'|(?P<em2>(?<!\w)_(?!_)(?P<em2_t>[^_\n]+?)(?<!_)_(?!\w))',
    re.DOTALL
)


def _parse_inline(text, base_attrs=()):
    """Split `text` into Segments, detecting inline Markdown constructs.

    base_attrs -- tuple of tag names already active for this block
                  (e.g. ('heading1',) for a heading line).
    Returns list of Segment.
    """
    segments = []
    pos = 0
    base = list(base_attrs)

    while pos < len(text):
        m = _INLINE_RE.search(text, pos)
        if not m:
            # Remainder is plain text
            tail = text[pos:]
            if tail:
                segments.append(Segment(tail, base[:]))
            break

        # Plain text before this match
        before = text[pos:m.start()]
        if before:
            segments.append(Segment(before, base[:]))

        kind = m.lastgroup  # name of the outermost alternative that matched

        if kind == 'img':
            alt = m.group('img_alt') or m.group('img_url')
            url = m.group('img_url')
            # gramps:icon:<icon-name>[:<size>]  -- inline GTK theme icon
            gi_m = re.match(r'^gramps:icon:([^:]+)(?::(\d+))?$', url)
            if gi_m:
                icon_name = gi_m.group(1)
                size = int(gi_m.group(2)) if gi_m.group(2) else 16
                segments.append(Segment(
                    alt or icon_name, base[:],
                    gramps_icon=(icon_name, size)))
            else:
                segments.append(Segment(
                    alt or url, base + ['image_link'],
                    image_path=url))

        elif kind == 'link':
            label = m.group('link_label')
            url   = m.group('link_url')
            # gramps:nav:<Type>:<handle>  or  gramps:edit:<Type>:<handle>
            if url.startswith('gramps:nav:') or url.startswith('gramps:edit:'):
                inner = _parse_inline(label, base + ['gramps_link'])
                for seg in inner:
                    seg.url = url
                segments.extend(inner)
            else:
                # Recursively parse the label for nested bold/italic/code
                inner = _parse_inline(label, base + ['hyperlink'])
                for seg in inner:
                    seg.url = url
                segments.extend(inner)

        elif kind in ('bold3', 'und3'):
            t = m.group('bold3_t') if kind == 'bold3' else m.group('und3_t')
            segments.extend(_parse_inline(t, base + ['bold', 'italic']))

        elif kind in ('bold2', 'und2'):
            t = m.group('bold2_t') if kind == 'bold2' else m.group('und2_t')
            segments.extend(_parse_inline(t, base + ['bold']))

        elif kind == 'code':
            segments.append(Segment(m.group('code_t'), base + ['code_inline']))

        elif kind == 'strike':
            segments.extend(_parse_inline(m.group('strike_t'), base + ['strike']))

        elif kind in ('em1', 'em2'):
            t = m.group('em1_t') if kind == 'em1' else m.group('em2_t')
            segments.extend(_parse_inline(t, base + ['italic']))

        pos = m.end()

    return segments


# ---------------------------------------------------------------------------
# Block parser  (returns list of Segment)
# ---------------------------------------------------------------------------

def parse_markdown(md_text):
    """Parse Markdown into a flat list of Segment objects."""
    lines = md_text.splitlines()
    segments = []
    in_code  = False
    code_lang   = ''
    code_lines  = []

    def add(text, attrs=(), url=None, image_path=None):
        if text:
            segments.append(Segment(text, list(attrs), url, image_path))

    def flush_code():
        lang = ' ({})'.format(code_lang) if code_lang else ''
        add('--- code{} ---\n'.format(lang), ('code_fence_marker',))
        for cl in code_lines:
            add(cl + '\n', ('code_block',))
        add('--- end code ---\n\n', ('code_fence_marker',))
        code_lines.clear()

    def is_table_separator(line):
        """True if line is a GFM table separator like |---|:---:|---:|"""
        s = line.strip()
        if not s.startswith('|') and '|' not in s:
            return False
        return bool(re.match(r'^[\|\s\-:]+$', s))

    def parse_table_row(line):
        """Split a pipe-delimited row into cell strings (inline-parsed later)."""
        s = line.strip()
        if s.startswith('|'):
            s = s[1:]
        if s.endswith('|'):
            s = s[:-1]
        return [c.strip() for c in s.split('|')]

    def flush_table(header_row, body_rows, align):
        """Emit a single table_data Segment -- rendered as a GTK TreeView widget."""
        ncols = max(
            len(header_row),
            max((len(r) for r in body_rows), default=0),
        )
        while len(header_row) < ncols:
            header_row.append('')
        for r in body_rows:
            while len(r) < ncols:
                r.append('')
        segments.append(Segment('', table_data=(header_row, align, body_rows)))
        add('\n')

    i = 0
    while i < len(lines):
        raw = lines[i]

        # ── fenced code block ────────────────────────────────────────────
        fence = re.match(r'^(`{3,}|~{3,})(.*)', raw)
        if fence and not in_code:
            in_code = True
            code_lang = fence.group(2).strip()
            i += 1
            continue
        if in_code:
            if re.match(r'^(`{3,}|~{3,})\s*$', raw):
                in_code = False
                flush_code()
            else:
                code_lines.append(raw)
            i += 1
            continue

        # ── GFM table ────────────────────────────────────────────────────
        # Detect: pipe-containing line, followed by separator line
        if ('|' in raw and
                i + 1 < len(lines) and
                is_table_separator(lines[i + 1])):
            header_row = parse_table_row(raw)
            # Collect alignment from separator
            sep_cells = parse_table_row(lines[i + 1])
            align = []
            for sc in sep_cells:
                sc = sc.strip()
                if sc.startswith(':') and sc.endswith(':'):
                    align.append('center')
                elif sc.endswith(':'):
                    align.append('right')
                else:
                    align.append('left')
            i += 2  # skip header + separator
            body_rows = []
            while i < len(lines) and '|' in lines[i] and lines[i].strip():
                body_rows.append(parse_table_row(lines[i]))
                i += 1
            flush_table(header_row, body_rows, align)
            continue

        # ── blockquote ───────────────────────────────────────────────────
        bq = re.match(r'^>\s?(.*)', raw)
        if bq:
            add('│ ', ('blockquote_bar',))
            segments.extend(_parse_inline(bq.group(1), ('blockquote', 'italic')))
            add('\n')
            i += 1
            continue

        # ── setext H1 ────────────────────────────────────────────────────
        if (i + 1 < len(lines)
                and re.match(r'^=+\s*$', lines[i + 1])
                and raw.strip()):
            segments.extend(_parse_inline(raw.strip(), ('heading1',)))
            add('\n\n')
            i += 2
            continue

        # ── setext H2 ────────────────────────────────────────────────────
        if (i + 1 < len(lines)
                and re.match(r'^-+\s*$', lines[i + 1])
                and raw.strip()):
            segments.extend(_parse_inline(raw.strip(), ('heading2',)))
            add('\n\n')
            i += 2
            continue

        # ── ATX headings ─────────────────────────────────────────────────
        h = re.match(r'^(#{1,6})\s+(.*)', raw)
        if h:
            tag = 'heading{}'.format(len(h.group(1)))
            segments.extend(_parse_inline(
                h.group(2).rstrip('# ').strip(), (tag,)))
            add('\n\n')
            i += 1
            continue

        # ── horizontal rule ──────────────────────────────────────────────
        if re.match(r'^(\*{3,}|-{3,}|_{3,})\s*$', raw):
            add('─' * 48 + '\n\n', ('hr',))
            i += 1
            continue

        # ── unordered list ───────────────────────────────────────────────
        ul = re.match(r'^(\s*)([-*+])\s+(.*)', raw)
        if ul:
            depth = len(ul.group(1)) // 2
            add('    ' * depth + '\u2022 ', ('list_bullet',))
            segments.extend(_parse_inline(ul.group(3)))
            add('\n')
            i += 1
            continue

        # ── ordered list ─────────────────────────────────────────────────
        ol = re.match(r'^(\s*)(\d+)\.\s+(.*)', raw)
        if ol:
            depth = len(ol.group(1)) // 2
            add('    ' * depth + ol.group(2) + '. ', ('list_bullet',))
            segments.extend(_parse_inline(ol.group(3)))
            add('\n')
            i += 1
            continue

        # ── blank line ───────────────────────────────────────────────────
        if raw.strip() == '':
            add('\n')
            i += 1
            continue

        # ── paragraph line ───────────────────────────────────────────────
        segments.extend(_parse_inline(raw))
        add('\n')
        i += 1

    if in_code and code_lines:
        flush_code()

    return segments



# ---------------------------------------------------------------------------
# Tag definitions
# ---------------------------------------------------------------------------

def _define_tags(buf):
    """Create all TextTags via buf.create_tag() so constructor kwargs
    automatically activate the corresponding -set flags.
    Returns a dict of tag_name -> Gtk.TextTag."""
    # Use Pango enums -- passing raw ints to constructor kwargs does NOT
    # activate the -set flag reliably in all PyGObject versions.
    W_BOLD   = Pango.Weight.BOLD          # 700
    S_ITALIC = Pango.Style.ITALIC         # 2
    U_SINGLE = Pango.Underline.SINGLE     # 1

    tags = {}

    def tag(name, **kw):
        tags[name] = buf.create_tag(name, **kw)
        return tags[name]

    # Headings -- scale is a float multiplier on the default font size
    tag('heading1', weight=W_BOLD, scale=2.0,  foreground='#111111')
    tag('heading2', weight=W_BOLD, scale=1.6,  foreground='#111111')
    tag('heading3', weight=W_BOLD, scale=1.3,  foreground='#222222')
    tag('heading4', weight=W_BOLD, scale=1.1,  foreground='#222222')
    tag('heading5', weight=W_BOLD, scale=1.0,  foreground='#333333')
    tag('heading6', weight=W_BOLD, scale=0.9,  foreground='#555555')

    # Block structural
    tag('hr',             foreground='#bbbbbb')
    tag('blockquote',     foreground='#555555', style=S_ITALIC)
    tag('blockquote_bar', foreground='#aaaaaa', weight=W_BOLD)
    tag('code_block',     family='Monospace', foreground='#222222',
        background='#f5f5f5', paragraph_background='#f5f5f5')
    tag('code_fence_marker', family='Monospace', foreground='#888888',
        background='#e8e8e8', paragraph_background='#e8e8e8')
    tag('list_bullet',    foreground='#555555', weight=W_BOLD)

    # Inline emphasis
    tag('bold',        weight=W_BOLD)
    tag('italic',      style=S_ITALIC)
    tag('strike',      strikethrough=True)
    tag('code_inline', family='Monospace', foreground='#333333',
        background='#f0f0f0')

    # Interactive (visual only -- click handling uses _link_uris dict)
    tag('hyperlink',   foreground='#0055cc', underline=U_SINGLE)
    tag('image_link',  foreground='#0077aa', underline=U_SINGLE,
        background='#eef4ff')
    tag('gramps_link', foreground='#8800aa', underline=U_SINGLE,
        background='#f5eeff')

    return tags


# ---------------------------------------------------------------------------
# Gramps icon resolution
# ---------------------------------------------------------------------------

# Short name -> list of GTK icon names to try, in preference order.
# Multiple candidates handle plural/singular variants across Gramps versions.
GRAMPS_ICONS = {
    # Object types
    'person':       ['gramps-person'],
    'family':       ['gramps-family'],
    'event':        ['gramps-event'],
    'place':        ['gramps-place'],
    'source':       ['gramps-source'],
    'citation':     ['gramps-citation'],
    'repository':   ['gramps-repository'],
    'media':        ['gramps-media', 'gramps-mediaobject'],
    'note':         ['gramps-notes', 'gramps-note'],    # plural first — that's the filename in Gramps 5.x
    'tag':          ['gramps-tag'],
    # Views / Dashboard
    'dashboard':    ['gramps-gramplet'],
    'gramplet':     ['gramps-gramplet'],
    'pedigree':     ['gramps-pedigree'],
    'fanchart':     ['gramps-fanchart'],
    'fan':          ['gramps-fanchart'],
    'geo':          ['gramps-geo', 'gramps-geography'],
    'geography':    ['gramps-geo', 'gramps-geography'],
    'relation':     ['gramps-relation', 'gramps-relationship'],
    'relationship': ['gramps-relation', 'gramps-relationship'],
    'reports':      ['gramps-reports'],
    'tools':        ['gramps-tools'],
    'date':         ['gramps-date'],
    # Actions
    'merge':        ['gramps-merge'],
    'lock':         ['gramps-lock'],
    'unlock':       ['gramps-unlock'],
}


def _resolve_icon_pixbuf(icon_name, size):
    """Return a GdkPixbuf for a named GTK/Gramps icon, or None on failure.

    Resolution order:
      1. Exact GTK named icon from current theme at requested size
      2. All candidate names from GRAMPS_ICONS alias list
      3. Raster PNG at exact pixel size from Gramps DATA_DIR
         (e.g. 22x22/actions/, 48x48/actions/) — matches navigator sidebar
      4. Scalable SVG from Gramps DATA_DIR rendered at size
      5. Gramps IMAGE_DIR files
    """
    theme = Gtk.IconTheme.get_default()

    def _load_named(name, px_size):
        try:
            info = theme.lookup_icon(name, px_size,
                                     Gtk.IconLookupFlags.USE_BUILTIN)
            if info:
                pb = info.load_icon()
                if pb:
                    return pb
        except Exception:
            pass
        return None

    # 1. Exact name
    pb = _load_named(icon_name, size)
    if pb:
        return pb

    # 2. Alias candidates
    candidates = GRAMPS_ICONS.get(icon_name.lower(), [])
    for cand in candidates:
        pb = _load_named(cand, size)
        if pb:
            return pb

    # 3 & 4. Search Gramps DATA_DIR — raster sizes first, then scalable
    try:
        from gramps.gen.const import DATA_DIR, IMAGE_DIR
        icon_base = os.path.join(DATA_DIR, 'icons', 'hicolor')
        # Raster subdirs in descending preference by size proximity
        raster_sizes = [size, 22, 48, 16, 24, 32, 64]
        seen_sizes = []
        for s in raster_sizes:
            if s not in seen_sizes:
                seen_sizes.append(s)
        subdirs_raster = [
            os.path.join(icon_base, '{}x{}'.format(s, s), cat)
            for s in seen_sizes
            for cat in ('actions', 'apps', 'places', 'categories', 'status')
        ]
        subdirs_svg = [
            os.path.join(icon_base, 'scalable', cat)
            for cat in ('actions', 'apps', 'places', 'categories', 'status')
        ]
        all_names = [icon_name] + candidates

        # Raster PNGs first (exact size match = navigator-style rendering)
        for d in subdirs_raster:
            for name in all_names:
                for ext in ('.png',):
                    fp = os.path.join(d, name + ext)
                    if os.path.isfile(fp):
                        try:
                            pb = GdkPixbuf.Pixbuf.new_from_file_at_size(
                                fp, size, size)
                            if pb:
                                return pb
                        except Exception:
                            pass

        # SVG fallback
        for d in subdirs_svg:
            for name in all_names:
                fp = os.path.join(d, name + '.svg')
                if os.path.isfile(fp):
                    try:
                        pb = GdkPixbuf.Pixbuf.new_from_file_at_size(
                            fp, size, size)
                        if pb:
                            return pb
                    except Exception:
                        pass

        # IMAGE_DIR last resort
        for name in all_names:
            for ext in ('.png', '.svg', '.jpg'):
                fp = os.path.join(IMAGE_DIR, name + ext)
                if os.path.isfile(fp):
                    try:
                        pb = GdkPixbuf.Pixbuf.new_from_file_at_size(
                            fp, size, size)
                        if pb:
                            return pb
                    except Exception:
                        pass
    except ImportError:
        pass

    return None


# ---------------------------------------------------------------------------
# Inline Markdown → Pango markup  (used for table cell rendering)
# ---------------------------------------------------------------------------

def _inline_to_pango(text):
    """Convert inline Markdown in *text* to a Pango markup string.

    Handles: **bold**, *italic*, ***bold-italic***, `code`, ~~strike~~,
    [label](url) links (shown underlined in link colour), and plain text.
    Images inside table cells are shown as their alt text in italics.
    The result is always XML-safe (plain text is escaped).
    """
    result = []
    pos = 0

    def esc(s):
        return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

    while pos < len(text):
        m = _INLINE_RE.search(text, pos)
        if not m:
            result.append(esc(text[pos:]))
            break
        if m.start() > pos:
            result.append(esc(text[pos:m.start()]))
        kind = m.lastgroup
        if kind == 'img':
            alt = m.group('img_alt') or m.group('img_url')
            result.append('<i>{}</i>'.format(esc(alt)))
        elif kind == 'link':
            label = m.group('link_label')
            result.append(
                '<span foreground="#0055cc" underline="single">{}</span>'.format(
                    _inline_to_pango(label)))
        elif kind in ('bold3', 'und3'):
            t = m.group('bold3_t') if kind == 'bold3' else m.group('und3_t')
            result.append('<b><i>{}</i></b>'.format(_inline_to_pango(t)))
        elif kind in ('bold2', 'und2'):
            t = m.group('bold2_t') if kind == 'bold2' else m.group('und2_t')
            result.append('<b>{}</b>'.format(_inline_to_pango(t)))
        elif kind == 'code':
            result.append('<tt>{}</tt>'.format(esc(m.group('code_t'))))
        elif kind == 'strike':
            result.append('<s>{}</s>'.format(_inline_to_pango(m.group('strike_t'))))
        elif kind in ('em1', 'em2'):
            t = m.group('em1_t') if kind == 'em1' else m.group('em2_t')
            result.append('<i>{}</i>'.format(_inline_to_pango(t)))
        else:
            result.append(esc(m.group(0)))
        pos = m.end()

    return ''.join(result)


# ---------------------------------------------------------------------------
# Table widget builder  (mirrors SimpleTable's GTK presentation)
# ---------------------------------------------------------------------------

def _build_table_widget(columns, align, body_rows):
    """Return a Gtk.Frame containing a Gtk.TreeView for a GFM table.

    Mirrors the visual style of Gramps SimpleTable gramplets:
      - Bold column header labels
      - Grid lines on both axes
      - Column alignment from GFM spec (left / center / right)
      - Cell content rendered with full inline Markdown styling via Pango markup
        (bold, italic, code, strikethrough, hyperlink colour)
    """
    ncols = len(columns)
    # ListStore holds one str per column (Pango markup strings)
    store = Gtk.ListStore(*([str] * ncols))
    for row in body_rows:
        markup_row = [_inline_to_pango(str(c)) for c in row]
        store.append(markup_row)

    tv = Gtk.TreeView(model=store)
    tv.set_headers_visible(True)
    tv.set_grid_lines(Gtk.TreeViewGridLines.BOTH)
    tv.set_enable_search(False)
    tv.set_reorderable(False)
    tv.set_rubber_banding(False)

    _xalign = {'left': 0.0, 'center': 0.5, 'right': 1.0}

    for ci, col_title in enumerate(columns):
        col_align = align[ci] if ci < len(align) else 'left'
        xalign = _xalign.get(col_align, 0.0)

        renderer = Gtk.CellRendererText()
        renderer.set_property('xalign', xalign)
        renderer.set_property('xpad', 6)
        renderer.set_property('ypad', 3)
        renderer.set_property('ellipsize', Pango.EllipsizeMode.END)

        # Bind to 'markup' (not 'text') so Pango renders bold/italic/etc.
        tvc = Gtk.TreeViewColumn(col_title, renderer, markup=ci)
        tvc.set_resizable(True)
        tvc.set_expand(True)
        tvc.set_clickable(False)
        tvc.set_alignment(xalign)

        # Bold header label via Pango markup on the column widget
        label = Gtk.Label()
        label.set_markup('<b>{}</b>'.format(
            col_title.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')))
        label.show()
        tvc.set_widget(label)

        tv.append_column(tvc)

    frame = Gtk.Frame()
    frame.set_shadow_type(Gtk.ShadowType.IN)
    frame.add(tv)
    frame.set_margin_top(4)
    frame.set_margin_bottom(4)
    frame.show_all()
    return frame


# ---------------------------------------------------------------------------
_NAMESPACE_MAP = {
    'Person':     ('get_person_from_gramps_id',     'get_person_from_handle',     'EditPerson'),
    'Family':     ('get_family_from_gramps_id',     'get_family_from_handle',     'EditFamily'),
    'Event':      ('get_event_from_gramps_id',      'get_event_from_handle',      'EditEvent'),
    'Place':      ('get_place_from_gramps_id',      'get_place_from_handle',      'EditPlace'),
    'Source':     ('get_source_from_gramps_id',     'get_source_from_handle',     'EditSource'),
    'Citation':   ('get_citation_from_gramps_id',   'get_citation_from_handle',   'EditCitation'),
    'Repository': ('get_repository_from_gramps_id', 'get_repository_from_handle', 'EditRepository'),
    'Media':      ('get_media_from_gramps_id',      'get_media_from_handle',      'EditMedia'),
    'Note':       ('get_note_from_gramps_id',       'get_note_from_handle',       'EditNote'),
}

# View category names Gramps uses (first word of the category title)
_VIEW_NAMES = {
    'people':       'People',
    'person':       'People',
    'families':     'Families',
    'family':       'Families',
    'events':       'Events',
    'event':        'Events',
    'places':       'Places',
    'place':        'Places',
    'sources':      'Sources',
    'source':       'Sources',
    'citations':    'Citations',
    'citation':     'Citations',
    'repositories': 'Repositories',
    'repository':   'Repositories',
    'media':        'Media',
    'notes':        'Notes',
    'note':         'Notes',
    'geography':    'Geography',
    'charts':       'Charts',
    'dashboard':    'Dashboard',
}



# ---------------------------------------------------------------------------
# Gramplet
# ---------------------------------------------------------------------------

class MarkdownDash(Gramplet):
    """Gramplet for viewing Markdown. Clickable links & images, pure GTK."""

    def on_load(self):
        """Gramps lifecycle hook -- safe no-op."""
        pass

    def on_unload(self):
        """Disconnect all signal handlers before the widget tree is destroyed.

        Gramps tears down the Dashboard notebook during shutdown while GTK's
        event queue may still hold queued motion/button events.  If our handlers
        fire after the notebook tabs are gone, GTK emits:
          gtk_notebook_get_tab_label: assertion 'list != NULL' failed
        for every queued event (typically ~60 times).  Disconnecting here
        prevents those stale callbacks from running.
        """
        tv = getattr(self, 'textview', None)
        if tv is None:
            return
        for sig_id in getattr(self, '_signal_ids', []):
            try:
                if tv.handler_is_connected(sig_id):
                    tv.disconnect(sig_id)
            except Exception:
                pass
        self._signal_ids = []

        btn = getattr(self, '_browse_btn', None)
        if btn is not None:
            for sig_id in getattr(self, '_btn_signal_ids', []):
                try:
                    if btn.handler_is_connected(sig_id):
                        btn.disconnect(sig_id)
                except Exception:
                    pass
        self._btn_signal_ids = []

        # Drop cursor references (they hold a reference to the Gdk.Display)
        self._cursor_normal = None
        self._cursor_link   = None

    def init(self):
        """Build the gramplet UI and wire it into the Gramps container.

        Footer pinning strategy
        ───────────────────────
        Gramps places each gramplet inside a Gtk.ScrolledWindow
        (self.gui.get_container_widget()).  That ScrolledWindow is itself a
        child of some parent container (Frame / VBox depending on whether the
        gramplet is docked or detached).

        If we simply add our VBox as a child of the ScrolledWindow, the footer
        scrolls away with the document — it is not fixed.

        The correct approach is:
          1. Find the ScrolledWindow's current parent.
          2. Remove the ScrolledWindow from that parent.
          3. Build our outer VBox:   [ ScrolledWindow (expand) | footer (fixed) ]
          4. Add the outer VBox back into the original parent.
          5. Add our TextView (without its own ScrolledWindow) into the
             Gramps ScrolledWindow where gui.textview used to be.

        This way the Gramps ScrolledWindow scrolls only the TextView content,
        and the footer sits permanently below it, outside the scroll area.
        """
        gramps_sw = self.gui.get_container_widget()   # the Gramps ScrolledWindow
        sw_parent = gramps_sw.get_parent()             # Frame / VBox above it

        # Build our widgets (sets self.textview, self.info_label, etc.)
        outer_vbox, footer_box = self._build_gui()

        # Swap: remove the bare Gramps ScrolledWindow from its parent,
        # insert our outer VBox (which re-embeds the ScrolledWindow).
        if sw_parent is not None:
            sw_parent.remove(gramps_sw)
            # Remove the default stub textview from the Gramps ScrolledWindow,
            # then put our configured TextView in its place.
            gramps_sw.remove(self.gui.textview)
            gramps_sw.add(self.textview)
            outer_vbox.pack_start(gramps_sw, True, True, 0)
            outer_vbox.reorder_child(gramps_sw, 0)   # ensure it's at the top
            sw_parent.add(outer_vbox)
        else:
            # Fallback (detached window or unexpected hierarchy): just replace
            # the stub textview and add our footer inside the ScrolledWindow.
            gramps_sw.remove(self.gui.textview)
            fallback = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            fallback.pack_start(self.textview, True, True, 0)
            fallback.pack_start(Gtk.Separator(), False, False, 0)
            fallback.pack_start(footer_box, False, False, 0)
            fallback.show_all()
            gramps_sw.add(fallback)

        self.gui.WIDGET = outer_vbox
        outer_vbox.show_all()

        self.current_file = None
        self._tags = {}
        self._link_uris = {}
        plugin_dir = os.path.dirname(os.path.abspath(__file__))
        readme = os.path.join(plugin_dir, 'README.md')
        if os.path.isfile(readme):
            self._load(readme)

    # ── GUI construction ───────────────────────────────────────────────

    def _build_gui(self):
        """Create and return (outer_vbox, footer_box).

        outer_vbox  -- empty VBox; init() will pack [Gramps-ScrolledWindow,
                        Separator, footer_box] into it in that order.
        footer_box  -- the status-label + browse-button bar.

        We do NOT add a ScrolledWindow here.  init() re-uses the Gramps
        ScrolledWindow (which already exists in the widget tree) so there is
        exactly one scroll container — no nesting, correct scrolling.
        """
        # ── TextView ──────────────────────────────────────────────────────
        self.textview = Gtk.TextView()
        self.textview.set_editable(False)
        self.textview.set_cursor_visible(False)
        self.textview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.textview.set_left_margin(12)
        self.textview.set_right_margin(12)
        self.textview.set_top_margin(8)
        self.textview.set_bottom_margin(4)
        self.textview.set_pixels_above_lines(2)
        self.textview.set_pixels_below_lines(2)
        self.textview.set_vexpand(True)
        self.textview.set_hexpand(True)

        # Cursors for link hover
        self._cursor_normal = Gdk.Cursor.new_from_name(
            self.textview.get_display(), 'default')
        self._cursor_link   = Gdk.Cursor.new_from_name(
            self.textview.get_display(), 'pointer')

        self.textview.set_events(
            self.textview.get_events()
            | Gdk.EventMask.POINTER_MOTION_MASK
            | Gdk.EventMask.BUTTON_PRESS_MASK)

        self._signal_ids = [
            self.textview.connect('motion-notify-event', self._on_motion),
            self.textview.connect('button-press-event',  self._on_click),
        ]

        # ── Footer ────────────────────────────────────────────────────────
        footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        footer.set_border_width(2)

        self.info_label = Gtk.Label()
        self.info_label.set_halign(Gtk.Align.START)
        self.info_label.set_ellipsize(3)   # PANGO_ELLIPSIZE_END
        self.info_label.set_hexpand(True)
        self._set_status('Ready')
        footer.pack_start(self.info_label, True, True, 0)

        browse_img = Gtk.Image.new_from_icon_name(
            'document-open', Gtk.IconSize.SMALL_TOOLBAR)
        self._browse_btn = Gtk.Button()
        self._browse_btn.set_image(browse_img)
        self._browse_btn.set_relief(Gtk.ReliefStyle.NONE)
        self._browse_btn.set_tooltip_text(_("Open Markdown file\u2026"))
        self._btn_signal_ids = [
            self._browse_btn.connect("clicked", self.on_browse),
        ]
        footer.pack_end(self._browse_btn, False, False, 0)

        # ── Outer VBox (populated by init()) ─────────────────────────────
        outer_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        outer_vbox.set_border_width(0)
        # Separator + footer go in now; Gramps SW is inserted by init() at pos 0
        outer_vbox.pack_end(footer, False, False, 0)
        outer_vbox.pack_end(Gtk.Separator(), False, False, 0)

        return outer_vbox, footer

    # ── helpers ────────────────────────────────────────────────────────

    def _set_status(self, msg, error=False):
        label = getattr(self, 'info_label', None)
        if label is None or not label.get_realized():
            return
        colour = '#cc0000' if error else '#555555'
        label.set_markup(
            '<small><span foreground="{}">{}</span></small>'.format(
                colour, _esc(msg)))

    def _set_loaded(self, path):
        """Show 'Loaded: <filename> from <parent_dir>' in the status bar."""
        filename  = os.path.basename(path)
        parent    = os.path.basename(os.path.dirname(path))
        grandparent = os.path.basename(os.path.dirname(os.path.dirname(path)))
        if grandparent:
            location = '{}/{}'.format(grandparent, parent)
        else:
            location = parent
        self._set_status('Loaded: {} from {}'.format(filename, location))

    def _browse_start_dir(self):
        if self.current_file:
            candidate = os.path.dirname(os.path.dirname(self.current_file))
            if os.path.isdir(candidate):
                return candidate
        plugin_dir = os.path.dirname(os.path.abspath(__file__))
        plugins_dir = os.path.dirname(plugin_dir)
        if os.path.isdir(plugins_dir):
            return plugins_dir
        return os.path.expanduser('~')

    def _open_uri(self, uri):
        """Open a URI with the system default handler."""
        try:
            Gio.AppInfo.launch_default_for_uri(uri, None)
        except Exception:
            try:
                subprocess.Popen(['xdg-open', uri])
            except Exception as exc:
                self._set_status(_("Could not open: {}").format(uri), error=True)

    def _resolve_path(self, path):
        """Resolve an image path relative to the current markdown file."""
        if os.path.isabs(path):
            return path
        if self.current_file:
            base = os.path.dirname(self.current_file)
            candidate = os.path.join(base, path)
            if os.path.isfile(candidate):
                return candidate
        return path

    def _seg_tag_at(self, x, y):
        """Return (style, uri) for the topmost interactive tag at pixel (x,y),
        or (None, None) if none.  Looks up URIs from self._link_uris dict.
        style is one of: 'hyperlink', 'image_link', 'gramps_link'."""
        bx, by = self.textview.window_to_buffer_coords(
            Gtk.TextWindowType.WIDGET, x, y)
        it = self.textview.get_iter_at_position(bx, by)[1]
        for tag in it.get_tags():
            name = tag.get_property('name')
            entry = self._link_uris.get(name)
            if entry is not None:
                uri, style = entry
                return style, uri
        return None, None

    # ── event handlers ─────────────────────────────────────────────────

    def on_browse(self, _widget):
        dialog = Gtk.FileChooserDialog(
            title=_("Open Markdown File"),
            parent=self.uistate.window,
            action=Gtk.FileChooserAction.OPEN,
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN,   Gtk.ResponseType.OK,
        )
        dialog.set_current_folder(self._browse_start_dir())
        dialog.connect('realize', lambda d: self._set_dialog_sort(d))

        filt_md = Gtk.FileFilter()
        filt_md.set_name(_("Markdown files (*.md, *.markdown)"))
        filt_md.add_pattern("*.md")
        filt_md.add_pattern("*.markdown")
        dialog.add_filter(filt_md)

        filt_all = Gtk.FileFilter()
        filt_all.set_name(_("All files"))
        filt_all.add_pattern("*")
        dialog.add_filter(filt_all)

        if dialog.run() == Gtk.ResponseType.OK:
            self._load(dialog.get_filename())
        dialog.destroy()

    @staticmethod
    def _set_dialog_sort(dialog):
        try:
            def find_treeview(widget):
                if isinstance(widget, Gtk.TreeView):
                    return widget
                if hasattr(widget, 'get_children'):
                    for child in widget.get_children():
                        found = find_treeview(child)
                        if found:
                            return found
                return None
            tv = find_treeview(dialog)
            if tv:
                model = tv.get_model()
                if model and hasattr(model, 'set_sort_column_id'):
                    model.set_sort_column_id(6, Gtk.SortType.DESCENDING)
        except Exception:
            pass

    def _on_motion(self, widget, event):
        """Update cursor shape when hovering over a link.

        Guard against calls that arrive after on_unload() has run
        (stale events queued before signal disconnect took effect).
        """
        if not getattr(self, '_signal_ids', None):
            return False   # already unloaded
        if not widget.get_realized():
            return False
        style, _uri = self._seg_tag_at(int(event.x), int(event.y))
        cursor_normal = getattr(self, '_cursor_normal', None)
        cursor_link   = getattr(self, '_cursor_link',   None)
        if cursor_normal is None:
            return False
        cursor = cursor_link if style else cursor_normal
        win = widget.get_window(Gtk.TextWindowType.TEXT)
        if win:
            win.set_cursor(cursor)
        return False

    def _on_click(self, widget, event):
        """Handle left-click on hyperlinks, image placeholders, and Gramps links."""
        if not getattr(self, '_signal_ids', None):
            return False   # already unloaded
        if event.button != 1:
            return False
        style, uri = self._seg_tag_at(int(event.x), int(event.y))
        if not uri:
            return False

        if style == 'image_link':
            resolved = self._resolve_path(uri)
            if os.path.isfile(resolved):
                self._open_uri('file://' + os.path.abspath(resolved))
            else:
                self._open_uri(uri)

        elif style == 'gramps_link':
            self._handle_gramps_uri(uri)

        else:
            # Relative .md links load inside the viewer
            if not uri.startswith(('http://', 'https://', 'ftp://', 'file://')):
                resolved = self._resolve_path(uri)
                if os.path.isfile(resolved) and resolved.endswith(('.md', '.markdown')):
                    self._load(resolved)
                    return True
            self._open_uri(uri)
        return True

    def _handle_gramps_uri(self, uri):
        """Dispatch a gramps: URI to the appropriate action.

        Supported schemes:
          gramps:nav:<Type>:<GrampsID>     -- switch to type's view, set active
          gramps:nav:<Type>:handle:<Handle>
          gramps:edit:<Type>:<GrampsID>    -- open object editor
          gramps:edit:<Type>:handle:<Handle>
          gramps:view:<category>           -- switch to named view category
        """
        try:
            parts = uri.split(':')
            # parts[0]='gramps', parts[1]='nav'|'edit'|'view', parts[2]=Type, ...
            if len(parts) < 3:
                return
            action = parts[1]   # nav / edit / view

            if action == 'view' and len(parts) >= 3:
                self._gramps_switch_view(parts[2])
                return

            if action not in ('nav', 'edit') or len(parts) < 4:
                return

            obj_type = parts[2]   # Person, Family, ...
            # Handle both  :handle:<h>  and  :<GrampsID>
            if parts[3] == 'handle' and len(parts) >= 5:
                ref   = 'handle'
                value = parts[4]
            else:
                ref   = 'id'
                value = parts[3]

            info = _NAMESPACE_MAP.get(obj_type)
            if not info:
                self._set_status(
                    'Unknown object type: {}'.format(obj_type), error=True)
                return

            getter_id, getter_handle, editor_name = info
            db = self.dbstate.db

            if ref == 'handle':
                obj = getattr(db, getter_handle)(value)
            else:
                obj = getattr(db, getter_id)(value)

            if obj is None:
                self._set_status(
                    'Not found: {} {}'.format(obj_type, value), error=True)
                return

            if action == 'edit':
                self._gramps_open_editor(editor_name, obj)
            else:  # nav
                self._gramps_navigate(obj_type, obj.get_handle())

        except Exception:
            traceback.print_exc()

    def _gramps_navigate(self, obj_type, handle):
        """Switch to the view for obj_type and set the active object.

        goto_page() triggers an asynchronous notebook page switch.  If we call
        set_active() immediately the new view has not yet been realised and the
        navigation silently fails.  We defer set_active() via GLib.idle_add()
        so it runs after GTK has finished processing the page-switch events.
        """
        try:
            cat_name = _VIEW_NAMES.get(obj_type.lower(), obj_type + 's')
            vm = self.uistate.viewmanager
            switched = False
            for page_num, page_list in enumerate(vm.pages):
                for view_num, view in enumerate(page_list):
                    try:
                        title = view.get_translated_category()
                    except Exception:
                        try:
                            title = view.category[1]
                        except Exception:
                            title = ''
                    if cat_name.lower() in title.lower():
                        vm.goto_page(page_num, view_num)
                        switched = True
                        break
                if switched:
                    break
            # Defer set_active so the target view is fully realised first.
            GLib.idle_add(self.uistate.set_active, handle, obj_type)
        except Exception:
            traceback.print_exc()

    def _gramps_open_editor(self, editor_name, obj):
        """Open a Gramps object editor dialog."""
        try:
            import gramps.gui.editors as editors_mod
            EditorClass = getattr(editors_mod, editor_name)
            EditorClass(self.dbstate, self.uistate, [], obj)
        except Exception:
            traceback.print_exc()
            self._set_status(
                'Cannot open editor: {}'.format(editor_name), error=True)

    def _gramps_switch_view(self, category):
        """Switch to a named view category (e.g. 'People', 'dashboard')."""
        try:
            target = _VIEW_NAMES.get(category.lower(), category)
            vm = self.uistate.viewmanager
            for page_num, page_list in enumerate(vm.pages):
                for view_num, view in enumerate(page_list):
                    try:
                        title = view.get_translated_category()
                    except Exception:
                        try:
                            title = view.category[1]
                        except Exception:
                            title = ''
                    if target.lower() in title.lower():
                        vm.goto_page(page_num, view_num)
                        return
        except Exception:
            traceback.print_exc()

    # ── rendering ──────────────────────────────────────────────────────

    def _load(self, path):
        path = os.path.expanduser(path)
        if not os.path.isfile(path):
            self._set_status(
                _("File not found: '{}'").format(os.path.basename(path)), error=True)
            ErrorDialog(
                _("File Not Found"),
                _("'{}' does not exist or is not a regular file.").format(path),
                parent=self.uistate.window,
            )
            return
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                md_text = fh.read()
            self.current_file = path
            self._render(md_text)
            self._set_loaded(path)
        except Exception as exc:
            traceback.print_exc()   # always visible on the console
            self._set_status(_("Error: {}").format(str(exc)), error=True)
            ErrorDialog(_("Error Loading File"), str(exc), parent=self.uistate.window)

    def _render(self, md_text):
        """Parse md_text and populate the TextBuffer segment by segment."""
        # Create a fresh buffer each time so the tag table is empty.
        # Reusing a buffer and calling create_tag() again raises
        # 'tag already exists' because the tag table persists across set_text().
        buf = Gtk.TextBuffer()
        self.textview.set_buffer(buf)

        self._tags = _define_tags(buf)

        # We need unique tags per link so each carries its own URI.
        # PyGObject does not expose GObject set_data/get_data, so we keep a
        # plain dict  self._link_uris  mapping tag-name -> uri.
        self._link_uris = {}
        link_counter = [0]

        def make_link_tag(style_tag_name, uri):
            link_counter[0] += 1
            name = '_link_{}'.format(link_counter[0])
            if style_tag_name == 'image_link':
                t = buf.create_tag(name,
                    foreground='#0077aa',
                    underline=Pango.Underline.SINGLE,
                    background='#eef4ff')
            elif style_tag_name == 'gramps_link':
                t = buf.create_tag(name,
                    foreground='#8800aa',
                    underline=Pango.Underline.SINGLE,
                    background='#f5eeff')
            else:
                t = buf.create_tag(name,
                    foreground='#0055cc',
                    underline=Pango.Underline.SINGLE)
            # Store (uri, style) tuple so _seg_tag_at can return both
            self._link_uris[name] = (uri, style_tag_name)
            return t

        segments = parse_markdown(md_text)
        it = buf.get_end_iter()

        for seg in segments:
            if seg.table_data:
                # ── embedded GTK TreeView table ───────────────────────────
                columns, align, body_rows = seg.table_data
                tbl_widget = _build_table_widget(columns, align, body_rows)
                anchor = buf.create_child_anchor(it)
                self.textview.add_child_at_anchor(tbl_widget, anchor)
                tbl_widget.show_all()

            elif seg.gramps_icon:
                # ── inline GTK/Gramps theme icon ──────────────────────────
                icon_name, size = seg.gramps_icon
                pb = _resolve_icon_pixbuf(icon_name, size)
                if pb:
                    buf.insert_pixbuf(it, pb)
                else:
                    # Fallback: show the icon name in italic grey
                    start_mark = buf.create_mark(None, it, True)
                    buf.insert(it, '[{}]'.format(icon_name))
                    start_it = buf.get_iter_at_mark(start_mark)
                    t = self._tags.get('blockquote')
                    if t:
                        buf.apply_tag(t, start_it, it)
                    buf.delete_mark(start_mark)

            elif seg.image_path:
                # ── embedded image or clickable placeholder ───────────────
                img_path = self._resolve_path(seg.image_path)
                inserted = False
                if os.path.isfile(img_path):
                    inserted = self._insert_image(buf, it, img_path, seg.text)
                if not inserted:
                    display = '[image: {}]'.format(seg.text or seg.image_path)
                    link_tag = make_link_tag('image_link', seg.image_path)
                    start_mark = buf.create_mark(None, it, True)
                    buf.insert(it, display)
                    start_it = buf.get_iter_at_mark(start_mark)
                    buf.apply_tag(link_tag, start_it, it)
                    buf.delete_mark(start_mark)

            elif seg.url:
                # ── clickable link (web, file, or gramps:) ────────────────
                if seg.url.startswith('gramps:'):
                    link_tag = make_link_tag('gramps_link', seg.url)
                else:
                    link_tag = make_link_tag('hyperlink', seg.url)
                start_mark = buf.create_mark(None, it, True)
                buf.insert(it, seg.text)
                start_it = buf.get_iter_at_mark(start_mark)
                buf.apply_tag(link_tag, start_it, it)
                buf.delete_mark(start_mark)

            else:
                # ── styled plain text ─────────────────────────────────────
                start_mark = buf.create_mark(None, it, True)
                buf.insert(it, seg.text)
                start_it = buf.get_iter_at_mark(start_mark)
                for attr in seg.attrs:
                    t = self._tags.get(attr)
                    if t:
                        buf.apply_tag(t, start_it, it)
                buf.delete_mark(start_mark)

            it = buf.get_end_iter()

    def _insert_image(self, buf, it, img_path, alt_text):
        """Insert a scaled pixbuf into buf at it.  Returns True on success."""
        try:
            # Load and scale to fit within the gramplet width
            MAX_W = 560
            pb = GdkPixbuf.Pixbuf.new_from_file(img_path)
            w, h = pb.get_width(), pb.get_height()
            if w > MAX_W:
                h = int(h * MAX_W / w)
                w = MAX_W
                pb = pb.scale_simple(w, h, GdkPixbuf.InterpType.BILINEAR)
            buf.insert_pixbuf(it, pb)
            # Caption line beneath image
            buf.insert(it, '\n')
            caption_tag = self._tags.get('blockquote')
            if alt_text and caption_tag:
                start_mark = buf.create_mark(None, it, True)
                buf.insert(it, alt_text + '\n')
                start_it = buf.get_iter_at_mark(start_mark)
                buf.apply_tag(caption_tag, start_it, it)
                buf.delete_mark(start_mark)
            return True
        except Exception:
            return False

    def main(self):
        pass
