#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2025  Phonetic Matching Gramplet contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Soundex encoder for the Fuzzy Matching Gramplet.

Wraps the existing, already-tested :func:`gramps.gen.soundex.soundex`
function rather than duplicating it, per Gramps' guidance to reuse
core engine code instead of reinventing it. See the :mod:`encoders`
package docstring for the contract this module implements, and for
this file as a template for adding another algorithm.
"""

# ------------------------
# Python modules
# ------------------------
import logging

# ------------------------
# Gramps modules
# ------------------------
from gramps.gen.soundex import soundex

LOG = logging.getLogger(__name__)

#: Registry key. See the contract in the :mod:`encoders` package
#: docstring for why this should be treated as stable once shipped.
ALGORITHM_ID = "soundex"

#: Display label shown in the gramplet's "Encoding system" dropdown.
ALGORITHM_LABEL = "Soundex"


def encode(name: str) -> set[str]:
    """
    Return the (single-element) Soundex code set for ``name``.

    :param name: The surname (or any word) to encode.
    :returns: A one-element set containing the four-character Soundex
        code, matching the value that
        :func:`gramps.gen.soundex.soundex` would return.
    """
    try:
        return {soundex(name)}
    except UnicodeEncodeError:
        LOG.debug("Soundex encoding failed for %r, falling back to empty", name)
        return {soundex("")}
