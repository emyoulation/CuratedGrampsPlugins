#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2025  Phonetic Matching Gramplet contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Phonetic encoder plugins for the Fuzzy Matching Gramplet.

Every module in this package is auto-discovered by :mod:`phonetic_codes`
(see ``phonetic_codes._discover_encoder_modules``/``_register_encoders``)
- adding a new phonetic algorithm means adding one new file here.
Nothing in ``phonetic_codes.py``, ``FuzzyMatchingGramplet.py``, or
anywhere else needs to change, so two contributors adding different
algorithms at the same time never touch the same line of the same
file.

A module in this package is treated as an encoder, and imported and
validated at startup, unless its own filename starts with an
underscore (for shared helper code an encoder imports but that is not
itself an encoder - e.g. ``_shared.py``). An encoder module must
define exactly:

* ``ALGORITHM_ID: str`` - a unique registry key (e.g. ``"soundex"``),
  used internally and as the value saved for the gramplet's
  "Encoding system" selection. Once shipped, treat this as stable:
  renaming it is the same as removing the old algorithm and adding a
  new one under a different id.
* ``ALGORITHM_LABEL: str`` - the display label shown in the gramplet's
  "Encoding system" dropdown (e.g. ``"Soundex"``).
* ``encode(name: str) -> set[str]`` - encodes one surname (or any
  word) to its phonetic code(s). Returns a *set*, not a single string,
  because some algorithms legitimately produce more than one valid
  code for a single spelling (Daitch-Mokotoff, for example). Must
  never raise: catch whatever inputs your algorithm can't handle
  (unusual Unicode, empty strings, etc.) and fall back to encoding an
  empty string, rather than letting one odd surname take down the
  background indexer partway through a large tree.

A module missing any of these, or reusing an ``ALGORITHM_ID`` an
earlier-discovered module already claimed, is logged and skipped
rather than aborting every other encoder along with it.

See ``soundex.py`` in this package for a minimal, complete example,
and ``FuzzyDev.md`` for a worked walkthrough of adding a new one,
including why Daitch-Mokotoff Soundex isn't included yet.
"""
