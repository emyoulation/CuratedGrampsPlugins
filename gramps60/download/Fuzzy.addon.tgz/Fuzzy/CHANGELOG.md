# Change Log - Fuzzy Matching gramplet 
[ReadMe](README.md) ● [Change Log](CHANGELOG.md) ● [adding Phonetic systems (for developers)](FuzzyDev.md)  

2026 09 08 - first 'experimental' release


