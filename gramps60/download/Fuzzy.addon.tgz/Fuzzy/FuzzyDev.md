# Developer Notes - Fuzzy Matching gramplet
[ReadMe](README.md) ● [Change Log](CHANGELOG.md) ● [adding Phonetic systems (for developers)](FuzzyDev.md)

# Preliminary! 
## Please do not use. Wait for the new approach. 
Switching to drop-in system rather than editing a fragile shared file.
(Estimated 12 Sep 2026)

This document is for anyone changing the code, not using the gramplet — see [README.md](README.md) for that. It covers how to add a new phonetic encoding system, the shape of the codebase and why a few parts of it look more careful than they might seem to need to be, and how to actually run the test suite.

## Adding an encoding system

The encoding-system list in the gramplet's UI is driven entirely by the registry in `phonetic_codes.py` — nothing in `FuzzyMatchingGramplet.py` needs to change to add one.

```python
# phonetic_codes.py
def my_algorithm_codes(name: str) -> set[str]:
    """Return the code(s) `name` encodes to under this algorithm."""
    return {my_algorithm(name)}

ALGORITHMS["my_algorithm"] = my_algorithm_codes
ALGORITHM_LABELS["my_algorithm"] = "My Algorithm"
```

A function in `ALGORITHMS` must:

* Accept a single string (a surname) and return a `set[str]` of codes. A set, not a single string, because some algorithms legitimately produce more than one valid code for one spelling.
* Never raise. `soundex_codes` catches `UnicodeEncodeError` and falls back to encoding an empty string rather than letting a single odd surname take down the background indexer partway through a large tree; a new algorithm should have an equivalent fallback for whatever inputs it can't handle.
* Be reasonably fast per call. It runs once per unique surname and, in the worst case, once per person in the tree (see "Two background indexing passes, not one" below) - not asymptotically expensive itself, but not a place to do anything like a database lookup either.

Add a matching test to `test/phonetic_codes_test.py`: at minimum, agreement with a reference implementation on a handful of names, and confirmation that known phonetic variants of a name (e.g. Smith/Smyth for Soundex) produce the same code.

### Soundex

Soundex (4-character "Russell", aka "NARA") is the phonetic encoding system bundled with Gramps (`gramps.gen.soundex.soundex`), and the only one this gramplet ships with. `phonetic_codes.soundex_codes` wraps it rather than reimplementing it.

### Daitch-Mokotoff Soundex (not included - a cautionary tale)

An implementation of Daitch-Mokotoff Soundex (useful for Slavic/Yiddish surname variants, since it's designed to produce the same code for spellings that plain Soundex treats as unrelated) was written for an earlier version of this gramplet and then dropped: it failed validation against the standard reference vectors (e.g. "Peters" should encode to `{"739400", "734000"}`, both codes, since Daitch-Mokotoff allows a name to have more than one valid encoding). If you pick this back up, validate against a full published reference table before wiring it into `ALGORITHMS` - the algorithm has enough edge cases (adjacent-letter combination rules, branching codes) that "looks right for a few test names" is not enough evidence it's correct.

## Two background indexing passes, not one

`FuzzyMatchingGramplet.main()` is a generator, run by the Gramplet framework's own `update()`/`GLib.idle_add` machinery rather than called directly, and it builds two separate lookups:

1. **code → surnames**, over the database's unique surname list (`db.get_surname_list()`).
2. **surname → person handles**, over every person in the tree (`db.get_person_handles()`), so clicking a surname in the Matches list can populate the person column from a plain dictionary lookup instead of a fresh scan.

Both stages yield periodically (`INDEX_CHUNK_SECONDS`, time-based rather than a fixed item count, since per-item cost varies) so a large tree can't freeze the interface. This two-stage split, and the chunking itself, exist because of a real, measured problem in an earlier version of this gramplet, not as precautionary engineering:

An earlier version populated the Surname field with a `Gtk.ComboBox` holding every unique surname via `gramps.gui.autocomp.fill_combo`. Attaching that many rows to a combo box's model turned out to be roughly quadratic in GTK itself:

| Unique surnames | `combo.set_model()` time |
|---|---|
| 5,000 | 0.25 s |
| 15,000 | 1.2 s |
| 30,000 | 5.3 s |
| 60,000 | 31.6 s |

...run synchronously, with no progress feedback - "Gramps freezes, with no indication anything is happening." The actual phonetic-code computation over the same 60,000 surnames takes about 0.2 seconds in pure Python; the combo box, not the indexing logic, was the bottleneck. The fix was to stop putting the full surname list into a GTK widget at all (see "Nearby surnames vs. browsing the whole tree" below), and separately, to run whatever indexing *is* needed through the Gramplet framework's background-generator hook so a future performance regression degrades gracefully instead of freezing the UI outright.

## Repopulating a `Gtk.ListStore` fires selection signals - even without `select_path()`

`cb_name_changed`, `cb_surname_selected`, and `_clear_matches` all wrap their `Gtk.ListStore.clear()`/repopulate calls in `_blocked_selection_handlers()`, which blocks the relevant `Gtk.TreeSelection`'s "changed" handler for the duration via GObject's own `handler_block`/`handler_unblock`. This isn't defensive boilerplate: clearing and refilling a `Gtk.ListStore` while its `Gtk.TreeView` has keyboard focus fires spurious `TreeSelection` "changed" signals on its own, independent of any real selection - confirmed directly against real, realized/focused GTK widgets, not assumed. Since selecting a row in the person column calls `DisplayState.set_active()` (see below), a spurious "changed" event there would silently and incorrectly change the active person as a side effect of the list merely being refreshed. If you add a new store that needs repopulating, wrap it the same way; a hand-rolled "is this a programmatic change" boolean flag checked inside the handler is not sufficient; GTK does not guarantee synchronous, single delivery in every code path, and a flag can be reset before a signal it should have suppressed actually arrives. `handler_block`/`handler_unblock` prevents the handler from being invoked at all, which does not depend on that timing.

## Active-person sync goes through Gramps' own signals, not a private tracker

`db_changed()` and `active_changed()` are the Gramplet framework's own hooks for "the database changed" / "the active person changed" - this gramplet does not poll or independently watch for either. In the other direction, `cb_person_selected` calls `DisplayState.set_active()`, Gramps' own active-object mechanism, rather than pushing state into some gramplet-local notion of "current person." Two things to know if you touch this code:

* `History.push()` (which `set_active()` calls into) re-emits Gramps' `active-changed` signal *unconditionally*, even when the handle given is already the active one. `cb_person_selected` therefore only calls `set_active()` when the clicked handle differs from `self.uistate.get_active("Person")`, to avoid a redundant emission.
* `_focus_active_person()` (called from `db_changed()`, `active_changed()`, and the end of `main()`) selects/scrolls to the active person's row purely as a *display* reaction to an already-happened change. It must never itself trigger another "active person changed" notification - that's what the handler-blocking above is protecting against specifically for this code path, and it's the direct fix for a real, reported `Signal recursion blocked... active-changed` warning from Gramps' own `gramps.gen.utils.callback.Callback.emit()`.

## Nearby surnames vs. browsing the whole tree

The Surname field's dropdown (`_refresh_nearby_combo`) never holds the full surname list - see the freeze story above. Instead it walks outward from the active person in three stages, the same shape as the published `DegreesOfSeparationHome` filter rule addon (rooted at the active person instead of the Home Person):

1. Walk upward from the active person, `NEARBY_DEGREES` generations, collecting ancestors.
2. From *each* ancestor found (including the active person), walk back downward the same number of generations, collecting descendants. Doing this from every ancestor, not just the active person, is what pulls in siblings, cousins, aunts and uncles - not just the direct line.
3. Add the partners/spouses of everyone collected.

This set is bounded by family structure, not tree size, so it stays cheap on a tree of any size. It's a convenience shortlist, not a way to reach everyone in the tree - that's what the "gtk-index" button beside the field is for, which opens `gramps.gui.selectors.SelectorFactory("Person")`, the standard Person selector, unmodified.

## Creating a filter from a match

Double-clicking a row in the Code(s) list (`cb_code_activated`) builds a `gramps.gen.filters.GenericFilter` using `gramps.gen.filters.rules.person.HasSoundexName` and opens it in `gramps.gui.editors.EditFilter`, mirroring the Clipboard module's own "Create a filter from the selected..." feature (`gramps.gui.makefilter.make_filter`) rather than reinventing that flow. `edit_filter_save` (also reused from `makefilter.py`) is passed as the dialog's own save callback, so the filter is written only if the user clicks OK in the dialog - never automatically.

**Known upstream issue, not caused by this code:** clicking "Edit" on the pre-filled rule (or on a rule in *any* filter, built by this gramplet or by hand) can log `Gtk-CRITICAL **: gtk_tree_model_filter_get_path: assertion 'GTK_TREE_MODEL_FILTER (model)->priv->stamp == iter->stamp' failed`. This traces to `EditRule.select_iter()` in `gramps/gui/editors/filtereditor.py`, which passes `Gtk.TreeStore` iterators to a `Gtk.TreeSelection` whose model is actually a `Gtk.TreeModelFilter` wrapping that store - a child/filter iterator mismatch, not anything specific to the `HasSoundexName` rule or to how this gramplet builds the filter. Confirmed reproducible with a manually-created filter too. Worth a Mantis BT report if one doesn't already exist; not fixable from an addon.

## Layout position is persisted via `ConfigManager`, in the addon's own folder

The Matches panel's divider position survives restarts via `gramps.gen.utils.configmanager.ConfigManager`, not a hand-rolled config file:

```python
CONFIG = global_config.register_manager("FuzzyMatchingGramplet", use_plugins_path=False)
```

`use_plugins_path=False` with no `override` makes `ConfigManager` use *the calling file's own directory* for the `.ini` (see the "Simple.ini" example in `register_manager`'s docstring) - this addon's own folder, alongside `FuzzyMatchingGramplet.py`, rather than Gramps' general per-user config directory. Reading/writing goes through the Gramplet framework's `on_load()`/`on_save()` lifecycle hooks, so the file is written at sensible points (e.g. closing Gramps), not on every pixel of a drag.

The `.ini`'s `[meta]` block (`plugin_id`, `schema_version`) identifies which addon the file belongs to, matching the convention used by this addon's sibling gramplets. It's registered with an empty placeholder default and then explicitly `.set()`, rather than registering the real value as the default directly: `ConfigManager.save()` comments out (`;;`) any key whose current value equals its own registered default, so registering the real identifying value as the default would leave `[meta]` permanently commented-out instead of recording it as a live identifier.

If you add a new persisted setting, register it the straightforward way (real default, no placeholder dance) unless you specifically need it to always appear uncommented regardless of whether it's been changed - that's a `[meta]`-block-specific need, not a general pattern.

## Running the tests

```bash
GRAMPS_RESOURCES=. python3 -m unittest discover -p "*_test.py"
```

Run from the addon's root directory. Two non-obvious things had to be gotten right here, both stemming from the same fact: a Gramps addon like this one is not an installed Python package, so neither Gramps' own plugin loader nor `unittest discover` treat it like one.

* **`test/__init__.py` must exist**, or `unittest discover` run this way silently reports "NO TESTS RAN" instead of an error - it doesn't find `test/` at all without it.
* **`test/phonetic_codes_test.py` cannot use a relative import** (`from .. import phonetic_codes`) to reach `phonetic_codes.py`. With `test/__init__.py` present, `test` becomes the top-level package when discovered this way, so `..` goes beyond it (`ImportError: attempted relative import beyond top-level package`). It instead inserts the addon root onto `sys.path` directly and imports `phonetic_codes` by its bare name - the same pattern `FuzzyMatchingGramplet.py` itself has to use to reach `phonetic_codes.py`, since Gramps' plugin loader (`gramps.gen.plug._manager.PluginManager.import_plugin`) imports a gramplet's main module as a bare top-level module after pushing the addon's own folder onto `sys.path`, not as part of a package - a package-relative import there fails with "attempted relative import with no known parent package" even though it looks correct.

If you add a new module to the addon that other modules need to import, give it the same bare-import treatment; a normal `from . import whatever` will work under some test runners and fail under Gramps' real plugin loader, or vice versa, depending on exactly how it's invoked.
