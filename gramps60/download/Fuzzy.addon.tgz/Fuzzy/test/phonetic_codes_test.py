#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2025  Phonetic Matching Gramplet contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Unit tests for :mod:`phonetic_codes`.

Tests for any one encoder's actual algorithm (e.g. Soundex) live next
to that encoder, in ``test/encoders/``, not here - this file covers
only the auto-discovery/registration machinery in ``phonetic_codes.py``
itself, which is shared by every encoder regardless of algorithm.
"""

# ------------------------
# Python modules
# ------------------------
import os
import sys
import types
import unittest

# ------------------------
# Gramps specific
# ------------------------
# Gramps addons are not installed packages, so "phonetic_codes" cannot
# be reached with a package-relative import here. See the note at the
# top of PhoneticMatchingGramplet.py/FuzzyMatchingGramplet.py for why;
# this inserts the addon root onto sys.path directly and imports
# phonetic_codes by its bare name, the same way Gramps' own plugin
# loader resolves sibling modules for the gramplet itself.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), os.pardir))

import phonetic_codes


def _make_encoder_module(algorithm_id, algorithm_label="Label", encode=None):
    """
    Build a minimal in-memory module satisfying (or, for negative
    tests, deliberately not satisfying) the encoder contract, so the
    registration logic can be tested without real files in
    ``encoders/``.

    :param algorithm_id: Value to set as ``ALGORITHM_ID``, or None to
        omit the attribute entirely.
    :param algorithm_label: Value to set as ``ALGORITHM_LABEL``.
    :param encode: Value to set as ``encode``, or None to omit the
        attribute entirely (not the same as an ``encode`` that returns
        None - use a lambda for that).
    :returns: The fake module.
    """
    module = types.ModuleType(f"encoders._fake_{id(object())}")
    if algorithm_id is not None:
        module.ALGORITHM_ID = algorithm_id
    module.ALGORITHM_LABEL = algorithm_label
    if encode is not None:
        module.encode = encode
    return module


# ------------------------------------------------------------
#
# AlgorithmRegistryTest
#
# ------------------------------------------------------------
class AlgorithmRegistryTest(unittest.TestCase):
    """Tests for the real, auto-discovered ALGORITHMS registry."""

    def test_soundex_was_discovered(self) -> None:
        """The bundled Soundex encoder must be found and registered."""
        self.assertIn("soundex", phonetic_codes.ALGORITHMS)

    def test_default_algorithm_is_registered(self) -> None:
        """The default algorithm id must exist in the registry."""
        self.assertIn(phonetic_codes.DEFAULT_ALGORITHM, phonetic_codes.ALGORITHMS)

    def test_every_algorithm_has_a_label(self) -> None:
        """Every registered algorithm must have a matching display label."""
        self.assertEqual(
            set(phonetic_codes.ALGORITHMS), set(phonetic_codes.ALGORITHM_LABELS)
        )

    def test_registered_algorithms_are_callable(self) -> None:
        """Every registered algorithm must accept a name and return a set."""
        for name, func in phonetic_codes.ALGORITHMS.items():
            with self.subTest(algorithm=name):
                result = func("Testname")
                self.assertIsInstance(result, set)
                self.assertTrue(result)


# ------------------------------------------------------------
#
# RegisterEncodersTest
#
# ------------------------------------------------------------
class RegisterEncodersTest(unittest.TestCase):
    """
    Tests for the discovery/registration mechanics in isolation, using
    fake in-memory modules - this is what makes it safe for one broken
    or half-finished encoder module to exist in ``encoders/`` without
    taking every other algorithm down with it.
    """

    def test_well_formed_module_is_registered(self) -> None:
        """A module satisfying the contract should be registered as-is."""
        module = _make_encoder_module("dummy", "Dummy", lambda n: {"X"})
        algorithms, labels = phonetic_codes._register_encoders([module])
        self.assertEqual(set(algorithms), {"dummy"})
        self.assertEqual(labels["dummy"], "Dummy")
        self.assertEqual(algorithms["dummy"]("anything"), {"X"})

    def test_module_missing_algorithm_id_is_skipped(self) -> None:
        """A module missing ALGORITHM_ID must be skipped, not raise."""
        module = _make_encoder_module(None, "Dummy", lambda n: {"X"})
        algorithms, labels = phonetic_codes._register_encoders([module])
        self.assertEqual(algorithms, {})
        self.assertEqual(labels, {})

    def test_module_missing_encode_is_skipped(self) -> None:
        """A module missing encode entirely must be skipped, not raise."""
        module = _make_encoder_module("dummy", "Dummy", encode=None)
        algorithms, labels = phonetic_codes._register_encoders([module])
        self.assertEqual(algorithms, {})
        self.assertEqual(labels, {})

    def test_module_with_non_callable_encode_is_skipped(self) -> None:
        """A module whose encode isn't callable must be skipped, not raise."""
        module = _make_encoder_module("dummy", "Dummy", encode="not callable")
        algorithms, labels = phonetic_codes._register_encoders([module])
        self.assertEqual(algorithms, {})
        self.assertEqual(labels, {})

    def test_duplicate_algorithm_id_keeps_first(self) -> None:
        """Two modules claiming the same id must not raise; the first wins."""
        first = _make_encoder_module("dupe", "First", lambda n: {"1"})
        second = _make_encoder_module("dupe", "Second", lambda n: {"2"})
        algorithms, labels = phonetic_codes._register_encoders([first, second])
        self.assertEqual(labels["dupe"], "First")
        self.assertEqual(algorithms["dupe"]("anything"), {"1"})

    def test_one_broken_module_does_not_affect_others(self) -> None:
        """A broken module among good ones should not prevent the rest."""
        broken = _make_encoder_module(None, "Broken")
        good = _make_encoder_module("good", "Good", lambda n: {"G"})
        algorithms, labels = phonetic_codes._register_encoders([broken, good])
        self.assertEqual(set(algorithms), {"good"})
        self.assertEqual(labels["good"], "Good")


# ------------------------------------------------------------
#
# ChooseDefaultTest
#
# ------------------------------------------------------------
class ChooseDefaultTest(unittest.TestCase):
    """Tests for :func:`phonetic_codes._choose_default`."""

    def test_prefers_the_preferred_default_when_present(self) -> None:
        """PREFERRED_DEFAULT_ALGORITHM should win if it was discovered."""
        preferred = phonetic_codes.PREFERRED_DEFAULT_ALGORITHM
        algorithms = {preferred: lambda n: set(), "zzz-other": lambda n: set()}
        self.assertEqual(phonetic_codes._choose_default(algorithms), preferred)

    def test_falls_back_to_first_sorted_id(self) -> None:
        """Without the preferred default, the first id (sorted) should win."""
        algorithms = {"zebra": lambda n: set(), "alpha": lambda n: set()}
        self.assertEqual(phonetic_codes._choose_default(algorithms), "alpha")

    def test_none_when_nothing_registered(self) -> None:
        """With no encoders at all, there is no default to choose."""
        self.assertIsNone(phonetic_codes._choose_default({}))


if __name__ == "__main__":
    unittest.main()
