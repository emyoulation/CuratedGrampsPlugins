#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2025  Phonetic Matching Gramplet contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Unit tests for :mod:`encoders.soundex`.

A new encoder module should have a test file here shaped like this
one: agreement with a reference implementation where one exists,
confirmation that known phonetic variants collide, confirmation that
clearly unrelated names don't, and confirmation the module declares
the contract documented in ``encoders/__init__.py``.
"""

# ------------------------
# Python modules
# ------------------------
import os
import sys
import unittest

# ------------------------
# Gramps specific
# ------------------------
# See the note in test/phonetic_codes_test.py: this addon is not an
# installed package, so "encoders" cannot be reached with a
# package-relative import from two directories down. This inserts the
# addon root (two levels up from test/encoders/) onto sys.path.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))

from encoders import soundex


# ------------------------------------------------------------
#
# SoundexEncodeTest
#
# ------------------------------------------------------------
class SoundexEncodeTest(unittest.TestCase):
    """Tests for :func:`encoders.soundex.encode`."""

    def test_matches_core_soundex(self) -> None:
        """encode should agree with gramps.gen.soundex.soundex."""
        from gramps.gen.soundex import soundex as core_soundex

        for name in ("Smith", "Schmidt", "Robert", "Müller", ""):
            with self.subTest(name=name):
                self.assertEqual(soundex.encode(name), {core_soundex(name)})

    def test_phonetic_variants_can_match(self) -> None:
        """Common spelling variants should share a Soundex code."""
        self.assertEqual(soundex.encode("Smith"), soundex.encode("Smyth"))

    def test_unrelated_names_differ(self) -> None:
        """Clearly unrelated surnames should not collide."""
        self.assertNotEqual(soundex.encode("Anderson"), soundex.encode("Zimmerman"))

    def test_empty_name_is_handled(self) -> None:
        """An empty name must not raise and returns a well-formed code."""
        codes = soundex.encode("")
        self.assertEqual(len(codes), 1)
        self.assertEqual(len(next(iter(codes))), 4)


# ------------------------------------------------------------
#
# SoundexContractTest
#
# ------------------------------------------------------------
class SoundexContractTest(unittest.TestCase):
    """Confirms the module declares the encoder contract correctly."""

    def test_algorithm_id(self) -> None:
        """ALGORITHM_ID must be the stable registry key for this encoder."""
        self.assertEqual(soundex.ALGORITHM_ID, "soundex")

    def test_algorithm_label_is_a_string(self) -> None:
        """ALGORITHM_LABEL must be a display-ready string."""
        self.assertIsInstance(soundex.ALGORITHM_LABEL, str)
        self.assertTrue(soundex.ALGORITHM_LABEL)

    def test_encode_is_callable(self) -> None:
        """encode must be callable, per the encoder contract."""
        self.assertTrue(callable(soundex.encode))


if __name__ == "__main__":
    unittest.main()
