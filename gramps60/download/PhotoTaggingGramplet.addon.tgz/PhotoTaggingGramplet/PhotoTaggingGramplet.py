#
# Gramps - a GTK+/GNOME based genealogy program
# http://gramps-project.org
# Gramplet registration - plug-in/add-on to extend Gramps
#
# Copyright (C) 2013    Artem Glebov <artem.glebov@gmail.com>
# Copyright (C) 2014    Nick Hall
# Copyright (C) 2021    Paul Culley
# Copyright (C) 2021    Bruce Jackson
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

# $Id: $

# -------------------------------------------------------------------------
#
# Standard python modules
#
# -------------------------------------------------------------------------
import sys
import os
import pickle
import logging
from urllib.parse import quote
import cairo

LOG = logging.getLogger(".PhotoTaggingGramplet")

# -------------------------------------------------------------------------
#
# GTK/Gnome modules
#
# -------------------------------------------------------------------------
from gi.repository import Gio
from gi.repository import Gtk
from gi.repository import Gdk
from gi.repository import GdkPixbuf
from gi.repository import GLib
from gi.repository import GObject

import gi

repository = gi.Repository.get_default()
v_array = repository.enumerate_versions("GExiv2")
if not v_array:
    raise ValueError("GExiv2 is not installed")
gi.require_version("GExiv2", v_array[-1])
from gi.repository import GExiv2

# -------------------------------------------------------------------------
#
# gramps modules
#
# -------------------------------------------------------------------------
from gramps.gen.utils.db import get_birth_or_fallback, get_death_or_fallback
from gramps.gen.utils.file import media_path_full
from gramps.gen.errors import WindowActiveError
from gramps.gen.config import config
from gramps.gen.db import DbTxn
from gramps.gen.display.name import displayer as name_displayer
from gramps.gen.datehandler import displayer as date_displayer
from gramps.gen.plug import Gramplet, MenuOptions, PluginRegister
from gramps.gen.lib import (
    Attribute,
    MediaRef,
    Name,
    Note,
    NoteType,
    Person,
    StyledText,
    StyledTextTag,
    StyledTextTagType,
)
from gramps.gen.lib.date import Today
from gramps.gui.dialog import OkDialog
from gramps.gui.editors import EditNote, EditObject
from gramps.gui.editors.editperson import EditPerson
from gramps.gui.selectors import SelectorFactory
from gramps.gen.plug.menu import BooleanOption, NumberOption
from gramps.gui.plug import PluginWindows
from gramps.gui.pluginmanager import GuiPluginManager
from gramps.gui.widgets import SelectionWidget, Region
from gramps.gui.widgets.styledtexteditor import StyledTextEditor
from gramps.gui.ddtargets import DdTargets

from gramps.gen.const import GRAMPS_LOCALE as glocale

try:
    _ = glocale.get_addon_translator(__file__).sgettext
except ValueError:
    _ = glocale.translation.sgettext

# -------------------------------------------------------------------------
#
# face detection module
#
# -------------------------------------------------------------------------
sys.path.append(os.path.abspath(os.path.dirname(__file__)))
import facedetection

# -------------------------------------------------------------------------
#
# configuration
#
# -------------------------------------------------------------------------

GRAMPLET_CONFIG_NAME = "phototagginggramplet"
CONFIG = config.register_manager(GRAMPLET_CONFIG_NAME)
CONFIG.register("detection.box_size", (50, 50))
CONFIG.register("detection.inside_existing_boxes", False)
CONFIG.register("detection.sensitivity", 10)
CONFIG.register("selection.replace_without_asking", False)
CONFIG.load()
CONFIG.save()

MIN_FACE_SIZE = CONFIG.get("detection.box_size")
REPLACE_WITHOUT_ASKING = CONFIG.get("selection.replace_without_asking")
DETECT_INSIDE_EXISTING_BOXES = CONFIG.get("detection.inside_existing_boxes")
SENSITIVITY = CONFIG.get("detection.sensitivity")

# This addon's own registered id (see PhotoTaggingGramplet.gpr.py), used to
# look up its own PluginData (README path, help_url) when the Help button
# is clicked.
MY_PLUGIN_ID = "Photo Tagging"

# Markdown Dash's registered id (see that addon's own .gpr.py, if
# installed) -- its local README.md viewer is preferred, when available,
# over opening the wiki page below.
#
# NOTE: this assumes Markdown Dash is a registered addon. If/when
# MarkdownUtils/Markdown Dash are folded into Gramps core (discussed for
# 6.2/7.0), PluginRegister will no longer have this id at all, and
# resolve_markdown_dash_opener() will *silently* fall back to help_url
# forever, mistaking "now built in" for "not installed" -- not a crash,
# but a quiet loss of the in-app README viewer. Whoever does that merge
# should replace this addon-id lookup with however the core module is
# actually detected/imported at that point.
MARKDOWNDASH_ID = "markdowndash"

# Drag-and-drop target used to reorder rows within the region list itself.
# The value only needs to be unique; the source/destination match is done
# by comparing the id() of the gramplet, the same technique used by
# gramps.gui.editors.displaytabs.embeddedlist.EmbeddedList.
REORDER_TARGET_NAME = "PHOTOTAGGING_REGION_ROW"
REORDER_ATOM = Gdk.atom_intern(REORDER_TARGET_NAME, False)

# The 3 states cycled through by the "show ID" toolbar button.
ID_MODE_ROW = "row"
ID_MODE_GRAMPS = "gramps"
ID_MODE_HIDDEN = "hidden"
ID_MODE_ORDER = [ID_MODE_ROW, ID_MODE_GRAMPS, ID_MODE_HIDDEN]

# Gramps has no built-in notion of "these people's display order within
# this photo", so the manual order set via drag-and-drop or the Move
# Up/Down buttons is persisted as a single custom Attribute on the
# Media object itself (the photo) -- the standard way for an addon to
# attach its own data to a Gramps object without changing the database
# schema. Without this, the order only survived in memory for the life
# of the gramplet instance, and was lost as soon as the photo was
# reloaded (switching away and back, or restarting Gramps).
#
# The attribute's value is a small human-readable table, one line per
# tagged region, "row, Gramps ID" -- 1-based rows matching the list's
# own row numbers, and a Gramps ID (e.g. "I1123") rather than a handle
# since a person is expected to be able to read (and, deliberately,
# hand-edit) it:
#
#   1, I1123
#   2, I0106
#   3, I1010
ORDER_ATTR_TYPE = "PhotoTagging Order"

# Single translatable string per task, reused for the context menu item,
# toolbar tooltip, and (for LINK_PERSON_TEXT) the Person selector dialog
# title, rather than three subtly different phrases for the same action.
LINK_PERSON_TEXT = _("Link")
ADD_NEW_PERSON_TEXT = _("Add a new person")
CLEAR_REFERENCE_TEXT = _("Clear Reference")

# The "Caption" Note type used by the Show/Hide Caption toolbar button
# and panel (see refresh_caption()) is a custom NoteType -- Gramps has
# no built-in NoteType for this -- identified purely by this string,
# the same way ORDER_ATTR_TYPE above identifies this addon's own
# custom Attribute type. Not wrapped in _() since it is stored in the
# database as literal text (via NoteType((NoteType.CUSTOM,
# CAPTION_NOTE_TYPE_STRING))) and must match consistently regardless
# of the active display language, matching ORDER_ATTR_TYPE's own
# reasoning.
CAPTION_NOTE_TYPE_STRING = "Caption"

# Prefix used by every "gramps://" object link this addon builds into
# Note text (see NoteTextBuilder.add_link() callers) and the one
# prefix CaptionTextEditor recognizes when handling a click -- kept as
# a single constant rather than repeating the literal string, so a
# link built here and a link parsed there can't silently drift apart.
GRAMPS_URL_PREFIX = "gramps://"

# Background color CaptionTextEditor.highlight_person() applies to a
# Person's linked text in the Caption panel, to match their selected
# row/marquee elsewhere in the gramplet (see
# PhotoTaggingGramplet.apply_selected_region()) -- a soft highlighter
# yellow, chosen (rather than reusing MARQUEE_BLUE elsewhere in this
# file, which is a foreground/outline color, not a fill) to read
# clearly as a text background against both light and dark Gramps
# themes.
CAPTION_HIGHLIGHT_BACKGROUND = "#fff3a0"


def get_media_order_attribute(media):
    for attr in media.get_attribute_list():
        if str(attr.get_type()) == ORDER_ATTR_TYPE:
            return attr
    return None


def find_caption_note(media, db) -> Note | None:
    """
    Return the first Caption-type :class:`~gramps.gen.lib.note.Note`
    attached to `media` (in its own note list order), or ``None`` if
    it has none -- used to decide whether the Show/Hide Caption
    toolbar button should be dimmed and, when it isn't, what to
    render in the Caption panel (see
    ``PhotoTaggingGramplet.refresh_caption()``).

    :param media: The Media object to look for a Caption Note on, or
        ``None`` (e.g. no active Media), in which case ``None`` is
        returned.
    :param db: The database to look up Note handles in.
    :returns: The first Caption-type Note, or ``None``.
    """
    if media is None:
        return None
    for note_handle in media.get_note_list():
        note = db.get_note_from_handle(note_handle)
        if note is not None and str(note.get_type()) == CAPTION_NOTE_TYPE_STRING:
            return note
    return None


def parse_region_order_text(text, db):
    """
    Parses the "row, Gramps ID" table stored in a Media object's
    PhotoTagging Order attribute into {person_handle: row}.

    Returns (order_by_handle, ok). Since a person can hand-edit this
    attribute (it is a normal, visible Attribute) and mangle it, ok is
    False whenever the text is structurally invalid -- the caller
    should then discard it and persist a fresh, valid table reflecting
    the current natural order, rather than crash or let the corrupt
    text linger unfixed. A blank/absent attribute, or a row that names
    a Gramps ID with no matching person (e.g. that person was since
    deleted), is not treated as corruption -- those rows are simply
    skipped.
    """
    order_by_handle = {}
    if not text or not text.strip():
        return order_by_handle, True
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(",", 1)
        if len(parts) != 2:
            return {}, False
        row_text, gramps_id = parts[0].strip(), parts[1].strip()
        if not gramps_id:
            return {}, False
        try:
            row = int(row_text)
        except ValueError:
            return {}, False
        person = db.get_person_from_gramps_id(gramps_id)
        if person is not None:
            order_by_handle[person.get_handle()] = row
    return order_by_handle, True


def serialize_region_order(regions):
    """
    Builds the "row, Gramps ID" table for the current region order, one
    line per tagged region, using the same 1-based row numbers shown in
    the list.
    """
    lines = []
    for index, region in enumerate(regions, start=1):
        if region.person is not None:
            gramps_id = region.person.get_gramps_id()
            if gramps_id:
                lines.append("%d, %s" % (index, gramps_id))
    return "\n".join(lines)


def save_config():
    CONFIG.set("detection.box_size", MIN_FACE_SIZE)
    CONFIG.set("detection.inside_existing_boxes", DETECT_INSIDE_EXISTING_BOXES)
    CONFIG.set("detection.sensitivity", SENSITIVITY)
    CONFIG.set("selection.replace_without_asking", REPLACE_WITHOUT_ASKING)
    CONFIG.save()


# -------------------------------------------------------------------------
#
# Help button (see HelpDocButton.md)
#
# -------------------------------------------------------------------------


def find_local_readme(pdata):
    """
    Return the path to pdata's own README.md, or None if pdata has no
    on-disk folder or that folder has no README.md.
    """
    if pdata is None or not pdata.fpath:
        return None
    readme_path = os.path.join(pdata.fpath, "README.md")
    return readme_path if os.path.isfile(readme_path) else None


def resolve_markdown_dash_opener():
    """
    Return Markdown Dash's open_markdown_file() function, or None if
    Markdown Dash is not registered, fails to load, or does not (yet)
    provide that function -- each a distinct failure mode collapsed to
    None since every caller does the same thing either way: fall back
    to opening help_url in the browser instead.
    """
    gpm = GuiPluginManager.get_instance()
    if MARKDOWNDASH_ID in gpm.get_hidden_plugin_ids():
        return None
    pdata = PluginRegister.get_instance().get_plugin(MARKDOWNDASH_ID)
    if pdata is None or not pdata.fpath:
        return None
    mod = gpm.load_plugin(pdata)
    if not mod:
        return None
    return getattr(mod, "open_markdown_file", None)


def open_help_url(pdata, parent):
    """
    Open pdata's registered help_url in the desktop's default browser.
    A bare wiki page title is resolved against gramps-project.org and
    percent-encoded; a full http(s):// URL is used as-is.
    """
    help_url = getattr(pdata, "help_url", None)
    if not help_url:
        OkDialog(
            _("No documentation available"),
            _("This plugin has neither a README.md nor a registered " "help_url."),
            parent=parent,
        )
        return
    if help_url.startswith(("http://", "https://")):
        full_url = help_url
    else:
        full_url = "https://gramps-project.org/wiki/index.php?title=" + quote(
            help_url, safe=":"
        )
    try:
        Gio.AppInfo.launch_default_for_uri(full_url, None)
    except GLib.Error:
        LOG.exception("PhotoTaggingGramplet: could not open help_url: %s", full_url)


# -------------------------------------------------------------------------
#
# Gramplet Options
#
# -------------------------------------------------------------------------

THUMBNAIL_IMAGE_SIZE = (50, 50)

# Initial fraction of the left pane's height given to the image/
# marquee Preview area, the rest going to the Caption panel below it
# -- see build_gui()'s left_pane and cb_left_pane_size_allocate().
CAPTION_SPLIT_INITIAL_RATIO = 0.75

# Same blue gramps.gui.widgets.SelectionWidget._draw_region_frame() uses
# for its outer marquee border, so the Row/Gramps ID label drawn inside
# the box (see _draw_region_id()) matches it.
MARQUEE_BLUE = (0.0, 0.0, 1.0)

# The toolbar buttons live in a plain Gtk.HBox rather than a Gtk.Toolbar.
# Gtk.ToolButton silently re-resolves a stock/icon-name icon to its own
# ambient icon size when realized (24px by default outside of a real
# Gtk.Toolbar), discarding whatever size the icon was originally built
# at -- confirmed by testing set_icon_widget() with a
# Gtk.Image.new_from_stock()/new_from_icon_name() image explicitly built
# at a larger size, which still rendered at 24px. A concrete Gtk.Image
# built from a Pixbuf is not subject to that renegotiation, so icons are
# loaded to an explicit pixel size via the icon theme and wrapped as a
# plain pixbuf image instead.
TOOLBAR_ICON_PX = 32


def load_toolbar_icon(icon_name, size=TOOLBAR_ICON_PX):
    """
    Loads a themed icon as a concrete Pixbuf at an explicit pixel size,
    or None if the current icon theme has no such icon.
    """
    theme = Gtk.IconTheme.get_default()
    try:
        return theme.load_icon(icon_name, size, Gtk.IconLookupFlags.FORCE_SIZE)
    except GLib.GError:
        return None


def set_toolbar_icon(button, icon_names, size=TOOLBAR_ICON_PX):
    """
    Tries each name in icon_names (a string, or a list of fallback
    names in priority order) and uses the first one available in the
    current icon theme, loaded at an explicit pixel size. Leaves the
    button's current icon untouched if none of the names are available.
    """
    if isinstance(icon_names, str):
        icon_names = [icon_names]
    for name in icon_names:
        pixbuf = load_toolbar_icon(name, size)
        if pixbuf is not None:
            image = Gtk.Image.new_from_pixbuf(pixbuf)
            button.set_icon_widget(image)
            image.show()
            return True
    return False


def get_xmp_tag_string(metadata, key: str) -> str | None:
    """
    Read a single tag as a string, without depending on
    Metadata.get() -- a convenience method only provided by the
    optional Python override module (gi/overrides/GExiv2.py), which
    some GExiv2 packages/builds don't ship, in which case Metadata is
    the plain, override-less GObject-Introspection class and has no
    .get() at all (only its native methods, has_tag()/get_tag_string()
    among them, which this reimplements the same fallback-to-None
    behaviour on top of).

    :param metadata: An opened ``GExiv2.Metadata`` instance.
    :param key: Fully-qualified tag name, e.g. ``"Xmp.dc.subject"``.
    :returns: The tag's string value, or ``None`` if it isn't set.
    """
    try:
        if metadata.has_tag(key):
            return metadata.get_tag_string(key)
    except Exception:  # pylint: disable=broad-except
        LOG.exception("PhotoTagging: could not read tag %s", key)
    return None


def load_bundled_icon(
    icon_filename: str, size: int = TOOLBAR_ICON_PX
) -> GdkPixbuf.Pixbuf | None:
    """
    Load an SVG icon bundled with this addon as a concrete Pixbuf at an
    explicit pixel size.

    Bundled icons live under ``media/icons/`` next to this module, so
    the addon does not depend on names that may or may not exist in
    the user's current system icon theme.

    :param icon_filename: File name of the bundled icon, for example
        ``"gtk-index.svg"``.
    :param size: Target width/height in pixels.
    :returns: A ``GdkPixbuf.Pixbuf``, or ``None`` if the file is
        missing or unreadable.
    """
    addon_dir = os.path.dirname(__file__)
    icon_path = os.path.join(addon_dir, "media", "icons", icon_filename)
    try:
        return GdkPixbuf.Pixbuf.new_from_file_at_size(icon_path, size, size)
    except GLib.GError:
        return None


def set_bundled_toolbar_icon(
    button,
    icon_filename: str,
    fallback_names: list[str] | None = None,
    size: int = TOOLBAR_ICON_PX,
) -> bool:
    """
    Set a toolbar button's icon from a bundled SVG file under
    ``media/icons/``, falling back to themed icon names if the bundled
    file can't be loaded, so a broken or incomplete install still gets
    some icon rather than a blank button.

    :param button: The ``Gtk.ToolButton`` to set the icon on.
    :param icon_filename: File name of the bundled icon, for example
        ``"gtk-index.svg"``.
    :param fallback_names: Themed icon names to try, in priority
        order, if the bundled file can't be loaded.
    :param size: Target width/height in pixels.
    :returns: ``True`` if an icon was set on the button, ``False``
        otherwise.
    """
    pixbuf = load_bundled_icon(icon_filename, size)
    if pixbuf is not None:
        image = Gtk.Image.new_from_pixbuf(pixbuf)
        button.set_icon_widget(image)
        image.show()
        return True
    if fallback_names:
        return set_toolbar_icon(button, fallback_names, size)
    return False


class NoteTextBuilder:
    """
    Incrementally builds the plain text and styling spans for a
    Note's StyledText, tracking character offsets as each piece of
    text is appended -- one StyledTextTag(tag_type, value,
    [(start, end)]) per styled span (link or bold). PedigreeBreadcrumbs.py
    builds its link tags using the bare string "link" instead of the
    real StyledTextTagType.LINK enum value; that string form did not
    actually produce clickable links when tested live, hence always
    using the real enum constants here instead.

    Used by transcribe_list_to_note_clicked() to assemble a multi-line
    Note with a mix of plain, bold, and Gramps-object-linked text.
    """

    def __init__(self):
        self.text = ""
        self._tags = []  # list of (StyledTextTagType, value, start, end)

    def add_text(self, text):
        """Append plain, unstyled text (no trailing newline)."""
        self.text += text

    def add_styled(self, text, tag_type, value=None):
        """Append text and record a styling tag range over exactly it."""
        start = len(self.text)
        self.text += text
        self._tags.append((tag_type, value, start, len(self.text)))

    def add_link(self, text, url):
        """Append text and record a link tag range over exactly it."""
        self.add_styled(text, StyledTextTagType.LINK, url)

    def add_bold(self, text):
        """Append text and record a bold tag range over exactly it."""
        self.add_styled(text, StyledTextTagType.BOLD, True)

    def add_line(self, text=""):
        """Append plain text followed by a newline."""
        self.text += text + "\n"

    def add_linked_line(self, text, url):
        """Append a link-tagged line: link range covers just `text`."""
        self.add_link(text, url)
        self.text += "\n"

    def add_bold_line(self, text):
        """Append a bold-tagged line: bold range covers just `text`."""
        self.add_bold(text)
        self.text += "\n"

    def add_blank_lines(self, count=1):
        self.text += "\n" * count

    def build_styled_text(self):
        """
        :returns: A StyledText combining all appended text with one
            StyledTextTag per add_styled()/add_link()/add_bold() call
            (and their *_line() equivalents).
        """
        tags = [
            StyledTextTag(tag_type, value, [(start, end)])
            for tag_type, value, start, end in self._tags
        ]
        return StyledText(self.text, tags)


# ------------------------------------------------------------
#
# CaptionTextEditor
#
# ------------------------------------------------------------
class CaptionTextEditor(StyledTextEditor):
    """
    Read-only :class:`StyledTextEditor` used to render the Caption
    Note's content in the Caption panel (see
    ``PhotoTaggingGramplet.refresh_caption()``), changing how a click
    there behaves:

    - A plain (non-Ctrl) single left click on a Person link selects
      that person's row in the region list (see
      ``select_person_in_list()``) if they are tagged in this photo,
      and does nothing at all otherwise (any other link, or a Person
      not tagged here).
    - A plain single left click anywhere else (not on a link) is
      unchanged from the base class -- normal cursor placement/text
      selection.
    - A plain double click on *any* link additionally opens it for
      editing -- the same effect the base class's own Ctrl+click
      already has -- so double-clicking a Person link both selects
      their row and opens Edit Person.
    - A plain double click on unlinked space opens the Note editor
      for this Caption Note itself (see ``edit_caption_note()``),
      instead of the base class's own default of selecting the word
      under the pointer.
    - Ctrl+click is left entirely to the base class's own handling.

    This overrides on_button_press_event() itself, rather than
    merely adding a second handler alongside the base class's own
    (which was tried first): StyledTextEditor._connect_signals()
    connects it by looking up ``self.on_button_press_event`` at
    __init__ time, so Python's normal method resolution routes that
    straight here for a CaptionTextEditor instance, without needing
    a second, separately-connected handler racing it. That matters
    because the base handler's own Ctrl+click test --
    ``event.get_state() and Gdk.ModifierType.CONTROL_MASK``, an
    ``and`` where a bitwise ``&`` was surely intended -- treats *any*
    nonzero modifier state (e.g. NumLock simply being on) as if Ctrl
    were held, so merely adding a second handler left the base
    class's own "open link" action *also* firing on a plain single
    click alongside this one; fully replacing it, rather than only
    supplementing it, is what actually prevents that.
    """

    def __init__(self, gramplet: "PhotoTaggingGramplet") -> None:
        """
        :param gramplet: The owning PhotoTaggingGramplet, whose
            ``select_person_in_list()``, ``edit_caption_note()``,
            ``dbstate``, ``uistate``, and ``track`` this uses to
            react to a click.
        """
        self._gramplet = gramplet
        StyledTextEditor.__init__(self)
        # Created once and reused for the life of this editor: tags
        # stay registered in a Gtk.TextBuffer's tag table across
        # set_text() replacing its actual content (see
        # highlight_person()'s own docstring), so this never needs
        # recreating on refresh.
        self._highlight_tag = self.textbuffer.create_tag(
            "caption-person-highlight", background=CAPTION_HIGHLIGHT_BACKGROUND
        )

    def highlight_person(self, person_handle: str | None) -> None:
        """
        Highlights every occurrence, in the currently displayed text,
        of a ``gramps://Person/handle/<person_handle>`` link, clearing
        any previous highlight first -- so a Person's linked text
        lights up together with their row/marquee selection (see
        PhotoTaggingGramplet.apply_selected_region()). A person can
        be linked more than once in the same Note (e.g. once in the
        title area, once in the name list); every occurrence is
        highlighted, not just the first.

        Must be re-called (see
        PhotoTaggingGramplet.refresh_caption()/sync_caption_highlight())
        any time set_text() replaces this editor's content outright,
        since that deletes the old text -- and with it, every
        previously highlighted range -- even though the tag itself
        (created once, in __init__) remains registered and does not
        need recreating.

        :param person_handle: Handle of the Person to highlight, or
            ``None`` to only clear the existing highlight.
        """
        start, end = self.textbuffer.get_bounds()
        self.textbuffer.remove_tag(self._highlight_tag, start, end)
        if not person_handle:
            return
        target_url = "%sPerson/handle/%s" % (GRAMPS_URL_PREFIX, person_handle)
        pos = self.textbuffer.get_start_iter()
        while not pos.is_end():
            next_pos = pos.copy()
            advanced = next_pos.forward_to_tag_toggle(None)
            if not advanced:
                next_pos = self.textbuffer.get_end_iter()
            for tag in pos.get_tags():
                name = tag.get_property("name") or ""
                if name.startswith("link") and getattr(tag, "data", None) == target_url:
                    self.textbuffer.apply_tag(self._highlight_tag, pos, next_pos)
                    break
            if not advanced:
                break
            pos = next_pos

    def on_button_press_event(
        self, widget: Gtk.TextView, event: Gdk.EventButton
    ) -> bool:
        """
        Overrides StyledTextEditor.on_button_press_event() -- see the
        class docstring for why overriding, rather than connecting a
        second handler, is what's needed here.

        :param widget: This editor (unused; provided by the signal).
        :param event: The Gdk.EventButton for the click.
        :returns: ``True`` if a plain click was handled here (either
            on a link, or a double click on unlinked space --
            consuming the event either way, so it doesn't also start
            or extend a text selection), otherwise whatever the base
            class's own handling of the same event returns.
        """
        if event.button == 1 and not event.get_state() & Gdk.ModifierType.CONTROL_MASK:
            # Gdk.EventType._2BUTTON_PRESS is GDK's own real, public
            # enum member -- its name simply can't start with a
            # digit, hence the leading underscore, which pylint
            # otherwise mistakes for a protected-access violation.
            is_double_click = (
                event.type == Gdk.EventType._2BUTTON_PRESS
            )  # pylint: disable=protected-access
            link = self._link_at_event(event)
            if link is not None:
                obj_class, prop, value = link
                if obj_class == "Person" and prop == "handle":
                    self._gramplet.select_person_in_list(value)
                if is_double_click:
                    EditObject(
                        self._gramplet.dbstate,
                        self._gramplet.uistate,
                        self._gramplet.track,
                        obj_class,
                        prop,
                        value,
                    )
                return True
            if is_double_click:
                self._gramplet.edit_caption_note()
                return True
        return StyledTextEditor.on_button_press_event(self, widget, event)

    def _link_at_event(self, event: Gdk.EventButton) -> tuple[str, str, str] | None:
        """
        Return the ``(obj_class, prop, value)`` parsed out of the
        ``gramps://`` link tag under `event`'s position, or ``None``
        if it isn't over such a link -- mirroring how the base
        class's own on_motion_notify_event() recognizes a LinkTag, by
        name prefix, and its own _open_url_cb() parses the link's
        three '/'-separated parts.
        """
        buffer_x, buffer_y = self.window_to_buffer_coords(
            Gtk.TextWindowType.WIDGET, int(event.x), int(event.y)
        )
        # PyGObject versions differ on whether this out-parameter
        # method returns a plain Gtk.TextIter or a (found, iter)
        # tuple -- accept either rather than depending on one.
        result = self.get_iter_at_location(buffer_x, buffer_y)
        if isinstance(result, tuple):
            found, text_iter = result[0], result[-1]
            if not found:
                return None
        else:
            text_iter = result
        for tag in text_iter.get_tags():
            name = tag.get_property("name") or ""
            if not name.startswith("link"):
                continue
            url = getattr(tag, "data", None)
            if not url or not url.startswith(GRAMPS_URL_PREFIX):
                continue
            try:
                obj_class, prop, value = url[len(GRAMPS_URL_PREFIX) :].split("/")
            except ValueError:
                continue
            return obj_class, prop, value
        return None


class PhotoTaggingOptions(MenuOptions):

    def __init__(self):
        MenuOptions.__init__(self)

    def add_menu_options(self, menu):
        category_name = _("Selection")
        self.replace_without_asking = BooleanOption(
            _(
                "Replace existing references to the person "
                "being assigned without asking"
            ),
            REPLACE_WITHOUT_ASKING,
        )

        menu.add_option(
            category_name, "replace_without_asking", self.replace_without_asking
        )

        category_name = _("Face detection")
        width, height = MIN_FACE_SIZE
        sensitivity = SENSITIVITY
        self.min_face_width = NumberOption(
            _("Minimum face width (px)"), width, 1, 1000, 1
        )
        self.min_face_height = NumberOption(
            _("Minimum face height (px)"), height, 1, 1000, 1
        )
        self.detect_inside_existing_boxes = BooleanOption(
            _("Detect faces inside existing marquees"), DETECT_INSIDE_EXISTING_BOXES
        )
        self.sensitivity = NumberOption(
            _("Sensitivity (1 min .. 20 max)"), sensitivity, 1, 20, 1
        )

        menu.add_option(category_name, "min_face_width", self.min_face_width)
        menu.add_option(category_name, "min_face_height", self.min_face_height)
        menu.add_option(category_name, "sensitivity", self.sensitivity)
        menu.add_option(
            category_name,
            "detect_inside_existing_boxes",
            self.detect_inside_existing_boxes,
        )

    def update_settings(self):
        global REPLACE_WITHOUT_ASKING
        global DETECT_INSIDE_EXISTING_BOXES
        global MIN_FACE_SIZE
        global SENSITIVITY
        REPLACE_WITHOUT_ASKING = self.replace_without_asking.get_value()
        DETECT_INSIDE_EXISTING_BOXES = self.detect_inside_existing_boxes.get_value()
        width = self.min_face_width.get_value()
        height = self.min_face_height.get_value()
        MIN_FACE_SIZE = (width, height)
        SENSITIVITY = self.sensitivity.get_value()
        save_config()


# -------------------------------------------------------------------------
#
# Settings Dialog
#
# -------------------------------------------------------------------------


class SettingsDialog(PluginWindows.ToolManagedWindowBase):

    def __init__(self, dbstate, uistate, title, options):
        self.dbstate = dbstate
        self.uistate = uistate
        self.title = title
        self.options = options

        PluginWindows.ToolManagedWindowBase.__init__(
            self, dbstate, uistate, None, "SettingsDialog"
        )

        self.ok.set_label(_("_OK"))

    def get_title(self):
        return self.title

    def on_ok_clicked(self, obj):
        self.options.update_settings()
        self.close()


# -------------------------------------------------------------------------
#
# Photo Tagging Gramplet
#
# -------------------------------------------------------------------------


class PhotoTaggingGramplet(Gramplet):
    def init(self):
        self.regions = []
        self.marquees_visible = True
        self.metadata_clues_visible = True
        self.id_display_mode = ID_MODE_ROW

        # Whether the Caption panel should be shown when a Caption
        # Note exists -- a plain user-facing toggle, like
        # marquees_visible/metadata_clues_visible above, except its
        # *initial* value additionally needs the current Media's own
        # Caption-Note status (see refresh_caption()), so it starts
        # True here and is set to reflect that before the panel is
        # ever first shown, in the first refresh_caption() call from
        # main().
        self.caption_panel_visible = True
        # Whether the current Media object has a Caption Note at all
        # -- refreshed by refresh_caption(); drives the toolbar
        # button's dimmed appearance and whether the panel can be
        # shown regardless of caption_panel_visible above.
        self.caption_note_exists = False
        # GLib.get_monotonic_time() timestamp of the previous click on
        # the Caption toolbar button, used by cb_caption_button_toggled()
        # to recognize a double-click.
        self._caption_last_toggle_us = 0

        # Current Preview:Caption height split of left_pane (see
        # build_gui()), as a fraction of its total height -- starts
        # at CAPTION_SPLIT_INITIAL_RATIO, then tracks wherever the
        # person last dragged the handle to (see
        # cb_left_pane_position_changed()), so a later resize of the
        # containing window/dock (cb_left_pane_size_allocate())
        # preserves that, rather than resetting to the initial split
        # every time.
        self._caption_split_ratio = CAPTION_SPLIT_INITIAL_RATIO
        # left_pane's own total allocated height as of the last time
        # cb_left_pane_size_allocate() acted on it, or None before
        # the first one -- lets that handler tell an actual resize
        # (height changed) apart from any other size-allocate.
        self._left_pane_last_height = None
        # True while cb_left_pane_size_allocate() itself is moving
        # the handle to reapply _caption_split_ratio, so
        # cb_left_pane_position_changed() can tell that apart from
        # the person actually dragging it (see that method).
        self._caption_split_ratio_lock = False

        # True while apply_selected_region() is itself moving the
        # treeview's cursor, so a re-entrant cursor_changed() call
        # (set_cursor() below can trigger one synchronously) knows to
        # do nothing rather than calling straight back into
        # apply_selected_region() again.
        self._syncing_selection = False
        # The handle of the Media object currently reflected in
        # self.regions, and whether self.regions' order has changed in
        # memory since it was last read from (or written to) that
        # object's PhotoTagging Order attribute. Reading/writing that
        # attribute only happens on entering/leaving a Media object
        # (see main() and flush_region_order()), not on every move --
        # there's no reason to hit the database while the order is
        # just being rearranged in memory during a session.
        self._loaded_media_handle = None
        self._order_dirty = False

        # Whichever Gtk.Window currently hosts this gramplet, tracked so
        # we can catch that window's maximize/unmaximize events -- see
        # on_hierarchy_changed()/on_toplevel_window_state_event().
        self._toplevel = None
        self._toplevel_handler_id = None

        self.age_precision = config.get("preferences.age-display-precision")

        self.build_context_menu()

        self.gui.WIDGET = self.build_gui()
        self.gui.get_container_widget().remove(self.gui.textview)
        self.gui.get_container_widget().add(self.gui.WIDGET)
        self.top.show_all()

    def on_save(self):
        self.flush_region_order()
        CONFIG.save()

    # ======================================================
    # building the GUI
    # ======================================================

    def build_gui(self):
        """
        Build the GUI interface.
        """
        self.top = Gtk.VBox()

        hpaned = Gtk.HPaned()
        self.hpaned = hpaned

        button_panel = Gtk.HBox()

        self.button_index = Gtk.ToolButton(stock_id=Gtk.STOCK_INDEX)
        self.button_add = Gtk.ToolButton(stock_id=Gtk.STOCK_ADD)
        self.button_del = Gtk.ToolButton(stock_id=Gtk.STOCK_REMOVE)
        self.button_clear = Gtk.ToolButton(stock_id=Gtk.STOCK_CLEAR)
        self.button_edit = Gtk.ToolButton(stock_id=Gtk.STOCK_EDIT)
        self.button_move_up = Gtk.ToolButton(stock_id=Gtk.STOCK_GO_UP)
        self.button_move_down = Gtk.ToolButton(stock_id=Gtk.STOCK_GO_DOWN)
        self.button_zoom_in = Gtk.ToolButton(stock_id=Gtk.STOCK_ZOOM_IN)
        self.button_zoom_out = Gtk.ToolButton(stock_id=Gtk.STOCK_ZOOM_OUT)
        self.button_settings = Gtk.ToolButton(stock_id=Gtk.STOCK_PREFERENCES)
        self.button_help = Gtk.ToolButton(stock_id=Gtk.STOCK_HELP)
        # Buttons whose icon is one of a small handful of names that are
        # reasonably common across system icon themes.
        for button, icon_names in (
            (self.button_clear, ["edit-clear", Gtk.STOCK_CLEAR]),
            (self.button_settings, ["preferences-system", Gtk.STOCK_PREFERENCES]),
            (self.button_help, ["help-browser", "help-contents", Gtk.STOCK_HELP]),
        ):
            set_toolbar_icon(button, icon_names)

        # Buttons whose icon is bundled with this addon under
        # media/icons/, since the desired artwork is not reliably
        # available (or not visually distinct enough) in system icon
        # themes. Each still falls back to a themed name if the
        # bundled file is missing, so the toolbar degrades gracefully
        # rather than showing a blank button.
        for button, icon_filename, fallback_names in (
            (
                self.button_index,
                "gtk-index.svg",
                [
                    "color-select-symbolic",
                    "edit-find",
                    "system-search",
                    Gtk.STOCK_INDEX,
                ],
            ),
            (self.button_add, "List-add.svg", ["list-add", Gtk.STOCK_ADD]),
            (self.button_del, "List-remove.svg", ["list-remove", Gtk.STOCK_REMOVE]),
            (self.button_edit, "gtk-edit.svg", ["document-edit", Gtk.STOCK_EDIT]),
            (
                self.button_move_up,
                "Gnome-view-sort-ascending.svg",
                ["go-up", Gtk.STOCK_GO_UP],
            ),
            (
                self.button_move_down,
                "Gnome-view-sort-descending.svg",
                ["go-down", Gtk.STOCK_GO_DOWN],
            ),
            (self.button_zoom_in, "gramps-zoom-in.svg", ["zoom-in", Gtk.STOCK_ZOOM_IN]),
            (
                self.button_zoom_out,
                "gramps-zoom-out.svg",
                ["zoom-out", Gtk.STOCK_ZOOM_OUT],
            ),
        ):
            set_bundled_toolbar_icon(button, icon_filename, fallback_names)

        # set custom icon for face detect button
        self.button_detect = Gtk.ToolButton()
        set_bundled_toolbar_icon(
            self.button_detect,
            "gramps-face-detection.svg",
            ["edit-find", "system-search", Gtk.STOCK_FIND],
        )

        # marquee visibility is a 2-state toggle; the ID button cycles
        # through 3 states (Row ID / Gramps ID / hidden) on each click
        self.button_marquees = Gtk.ToggleToolButton()
        self.button_show_ids = Gtk.ToolButton()

        # Shows/hides the "Metadata clues" column. Like button_marquees
        # above (and for the same reason: a pressed/highlighted toggle
        # button should indicate the non-default, "hidden" state, not
        # the default, "data visible" one), active means "hidden" --
        # the inverse of self.metadata_clues_visible.
        self.button_metadata_clues = Gtk.ToggleToolButton()
        set_bundled_toolbar_icon(
            self.button_metadata_clues,
            "XMP_logo.svg",
            ["dialog-information-symbolic", Gtk.STOCK_INFO],
        )
        self.button_metadata_clues.set_active(not self.metadata_clues_visible)
        self.update_metadata_clues_button()

        # Shows/hides the Caption panel (see refresh_caption()).
        # Active likewise means "hidden", matching button_marquees/
        # button_metadata_clues above. Always left sensitive (never
        # set_sensitive(False)) even when there is no Caption Note to
        # show -- an insensitive Gtk widget stops receiving button
        # events entirely, which would also swallow the double-click
        # that is supposed to still work in that state (see
        # cb_caption_button_toggled()); set_caption_button_dimmed()
        # gives it a dimmed appearance instead, purely cosmetically.
        self.button_caption = Gtk.ToggleToolButton()
        set_bundled_toolbar_icon(
            self.button_caption,
            "ClosedCaption.svg",
            ["media-view-subtitles-symbolic", "insert-text", Gtk.STOCK_JUSTIFY_LEFT],
        )
        self.button_caption.set_active(not self.caption_panel_visible)
        self.update_caption_button()

        self.button_index.connect("clicked", self.sel_person_clicked)
        self.button_add.connect("clicked", self.add_person_clicked)
        self.button_del.connect("clicked", self.clear_ref_clicked)
        self.button_clear.connect("clicked", self.del_region_clicked)
        self.button_edit.connect("clicked", self.edit_person_clicked)
        self.button_move_up.connect("clicked", self.move_up_clicked)
        self.button_move_down.connect("clicked", self.move_down_clicked)
        self.button_zoom_in.connect("clicked", self.zoom_in_clicked)
        self.button_zoom_out.connect("clicked", self.zoom_out_clicked)
        self.button_detect.connect("clicked", self.detect_faces_clicked)
        self.button_settings.connect("clicked", self.settings_clicked)
        self.button_help.connect("clicked", self.on_help_clicked)
        self.button_marquees.connect("toggled", self.marquees_toggled)
        self.button_show_ids.connect("clicked", self.show_ids_clicked)
        self.button_metadata_clues.connect("toggled", self.metadata_clues_toggled)
        self.button_caption.connect("toggled", self.cb_caption_button_toggled)

        button_panel.pack_start(
            self.button_marquees, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_show_ids, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_caption, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_metadata_clues, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(self.button_index, expand=False, fill=False, padding=5)
        button_panel.pack_start(self.button_add, expand=False, fill=False, padding=5)
        button_panel.pack_start(self.button_del, expand=False, fill=False, padding=5)
        button_panel.pack_start(self.button_clear, expand=False, fill=False, padding=5)
        button_panel.pack_start(self.button_edit, expand=False, fill=False, padding=5)
        button_panel.pack_start(
            self.button_move_up, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_move_down, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_zoom_in, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_zoom_out, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(self.button_detect, expand=False, fill=False, padding=5)
        button_panel.pack_start(
            self.button_settings, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(self.button_help, expand=False, fill=False, padding=5)

        self.button_index.set_tooltip_text(LINK_PERSON_TEXT)
        self.button_add.set_tooltip_text(ADD_NEW_PERSON_TEXT)
        self.button_del.set_tooltip_text(CLEAR_REFERENCE_TEXT)
        self.button_clear.set_tooltip_text(_("Remove Selection"))
        self.button_edit.set_tooltip_text(_("Edit referenced Person"))
        self.button_move_up.set_tooltip_text(_("Move Up"))
        self.button_move_down.set_tooltip_text(_("Move Down"))
        self.button_zoom_in.set_tooltip_text(_("Zoom In"))
        self.button_zoom_out.set_tooltip_text(_("Zoom Out"))

        # active means "hidden"/"showing", the opposite of the default
        self.button_marquees.set_active(not self.marquees_visible)
        self.update_marquees_button()
        self.update_show_ids_button()

        if facedetection.computer_vision_available:
            text = _("Detect faces")
        else:
            text = _("Detect faces (OpenCV module required)")
        self.button_detect.set_tooltip_text(text)

        self.button_settings.set_tooltip_text(_("Settings"))
        self.button_help.set_tooltip_text(_("Help"))

        self.top.pack_start(button_panel, expand=False, fill=True, padding=5)

        self.selection_widget = SelectionWidget()
        self.selection_widget.set_size_request(200, -1)
        self.selection_widget.connect("region-modified", self.region_modified)
        self.selection_widget.connect("region-created", self.region_created)
        self.selection_widget.connect("region-selected", self.region_selected)
        self.selection_widget.connect("selection-cleared", self.selection_cleared)
        self.selection_widget.connect("right-button-clicked", self.right_button_clicked)
        self.selection_widget.connect("zoomed-in", self.zoomed)
        self.selection_widget.connect("zoomed-out", self.zoomed)

        # Draws the person's Gramps ID over each region frame, on top of
        # whatever gramps.gui.widgets.SelectionWidget has already drawn for
        # the same "draw" event (connect_after runs after its own handler,
        # which is itself connected via connect_after in the widget's
        # __init__, so ours always paints last).
        self.selection_widget.image.connect_after("draw", self.draw_ids_overlay)

        # Can drop a PERSON here:
        tglist = Gtk.TargetList.new([])
        tglist.add(
            DdTargets.PERSON_LINK.atom_drag_type,
            DdTargets.PERSON_LINK.target_flags,
            DdTargets.PERSON_LINK.app_id,
        )
        # Can drop a LIST of HANDLES here:
        tglist.add(
            DdTargets.HANDLE_LIST.atom_drag_type,
            DdTargets.HANDLE_LIST.target_flags,
            DdTargets.HANDLE_LIST.app_id,
        )

        # Drag and Drop for selection widget:
        self.selection_widget.event_box.drag_dest_set(
            Gtk.DestDefaults.MOTION | Gtk.DestDefaults.DROP, [], Gdk.DragAction.COPY
        )
        self.selection_widget.event_box.drag_dest_set_target_list(tglist)
        self.selection_widget.event_box.connect(
            "drag_data_received",
            lambda *args: self.drag_data_received(*args, on_image=True),
        )
        # End Drag and Drop for selection widget

        # The Caption panel (see refresh_caption()) sits below the
        # image/marquee Preview area, both stacked in a VPaned (a
        # draggable divider, so the person can resize the split by
        # hand) forming the HPaned's own left pane -- rather than,
        # say, the right pane alongside the region list -- since it
        # renders the *photo's* caption, not anything about an
        # individual tagged region.
        self.left_pane = Gtk.VPaned()

        self.caption_scrolled_window = Gtk.ScrolledWindow()
        self.caption_scrolled_window.set_policy(
            Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC
        )

        self.caption_editor = CaptionTextEditor(self)
        self.caption_editor.set_editable(False)
        self.caption_editor.set_wrap_mode(Gtk.WrapMode.WORD)
        self.caption_editor.set_left_margin(6)
        self.caption_editor.set_right_margin(6)
        self.caption_scrolled_window.add(self.caption_editor)

        self.left_pane.pack1(self.selection_widget, resize=True, shrink=False)
        self.left_pane.pack2(self.caption_scrolled_window, resize=True, shrink=False)

        # Both panes are marked resize=True above (rather than, say,
        # holding the Caption panel to a fixed pixel height) since
        # the two handlers below take over positioning the divider
        # themselves on every resize, as a fraction of left_pane's
        # own total height (starting at CAPTION_SPLIT_INITIAL_RATIO)
        # -- native Gtk.Paned has no percentage-split notion of its
        # own, only ever remembering an absolute pixel offset.
        self.left_pane.connect("size-allocate", self.cb_left_pane_size_allocate)
        self.left_pane.connect("notify::position", self.cb_left_pane_position_changed)

        hpaned.pack1(self.left_pane, resize=True, shrink=False)

        # Columns: row number, preview thumbnail, combined Person+Age

        # (Pango markup -- see refresh_list()), Metadata clues text.
        # The separate boolean "suspicious age" flag column that used
        # to drive column4's foreground-set is gone: since Person and
        # Age are now one cell, the red highlight is baked directly
        # into the markup string built in refresh_list() instead.
        self.treestore = Gtk.TreeStore(int, GdkPixbuf.Pixbuf, str, str)

        self.treeview = Gtk.TreeView(model=self.treestore)
        self.treeview.set_size_request(400, -1)
        self.treeview.connect("cursor-changed", self.cursor_changed)
        self.treeview.connect("row-activated", self.row_activated)
        self.treeview.connect("button-press-event", self.row_mouse_click)
        column1 = Gtk.TreeViewColumn(title="")
        column2 = Gtk.TreeViewColumn(title=_("Preview"))
        column3 = Gtk.TreeViewColumn()
        column4 = Gtk.TreeViewColumn(title=_("Metadata clues"))
        self.column_metadata_clues = column4
        self.treeview.append_column(column1)
        self.treeview.append_column(column2)
        self.treeview.append_column(column3)
        self.treeview.append_column(column4)

        # column3's header is "Person" / "    Age on <date>" on two
        # lines (see format_person_age_header() / refresh_list()),
        # which needs a real widget rather than set_title()'s
        # single-line text.
        self.column_person_age_header = Gtk.Label()
        self.column_person_age_header.set_xalign(0)
        self.column_person_age_header.set_justify(Gtk.Justification.LEFT)
        self.column_person_age_header.show()
        column3.set_widget(self.column_person_age_header)

        cell1 = Gtk.CellRendererText()
        cell2 = Gtk.CellRendererPixbuf()
        cell3 = Gtk.CellRendererText()
        cell4 = Gtk.CellRendererText()
        column1.pack_start(cell1, expand=True)
        column1.add_attribute(cell1, "text", 0)
        column2.pack_start(cell2, expand=True)
        column2.add_attribute(cell2, "pixbuf", 1)
        column3.pack_start(cell3, expand=True)
        column3.add_attribute(cell3, "markup", 2)
        column3.set_resizable(True)
        column3.set_reorderable(True)
        column3.set_min_width(20)
        column4.pack_start(cell4, expand=False)
        column4.add_attribute(cell4, "text", 3)
        column4.set_resizable(True)
        column4.set_reorderable(True)
        column4.set_min_width(20)

        self.apply_alternating_row_shading(
            (column1, cell1), (column2, cell2), (column3, cell3), (column4, cell4)
        )

        self.treeview.set_search_column(0)
        # Columns are intentionally not made sortable-by-click: the row
        # order is the manual order the user sets via drag-and-drop or the
        # Move Up/Down buttons, and must always match self.regions.

        # Drag and Drop for tree view: accepts dropped people (same as the
        # image), plus its own rows dragged onto itself to reorder them.
        # NOTE: deliberately NOT calling self.treeview.set_reorderable(True)
        # here (it was previously enabled purely for the cosmetic native
        # drop-position indicator). Field testing showed a single physical
        # drag producing TWO full drag_data_get/drag_data_received cycles:
        # the first one performed the intended move correctly, and a second
        # one immediately followed, re-picking-up the just-moved row (now
        # re-selected by region_order_changed()) and re-dropping it using
        # the first drop's now-stale coordinates -- typically shoving it to
        # the end. That double-fire is consistent with set_reorderable()
        # additionally activating Gtk.TreeView's own internal row-drag
        # handling alongside our manual REORDER_ATOM-based handling below.
        # The manual handling alone (as in
        # gramps.gui.editors.displaytabs.embeddedlist.EmbeddedList, though
        # that class uses enable_model_drag_source/dest rather than the
        # plain drag_source_set/drag_dest_set used here, since this
        # treeview also needs to accept external Person drops) is
        # sufficient; the native indicator is not worth the double-fire.

        tree_tglist = Gtk.TargetList.new([])
        tree_tglist.add(
            DdTargets.PERSON_LINK.atom_drag_type,
            DdTargets.PERSON_LINK.target_flags,
            DdTargets.PERSON_LINK.app_id,
        )
        tree_tglist.add(
            DdTargets.HANDLE_LIST.atom_drag_type,
            DdTargets.HANDLE_LIST.target_flags,
            DdTargets.HANDLE_LIST.app_id,
        )
        tree_tglist.add(REORDER_ATOM, Gtk.TargetFlags.SAME_WIDGET, 0)

        self.treeview.drag_dest_set(
            Gtk.DestDefaults.MOTION | Gtk.DestDefaults.DROP,
            [],
            Gdk.DragAction.COPY | Gdk.DragAction.MOVE,
        )
        self.treeview.drag_dest_set_target_list(tree_tglist)
        self.treeview.connect("drag_data_received", self.drag_data_received)
        self.treeview.drag_source_set(
            Gdk.ModifierType.BUTTON1_MASK,
            [Gtk.TargetEntry.new(REORDER_TARGET_NAME, Gtk.TargetFlags.SAME_WIDGET, 0)],
            Gdk.DragAction.MOVE,
        )
        self.treeview.connect("drag_data_get", self.treeview_drag_data_get)
        # End Drag and Drop for tree_view

        scrolled_window2 = Gtk.ScrolledWindow()
        scrolled_window2.add(self.treeview)
        scrolled_window2.set_size_request(400, -1)
        scrolled_window2.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)

        hpaned.pack2(scrolled_window2, resize=False, shrink=False)

        self.top.pack_start(hpaned, True, True, 5)

        self.enable_buttons()

        self.top.connect("key-press-event", self.on_key_press_event)
        self.top.connect("hierarchy-changed", self.on_hierarchy_changed)

        return self.top

    def on_hierarchy_changed(self, widget, previous_toplevel):
        """
        Tracks whichever Gtk.Window currently hosts this gramplet (it
        moves between windows when undocked into its own dialog, or
        docked back into the main Gramps window), keeping a
        window-state-event handler connected to it -- see
        on_toplevel_window_state_event() for why.
        """
        toplevel = self.top.get_toplevel()
        if toplevel is self._toplevel:
            return
        if self._toplevel is not None and self._toplevel_handler_id:
            self._toplevel.disconnect(self._toplevel_handler_id)
        self._toplevel = None
        self._toplevel_handler_id = None
        if isinstance(toplevel, Gtk.Window):
            self._toplevel = toplevel
            self._toplevel_handler_id = toplevel.connect(
                "window-state-event", self.on_toplevel_window_state_event
            )

    def on_toplevel_window_state_event(self, window, event):
        """
        Works around SelectionWidget drawing the image (and hence the
        marquees) offset by a fixed amount after this gramplet's host
        window is maximized or unmaximized -- reported as ~20px to the
        left, not corrected until the HPaned divider between the image
        and the list is manually moved.

        SelectionWidget._resize() only recomputes its scale/offset when
        its own allocated size differs from the size it last saw, and
        manually dragging the HPaned divider "fixes" it only because
        that eventually changes the SelectionWidget's allocated width,
        forcing that check to see a difference and recompute. This
        schedules the same kind of nudge programmatically -- see
        nudge_selection_widget_layout() for why it is delayed and
        forces the recompute rather than relying on a lucky pixel
        difference.
        """
        if event.changed_mask & Gdk.WindowState.MAXIMIZED:
            GLib.timeout_add(150, self.nudge_selection_widget_layout)

    def nudge_selection_widget_layout(self):
        """
        Forces SelectionWidget to rescale its image to the (by now
        settled) real window size.

        Two things beyond a plain divider nudge turned out to matter:

        - Firing right on the window-state-event was too early -- a
          window-manager-driven maximize can still be settling its
          final geometry at that point, so a nudge done immediately
          could itself get rescaled against a transitional, not-yet-
          final size (the reported symptom: the ID/marquee overlay,
          which recomputes from the live widget size on every draw,
          ends up correct, but SelectionWidget's own cached image
          does not, leaving it offset with a spurious scrollbar until
          some unrelated event -- e.g. hovering the scrollbar --
          happens to trigger yet another size-allocate). Delaying via
          the timeout in on_toplevel_window_state_event() gives the
          resize time to finish first, mirroring the delay inherent
          in the user doing this by hand.
        - SelectionWidget.old_viewport_size (the "size it last saw")
          is reset to an impossible (0, 0) value first, so the
          size-allocate the divider nudge triggers is guaranteed to
          be treated as a real change and force a genuine rescale of
          the displayed image against whatever the current real
          allocation is -- rather than depending on the nudge's exact
          pixel delta happening to differ from a value that may itself
          already be stale.
        """
        if self.selection_widget.old_viewport_size is not None:
            self.selection_widget.old_viewport_size = Gdk.Rectangle()

        position = self.hpaned.get_position()
        self.hpaned.set_position(position + 1)
        GLib.idle_add(self._restore_hpaned_position, position)
        return False

    def _restore_hpaned_position(self, position):
        if self.selection_widget.old_viewport_size is not None:
            self.selection_widget.old_viewport_size = Gdk.Rectangle()
        self.hpaned.set_position(position)
        return False

    def on_key_press_event(self, widget, event):
        """
        Alt+Up / Alt+Down move the selected region up/down in the list,
        wherever the keyboard focus currently is within the gramplet.
        (Ctrl+Up/Down is already used elsewhere to move an indicator, not
        the selection, so Alt is used here instead.)
        """
        alt = bool(event.get_state() & Gdk.ModifierType.MOD1_MASK)
        if alt and event.keyval == Gdk.KEY_Up:
            self.move_up_clicked(None)
            return True
        if alt and event.keyval == Gdk.KEY_Down:
            self.move_down_clicked(None)
            return True
        return False

    def on_help_clicked(self, widget):
        """
        Show the closest documentation available for this addon: its own
        local README.md via Markdown Dash when available, else its
        registered help_url in the default browser (see HelpDocButton.md).
        """
        pdata = PluginRegister.get_instance().get_plugin(MY_PLUGIN_ID)
        readme_path = find_local_readme(pdata)
        if readme_path is not None:
            open_markdown_file = resolve_markdown_dash_opener()
            if open_markdown_file is not None:
                open_markdown_file(
                    readme_path,
                    self.uistate,
                    parent=self.uistate.window,
                    addon_name=pdata.name,
                )
                return
        open_help_url(pdata, self.uistate.window)

    def drag_data_received(
        self, widget, context, x, y, sel_data, info, time, on_image=None
    ):
        """
        Receive a dropped person onto the treeview.
        """
        if sel_data:
            if not on_image and sel_data.get_data_type() == REORDER_ATOM:
                self.reorder_drag_received(sel_data, x, y)
                return
            pickled_data = sel_data.get_data()
            if not pickled_data:
                return
            data = pickle.loads(pickled_data)
            # Perhaps allow multiple person drops
            # Sometimes, more than one person could be in a selected area
            people = []
            # Just get the first one for now:, if a list:
            if sel_data.get_data_type() == DdTargets.HANDLE_LIST.atom_drag_type:
                if data[0][0] == "Person":
                    handle = data[0][1]
                    person = self.dbstate.db.get_person_from_handle(handle)
                    if person:
                        people.append(person)
                elif data[0][0] == "Event":
                    # get first, primary person of event:
                    event_handle = data[0][1]
                    event = self.dbstate.db.get_event_from_handle(event_handle)
                    for obj_class, handle in event.get_referenced_handles():
                        if obj_class == "Person":
                            person = self.dbstate.db.get_person_from_handle(handle)
                            if person:
                                people.append(person)
                                break
            elif sel_data.get_data_type() == DdTargets.PERSON_LINK.atom_drag_type:
                drag_type, idval, handle, val = data
                person = self.dbstate.db.get_person_from_handle(handle)
                if person:
                    people.append(person)
            else:  # other formats work like this:
                handle = None
                try:
                    drag_type, idval, handle, val = data
                except:
                    pass
                if handle:
                    person = self.dbstate.db.get_person_from_handle(handle)
                    if person:
                        people.append(person)
                else:
                    LOG.warn(
                        "Can't handle this type of drop: '%s'"
                        % sel_data.get_data_type()
                    )
                    return
            for person in people:
                if on_image:  # drop on image
                    region = self.selection_widget.find_region(x, y)
                    current = self.selection_widget.get_current()
                    if region and (current is None or current == region):
                        self.ask_and_set_person(region, person)
                        self.selection_widget.clear_selection()
                        self.refresh()
                        self.enable_buttons()
                else:  # drop on list
                    drop_info = self.treeview.get_dest_row_at_pos(x, y)
                    if drop_info:
                        # path, position = drop_info
                        # self.treeview.set_cursor(path)
                        self.set_current_person(person)
                        self.selection_widget.clear_selection()
                        self.refresh()
                        self.enable_buttons()

    def build_context_menu(self):
        self.context_menu = Gtk.Menu()
        self.context_menu.set_reserve_toggle_size(False)

        self.context_button_details = Gtk.MenuItem.new_with_mnemonic(
            _("_See the person details")
        )
        self.context_button_details.connect("activate", self.edit_person_clicked)

        self.context_button_active = Gtk.MenuItem.new_with_mnemonic(
            _("Make the person active")
        )
        self.context_button_active.connect("activate", self.set_active_person)

        self.context_button_select = Gtk.MenuItem.new_with_mnemonic(
            "_" + LINK_PERSON_TEXT
        )
        self.context_button_select.connect("activate", self.sel_person_clicked)

        self.context_button_add = Gtk.MenuItem.new_with_mnemonic(
            "_" + ADD_NEW_PERSON_TEXT
        )
        self.context_button_add.connect("activate", self.add_person_clicked)

        self.context_button_clear = Gtk.MenuItem.new_with_mnemonic(
            "_" + CLEAR_REFERENCE_TEXT
        )
        self.context_button_clear.connect("activate", self.clear_ref_clicked)

        self.context_button_remove = Gtk.MenuItem.new_with_mnemonic(_("_Remove"))
        self.context_button_remove.connect("activate", self.del_region_clicked)

        self.context_button_move_up = Gtk.MenuItem.new_with_mnemonic(_("Move _Up"))
        self.context_button_move_up.connect("activate", self.move_up_clicked)

        self.context_button_move_down = Gtk.MenuItem.new_with_mnemonic(_("Move _Down"))
        self.context_button_move_down.connect("activate", self.move_down_clicked)

        self.context_button_transcribe = Gtk.MenuItem.new_with_mnemonic(
            _("_Transcribe list to a Note")
        )
        self.context_button_transcribe.connect(
            "activate", self.transcribe_list_to_note_clicked
        )

        self.context_menu.append(self.context_button_details)
        self.context_menu.append(self.context_button_active)
        self.context_menu.append(self.context_button_select)
        self.context_menu.append(self.context_button_add)
        self.context_menu.append(self.context_button_clear)
        self.context_menu.append(self.context_button_remove)
        self.context_menu.append(self.context_button_move_up)
        self.context_menu.append(self.context_button_move_down)
        self.context_menu.append(Gtk.SeparatorMenuItem())
        self.context_menu.append(self.context_button_transcribe)

        self.additional_items = []

    def refresh(self):
        self.selection_widget.refresh()
        self.refresh_list()
        self.refresh_selection()

    # ======================================================
    # gramplet event handlers
    # ======================================================

    def db_changed(self):
        self.connect(self.dbstate.db, "media-update", self.update)
        self.connect(self.dbstate.db, "person-update", self.update)
        self.connect(self.dbstate.db, "person-delete", self.update)
        # A Caption Note can be added, edited, or removed from
        # elsewhere in Gramps (e.g. the Media editor's own Notes tab)
        # without that necessarily also touching the Media object
        # itself, so the Caption panel/button need their own refresh
        # hook on Note signals -- not just the "media-update" above --
        # to reliably reflect that (see refresh_caption()).
        self.connect(self.dbstate.db, "note-add", self.cb_note_changed)
        self.connect(self.dbstate.db, "note-update", self.cb_note_changed)
        self.connect(self.dbstate.db, "note-delete", self.cb_note_changed)
        self.connect_signal("Media", self.update)

    def main(self):
        media = self.get_current_object()
        self.top.hide()
        is_image = media is not None and media.mime.startswith("image")
        new_handle = media.get_handle() if media else None
        if new_handle != self._loaded_media_handle:
            # Entering a different Media object (or leaving to no
            # active media): flush any unsaved order for the one being
            # left, then load the new one fresh, including reading its
            # stored order. A refresh triggered for some other reason
            # (e.g. a commit from resizing a marquee) while still on
            # the same object leaves self.regions as they already are.
            self.flush_region_order()
            self._loaded_media_handle = new_handle
            if is_image:
                self.load_image(media)
            else:
                self.regions = []
                self.sync_selection_widget_regions()
        if not is_image:
            self.selection_widget.show_missing()
        self.refresh_list()
        self.refresh_caption()
        self.enable_buttons()
        self.top.show()
        # refresh_list() just cleared and rebuilt the treeview's
        # model, which drops its row selection entirely (self.regions
        # itself is untouched here, so refresh_selection() restores
        # it to the same region as before -- self.selection_widget's
        # own current-region state, unlike the treeview's, isn't tied
        # to that model and so survives the rebuild). Without this,
        # a refresh triggered by, say, clicking OK in the editor
        # opened by double-clicking a row -- which re-enters here via
        # the resulting db signal -- left the list with no selection
        # restored.
        #
        # Deliberately called only now, after self.top.show() above
        # (and even then via GLib.idle_add, not directly), rather
        # than right after refresh_list() like region_modified()/
        # region_created() below do: this whole gramplet is hidden
        # via self.top.hide() at the very top of this method, and
        # Gtk.TreeView.set_cursor() -- which apply_selected_region()
        # uses to restore the selection -- does not reliably take
        # effect on a widget that isn't realized/mapped, which it
        # isn't while still hidden here. GLib.idle_add defers it past
        # the coming show(), so the row's own geometry has settled by
        # the time set_cursor()/scroll_to_selected_row() run, the same
        # reasoning scroll_to_selected_row() itself already relies on.
        GLib.idle_add(self.refresh_selection)

    def cb_note_changed(self, *args) -> None:
        """
        Callback for the "note-add"/"note-update"/"note-delete" db
        signals connected in db_changed() -- refreshes just the
        Caption panel/button, without reloading the image and region
        list that a full self.update()/main() would (unnecessary here,
        since a Note by itself never affects those).

        :param args: The signal's own arguments (typically a list of
            the affected Note handles), ignored: refresh_caption()
            always re-reads the current Media's Caption Note fresh
            rather than trying to determine from `args` alone whether
            the change was actually relevant to it.
        """
        self.refresh_caption()

    # ======================================================
    # loading the image
    # ======================================================

    def load_image(self, media):
        self.regions = []
        self.xmp_regions = []
        image_path = media_path_full(self.dbstate.db, media.get_path())
        self.selection_widget.loaded = False
        self.selection_widget.load_image(image_path)
        if self.selection_widget.loaded:
            self.retrieve_backrefs()
            self.get_xmp_regions(image_path)
            if not self.regions and not self.xmp_regions:
                # Last resort: no Gramps-linked region and no
                # Xmp.mwg-rs region for this photo at all -- whether
                # because the file genuinely has none, or because they
                # exist but can't be decoded (some GExiv2/exiv2
                # version combinations fail silently on this specific
                # structured tag). Xmp.dc.subject is a much simpler,
                # far more commonly supported flat tag that at least
                # carries the names, even with no position -- see
                # get_xmp_keyword_regions() for the trade-offs of
                # surfacing it this way.
                self.get_xmp_keyword_regions(image_path)
            self.regions = self.regions + self.xmp_regions
            self.sort_regions_by_stored_order(media)
            self.sync_selection_widget_regions()

    def sort_regions_by_stored_order(self, media):
        """
        Orders self.regions by the order persisted in the Media
        object's PhotoTagging Order attribute (see
        persist_region_order()), so a manual reorder set via
        drag-and-drop or the Move Up/Down buttons survives navigating
        away from this Media object and back, or restarting Gramps --
        not just a same-session refresh. Regions with no stored order
        (never explicitly reordered, or with no person at all, e.g. an
        unassigned XMP region) sort after all ordered ones, in their
        natural discovery order.
        """
        attr = get_media_order_attribute(media)
        text = attr.get_value() if attr is not None else ""
        order_by_handle, ok = parse_region_order_text(text, self.dbstate.db)

        def sort_key(region):
            if region.person is not None:
                row = order_by_handle.get(region.person.get_handle())
                if row is not None:
                    return (0, row)
            return (1, 0)

        self.regions.sort(key=sort_key)

        if not ok:
            # The attribute's text was structurally invalid (most
            # likely hand-edited into something else) -- replace it
            # with a clean table reflecting the natural order just
            # fallen back to, instead of leaving bad data in place to
            # fail the same way again next time.
            self.persist_region_order(media)

    def retrieve_backrefs(self):
        """
        Finds the media references pointing to the current image
        """
        backrefs = self.dbstate.db.find_backlink_handles(self.get_current_handle())
        for reftype, ref in backrefs:
            if reftype == "Person":
                person = self.dbstate.db.get_person_from_handle(ref)
                gallery = person.get_media_list()
                for mediaref in gallery:
                    referenced_handles = mediaref.get_referenced_handles()
                    for referens_item in referenced_handles:
                        handle_type, handle = referens_item
                        if (
                            handle_type == "Media"
                            and handle == self.get_current_handle()
                        ):
                            rect = mediaref.get_rectangle()
                            if rect is None:
                                rect = (0, 0, 100, 100)
                            coords = self.selection_widget.proportional_to_real_rect(
                                rect
                            )
                            region = Region(*coords)
                            region.person = person
                            region.xmp_person = ""
                            region.mediaref = mediaref
                            self.regions.append(region)

    def get_xmp_regions(self, image_path):
        """
        Get named regions from Xmp metadata.
        """
        try:
            # Deliberately not GExiv2.Metadata(image_path): that
            # one-argument shortcut only exists via a Python override
            # module some GExiv2 packages ship (gi/overrides/GExiv2.py)
            # that wraps the real, always-present open_path() method.
            # Where that override is missing or broken, the shortcut
            # falls through to the plain autogenerated GObject
            # constructor instead (which takes no arguments) and
            # raises TypeError -- previously swallowed here with no
            # trace at all by a bare `except:`. Calling open_path()
            # directly works either way.
            metadata = GExiv2.Metadata()
            metadata.open_path(image_path)
        except GLib.GError as err:
            # GExiv2's own well-defined "this isn't a format I can
            # read metadata from" signal -- e.g. an SVG icon or any
            # other non-photo file that happens to have an "image/*"
            # MIME type but no EXIF/XMP embedding GExiv2 understands.
            # Expected and routine, not a bug, so logged quietly
            # rather than as an alarming ERROR.
            LOG.debug("PhotoTagging: %s has no readable metadata (%s)", image_path, err)
            return
        except Exception:  # pylint: disable=broad-except
            LOG.exception("PhotoTagging: could not read metadata from %s", image_path)
            return

        region_tag = "Xmp.mwg-rs.Regions/mwg-rs:RegionList[%s]/"
        region_name = region_tag + "mwg-rs:Name"
        region_type = region_tag + "mwg-rs:Type"
        region_x = region_tag + "mwg-rs:Area/stArea:x"
        region_y = region_tag + "mwg-rs:Area/stArea:y"
        region_w = region_tag + "mwg-rs:Area/stArea:w"
        region_h = region_tag + "mwg-rs:Area/stArea:h"
        region_unit = region_tag + "mwg-rs:Area/stArea:unit"

        i = 1
        while True:
            name = get_xmp_tag_string(metadata, region_name % i)
            if name is None:
                break

            try:
                x = float(get_xmp_tag_string(metadata, region_x % i)) * 100
                y = float(get_xmp_tag_string(metadata, region_y % i)) * 100
                w = float(get_xmp_tag_string(metadata, region_w % i)) * 100
                h = float(get_xmp_tag_string(metadata, region_h % i)) * 100
            except (ValueError, TypeError):
                # ValueError: a present-but-non-numeric value (e.g. a
                # hand-edited or corrupted tag). TypeError: the tag
                # was missing entirely, so get_xmp_tag_string()
                # returned None and float(None) itself raises
                # TypeError rather than ValueError.
                x = y = 50
                w = h = 100

            rtype = get_xmp_tag_string(metadata, region_type % i)
            unit = get_xmp_tag_string(metadata, region_unit % i)

            # ensure region does not exceed bounds of image
            rect_p1 = x - (w / 2)
            if rect_p1 < 0:
                rect_p1 = 0
            rect_p2 = y - (h / 2)
            if rect_p2 < 0:
                rect_p2 = 0
            rect_p3 = x + (w / 2)
            if rect_p3 > 100:
                rect_p3 = 100
            rect_p4 = y + (h / 2)
            if rect_p4 > 100:
                rect_p4 = 100

            rect = (rect_p1, rect_p2, rect_p3, rect_p4)
            coords = self.selection_widget.proportional_to_real_rect(rect)
            xmp_region = Region(*coords)
            xmp_region.xmp_person = name

            # simple check to prevent infinite regions.  If regions are already
            # defined ignore the XMP regions.  Probably there is a way to compare
            # and merge the set of regions.
            if not len(self.regions):
                self.xmp_regions.append(xmp_region)
            i += 1

    def get_xmp_keyword_regions(self, image_path: str) -> None:
        """
        Fall back to the flat name list in Xmp.dc.subject when no
        per-person MWG region was found at all (see load_image()).
        Xmp.dc.subject carries no position information -- there's no
        real box to draw -- so each name is given a region spanning
        the entire image, the same "no known rectangle" convention
        already used in retrieve_backrefs() for a MediaRef with no
        stored rectangle of its own.

        This is a deliberate trade-off: every row built this way
        shares the exact same whole-image rectangle, so their Preview
        thumbnails are identical and their marquees exactly overlap
        on the canvas (selecting one via its row in the list works
        fine; telling them apart by clicking the canvas does not).
        It only ever runs when the gramplet would otherwise show
        nothing at all for this photo.

        :param image_path: Absolute path to the image file on disk.
        """
        try:
            # See get_xmp_regions() for why this avoids the
            # GExiv2.Metadata(image_path) shortcut constructor.
            metadata = GExiv2.Metadata()
            metadata.open_path(image_path)
        except GLib.GError as err:
            # See get_xmp_regions() -- an expected, routine "not a
            # format GExiv2 reads metadata from" signal, not a bug.
            LOG.debug("PhotoTagging: %s has no readable metadata (%s)", image_path, err)
            return
        except Exception:  # pylint: disable=broad-except
            LOG.exception("PhotoTagging: could not read metadata from %s", image_path)
            return

        try:
            # get_tag_multiple() is deprecated in favour of
            # try_get_tag_multiple() in newer GExiv2 releases, but is
            # kept here for compatibility with older ones still in use.
            names = metadata.get_tag_multiple("Xmp.dc.subject")
        except Exception:  # pylint: disable=broad-except
            LOG.exception(
                "PhotoTagging: could not read Xmp.dc.subject from %s",
                image_path,
            )
            return

        if not names:
            return

        whole_image_rect = self.selection_widget.proportional_to_real_rect(
            (0, 0, 100, 100)
        )
        for name in names:
            if not name:
                continue
            keyword_region = Region(*whole_image_rect)
            keyword_region.xmp_person = name
            keyword_region.xmp_whole_image = True
            self.xmp_regions.append(keyword_region)

    # ======================================================
    # managing regions
    # ======================================================

    def check_and_translate_to_proportional(self, mediaref, rect):
        if mediaref:
            return mediaref.get_rectangle()
        else:
            return self.selection_widget.real_to_proportional_rect(rect)

    def intersects_any(self, region):
        for r in self.regions:
            if r.intersects(region):
                return True
        return False

    def enclosing_region(self, region):
        for r in self.regions:
            if r.contains_rect(region):
                return r
        return None

    def regions_referencing_person(self, person):
        result = []
        for r in self.regions:
            if r.person == person:
                result.append(r)
        return result

    def all_referenced_persons(self):
        result = []
        for r in self.regions:
            if r.person is not None:
                result.append(r.person)
        return result

    # ======================================================
    # reordering regions
    # ======================================================
    # The list-move logic below follows the same pop/insert approach used
    # by gramps.gui.editors.editperson.EditPerson.reorder_child_ref_list
    # and by the row Up/Down buttons and drag-and-drop in
    # gramps.gui.editors.displaytabs.embeddedlist.EmbeddedList.

    def move_region_up(self, region):
        row_from = self.regions.index(region)
        if row_from > 0:
            del self.regions[row_from]
            self.regions.insert(row_from - 1, region)
            self.region_order_changed(region)

    def move_region_down(self, region):
        row_from = self.regions.index(region)
        if row_from < len(self.regions) - 1:
            del self.regions[row_from]
            self.regions.insert(row_from + 1, region)
            self.region_order_changed(region)

    def move_region(self, row_from, row_to, region):
        """
        Move a region from row_from to row_to, where row_to is the target
        drop slot in the list as it stands before the move (i.e. before
        row_from is removed).
        """
        if row_from == row_to:
            return
        if row_from < row_to:
            self.regions.insert(row_to, region)
            del self.regions[row_from]
        else:
            del self.regions[row_from]
            self.regions.insert(row_to, region)
        self.region_order_changed(region)

    def region_order_changed(self, region):
        """
        Refreshes after a move, keeping the moved region selected (in
        both the image and the list) so further moves can be chained.
        The new order is kept in memory only for now (see
        flush_region_order()) -- there's no reason to write it to the
        database until leaving this Media object or closing Gramps, so
        a move doesn't trigger a database commit (which would otherwise
        cause an async gramplet refresh that clears the treeview's
        selection right back out from under this method).
        """
        self._order_dirty = True
        self.sync_selection_widget_regions()
        self.selection_widget.select(region)
        self.refresh()
        self.enable_buttons()
        self.select_region_row(region)

    def flush_region_order(self):
        """
        Writes the in-memory order to the currently-loaded Media
        object's PhotoTagging Order attribute if it has changed since
        it was last read or written. Called when leaving a Media
        object (including to no active media) and when Gramps is
        closing (via on_save(), which Gramps calls on every open
        gramplet during its shutdown sequence -- observed to happen
        after the database connection itself has already been closed,
        raising sqlite3.ProgrammingError on any further use of it, so
        both an is_open() check and a broad try/except guard the actual
        database access here rather than letting that crash the
        shutdown).
        """
        if not self._order_dirty:
            return
        self._order_dirty = False
        if not self._loaded_media_handle:
            return
        if not self.dbstate.db.is_open():
            return
        try:
            media = self.dbstate.db.get_media_from_handle(self._loaded_media_handle)
            if media is not None:
                self.persist_region_order(media)
        except Exception:
            # The database can be closed out from under this call
            # (see docstring) at any point up to and including the
            # commit itself; there's nothing to save to at that point.
            pass

    def persist_region_order(self, media=None):
        """
        Writes the current display order into the Media object's
        PhotoTagging Order attribute (see serialize_region_order()) and
        commits it, if that text actually changed.
        """
        if media is None:
            media = self.get_current_object()
        if media is None:
            return
        new_text = serialize_region_order(self.regions)
        attr = get_media_order_attribute(media)
        if attr is not None:
            if attr.get_value() == new_text:
                return
            if new_text:
                attr.set_value(new_text)
            else:
                media.get_attribute_list().remove(attr)
        elif new_text:
            attr = Attribute()
            attr.set_type(ORDER_ATTR_TYPE)
            attr.set_value(new_text)
            media.add_attribute(attr)
        else:
            return
        self.commit_media(media)

    def select_region_row(self, region):
        if region in self.regions:
            path = Gtk.TreePath.new_from_indices([self.regions.index(region)])
            self.treeview.get_selection().select_path(path)
            self.treeview.set_cursor(path)
            self.scroll_to_selected_row()

    def scroll_to_selected_row(self):
        """
        Scrolls the list so the selected row ends up as close to
        vertically centered as the current scroll range allows, e.g.
        after selecting a region by clicking its marquee, moving the
        selection with Alt+Up/Down, or reordering the list.

        Deferred via GLib.idle_add: row geometry isn't necessarily up
        to date yet immediately after a selection or model change (the
        same reason gramps.gui.editors.displaytabs.embeddedlist.
        EmbeddedList's own _move_up()/_move_down() defer their
        scroll_to_cell() call the same way).
        """
        selection = self.treeview.get_selection()
        model, tree_iter = selection.get_selected()
        if tree_iter is None:
            return
        path = model.get_path(tree_iter)
        GLib.idle_add(self.treeview.scroll_to_cell, path, None, True, 0.5, 0.0)

    def find_drop_row(self, x, y):
        """
        Find the row index that a drag-and-drop at (x, y) targets: a
        drop above a row's own vertical centerline places it before
        that row, at or below the centerline places it after -- treating
        the result as a slot in the current (pre-move) list.

        (x, y) here are in treeview *widget* coordinates (including the
        column headers), as delivered by the drag_data_received signal.
        get_path_at_pos()/get_background_area() instead expect *bin
        window* coordinates -- the scrollable content area below the
        headers -- per their own docs, so they need converting first
        with convert_widget_to_bin_window_coords(). Skipping that
        conversion (as an earlier version of this method did) offsets
        every lookup downward by the header's height, silently
        returning no row (and so falling back to "append at the end")
        for any drop whose shifted position falls past the last row --
        which for a short list is effectively every drop, regardless of
        where it actually landed.

        Deliberately does not use Gtk.TreeView.get_dest_row_at_pos():
        in testing, its reported path was consistently one row earlier
        than the row actually under the given (bin-window) position --
        e.g. the vertical center of row 2 was reported as row 1 -- and
        it returned no result at all for the first row.
        """
        try:
            bin_x, bin_y = self.treeview.convert_widget_to_bin_window_coords(x, y)
            result = self.treeview.get_path_at_pos(bin_x, bin_y)
            if result is None:
                return len(self.regions)
            path, column, cell_x, cell_y = result
            index = path.get_indices()[0]
            rect = self.treeview.get_background_area(path, column)
            if bin_y < rect.y + rect.height / 2:
                return index
            return index + 1
        except Exception:
            # Never let a reorder drop silently do nothing because of
            # an unexpected exception here -- log it (so the exact
            # cause can be diagnosed) and fall back to appending at the
            # end, same as the plain "no row under the pointer" case
            # above.
            LOG.exception("find_drop_row failed for (x=%r, y=%r)", x, y)
            return len(self.regions)

    # ======================================================
    # utility functions for retrieving properties
    # ======================================================

    def get_current_handle(self):
        return self.get_active("Media")

    def get_current_object(self):
        # get_active() can return '' (e.g. no active Media, or the dummy
        # database with no tree open) -- looking that up directly logs a
        # "handle  does not exist" warning, so skip the lookup entirely.
        handle = self.get_current_handle()
        if not handle:
            return None
        try:
            return self.dbstate.db.get_media_from_handle(handle)
        except:
            return None

    # ======================================================
    # helpers for updating database objects
    # ======================================================

    def add_reference(self, person, rect):
        """
        Add a reference to the media object to the specified person.
        """
        mediaref = MediaRef()
        mediaref.ref = self.get_current_handle()
        mediaref.set_rectangle(rect)
        person.add_media_reference(mediaref)
        self.commit_person(person)
        return mediaref

    def remove_reference(self, person, mediaref):
        """
        Removes the reference to the media object from the person.
        """
        if mediaref in person.get_media_list():
            person.get_media_list().remove(mediaref)
            self.commit_person(person)

    def commit_person(self, person):
        """
        Save the modifications made to a Person object to the database.
        """
        with DbTxn("", self.dbstate.db) as trans:
            self.dbstate.db.commit_person(person, trans)
            msg = _("Edit Person (%s)") % name_displayer.display(person)
            trans.set_description(msg)

    def commit_media(self, media):
        """
        Save the modifications made to a Media object to the database.
        """
        with DbTxn("", self.dbstate.db) as trans:
            self.dbstate.db.commit_media(media, trans)
            trans.set_description(_("Edit Media Object"))

    # ======================================================
    # managing toolbar buttons
    # ======================================================
    def enable_buttons(self):
        selected = self.selection_widget.get_current()
        self.button_index.set_sensitive(selected is not None)
        self.button_add.set_sensitive(selected is not None)
        self.button_del.set_sensitive(
            selected is not None and selected.person is not None
        )
        self.button_clear.set_sensitive(selected is not None)
        self.button_edit.set_sensitive(
            selected is not None and selected.person is not None
        )
        index = self.regions.index(selected) if selected in self.regions else -1
        self.button_move_up.set_sensitive(index > 0)
        self.button_move_down.set_sensitive(
            index >= 0 and index < len(self.regions) - 1
        )
        self.button_zoom_in.set_sensitive(
            self.selection_widget.is_image_loaded()
            and self.selection_widget.can_zoom_in()
        )
        self.button_zoom_out.set_sensitive(
            self.selection_widget.is_image_loaded()
            and self.selection_widget.can_zoom_out()
        )
        self.button_detect.set_sensitive(
            self.selection_widget.is_image_loaded()
            and facedetection.computer_vision_available
        )

    # ======================================================
    # marquee visibility and ID overlay
    # ======================================================

    def sync_selection_widget_regions(self):
        """
        Give the SelectionWidget the region list to draw, respecting the
        current marquee show/hide state (it has no visibility flag of its
        own, so hiding is done by handing it an empty list).
        """
        self.selection_widget.set_regions(self.regions if self.marquees_visible else [])

    def show_marquees(self):
        """
        Force the marquees back to visible, e.g. after selecting a row or
        drawing a new region.
        """
        if self.button_marquees.get_active():
            self.button_marquees.set_active(False)

    def marquees_toggled(self, button):
        self.marquees_visible = not button.get_active()
        self.update_marquees_button()
        if not self.marquees_visible:
            # SelectionWidget draws the single actively-selected region
            # (with shading) regardless of its own regions list whenever
            # something is selected -- see sync_selection_widget_regions()
            # -- so hiding the marquees while a row/region is selected
            # has to also clear that selection, or its one box stays
            # visible no matter what regions we hand the widget.
            self.selection_widget.clear_selection()
            self.treeview.get_selection().unselect_all()
        self.sync_selection_widget_regions()
        self.selection_widget.refresh()
        self.enable_buttons()

    def metadata_clues_toggled(self, button):
        """
        Shows or hides the "Metadata clues" column. Like
        marquees_toggled(), active means "hidden": the button is
        pressed/highlighted only in the non-default state.
        """
        self.metadata_clues_visible = not button.get_active()
        self.column_metadata_clues.set_visible(self.metadata_clues_visible)
        self.update_metadata_clues_button()

    def update_metadata_clues_button(self):
        """
        Updates the "Metadata clues" toggle button's tooltip to
        reflect its current Hide/Show state, matching the pattern
        used by update_marquees_button()/update_show_ids_button().
        """
        if self.metadata_clues_visible:
            tooltip = _("Hide the Metadata clues column")
        else:
            tooltip = _("Show the Metadata clues column")
        self.button_metadata_clues.set_tooltip_text(tooltip)

    # ======================================================
    # Caption panel
    # ======================================================

    def refresh_caption(self) -> None:
        """
        Re-reads the active Media object's first Caption-type Note
        (see find_caption_note()) and updates the Caption panel/
        button to match: called from main() on every refresh (Media
        switched, or any db signal main() is connected to), and from
        cb_note_changed() specifically for Note signals.
        """
        media = self.get_current_object()
        note = find_caption_note(media, self.dbstate.db)
        self.caption_note_exists = note is not None
        if note is not None:
            self.caption_editor.set_text(note.get_styledtext())
        else:
            self.caption_editor.set_text(StyledText())
        self.update_caption_button()
        self.update_caption_panel_visibility()
        # set_text() above just replaced the panel's content outright,
        # discarding whatever range was highlighted in the old text
        # (see CaptionTextEditor.highlight_person()) -- reapply it for
        # whichever region is currently selected, rather than letting
        # it silently vanish until the selection itself next changes.
        self.sync_caption_highlight()

    def sync_caption_highlight(self) -> None:
        """
        Re-applies the Caption panel's highlight for whichever person
        the region list/marquee currently have selected (see
        apply_selected_region()) -- called after refresh_caption()
        replaces the panel's text outright.
        """
        current = self.selection_widget.get_current()
        person = current.person if current is not None else None
        self.caption_editor.highlight_person(person.get_handle() if person else None)

    def edit_caption_note(self) -> None:
        """
        Opens the Note editor for the Caption Note currently shown in
        the Caption panel -- the action for a double click on
        unlinked space there (see
        CaptionTextEditor.on_button_press_event()). Does nothing if
        there is currently no Caption Note (the panel is hidden and
        dimmed in that case anyway, so there is nothing to
        double-click on).

        Re-reads the Note fresh via find_caption_note() rather than
        keeping a cached reference from refresh_caption(), the same
        reasoning cb_note_changed() already relies on: it's always
        the current one, and simpler than keeping a second copy of
        the same state in sync.
        """
        media = self.get_current_object()
        note = find_caption_note(media, self.dbstate.db)
        if note is None:
            return
        try:
            EditNote(self.dbstate, self.uistate, self.track, note)
        except WindowActiveError:
            pass

    def update_caption_panel_visibility(self) -> None:
        """
        Shows or hides the Caption panel to match caption_panel_visible
        -- except there is never anything to show without a Caption
        Note at all, regardless of that flag.

        Native Gtk.Paned does not reclaim a hidden child's share of
        the space on its own -- the divider itself would otherwise
        stay right where it was, still draggable, with the Caption
        panel just an empty strip below it -- so hiding additionally
        pushes the divider all the way down (giving the Preview panel
        the freed height), and showing restores it to the last known
        Preview:Caption split (see _caption_split_ratio). Both are
        done through the same lock cb_left_pane_size_allocate() uses,
        so this repositioning is never mistaken for the person having
        dragged the handle to a new ratio (see
        cb_left_pane_position_changed()).
        """
        show = self.caption_panel_visible and self.caption_note_exists
        if show:
            self.caption_scrolled_window.show_all()
        else:
            self.caption_scrolled_window.hide()
        if not self._left_pane_last_height:
            return
        self._caption_split_ratio_lock = True
        try:
            if show:
                position = round(
                    self._left_pane_last_height * self._caption_split_ratio
                )
            else:
                position = self._left_pane_last_height
            self.left_pane.set_position(position)
        finally:
            self._caption_split_ratio_lock = False

    def update_caption_button(self) -> None:
        """
        Updates the Show/Hide Caption toggle button's tooltip and
        dimmed appearance to reflect whether the active Media has a
        Caption Note at all, and -- when it does -- the panel's
        current Show/Hide state, matching the pattern used by
        update_marquees_button()/update_metadata_clues_button().
        """
        if not self.caption_note_exists:
            tooltip = _(
                "No Caption note for this media "
                "(double-click to create one from the region list)"
            )
        elif self.caption_panel_visible:
            tooltip = _("Hide the Caption panel")
        else:
            tooltip = _("Show the Caption panel")
        self.button_caption.set_tooltip_text(tooltip)
        self.set_caption_button_dimmed(not self.caption_note_exists)

    def set_caption_button_dimmed(self, dimmed: bool) -> None:
        """
        Gives the Caption button's icon a dimmed appearance without
        actually disabling the button itself (see the comment on
        self.button_caption in build_gui() for why it stays
        sensitive): applies GTK's own INSENSITIVE state flag -- the
        same visual state a themed icon renders when its widget really
        is insensitive -- to just the icon widget.

        :param dimmed: bool
        """
        icon_widget = self.button_caption.get_icon_widget()
        if icon_widget is None:
            return
        if dimmed:
            icon_widget.set_state_flags(Gtk.StateFlags.INSENSITIVE, False)
        else:
            icon_widget.unset_state_flags(Gtk.StateFlags.INSENSITIVE)

    def cb_caption_button_toggled(self, button: Gtk.ToggleToolButton) -> None:
        """
        Callback for the Caption toggle button's "toggled" signal.

        A Gtk.ToggleToolButton fires "toggled" on every click,
        including both halves of a double-click -- which, being a
        toggle, leaves button.get_active() right back where it
        started. That quirk is used deliberately here: when there is
        no Caption Note to show at all (the button is dimmed), a
        single click has nothing useful left to toggle, so it is
        simply ignored rather than flipping caption_panel_visible for
        no visible effect; a double click -- this handler firing
        twice within the desktop's own configured double-click
        interval -- is instead treated as a request to create one,
        via the same action as the "Transcribe list to a Note"
        context menu item (which now always creates a Caption-type
        Note; see transcribe_list_to_note_clicked()).
        """
        now = GLib.get_monotonic_time()
        interval_us = (
            Gtk.Settings.get_default().get_property("gtk-double-click-time") * 1000
        )
        is_double_click = (now - self._caption_last_toggle_us) <= interval_us
        self._caption_last_toggle_us = now

        if not self.caption_note_exists:
            if is_double_click:
                self.transcribe_list_to_note_clicked(None)
            return

        self.caption_panel_visible = not button.get_active()
        self.update_caption_button()
        self.update_caption_panel_visibility()

    def select_person_in_list(self, person_handle: str) -> None:
        """
        Selects -- everywhere: the region list row, the marquee, and
        the Caption panel's own highlight (see
        apply_selected_region()) -- the region tagged with the Person
        identified by `person_handle`, if one of the currently listed
        regions is tagged with them. This is the action for a plain
        click on a Person link inside the Caption panel (see
        CaptionTextEditor.on_button_press_event()). Does nothing if
        no region names that person.

        :param person_handle: Handle of the Person to search for.
        """
        for region in self.regions:
            if (
                region.person is not None
                and region.person.get_handle() == person_handle
            ):
                self.apply_selected_region(region)
                return

    def apply_selected_region(self, region) -> None:
        """
        The single place responsible for keeping the region list's
        row selection, the image's marquee highlight, and the
        Caption panel's matching linked text all showing the same
        selection at once -- called any time that selection changes,
        regardless of which of the three the person actually
        interacted with (a row, a marquee, or a Person link in the
        Caption panel).

        Guarded against re-entrancy (self._syncing_selection):
        set_cursor() below can itself synchronously re-trigger
        cursor_changed(), which would otherwise call straight back in
        here for no further effect.

        :param region: The Region to select everywhere, or ``None``
            to clear the selection everywhere.
        """
        if self._syncing_selection:
            return
        self._syncing_selection = True
        try:
            if region is not None and region in self.regions:
                path = Gtk.TreePath.new_from_indices([self.regions.index(region)])
                self.treeview.set_cursor(path)
                self.scroll_to_selected_row()
            else:
                self.treeview.get_selection().unselect_all()
            self.selection_widget.select(region)
            if region is not None:
                self.show_marquees()
            self.caption_editor.highlight_person(
                region.person.get_handle()
                if region is not None and region.person is not None
                else None
            )
        finally:
            self._syncing_selection = False
        self.enable_buttons()

    def cb_left_pane_size_allocate(
        self, paned: Gtk.Paned, allocation: Gdk.Rectangle
    ) -> None:
        """
        Rescales the draggable split between the Preview (image) and
        Caption panels to preserve their current proportion --
        whatever the person last dragged it to, defaulting to
        CAPTION_SPLIT_INITIAL_RATIO the first time -- as the
        gramplet's docked height, or its floating window, is resized.
        Native Gtk.Paned has no percentage-split notion of its own:
        left alone, it holds one side to a fixed pixel size and lets
        the other absorb the entire change, which this corrects for.

        Guarded to only act when left_pane's own total allocated
        height has actually changed since the last call -- this
        handler is also (harmlessly) re-entered by the very
        set_position() call it makes below, and would otherwise also
        fire on every unrelated size-allocate (e.g. a horizontal-only
        resize, or the divider itself being dragged).
        """
        total = allocation.height
        if total <= 1 or total == self._left_pane_last_height:
            return
        self._left_pane_last_height = total
        self._caption_split_ratio_lock = True
        try:
            paned.set_position(round(total * self._caption_split_ratio))
        finally:
            self._caption_split_ratio_lock = False

    def cb_left_pane_position_changed(
        self, paned: Gtk.Paned, gparam: GObject.ParamSpec
    ) -> None:
        """
        Tracks the current Preview:Caption split ratio whenever the
        person drags the handle themselves, so
        cb_left_pane_size_allocate() above preserves *that*
        proportion on a later resize, instead of resetting back to
        CAPTION_SPLIT_INITIAL_RATIO every time.

        Ignored while cb_left_pane_size_allocate() itself is the one
        moving the handle (see self._caption_split_ratio_lock): that
        is an existing ratio being reapplied after a resize, not a
        new one being set.
        """
        if self._caption_split_ratio_lock:
            return
        total = self._left_pane_last_height
        if not total:
            return
        self._caption_split_ratio = paned.get_position() / total

    def update_marquees_button(self):
        if self.marquees_visible:
            names = ["view-reveal-symbolic", Gtk.STOCK_INDEX]
            tooltip = _("Hide face marquees")
        else:
            names = ["view-conceal-symbolic", "process-stop", Gtk.STOCK_CLEAR]
            tooltip = _("Show face marquees")
        set_toolbar_icon(self.button_marquees, names)
        self.button_marquees.set_tooltip_text(tooltip)

    def show_ids_clicked(self, button):
        """
        Cycles the ID-in-face-box display through its 3 states on each
        click: Row ID (default) -> Gramps ID -> hidden -> Row ID ...
        """
        idx = ID_MODE_ORDER.index(self.id_display_mode)
        self.id_display_mode = ID_MODE_ORDER[(idx + 1) % len(ID_MODE_ORDER)]
        self.update_show_ids_button()
        self.show_marquees()
        self.selection_widget.refresh()

    def update_show_ids_button(self):
        if self.id_display_mode == ID_MODE_HIDDEN:
            names = ["user-offline", "process-stop", Gtk.STOCK_CLEAR]
            tooltip = _("Face marquee ID: hidden (click for Row ID)")
        else:
            # Row ID and Gramps ID share the same icon; only the tooltip
            # differs, since both are "on" states.
            names = ["user-idle", Gtk.STOCK_INDEX]
            if self.id_display_mode == ID_MODE_ROW:
                tooltip = _("Face marquee ID: Row ID (click for Person ID)")
            else:
                tooltip = _("Face marquee ID: Person ID (click to hide)")
        set_toolbar_icon(self.button_show_ids, names)
        self.button_show_ids.set_tooltip_text(tooltip)

    def draw_ids_overlay(self, widget, cr):
        """
        Draws the row number or Gramps ID of each tagged person on top of
        whatever SelectionWidget has already drawn, mirroring exactly
        which region(s) it drew: either the single active selection (with
        shading), or all regions when nothing is selected.
        """
        if self.id_display_mode == ID_MODE_HIDDEN:
            return
        selwidget = self.selection_widget
        if not selwidget.pixbuf:
            return
        if selwidget.selection and selwidget.current is not None:
            self._draw_region_id(cr, selwidget.current)
        elif not selwidget.selection:
            for region in selwidget.regions:
                self._draw_region_id(cr, region)

    def _draw_region_id(self, cr, region):
        if self.id_display_mode == ID_MODE_GRAMPS:
            person = region.person
            if not person:
                return
            text = person.get_gramps_id()
            if not text:
                return
            font_size = 12
        else:
            # ID_MODE_ROW: the same 1-based number shown in the list's
            # first column. It's normally just 1-2 digits, so it can
            # afford to be drawn twice as large as the Gramps ID text.
            if region not in self.regions:
                return
            text = str(self.regions.index(region) + 1)
            font_size = 24

        # Reuses SelectionWidget's own (private) image-to-screen transform
        # so the label lines up exactly with the frame it draws for the
        # same region.
        x1, y1, x2, y2 = self.selection_widget._rect_image_to_screen(region.coords())
        cr.save()
        cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        cr.set_font_size(font_size)

        # A white plate behind the text keeps MARQUEE_BLUE legible
        # against any part of the photo.
        pad = 2
        extents = cr.text_extents(text)
        box_x = x1 + 2
        box_y = y1 + 2
        cr.set_source_rgb(1.0, 1.0, 1.0)
        cr.rectangle(
            box_x - pad, box_y - pad, extents.width + 2 * pad, extents.height + 2 * pad
        )
        cr.fill()

        cr.set_source_rgb(*MARQUEE_BLUE)
        cr.move_to(box_x - extents.x_bearing, box_y - extents.y_bearing)
        cr.show_text(text)
        cr.restore()

    # ======================================================
    # managing context menu buttons
    # ======================================================

    def prepare_context_menu(self):
        selected = self.selection_widget.get_current()
        has_person = selected is not None and selected.person is not None

        self.context_button_details.set_sensitive(has_person)
        self.context_button_active.set_sensitive(has_person)
        self.context_button_add.set_sensitive(selected is not None)
        self.context_button_select.set_sensitive(selected is not None)
        self.context_button_clear.set_sensitive(has_person)
        self.context_button_remove.set_sensitive(selected is not None)
        index = self.regions.index(selected) if selected in self.regions else -1
        self.context_button_move_up.set_sensitive(index > 0)
        self.context_button_move_down.set_sensitive(
            index >= 0 and index < len(self.regions) - 1
        )
        self.context_button_transcribe.set_sensitive(
            self.get_current_object() is not None and bool(self.regions)
        )

        # clear temporary items
        for item in self.additional_items:
            self.context_menu.remove(item)

        self.additional_items = []

        # populate the context menu
        persons = self.all_referenced_persons()
        if selected is not None and selected.person is not None:
            persons.remove(selected.person)
        if persons:
            media = self.get_current_object()
            name_as_of_date = self.name_as_of_date_for(media)

            def display_name_for(person):
                return display_name_respecting_format(
                    get_name_at_date(person, name_as_of_date)
                )

            self.additional_items.append(Gtk.SeparatorMenuItem())
            sorted_persons = sorted(list(persons), key=display_name_for)
            for person in sorted_persons:
                item = Gtk.MenuItem(_("Swap with {0}").format(display_name_for(person)))
                item.connect("activate", self.replace_reference, person)
                self.additional_items.append(item)
            for item in self.additional_items:
                self.context_menu.append(item)

    def show_context_menu(self):
        """
        Show popup menu using different functions according to Gtk version.
        'Gtk.Menu.popup' is deprecated since version 3.22, see:
        https://lazka.github.io/pgi-docs/index.html#Gtk-3.0/classes/Menu.html#Gtk.Menu.popup
        """
        self.prepare_context_menu()
        self.context_menu.show_all()
        if (Gtk.MAJOR_VERSION >= 3) and (Gtk.MINOR_VERSION >= 22):
            self.context_menu.popup_at_pointer(None)
        else:
            self.context_menu.popup(None, None, None, None, 0, 0)

    # ======================================================
    # selection event handlers
    # ======================================================

    def region_modified(self, sender):
        region = self.selection_widget.get_current()
        person = region.person
        mediaref = region.mediaref
        if person and mediaref:
            selection = self.selection_widget.get_selection()
            rect = self.selection_widget.real_to_proportional_rect(selection)
            mediaref.set_rectangle(rect)
            self.commit_person(person)
        self.enable_buttons()
        self.refresh_list()
        self.refresh_selection()

    def region_created(self, sender):
        self.show_marquees()
        self.enable_buttons()
        self.refresh_list()
        self.refresh_selection()
        self.show_context_menu()

    def right_button_clicked(self, sender):
        self.show_context_menu()

    def region_selected(self, sender):
        self.apply_selected_region(self.selection_widget.get_current())

    def selection_cleared(self, sender):
        self.apply_selected_region(None)

    def zoomed(self, sender):
        self.enable_buttons()

    # ======================================================
    # toolbar button event handles
    # ======================================================
    def add_person_clicked(self, event):
        if self.selection_widget.get_current():
            person = Person()
            EditPerson(
                self.dbstate, self.uistate, self.track, person, self.new_person_added
            )

    def sel_person_clicked(self, event):
        if self.selection_widget.get_current():
            SelectPerson = SelectorFactory("Person")
            sel = SelectPerson(
                self.dbstate,
                self.uistate,
                self.track,
                LINK_PERSON_TEXT,
                show_search_bar=True,
            )
            person = sel.run()
            if person:
                self.set_current_person(person)
                self.selection_widget.clear_selection()
                self.refresh()
                self.enable_buttons()

    def del_region_clicked(self, event):
        if self.selection_widget.get_current():
            self.delete_region(self.selection_widget.get_current())
            self.selection_widget.clear_selection()
            self.refresh()
            self.enable_buttons()

    def clear_ref_clicked(self, event):
        if self.clear_ref(self.selection_widget.get_current()):
            self.refresh()

    def edit_person_clicked(self, event):
        region = self.selection_widget.get_current()
        person = region.person
        if person:
            EditPerson(
                self.dbstate,
                self.uistate,
                self.track,
                person,
                lambda edited_person, region=region: self.cb_person_edited(region),
            )
            self.refresh()

    def cb_person_edited(self, region) -> None:
        """
        Callback for the Edit Person window opened by
        edit_person_clicked() (a double-clicked row, or the "_See the
        person details" context menu item) -- re-applies the
        selection to `region` (row, marquee, and Caption panel
        highlight; see apply_selected_region()) once its Person has
        actually been saved.

        This is on top of, not instead of, the same reselection
        db-signal-triggered refreshes already do (see
        main()/refresh_selection()): that alone was observed to get
        overwritten again right after, apparently by the Edit Person
        window's own close/focus-handoff back to the region list --
        leaving no row selected, with only the marquee still showing
        (whichever region happened to be last, not the one just
        edited). Deferring this to the next Gtk idle cycle, rather
        than applying it immediately here, runs it after whatever
        that close-triggered reset does, instead of racing it, which
        is what actually makes the reselection stick.
        """
        GLib.idle_add(self._cb_reapply_selected_region_once, region)

    def _cb_reapply_selected_region_once(self, region) -> bool:
        """
        GLib.idle_add callback for cb_person_edited(): applies
        apply_selected_region(region) exactly once.

        :returns: ``False``, telling GLib.idle_add not to call this
            again.
        """
        self.apply_selected_region(region)
        return False

    def move_up_clicked(self, event):
        region = self.selection_widget.get_current()
        if region:
            self.move_region_up(region)

    def move_down_clicked(self, event):
        region = self.selection_widget.get_current()
        if region:
            self.move_region_down(region)

    def zoom_in_clicked(self, event):
        self.selection_widget.zoom_in()

    def zoom_out_clicked(self, event):
        self.selection_widget.zoom_out()

    def detect_faces_clicked(self, event):
        self.uistate.push_message(self.dbstate, _("Detecting faces..."))
        media = self.get_current_object()
        image_path = media_path_full(self.dbstate.db, media.get_path())
        faces, img_size = facedetection.detect_faces(
            image_path, MIN_FACE_SIZE, SENSITIVITY
        )
        # verify and enlarge found faces regions
        for x, y, width, height in faces:
            # calculate enlarged region
            new_x1 = x - width / 5
            new_y1 = y - height / 3
            new_x2 = x + width * 6 / 5
            new_y2 = y + height * 7 / 5
            # prevent overflow image size
            new_y1 = 0 if new_y1 < 0 else new_y1
            new_y2 = img_size[0] if img_size[0] < new_y2 else new_y2
            new_x1 = 0 if new_x1 < 0 else new_x1
            new_x2 = img_size[1] if img_size[1] < new_x2 else new_x2

            region = Region(new_x1, new_y1, new_x2, new_y2)

            if DETECT_INSIDE_EXISTING_BOXES or self.enclosing_region(region) is None:
                self.regions.append(region)

        self.refresh()
        self.uistate.push_message(self.dbstate, _("Detection finished"))

    def settings_clicked(self, event):
        try:
            SettingsDialog(
                self.gui.dbstate, self.gui.uistate, _("Settings"), PhotoTaggingOptions()
            )
        except WindowActiveError:
            pass

    def set_active_person(self, event):
        """
        Set selected person as active.
        """
        person = self.selection_widget.get_current().person
        if person:
            person_handle = person.get_handle()
            self.set_active("Person", person_handle)

    # ======================================================
    # helpers for toolbar event handlers
    # ======================================================

    def delete_region(self, region):
        self.regions.remove(region)
        if region.person is not None:
            self.remove_reference(region.person, region.mediaref)

    def delete_regions(self, regions):
        for r in regions:
            self.delete_region(r)

    def new_person_added(self, person):
        self.set_current_person(person)
        self.selection_widget.clear_selection()
        self.refresh()
        self.enable_buttons()

    def set_current_person(self, person):
        self.ask_and_set_person(self.selection_widget.get_current(), person)

    def ask_and_set_person(self, region, person):
        if region and person:
            other_references = self.regions_referencing_person(person)
            ref_count = len(other_references)
            if ref_count > 0:
                person = other_references[0].person
                if REPLACE_WITHOUT_ASKING:
                    self.delete_regions(other_references)
                else:
                    if ref_count == 1:
                        text = _(
                            "Another region of this image "
                            "is associated with {name}. Remove it?"
                        )
                    else:
                        text = _(
                            "{count} other regions of this image "
                            "are associated with {name}. Remove them?"
                        )
                    message = text.format(
                        name=name_displayer.display(person), count=ref_count
                    )
                    dialog = Gtk.MessageDialog(
                        parent=None,
                        type=Gtk.MessageType.QUESTION,
                        buttons=Gtk.ButtonsType.YES_NO,
                        message_format=message,
                    )
                    response = dialog.run()
                    dialog.destroy()
                    if response == Gtk.ResponseType.YES:
                        self.delete_regions(other_references)
            self.set_person(region, person)

    def set_person(self, region, person):
        rect = self.check_and_translate_to_proportional(
            region.mediaref, region.coords()
        )
        self.clear_ref(region)
        mediaref = self.add_reference(person, rect)
        region.person = person
        region.mediaref = mediaref
        region.xmp_person = ""

    def clear_ref(self, region):
        if region:
            if region.person:
                self.remove_reference(region.person, region.mediaref)
                region.person = None
                region.mediaref = None
                return True
        return False

    # ======================================================
    # context menu event handles
    # ======================================================

    def replace_reference(self, event, person):
        """
        Swaps person assignments between the currently selected region
        and whichever region `person` is already assigned to: their
        rectangles/positions/index in the list are untouched -- only
        which person each one is linked to trades places. E.g. if row
        5 (some person, or none) is selected and "Swap with" row 18's
        person is chosen, row 5 ends up with row 18's former person
        and vice versa; every other row is unaffected.

        The target region (region_b below) is set first, using
        region_a's *original* person, before region_a itself is
        touched -- set_person() always reads a region's rectangle
        from its own current, unmodified mediaref/coords, so ordering
        it this way naturally avoids having to manipulate any
        MediaRef rectangle directly to achieve the swap.

        Both region_a and person_a are captured up front, not
        re-queried mid-method: as in the crash this replaced, each
        set_person()/clear_ref() call below commits a Person, and
        Gramps fires its database update signal synchronously on
        commit -- which re-enters this same gramplet's own refresh
        cycle while this method is still on the call stack.
        """
        region_a = self.selection_widget.get_current()
        if region_a is None:
            return
        person_a = region_a.person

        other_regions = self.regions_referencing_person(person)
        region_b = other_regions[0] if other_regions else None

        if region_b is not None:
            if person_a is not None:
                self.set_person(region_b, person_a)
            else:
                self.clear_ref(region_b)
        self.set_person(region_a, person)

        self.selection_widget.clear_selection()
        self.refresh()
        self.enable_buttons()

    def transcribe_list_to_note_clicked(self, event):
        """
        Creates a new Note -- as if the Media editor's own "create and
        add a new note" button had been clicked for the active Media
        object -- pre-populated with a transcription of the region
        list:

        1. Title (bold), date, and (linked) Gramps ID of the media,
           one per line, then a blank line.
        2. Every named person in the list, in row order, joined by
           "; ", each name linked to that person -- rendered with the
           same date-aware, display_as-respecting name shown in the
           table (see get_name_at_date()/display_name_respecting_format()),
           then two blank lines.
        3. The Metadata clues text for every remaining row that has no
           person assigned, one per line -- i.e. exactly what the
           "Metadata clues" column shows for those rows -- then two
           blank lines.
        4. The PhotoTagging Order attribute's raw content, if any,
           with each Gramps ID it names turned into a link and
           followed by that person's name, moved to the end since
           it's the least human-readable of the four sections.

        The Note is opened for editing unsaved; only once the person
        clicks OK in the Note editor is it actually created and added
        to the media object's own note list, matching what clicking
        "create and add a new note" in the Media editor would do.

        Its type is always set to the custom Caption type (see
        CAPTION_NOTE_TYPE_STRING) rather than General, since this is
        also the action invoked by double-clicking the Show/Hide
        Caption toolbar button while it is dimmed (see
        cb_caption_button_toggled()) -- the whole point there being to
        create a Note that button/panel will immediately recognize.
        """
        media = self.get_current_object()
        if media is None or not self.regions:
            return

        builder = NoteTextBuilder()
        media_date = media.get_date_object()
        name_as_of_date = self.name_as_of_date_for(media)

        # 1. Title (bold), date, ID (linked), blank line
        builder.add_bold_line(media.get_description())
        if media_date is not None and media_date.get_valid():
            builder.add_line(date_displayer.display(media_date))
        else:
            builder.add_line(_("undefined date"))
        media_gramps_id = media.get_gramps_id()
        builder.add_linked_line(
            media_gramps_id,
            "gramps://Media/handle/%s" % media.get_handle(),
        )
        builder.add_blank_lines(1)

        # 2. Names column values, "; "-joined, each linked
        named_regions = [r for r in self.regions if r.person is not None]
        for i, region in enumerate(named_regions):
            if i > 0:
                builder.add_text("; ")
            name = display_name_respecting_format(
                get_name_at_date(region.person, name_as_of_date)
            )
            builder.add_link(
                name, "gramps://Person/handle/%s" % region.person.get_handle()
            )
        builder.add_line()
        builder.add_blank_lines(2)

        # 3. Metadata clues values for the rows with no person assigned
        for region in self.regions:
            if region.person is not None:
                continue
            metadata_clue = getattr(region, "xmp_person", "")
            if not metadata_clue:
                continue
            if getattr(region, "xmp_whole_image", False):
                metadata_clue = _("%s (whole photo, no region)") % metadata_clue
            builder.add_line(metadata_clue)
        builder.add_blank_lines(2)

        # 4. PhotoTagging Order attribute content, IDs linked, each
        # followed by that person's own name -- moved to the end,
        # since it's the least human-readable of the four sections.
        order_attr = get_media_order_attribute(media)
        order_text = order_attr.get_value() if order_attr is not None else ""
        for line in order_text.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split(",", 1)
            if len(parts) != 2:
                builder.add_line(line)
                continue
            row_text, gramps_id = parts[0].strip(), parts[1].strip()
            person = self.dbstate.db.get_person_from_gramps_id(gramps_id)
            builder.add_text("%s, " % row_text)
            if person is not None:
                builder.add_link(
                    gramps_id, "gramps://Person/handle/%s" % person.get_handle()
                )
                name = display_name_respecting_format(
                    get_name_at_date(person, name_as_of_date)
                )
                builder.add_line(", %s" % name)
            else:
                builder.add_line(gramps_id)

        note = Note()
        note.set_type((NoteType.CUSTOM, CAPTION_NOTE_TYPE_STRING))
        # NOTE: set() takes a plain string and stores clear text only,
        # silently discarding any StyledTextTag formatting -- including
        # every link built above. set_styledtext() is the method that
        # actually preserves it.
        note.set_styledtext(builder.build_styled_text())
        try:
            EditNote(
                self.dbstate,
                self.uistate,
                self.track,
                note,
                self.note_added_to_media_callback,
            )
        except WindowActiveError:
            pass

    def note_added_to_media_callback(self, note_handle):
        """
        Commits the new note as a reference on the active Media object,
        the same effect as the Media editor's own "create and add a
        new note" button -- called once the person clicks OK in the
        Note editor opened by transcribe_list_to_note_clicked().
        """
        media = self.get_current_object()
        if media is None:
            return
        with DbTxn(_("Add Note"), self.dbstate.db) as trans:
            media.add_note(note_handle)
            self.dbstate.db.commit_media(media, trans)

    # ======================================================
    # list event handles
    # ======================================================

    def cursor_changed(self, treeview):
        self.apply_selected_region(self.get_selected_region())

    def row_activated(self, treeview, path, view_column):
        self.edit_person_clicked(None)

    def treeview_drag_data_get(self, widget, context, sel_data, info, time):
        """
        Provide the row index of the currently selected region so that
        drag_data_received can tell this is a reorder within the same list.
        """
        region = self.get_selected_region()
        if region is None:
            return
        row_from = self.regions.index(region)
        sel_data.set(REORDER_ATOM, 8, pickle.dumps(row_from))

    def reorder_drag_received(self, sel_data, x, y):
        """
        Handle a row of this treeview being dropped back onto itself,
        reordering self.regions accordingly.
        """
        try:
            row_from = pickle.loads(sel_data.get_data())
            if row_from < 0 or row_from >= len(self.regions):
                return
            region = self.regions[row_from]
            row_to = self.find_drop_row(x, y)
            self.move_region(row_from, row_to, region)
        except Exception:
            # A silent no-op here is indistinguishable from GTK simply
            # not registering the drop, so log the full traceback
            # rather than letting a reorder drag just appear to do
            # nothing with no clue why.
            LOG.exception("reorder_drag_received failed")

    def row_mouse_click(self, treeview, event):
        """
        Handle right mouse click on treeview.
        Show popup menu for row the same as for region.
        """
        button = event.get_button()[1]
        # right mouse button
        if button == 3:
            # change cursor position to apply row selection
            pthinfo = self.treeview.get_path_at_pos(event.x, event.y)
            if pthinfo is not None:
                path, col, cellx, celly = pthinfo
                self.treeview.grab_focus()
                self.treeview.set_cursor(path, col, 0)
                self.show_context_menu()
                # stop signal emission
                return True

    # ======================================================
    # helpers for list event handlers
    # ======================================================

    def get_selected_region(self):
        selection = self.treeview.get_selection()
        if selection:
            model, pathlist = selection.get_selected_rows()
            for path in pathlist:
                tree_iter = model.get_iter(path)
                i = model.get_value(tree_iter, 0)
                try:
                    return self.regions[i - 1]
                except:
                    return None
        return None

    # ======================================================
    # refreshing the list
    # ======================================================

    def name_as_of_date_for(self, media):
        """
        The date to select and display a person's name as of: the
        media's own date when it has a valid one, otherwise today --
        used both for the table (refresh_list()) and the "Swap with"
        context menu entries (prepare_context_menu()), so both always
        show the same name for the same person on the same photo.
        """
        media_date = media.get_date_object() if media else None
        if media_date is not None and media_date.get_valid():
            return media_date
        return Today()

    def apply_alternating_row_shading(self, *column_cell_pairs):
        """
        Lightly shades every other row of the region list.

        Deliberately not Gtk.TreeView.set_rules_hint() (deprecated
        since GTK 3.14, and even before that only did anything if the
        current theme chose to honor it) or CSS row:nth-child(even)
        selectors (support for which has historically been
        inconsistent across GTK3 versions/theme engines). Setting each
        cell renderer's own cell-background-rgba directly, based on
        the row's own index, always renders regardless of theme or
        GTK version.

        A mostly-transparent medium gray overlay is used rather than a
        fixed opaque color, so it stays neutral -- readable on both
        light and dark themes -- instead of a black overlay, which
        can read as muddy rather than a clean shade on dark themes.

        :param column_cell_pairs: Any number of (TreeViewColumn,
            CellRenderer) pairs to shade identically, so every column
            in a shaded row is shaded, not just one.
        """
        shade = Gdk.RGBA(0.5, 0.5, 0.5, 0.10)

        def cb(_column, cell, model, tree_iter, _data=None):
            index = model.get_path(tree_iter).get_indices()[0]
            cell.set_property("cell-background-set", index % 2 == 1)
            if index % 2 == 1:
                cell.set_property("cell-background-rgba", shade)

        for column, cell in column_cell_pairs:
            column.set_cell_data_func(cell, cb)

    def refresh_list(self):
        self.treestore.clear()
        media = self.get_current_object()
        media_date = media.get_date_object() if media else None
        # The name shown for each person is the one that was actually
        # in use as of the media's own date -- see get_name_at_date()
        # -- falling back to today when the media has no usable date
        # of its own, so a person's most current name is still shown
        # rather than an arbitrary historical one.
        name_as_of_date = self.name_as_of_date_for(media)
        self.column_person_age_header.set_text(
            self.format_person_age_header(media_date)
        )
        for i, region in enumerate(self.regions, start=1):
            if region.person:
                name = display_name_respecting_format(
                    get_name_at_date(region.person, name_as_of_date)
                )
                age = get_person_age(
                    region.person, self.dbstate.db, self.age_precision, media_date
                )
                age_is_suspicious = is_media_date_suspicious(
                    self.dbstate.db, region.person, media_date
                )
                person_age_markup = self.format_person_age_markup(
                    name, age, age_is_suspicious
                )
                metadata_clues = region.xmp_person

            elif hasattr(region, "xmp_person"):
                person_age_markup = ""
                metadata_clues = region.xmp_person
                if getattr(region, "xmp_whole_image", False):
                    metadata_clues = _("%s (whole photo, no region)") % metadata_clues
            else:
                person_age_markup = ""
                metadata_clues = ""
            thumbnail = self.safe_get_thumbnail(region, THUMBNAIL_IMAGE_SIZE)
            self.treestore.append(
                None, (i, thumbnail, person_age_markup, metadata_clues)
            )

    def format_person_age_header(self, media_date):
        """
        Builds the 2-line "Name" / "    Age on <date>" column header.
        The age line is meaningless without knowing what date it's
        calculated as of, so it's named explicitly; it's indented 4
        spaces to visually subordinate it to the Name line above,
        matching the per-row markup built by format_person_age_markup().
        """
        if media_date is not None and media_date.get_valid():
            date_text = date_displayer.display(media_date)
        else:
            date_text = _("undefined date")
        return "%s\n    %s" % (_("Name"), _("Age on %s") % date_text)

    def format_person_age_markup(self, name, age, age_is_suspicious):
        """
        Builds the Pango markup for a row's combined Person+Age cell:
        the person's name, then the age indented 4 spaces on its own
        line, coloured red when is_media_date_suspicious() flagged it
        (replacing the old separate Age column's foreground-set
        attribute, now that both live in a single cell).

        `age` is None whenever get_person_age() couldn't compute one
        at all (most commonly a freshly-added Person with no birth
        date yet) -- GLib.markup_escape_text() raises TypeError on
        None, so that's coerced to an empty string first rather than
        crashing the whole refresh mid-loop.
        """
        escaped_name = GLib.markup_escape_text(name or "")
        escaped_age = GLib.markup_escape_text(age or "")
        if age_is_suspicious:
            age_part = '<span foreground="red">%s</span>' % escaped_age
        else:
            age_part = escaped_age
        return "%s\n    %s" % (escaped_name, age_part)

    def safe_get_thumbnail(self, region, thumbnail_size):
        """
        Wraps SelectionWidget.get_thumbnail() with the same width/height
        check it already does, plus a check it is missing: its own
        resize_keep_aspect() computes the scaled size with integer
        division, which rounds down to 0 for a very thin/wide region
        (e.g. width 1000, height 1 scaling into a 50x50 box) and that 0
        then reaches gdk_pixbuf_scale_simple(), which logs a
        'dest_height > 0' (or width) GdkPixbuf-CRITICAL to the console.
        """
        width = region.x2 - region.x1
        height = region.y2 - region.y1
        if width < 1 or height < 1:
            return None
        target_x, target_y = thumbnail_size
        if width / height > target_x / target_y:
            scaled_height = target_x * height // width
            if scaled_height < 1:
                return None
        else:
            scaled_width = target_y * width // height
            if scaled_width < 1:
                return None
        return self.selection_widget.get_thumbnail(region, thumbnail_size)

    def refresh_selection(self):
        """
        Re-applies the currently selected region (self.selection_widget's
        own current-region state, which -- unlike the treeview's row
        selection -- survives refresh_list() clearing and rebuilding
        the treestore) everywhere via apply_selected_region(): the
        region list, the marquee, and the Caption panel highlight.
        Called after refresh_list() for that reason by main(),
        region_modified(), and region_created().
        """
        self.apply_selected_region(self.selection_widget.get_current())


# Average days per month, close enough for the plausibility check below.
AVG_MONTH_DAYS = 30.44


def is_media_date_suspicious(dbstate_db, person, media_date):
    """
    Returns True if media_date is more than 10 months before the
    person's fallback birthdate, or more than a month after their
    fallback death date -- flagging an age that suggests the photo's
    date, or the person tagged, may be wrong.
    """
    if media_date is None or not media_date.get_valid():
        return False
    media_sort = media_date.get_sort_value()

    birth = get_birth_or_fallback(dbstate_db, person)
    if birth:
        birth_date = birth.get_date_object()
        if birth_date and birth_date.get_valid():
            if birth_date.get_sort_value() - media_sort > 10 * AVG_MONTH_DAYS:
                return True

    death = get_death_or_fallback(dbstate_db, person)
    if death:
        death_date = death.get_date_object()
        if death_date and death_date.get_valid():
            if media_sort - death_date.get_sort_value() > AVG_MONTH_DAYS:
                return True

    return False


def get_person_age(person, dbstate_db, age_precision, media_date=None):
    """
    Function to get the person's age, calculated from the fallback
    birthdate. When media_date is a valid Date, the age is calculated
    as of that date (i.e. the person's age in the photo). Otherwise
    this falls back to today's date -- the same rule refresh_list()
    already applies to name selection (see name_as_of_date) -- rather
    than distinguishing a living person's current age from a deceased
    person's age at death.
    Returns string for age column.
    """
    birth = get_birth_or_fallback(dbstate_db, person)

    if birth:
        birth_date = birth.get_date_object()
        if birth_date and birth_date.get_valid():
            if media_date is not None and media_date.get_valid():
                as_of_date = media_date
            else:
                as_of_date = Today()
            age = as_of_date - birth_date
            return age.format(precision=age_precision)
    return None


def display_name_respecting_format(name):
    """
    Render a Name using its own "Display As" format, working around
    an apparent gap in Gramps 5.2's name-evaluation system: testing
    showed NameDisplay.display_name(name) silently falls back to the
    global default format -- ignoring a Name's own display_as -- for
    any Name that has no date set on it, whether that Name is a
    Person's primary name or an alternate. Since that happens even
    for an unmodified primary name (nothing in get_name_at_date()
    touches how a name gets rendered, only which Name object is
    chosen), the gap must live inside display_name() itself, not in
    this file -- so this bypasses it entirely rather than trying to
    work around whatever internal date logic causes it, using only
    the lower-level, purely mechanical pieces of the same public
    NameDisplay API: resolve display_as to a concrete format string
    ourselves (get_name_format()/get_default_format()), then apply it
    with format_str(), which does no format *selection* of its own.

    :param name: The Name instance to render.
    :returns: The formatted name string.
    """
    if name is None:
        return ""
    try:
        display_as = getattr(name, "display_as", 0) or 0
        if display_as == Name.DEF:
            # Name.DEF's own format_str is a permanent empty
            # placeholder (see get_name_format()'s "also_default"
            # entry) -- the *actual* format it stands for is whatever
            # get_default_format() currently points at.
            display_as = name_displayer.get_default_format()
        format_by_num = {
            num: fmt_str
            for num, _label, fmt_str, _active in name_displayer.get_name_format(
                also_default=False
            )
        }
        fmt_str = format_by_num.get(display_as) or format_by_num.get(
            name_displayer.get_default_format()
        )
        if not fmt_str:
            raise LookupError("no usable name format found")
        return name_displayer.format_str(name, fmt_str)
    except Exception:  # pylint: disable=broad-except
        # Never let a name-formatting corner case crash the gramplet
        # -- fall back to Gramps' own (possibly gap-affected)
        # resolution rather than showing nothing at all.
        LOG.exception("PhotoTagging: could not apply Name.display_as")
        return name_displayer.display_name(name)


def get_name_at_date(person, target_date):
    """
    Return the Name instance that was actually in use by a person as
    of a given date, i.e. the name display should reflect who they
    were called *at that point in their life* -- their birth name in
    a childhood photo, a married name in a later one -- rather than
    always their current primary name.

    Chooses among the primary name and every alternate name (each a
    Name, which -- like Person's birth/death events elsewhere in this
    file -- carries its own optional DateBase date) for the one with
    the latest date that is still on or before target_date, the same
    get_sort_value()-based comparison already used by
    is_media_date_suspicious()/get_person_age() above. Falls back to
    the primary name when no name has a usable date at all (by far
    the common case) or when target_date predates every dated name
    (e.g. a childhood photo, before any later name was adopted).

    :param person: The Person whose Name to select.
    :param target_date: The Date to select a Name as of -- typically
        the media's own date, or Today() when it has none.
    :returns: A Name instance.
    """
    primary_name = person.get_primary_name()
    target_sort = target_date.get_sort_value() if target_date else 0

    best_name = primary_name
    best_sort = -1
    for name in [primary_name] + list(person.get_alternate_names()):
        name_date = name.get_date_object()
        if name_date is None or not name_date.get_valid():
            continue
        name_sort = name_date.get_sort_value()
        if best_sort < name_sort <= target_sort:
            best_name = name
            best_sort = name_sort
    return best_name
