# Change Log (Photo Tagging gramplet)
[ReadMe](README.md) ● [Change Log](CHANGELOG.md) ● [XMP data](XMP_Region_Name.md) ● [Icon List](media/icons/ICONLIST.md) 

## What's New
Version 1.1.1 - Sep 2026

#### Metadata clues (renamed from "XMP Region Name")
- The column is now called **Metadata clues**, and can be shown or hidden with a new toolbar toggle button, without discarding anything it found.
- When a photo has no usable face-region metadata at all, the gramplet now falls back to the file's `Xmp.dc.subject` tag — a much more commonly supported, if less precise, list of names with no per-person position — rather than showing nothing. Names found this way are shown against the whole photo, labeled "*(whole photo, no region)*" so they're never mistaken for a real, positioned region.
- See [XMP data](XMP_Region_Name.md) for the full technical detail, including a real, now-fixed bug that could leave this column silently empty on some installs (a missing optional component of the underlying GExiv2 library, unrelated to the photo file itself).
- A context menu to "Transcribe list to a Note" will create a new (unsaved) Note for the Media object. The simplified list of XMP metadata is one subsection of the Note. 

#### Person and Age display
- The Person and Age columns are now one column, "Name", showing the person's name and their age on two lines.
- **The name shown is the one the person was actually using at the time of that photo** — their birth name in a childhood photo, a married name in a later one — chosen from their own Gramps Name records by the photo's date (or today's date, if the photo has none), and rendered using that specific Name record's own "Display As" format when one is set, not just whichever format is configured as your overall Gramps default.
- The age shown is now always calculated as of the photo's own date, or today's date if the photo has none — previously a photo with no date fell back to showing a deceased person's age at death instead; it now shows their age as of today consistently, matching how the name is chosen.

#### Right-click context menu
- New **See the person details** item, doing the same thing as double-clicking the row.
- "Set as active person" is now **Make the person active**.
- "Select" is now **Link**, and "Add" is now **Add a new person** — matching wording used elsewhere in Gramps for the same actions, and now used consistently for the equivalent toolbar buttons and dialog titles too.
- "Replace to *(name)*" is now **Swap with *(name)***, and — more importantly — now does what that name implies: it swaps person assignments between the two marquees involved, leaving both exactly where they are, rather than deleting the other person's own marquee and losing track of whoever was previously in the selected one.
- "Clear" is now **Clear Reference**, matching the toolbar button for the same action.
- New **Transcribe list to a Note** item — see below.

#### Transcribe list to a Note
- A new context menu action creates a Note attached to the photo — the same effect as clicking "create and add a new note" in the Media editor — pre-filled with:
  - The photo's title (bold), date, and Gramps ID (linked).
  - Every tagged person's name, semicolon-separated, each linked to their Gramps record. (Formatted to be the foundation of a caption.)
  - Any Metadata clues for people who aren't tagged yet, one per line.
  - The underlying row-to-person tagging order, with each ID linked and each person's name alongside it.
- The Note opens for you to review before saving, exactly like any other new Note.

#### Visual polish
- Alternating rows in the list are now lightly shaded for easier reading on longer lists, in a neutral gray that works on both light and dark Gramps themes.
- All "box"/"boxes" wording in the interface — tooltips, the settings dialog, menu items — now consistently says "marquee"/"marquees".
- The new "Show/Hide Metadata clues" toggle button now matches the existing "Show/Hide face marquees" button's convention: the default, data-showing state is a plain, unpressed icon, and only the non-default "hidden" state shows a pressed/highlighted button — previously the two toggle buttons used opposite conventions.

#### Stability fixes
- Fixed a real, confirmed cause of the Metadata clues column staying silently empty on some installs (see [XMP data](XMP_Region_Name.md) for the full writeup): the gramplet no longer depends on an optional Python convenience layer some GExiv2 packages don't include, and now logs a genuine, unexpected metadata-reading failure instead of discarding it with no trace, while still quietly ignoring the routine case of a non-photo file (such as an SVG icon) having no metadata to read.
- Fixed a crash when saving a newly-created person for a tagged marquee before giving them a birth date.
- Fixed a crash when swapping person assignments between two marquees (see "Swap with" above), caused by Gramps's own database-update notifications firing in the middle of the swap.
- Notes created by "Transcribe list to a Note" contain working links, rather than plain, unlinked text.

### Future objectives
* place holder marquees
* more flexibility in indexing (row/column? e.g., 7a, or G5)
* persistent Indexing (re-index options: automatic, on-demand
* "Common name" label overlays with CSS

---

Version 1.1.0 - 1 Sep 2026


#### Reordering tagged people
- You can now reorder the people tagged in a photo — drag and drop a row in the list, use the new Move Up/Down toolbar buttons or right-click menu, or press Alt+Up / Alt+Down.
- The row you just moved stays selected, so you can move it again right away without re-clicking it.
- Your custom order is saved and will still be there the next time you open that photo, or reopen Gramps — it's written efficiently (only when you leave the photo), not after every single move.

#### Age display
- The Age column now shows how old each person was *in that photo* (calculated from the photo's own date), instead of always showing their age as of today. If the photo has no date, it falls back to their age at death, or their current age if still living.
- If an age doesn't add up — the photo is dated more than about 10 months before the person was born, or more than a month after they died — that age is shown in red, flagging a possible wrong photo date or wrong person tagged.

#### Face marquee display
- New "Show/Hide face marquees" toggle button — temporarily hide all the outline boxes to see the photo clearly; it automatically turns boxes back on if you select a row or draw a new one.
- New "Show ID" toggle button (click repeatedly to cycle): show the row number in each box, show the person's Gramps ID instead, or show nothing.
- That label is now blue text on a white background (matching the box color) instead of yellow, and the row-number version is drawn extra large for easy reading.
- Both new toggle buttons are now the first two icons on the toolbar, and all toolbar icons are bigger (32×32) for visibility.

#### Refreshed and enlarged toolbar icons
- Several toolbar buttons now use new, clearer artwork instead of generic system icons that could look ambiguous or barely different from one another depending on your desktop theme: Select Person, Add Person, Clear Reference, and Edit Referenced Person all have distinct new icons, and Move Up/Down now use up/down sorting arrows that are easier to tell apart at a glance.
* ![Select existing Person](media/icons/gtk-edit.svg) 
* ![Add Person Marquee](media/icons/List-add.svg) 
* ![Remove Marquee](media/icons/List-remove.svg) 
* ![Edit Person](media/icons/gtk-edit.svg) 
* ![Move Up](media/icons/Gnome-view-sort-ascending.svg) 
* ![Move down](media/icons/Gnome-view-sort-descending.svg) 
* ![Zoom in](media/icons/gramps-zoom-in.svg) 
* ![Zoom out](media/icons/gramps-zoom-out.svg)  
* ![Face Detection](media/icons/gramps-face-detection.svg) 

#### Stability fixes
- Fixed a crash that could take down the whole photo view if a bundled icon file was missing from the install.
- Fixed an issue where the gramplet could fail to start, or pick up the wrong image-metadata library, on systems with more than one version of the underlying [GExiv2 library](https://wiki.gnome.org/Projects/gexiv2) installed.
- Fixed a couple of console warnings/glitches related to unusual face-box shapes and empty selections.
