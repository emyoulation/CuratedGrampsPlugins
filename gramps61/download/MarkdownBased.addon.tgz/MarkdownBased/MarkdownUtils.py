#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026  Brian McCullough
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

"""
MarkdownUtils  --  Reusable Markdown rendering library for Gramps add-ons.

Provides:
  - ``Segment``                 -- data model for a parsed text run
  - ``parse_markdown()``        -- convert Markdown text to a list of Segments
  - ``define_tags()``           -- create all Gtk.TextTag styles in a TextBuffer
  - ``inline_to_pango()``       -- convert inline Markdown to Pango markup (tables)
  - ``build_table_widget()``    -- build a Gtk.TreeView widget for a GFM table
  - ``resolve_icon_pixbuf()``   -- resolve a GTK/Gramps icon to a GdkPixbuf (Theme-aware)
  - ``list_icons_by_context()`` -- enumerate icon names from the live theme cascade
  - ``GRAMPS_ICONS``            -- short-name → GTK icon-name alias map
  - ``NAMESPACE_MAP``           -- Gramps object-type → DB getter / editor map
  - ``VIEW_NAMES``              -- lowercase category alias → canonical view name

Anchor / in-document navigation
--------------------------------
Headings carry an ``anchor`` attribute on their ``Segment``.  The anchor slug
is derived from the heading text using the same GitHub-Flavoured Markdown
algorithm:

  1. Lower-case the text.
  2. Remove everything that is not a letter, digit, space, or hyphen.
  3. Replace runs of whitespace with a single hyphen.

The caller (gramplet or other consumer) receives the anchor name via
``Segment.anchor`` and is responsible for placing a ``Gtk.TextMark`` in the
buffer at the corresponding position, then scrolling to that mark when the
user clicks an anchor link (``#anchor-slug``).

Icon-theme cascade awareness
----------------------------
:func:`resolve_icon_pixbuf` and :func:`list_icons_by_context` both call
:meth:`Gtk.IconTheme.get_default`, which returns the process-wide singleton
that GTK keeps in sync with the active theme at all times.  When the Gramps
Themes addon changes the GTK theme via
``Gtk.Settings.set_property("gtk-theme-name", …)``, GTK updates the
singleton's search paths in-place; every subsequent call to this module
automatically reflects the new cascade without any explicit cache invalidation.

Theme & Context Sync Alignment
-------------------------------
This version brings the pixel-rendering layer into synchronization with live
GTK widgets. By passing a widget's ``Gtk.StyleContext`` to ``resolve_icon_pixbuf``,
symbolic line-art variants inherit foreground, background, and state-based colors
directly from the active window workspace, preventing invisible or inverted icons
across light/dark mode variations while still permitting full-scale color imagery
for illustrative documentation text blocks.

:func:`resolve_icon_pixbuf` uses ``GENERIC_FALLBACK | USE_BUILTIN`` lookup
flags so it renders the identical pixel data that GTK widgets produce
internally, and never silently returns ``None`` for an icon that the GUI
itself would display.

Generated-by: Claude Sonnet 4.6 (Anthropic, claude-sonnet-4-6, release 2026-05)
Prompts: "restructure MarkdownDash gramplet — extract markdown handling into a
separate library module; add in-document anchor scroll navigation for header
links such as [label](#anchor-slug)"
Revision prompts: "update MarkdownUtils.py per MarkdownUtils_improvements.txt:
add GENERIC_FALLBACK|USE_BUILTIN lookup flags to resolve_icon_pixbuf; add
list_icons_by_context() public helper for IconBrowserGramplet enumeration;
implement theme context syncing for symbolic variants via load_symbolic_for_context."
Constraints: https://gramps-project.org/wiki/index.php/Howto:_Contribute_to_Gramps#AI_generated_code
             https://github.com/gramps-project/gramps/blob/master/AGENTS.md

Revised 20 Aug 2026  for bug fixes.
- More control over fallback to Symbolic icons
- Better support for image inset in tables
- enhanced to reduce redundant Markdown Rendering Code in Plugin Manager plus

Next target for fixes:
- reduction of endless warnings messages to console during scrolling:
    *** BUG ***
    In pixman_region32_init_rect: Invalid rectangle passed
    Set a breakpoint on '_pixman_log_error' to debug

    (gramps:1945501): Gtk-WARNING **: 19:30:30.532: gtk_widget_size_allocate():
    attempt to allocate widget with width 313 and height -7

Wishlist:
    search for string in Markdown text (stripped of formatting, lower case forced)
    support for showing normal/large thumbnail for the 1st Gallery object

"""
# ------------------------
# Python modules
# ------------------------
import os
import re
from typing import Callable

# ------------------------
# Gramps modules
# ------------------------
import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
gi.require_version("Pango", "1.0")
from gi.repository import Gdk, GdkPixbuf, Gtk, Pango

# ---------------------------------------------------------------------------
# Module-level logger
# ---------------------------------------------------------------------------
import logging

LOG = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
#
# Segment
#
# ---------------------------------------------------------------------------
class Segment:
    """One run of styled text to insert into a Gtk.TextBuffer.

    :param text:        Plain Unicode string to insert into the buffer.
    :param attrs:       List of tag-name strings (keys in the dict returned by
                        :func:`define_tags`) to apply to this run.
    :param url:         URI string that makes this run a clickable link, or
                        ``None``.
    :param image_path:  Filesystem path / URL for an embedded image, or
                        ``None``.
    :param gramps_icon: ``(icon_name, size, icon_style)`` tuple to embed a
        GTK theme icon
                        inline, or ``None``.
    :param table_data:  ``(columns, align, body_rows, sep_widths)`` tuple to
                        render a GFM table as a child widget, or ``None``.
    :param anchor:      GitHub-style anchor slug for heading segments so the
                        caller can place a ``Gtk.TextMark`` at this position.
                        ``None`` for non-heading segments.
    """

    __slots__ = (
        "text",
        "attrs",
        "url",
        "image_path",
        "gramps_icon",
        "table_data",
        "anchor",
    )

    def __init__(
        self,
        text: str,
        attrs: list | None = None,
        url: str | None = None,
        image_path: str | None = None,
        gramps_icon: tuple | None = None,
        table_data: tuple | None = None,
        anchor: str | None = None,
    ) -> None:
        """Initialise a Segment with text and optional rendering metadata."""
        self.text = text
        self.attrs = attrs or []
        self.url = url
        self.image_path = image_path
        self.gramps_icon = gramps_icon
        self.table_data = table_data
        self.anchor = anchor


# ---------------------------------------------------------------------------
#
# Inline parser helpers
#
# ---------------------------------------------------------------------------

# Inline token regex -- finds the first special construct in a string.
_INLINE_RE = re.compile(
    r"(?P<img>!\[(?P<img_alt>[^\]]*)\]\((?P<img_url>[^)]*)\))"
    r"|(?P<link>\[(?P<link_label>[^\]]+)\]\((?P<link_url>[^)]+)\))"
    r"|(?P<bold3>\*{3}(?P<bold3_t>.+?)\*{3})"
    r"|(?P<und3>_{3}(?P<und3_t>.+?)_{3})"
    r"|(?P<bold2>\*{2}(?P<bold2_t>.+?)\*{2})"
    r"|(?P<und2>_{2}(?P<und2_t>.+?)_{2})"
    r"|(?P<code>`(?P<code_t>[^`\n]+)`)"
    r"|(?P<strike>~~(?P<strike_t>.+?)~~)"
    r"|(?P<em1>(?<!\*)\*(?!\*)(?P<em1_t>[^*\n]+?)(?<!\*)\*(?!\*))"
    r"|(?P<em2>(?<!\w)_(?!_)(?P<em2_t>[^_\n]+?)(?<!_)_(?!\w))",
    re.DOTALL,
)

# Matches an HTML comment block, single- or multi-line: <!-- ... -->
_COMMENT_RE = re.compile(r"<!--(.*?)-->", re.DOTALL)


def _strip_hidden_comments(md_text: str) -> str:
    """Remove ``<!-- ... -->`` comment blocks from *md_text* before parsing.

    All HTML comments -- single- or multi-line -- are removed entirely so
    they never reach the TextBuffer. This is a *document-body* concern
    only: MarkdownDash's own leading title (``# Title`` on line 1) and
    layout-options directive (``<!-- key=value ... -->`` on line 2) are a
    separate, file-header convention consumed by that gramplet's own
    ``_parse_directives()`` *before* the remaining text is ever handed to
    :func:`parse_markdown` -- so this function never sees, and does not
    need to special-case, that directive line.

    :param md_text: Raw Markdown document text, before block parsing.
    :returns: *md_text* with all HTML comments removed.
    """

    def _replace(match: re.Match) -> str:
        del match  # unused; every comment is hidden unconditionally
        return ""

    return _COMMENT_RE.sub(_replace, md_text)


#: Accepted values for icon color-fallback control, used both by
#: :func:`resolve_icon_pixbuf`'s ``icon_style`` parameter and by the
#: optional third field of the inline ``gramps:icon:NAME[:SIZE[:STYLE]]``
#: Markdown syntax:
#:
#: - ``'auto'``     -- the previous fixed default: prefer the symbolic
#:                     (B&W) asset for icon sizes <=32px, prefer the
#:                     full-color asset above that; falls back to
#:                     whichever variant actually exists if the preferred
#:                     one is missing for that icon.
#: - ``'color'``    -- always prefer the full-color asset regardless of
#:                     size; falls back to symbolic only if no color
#:                     asset exists anywhere for that icon.
#: - ``'symbolic'`` -- always prefer the symbolic/B&W asset regardless of
#:                     size; falls back to color only if no symbolic
#:                     asset exists anywhere for that icon.
#:
#: An unrecognized value is treated as ``'auto'``.
ICON_STYLE_AUTO = "auto"
ICON_STYLE_COLOR = "color"
ICON_STYLE_SYMBOLIC = "symbolic"
_VALID_ICON_STYLES = {ICON_STYLE_AUTO, ICON_STYLE_COLOR, ICON_STYLE_SYMBOLIC}

#: Ambient default icon style for the current :func:`parse_markdown` call,
#: read by :func:`_parse_inline`'s image handling when a ``gramps:icon:``
#: reference doesn't specify its own ``:STYLE`` suffix. ``_parse_inline``
#: recurses through more than a dozen call sites (nested emphasis, links,
#: list items, blockquotes...), so this is set once at the top of
#: :func:`parse_markdown` and restored afterwards rather than threaded
#: through every one of those signatures individually. Safe under Gramps'
#: single-threaded GTK main-loop model; not safe if ``parse_markdown`` is
#: ever called concurrently from multiple threads.
_current_default_icon_style = ICON_STYLE_AUTO

#: Matches a Gramps inline icon image URL:
#: ``gramps:icon:NAME``, ``gramps:icon:NAME:SIZE``, or
#: ``gramps:icon:NAME:SIZE:STYLE`` (STYLE is one of :data:`_VALID_ICON_STYLES`).
#: Shared between :func:`_parse_inline` (regular TextBuffer flow) and
#: :func:`_extract_leading_icon` (table cells).
_GRAMPS_ICON_URL_RE = re.compile(
    r"^gramps:icon:([^:]+)(?::(\d+))?(?::(auto|color|symbolic))?$"
)


def _extract_leading_icon(
    text: str, default_icon_style: str = ICON_STYLE_AUTO
) -> tuple:
    """Pull the first ``gramps:icon:`` image reference out of *text*.

    A :class:`Gtk.TreeView` table cell can only display a single real
    ``GdkPixbuf.Pixbuf`` per column (via a paired ``CellRendererPixbuf`` +
    ``CellRendererText``, see :func:`build_table_widget`), so only the
    *first* Gramps icon reference in a cell becomes an actual rendered
    icon. Any additional image/icon references later in the same cell
    still render as italicized alt text via :func:`inline_to_pango`,
    unchanged from before.

    :param text:               Raw cell Markdown text.
    :param default_icon_style: :data:`ICON_STYLE_AUTO`/``'color'``/``'symbolic'``
        to use when the icon reference doesn't specify its own ``:STYLE``
        suffix (e.g. a document-wide default from a control-comment option).
    :returns: ``((icon_name, size, icon_style), remaining_text)`` if a
             Gramps icon reference was found and removed from *text*, else
             ``(None, text)`` with *text* unchanged.
    """
    for m in _INLINE_RE.finditer(text):
        if m.lastgroup != "img":
            continue
        gi_m = _GRAMPS_ICON_URL_RE.match(m.group("img_url"))
        if gi_m:
            icon_name = gi_m.group(1)
            size = int(gi_m.group(2)) if gi_m.group(2) else 16
            icon_style = gi_m.group(3) or default_icon_style
            remaining = (text[: m.start()] + text[m.end() :]).strip()
            return (icon_name, size, icon_style), remaining
    return None, text


def _esc(text: str) -> str:
    """XML-escape *text* for use inside Pango markup.

    :param text: Raw text string.
    :returns: XML-safe string.
    """
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _heading_anchor(text: str) -> str:
    """Derive a GitHub-style anchor slug from a heading's plain text.

    Algorithm:
      1. Strip inline Markdown tokens to get display text.
      2. Lower-case.
      3. Remove everything that is not a letter, digit, space, or hyphen.
      4. Replace runs of whitespace with a single ``-``.

    :param text: Raw heading text (may contain inline Markdown).
    :returns: Anchor slug string.
    """
    plain = re.sub(r"[*_`~\[\]!]", "", text)
    plain = re.sub(r"\(([^)]*)\)", "", plain)
    plain = plain.lower()
    plain = re.sub(r"[^\w\s-]", "", plain, flags=re.UNICODE)
    plain = re.sub(r"\s+", "-", plain.strip())
    return plain


# ---------------------------------------------------------------------------
#
# _parse_inline
#
# ---------------------------------------------------------------------------
def _parse_inline(text: str, base_attrs: tuple = ()) -> list[Segment]:
    """Split *text* into Segments, detecting inline Markdown constructs.

    :param text:       Input text that may contain inline Markdown.
    :param base_attrs: Tuple of tag names already active for this block
                       (e.g. ``('heading1',)`` for a heading line).
    :returns: List of :class:`Segment` objects.
    """
    segments: list[Segment] = []
    pos = 0
    base = list(base_attrs)

    while pos < len(text):
        m = _INLINE_RE.search(text, pos)
        if not m:
            tail = text[pos:]
            if tail:
                segments.append(Segment(tail, base[:]))
            break

        before = text[pos : m.start()]
        if before:
            segments.append(Segment(before, base[:]))

        kind = m.lastgroup

        if kind == "img":
            alt = m.group("img_alt") or m.group("img_url")
            url = m.group("img_url")
            gi_m = _GRAMPS_ICON_URL_RE.match(url)
            if gi_m:
                icon_name = gi_m.group(1)
                size = int(gi_m.group(2)) if gi_m.group(2) else 16
                icon_style = gi_m.group(3) or _current_default_icon_style
                segments.append(
                    Segment(
                        alt or icon_name,
                        base[:],
                        gramps_icon=(icon_name, size, icon_style),
                    )
                )
            else:
                segments.append(
                    Segment(alt or url, base + ["image_link"], image_path=url)
                )

        elif kind == "link":
            label = m.group("link_label")
            url = m.group("link_url")
            if url.startswith("#"):
                inner = _parse_inline(label, base + ["anchor_link"])
                for seg in inner:
                    seg.url = url
                segments.extend(inner)
            elif url.startswith("gramps:nav:") or url.startswith("gramps:edit:"):
                inner = _parse_inline(label, base + ["gramps_link"])
                for seg in inner:
                    seg.url = url
                segments.extend(inner)
            else:
                inner = _parse_inline(label, base + ["hyperlink"])
                for seg in inner:
                    seg.url = url
                segments.extend(inner)

        elif kind in ("bold3", "und3"):
            t = m.group("bold3_t") if kind == "bold3" else m.group("und3_t")
            segments.extend(_parse_inline(t, base + ["bold", "italic"]))

        elif kind in ("bold2", "und2"):
            t = m.group("bold2_t") if kind == "bold2" else m.group("und2_t")
            segments.extend(_parse_inline(t, base + ["bold"]))

        elif kind == "code":
            segments.append(Segment(m.group("code_t"), base + ["code_inline"]))

        elif kind == "strike":
            segments.extend(_parse_inline(m.group("strike_t"), base + ["strike"]))

        elif kind in ("em1", "em2"):
            t = m.group("em1_t") if kind == "em1" else m.group("em2_t")
            segments.extend(_parse_inline(t, base + ["italic"]))

        pos = m.end()

    return segments


# ---------------------------------------------------------------------------
#
# parse_markdown  (block parser)
#
# ---------------------------------------------------------------------------
def parse_markdown(
    md_text: str, default_icon_style: str = ICON_STYLE_AUTO
) -> list[Segment]:
    """Parse a Markdown document into a flat list of :class:`Segment` objects.

    Supported block constructs:
      - ATX headings (``# H1`` … ``###### H6``) with anchor slugs
      - Setext headings (underlined with ``=`` or ``-``)
      - Fenced code blocks (backtick or tilde)
      - GFM tables
      - Blockquotes
      - Unordered and ordered lists (with nesting)
      - Horizontal rules (Width tuned to 25 to protect narrow responsive columns)
      - Blank lines and paragraphs

    Heading :class:`Segment` objects carry a non-``None`` ``anchor`` attribute
    equal to the GitHub-style anchor slug so the caller can place a
    ``Gtk.TextMark`` for in-document scroll navigation.

    :param md_text: Full Markdown document text.
    :param default_icon_style: :data:`ICON_STYLE_AUTO` (default),
        ``'color'``, or ``'symbolic'`` -- applies to every
        ``gramps:icon:NAME[:SIZE]`` reference in the document that doesn't
        specify its own ``:STYLE`` suffix. Typically sourced from a
        document-wide control-comment option (e.g. MarkdownDash's
        ``<!-- icon_style=color -->``) rather than hardcoded by the caller.
    :returns: List of :class:`Segment` objects.
    """
    global _current_default_icon_style
    if default_icon_style not in _VALID_ICON_STYLES:
        default_icon_style = ICON_STYLE_AUTO
    _current_default_icon_style = default_icon_style

    md_text = _strip_hidden_comments(md_text)
    lines = md_text.splitlines()
    segments: list[Segment] = []
    in_code = False
    code_lang = ""
    code_lines: list[str] = []

    def add(
        text: str,
        attrs: tuple = (),
        url: str | None = None,
        image_path: str | None = None,
    ) -> None:
        """Append a plain :class:`Segment` (no anchor) to *segments*."""
        if text:
            segments.append(Segment(text, list(attrs), url, image_path))

    def add_heading(raw_text: str, level: int) -> None:
        """Parse heading inline content and append Segments with anchor set.

        The *first* segment for a heading carries the anchor slug; subsequent
        segments (from inline parsing) inherit ``anchor=None`` because the mark
        only needs to be placed at the start of the heading run.

        :param raw_text: The raw heading text (without the ``#`` prefix).
        :param level:    Heading level 1–6.
        """
        tag_name = "heading{}".format(level)
        slug = _heading_anchor(raw_text)
        inline_segs = _parse_inline(raw_text.strip(), (tag_name,))
        if inline_segs:
            inline_segs[0].anchor = slug
        segments.extend(inline_segs)
        add("\n\n")

    def flush_code() -> None:
        """Emit accumulated fenced-code-block lines as Segments."""
        lang = " ({})".format(code_lang) if code_lang else ""
        add("--- code{} ---\n".format(lang), ("code_fence_marker",))
        for cl in code_lines:
            add(cl + "\n", ("code_block",))
        add("--- end code ---\n\n", ("code_fence_marker",))
        code_lines.clear()

    def is_table_separator(line: str) -> bool:
        """Return ``True`` if *line* is a GFM table separator (``|---|:---:|``)."""
        s = line.strip()
        if not s.startswith("|") and "|" not in s:
            return False
        return bool(re.match(r"^[\|\s\-:]+$", s))

    def parse_table_row(line: str) -> list[str]:
        """Split a pipe-delimited table row into cell strings.

        :param line: A raw table row line.
        :returns: List of cell content strings.
        """
        s = line.strip()
        if s.startswith("|"):
            s = s[1:]
        if s.endswith("|"):
            s = s[:-1]
        return [c.strip() for c in s.split("|")]

    def flush_table(
        header_row: list[str],
        body_rows: list[list[str]],
        align: list[str],
        sep_widths: list[int],
    ) -> None:
        """Emit a single ``table_data`` Segment rendered as a GTK TreeView.

        :param header_row: List of header cell strings.
        :param body_rows:  List of rows, each a list of cell strings.
        :param align:      Per-column alignment: ``'left'``, ``'center'``, or
                           ``'right'``.
        :param sep_widths: Per-column dash count from the GFM separator row.
        """
        ncols = max(len(header_row), max((len(r) for r in body_rows), default=0))
        while len(header_row) < ncols:
            header_row.append("")
        for r in body_rows:
            while len(r) < ncols:
                r.append("")
        segments.append(
            Segment("", table_data=(header_row, align, body_rows, sep_widths))
        )
        add("\n")

    i = 0
    while i < len(lines):
        raw = lines[i]

        # ── fenced code block ────────────────────────────────────────────
        if fence := re.match(r"^(`{3,}|~{3,})(.*)", raw):
            if not in_code:
                in_code = True
                code_lang = fence.group(2).strip()
                i += 1
                continue
        if in_code:
            if re.match(r"^(`{3,}|~{3,})\s*$", raw):
                in_code = False
                flush_code()
            else:
                code_lines.append(raw)
            i += 1
            continue

        # ── GFM table ────────────────────────────────────────────────────
        if "|" in raw and i + 1 < len(lines) and is_table_separator(lines[i + 1]):
            header_row = parse_table_row(raw)
            sep_cells = parse_table_row(lines[i + 1])

            if len(header_row) != len(sep_cells):
                # Malformed table: the header and separator rows (the
                # "first 2 rows" of a GFM table) disagree on column
                # count. flush_table below pads header_row/body_rows up
                # to ncols = max(...) when they're short, but align/
                # sep_widths are sized only from sep_cells and were
                # never given the same treatment -- so build_table_widget
                # indexing align[ci]/sep_widths[ci] up to that wider
                # ncols raised IndexError there. Because parse_markdown
                # builds this whole document's segment list in one call,
                # before MarkdownDash._render's per-segment loop ever
                # starts, that IndexError aborted the *entire* document,
                # not just this one table.
                #
                # Rather than guess how to reconcile the mismatched
                # counts into a real table, render this table's own raw
                # lines as plain (monospace) text -- preserving its
                # original pipe/dash layout so the malformed markup
                # itself stays visible and diagnosable -- and keep
                # parsing the rest of the document normally.
                table_lines = [raw, lines[i + 1]]
                j = i + 2
                while j < len(lines) and "|" in lines[j] and lines[j].strip():
                    table_lines.append(lines[j])
                    j += 1
                for table_line in table_lines:
                    add(table_line + "\n", ("code_block",))
                add("\n")
                i = j
                continue

            align: list[str] = []
            sep_widths: list[int] = []
            for sc in sep_cells:
                sc = sc.strip()
                sep_widths.append(sc.count("-"))
                if sc.startswith(":") and sc.endswith(":"):
                    align.append("center")
                elif sc.endswith(":"):
                    align.append("right")
                else:
                    align.append("left")
            i += 2
            body_rows: list[list[str]] = []
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                body_rows.append(parse_table_row(lines[i]))
                i += 1
            flush_table(header_row, body_rows, align, sep_widths)
            continue

        # ── blockquote ───────────────────────────────────────────────────
        if bq := re.match(r"^>\s?(.*)", raw):
            add("│ ", ("blockquote_bar",))
            segments.extend(_parse_inline(bq.group(1), ("blockquote", "italic")))
            add("\n")
            i += 1
            continue

        # ── setext H1 ────────────────────────────────────────────────────
        if i + 1 < len(lines) and re.match(r"^=+\s*$", lines[i + 1]) and raw.strip():
            add_heading(raw.strip(), 1)
            i += 2
            continue

        # ── setext H2 ────────────────────────────────────────────────────
        if i + 1 < len(lines) and re.match(r"^-+\s*$", lines[i + 1]) and raw.strip():
            add_heading(raw.strip(), 2)
            i += 2
            continue

        # ── ATX headings ─────────────────────────────────────────────────
        if h := re.match(r"^(#{1,6})\s+(.*)", raw):
            add_heading(h.group(2).rstrip("# ").strip(), len(h.group(1)))
            i += 1
            continue

        # ── horizontal rule ──────────────────────────────────────────────
        if re.match(r"^(\*{3,}|-{3,}|_{3,})\s*$", raw):
            add("─" * 25 + "\n\n", ("hr",))
            i += 1
            continue

        # ── unordered list ───────────────────────────────────────────────
        if ul := re.match(r"^(\s*)([-*+])\s+(.*)", raw):
            depth = len(ul.group(1)) // 2
            add("    " * depth + "\u2022 ", ("list_bullet",))
            segments.extend(_parse_inline(ul.group(3)))
            add("\n")
            i += 1
            continue

        # ── ordered list ─────────────────────────────────────────────────
        if ol := re.match(r"^(\s*)(\d+)\.\s+(.*)", raw):
            depth = len(ol.group(1)) // 2
            add("    " * depth + ol.group(2) + ". ", ("list_bullet",))
            segments.extend(_parse_inline(ol.group(3)))
            add("\n")
            i += 1
            continue

        # ── blank line ───────────────────────────────────────────────────
        if raw.strip() == "":
            add("\n")
            i += 1
            continue

        # ── paragraph line ───────────────────────────────────────────────
        segments.extend(_parse_inline(raw))
        add("\n")
        i += 1

    if in_code and code_lines:
        flush_code()

    return segments


# ---------------------------------------------------------------------------
#
# define_tags
#
# ---------------------------------------------------------------------------
def define_tags(buf: Gtk.TextBuffer) -> dict[str, Gtk.TextTag]:
    """Create all rendering :class:`Gtk.TextTag` objects inside *buf*.

    Tags are created via ``buf.create_tag()`` so constructor keyword arguments
    automatically activate the corresponding ``-set`` flags.  All tags are also
    stored in the buffer's tag table and returned as a name-keyed dict.

    :param buf: The :class:`Gtk.TextBuffer` that will own the tags.
    :returns: ``dict`` mapping tag-name strings to :class:`Gtk.TextTag` objects.
    """
    W_BOLD = Pango.Weight.BOLD
    S_ITALIC = Pango.Style.ITALIC
    U_SINGLE = Pango.Underline.SINGLE

    tags: dict[str, Gtk.TextTag] = {}

    def tag(name: str, **kw) -> Gtk.TextTag:
        """Create a named tag in *buf* and store it in *tags*."""
        tags[name] = buf.create_tag(name, **kw)
        return tags[name]

    # Headings
    tag("heading1", weight=W_BOLD, scale=2.0, foreground="#111111")
    tag("heading2", weight=W_BOLD, scale=1.6, foreground="#111111")
    tag("heading3", weight=W_BOLD, scale=1.3, foreground="#222222")
    tag("heading4", weight=W_BOLD, scale=1.1, foreground="#222222")
    tag("heading5", weight=W_BOLD, scale=1.0, foreground="#333333")
    tag("heading6", weight=W_BOLD, scale=0.9, foreground="#555555")

    # Block structural
    tag("hr", foreground="#bbbbbb")
    tag(
        "blockquote",
        foreground="#555555",
        style=S_ITALIC,
        left_margin=28,
        indent=-28,
        pixels_above_lines=2,
        pixels_below_lines=2,
    )
    tag("blockquote_bar", foreground="#aaaaaa", weight=W_BOLD)
    tag(
        "code_block",
        family="Monospace",
        foreground="#222222",
        background="#f5f5f5",
        paragraph_background="#f5f5f5",
    )
    tag(
        "code_fence_marker",
        family="Monospace",
        foreground="#888888",
        background="#e8e8e8",
        paragraph_background="#e8e8e8",
    )
    tag("list_bullet", foreground="#555555", weight=W_BOLD)

    # Inline emphasis
    tag("bold", weight=W_BOLD)
    tag("italic", style=S_ITALIC)
    tag("strike", strikethrough=True)
    tag("code_inline", family="Monospace", foreground="#333333", background="#f0f0f0")

    # Interactive (visual only -- click handling is done by the consumer)
    tag("hyperlink", foreground="#0055cc", underline=U_SINGLE)
    tag("image_link", foreground="#0077aa", underline=U_SINGLE, background="#eef4ff")
    tag("gramps_link", foreground="#8800aa", underline=U_SINGLE, background="#f5eeff")
    tag("anchor_link", foreground="#006633", underline=U_SINGLE)

    return tags


# Per-link tag colors, keyed by link style. Distinct from define_tags'
# fixed-name style tags above: every individual link gets its own
# uniquely-named Gtk.TextTag (see render_markdown below), since a click/
# hover handler needs to tell exactly *which* link occurrence was under
# the pointer, not just that some "hyperlink"-styled text was -- so
# these colors are looked up by style name each time a new tag is
# created, rather than being one shared, reusable tag per style the way
# bold/italic/etc. are.
_LINK_STYLE_COLOURS: dict[str, tuple[str, str | None]] = {
    "hyperlink": ("#0055cc", None),
    "gramps_link": ("#8800aa", "#f5eeff"),
    "image_link": ("#0077aa", "#eef4ff"),
    "anchor_link": ("#006633", None),
    "mailto_link": ("#007755", None),
    "file_link": ("#885500", "#fff8ee"),
    "md_link": ("#006688", "#eaf6fb"),
}


def _insert_image_into_buffer(
    buf: Gtk.TextBuffer,
    it: Gtk.TextIter,
    tags: dict[str, Gtk.TextTag],
    img_path: str,
    alt_text: str,
    max_width: int = 560,
    center: bool = False,
    show_caption: bool = True,
    add_trailing_newline: bool = True,
) -> bool:
    """
    Insert a local image file into *buf* at *it*, scaled to fit.

    Shared by every :func:`render_markdown` caller (the embedded
    MarkdownDash gramplet, its standalone reader window, and Plugin
    Manager *plus*'s own Details/README pane *and* its small thumbnail-
    preview pane) so a wide image is capped at the same practical width
    everywhere, rather than each keeping its own copy of this scaling
    arithmetic — the last three of those differ only in *how* the
    resulting image is framed (centered thumbnail vs. left-aligned
    inline figure, captioned or not), which the three parameters below
    cover.

    :param buf: the buffer to insert into
    :param it: insertion point (the buffer's own end iter)
    :param tags: this buffer's style tags (see :func:`define_tags`) --
                 used for the optional caption's ``blockquote`` styling
    :param img_path: local filesystem path to the image file
    :param alt_text: the image's Markdown alt text, shown as a caption
                      underneath when present and *show_caption*
    :param max_width: pixel width to scale down to if the image is wider
    :param center: center the image (and its caption, if any)
                    horizontally, rather than the buffer's normal
                    left-aligned flow -- for a small standalone preview
                    thumbnail rather than an inline document figure
    :param show_caption: show *alt_text* as a caption underneath the
                          image; ``False`` for a plain thumbnail with no
                          accompanying text
    :param add_trailing_newline: insert a newline after the image (and
                                  before its caption, if shown); ``False``
                                  for a thumbnail that's the buffer's
                                  only content, where trailing
                                  whitespace would just waste space
    :returns: ``True`` if the image was inserted, ``False`` on any
               failure (caller falls back to a text placeholder)
    """
    try:
        pixbuf = GdkPixbuf.Pixbuf.new_from_file(img_path)
        width, height = pixbuf.get_width(), pixbuf.get_height()
        if width > max_width:
            height = int(height * max_width / width)
            width = max_width
            pixbuf = pixbuf.scale_simple(width, height, GdkPixbuf.InterpType.BILINEAR)
        image_start = buf.create_mark(None, it, True)
        buf.insert_pixbuf(it, pixbuf)
        if center:
            center_tag = buf.create_tag(None, justification=Gtk.Justification.CENTER)
            buf.apply_tag(center_tag, buf.get_iter_at_mark(image_start), it)
        buf.delete_mark(image_start)
        if add_trailing_newline:
            buf.insert(it, "\n")
        caption_tag = tags.get("blockquote")
        if show_caption and alt_text and caption_tag:
            start_mark = buf.create_mark(None, it, True)
            buf.insert(it, alt_text + "\n")
            start_it = buf.get_iter_at_mark(start_mark)
            buf.apply_tag(caption_tag, start_it, it)
            buf.delete_mark(start_mark)
        return True
    except Exception:  # pylint: disable=broad-except
        LOG.debug("Could not insert image: %s", img_path, exc_info=True)
        return False


def render_markdown(
    textview: Gtk.TextView,
    md_text: str,
    resolve_path: Callable[[str], str] | None = None,
    image_max_width: int = 560,
    center_images: bool = False,
    show_image_captions: bool = True,
    image_adds_newline: bool = True,
    default_icon_style: str = ICON_STYLE_AUTO,
) -> dict:
    """
    Render *md_text* into a fresh :class:`Gtk.TextBuffer` on *textview*.

    The shared rendering engine behind every plugin that displays
    rendered Markdown in a :class:`Gtk.TextView`: parses *md_text* (via
    :func:`parse_markdown`) and fills a fresh buffer with styled text,
    inline images, ``gramps:icon:`` pixbufs, GFM tables (via
    :func:`build_table_widget`), heading anchors, and seven kinds of
    clickable link (plain ``hyperlink``, ``gramps_link``, ``anchor_link``,
    ``image_link`` for a broken/missing image, ``mailto_link``,
    ``file_link``, and ``md_link`` for a bare relative reference that
    resolves to another local ``.md`` file) — the same way in every
    caller, so they can't silently drift out of sync with each other one
    bugfix at a time the way separately-maintained copies of this same
    logic once did.

    Callers still own hover/click handling themselves (this function
    only builds the buffer and hands back what's needed for that, it
    doesn't connect any signals) — see :func:`markdown_link_at` for the
    matching lookup half.

    :param textview: the view whose buffer is (re)built; also the widget
                      any table's :func:`build_table_widget` result is
                      attached to via ``add_child_at_anchor``
    :param md_text: document text to render (already locale-resolved and
                     directive-stripped by the caller, if applicable)
    :param resolve_path: optional callable resolving a relative image
                          path or bare (schemeless) link reference
                          against the document's own base directory;
                          defaults to a no-op (paths/references are only
                          ever treated as already-resolved/absolute)
    :param image_max_width: pixel width local images are scaled down to
                             fit, if wider (see
                             :func:`_insert_image_into_buffer`)
    :param center_images: center inline images (and their captions);
                           see :func:`_insert_image_into_buffer`
    :param show_image_captions: show each image's alt text underneath it
                                 as a caption; see
                                 :func:`_insert_image_into_buffer`
    :param image_adds_newline: insert a newline after each image; see
                                :func:`_insert_image_into_buffer`
    :param default_icon_style: :data:`ICON_STYLE_AUTO` (default),
                                ``'color'``, or ``'symbolic'`` -- the
                                document-wide default for any
                                ``gramps:icon:NAME[:SIZE]`` reference
                                that doesn't specify its own ``:STYLE``
                                suffix
    :returns: ``{"tags": ..., "link_uris": ..., "anchor_marks": ...}`` --
              ``tags`` is :func:`define_tags`'s own return value;
              ``link_uris`` maps each per-link tag's own name to
              ``(uri, style)``, for :func:`markdown_link_at`;
              ``anchor_marks`` maps each heading's anchor slug to the
              :class:`Gtk.TextMark` at its position, for in-document
              "jump to heading" navigation
    """
    if resolve_path is None:
        resolve_path = lambda path: path  # noqa: E731

    buf = Gtk.TextBuffer()
    textview.set_buffer(buf)

    tags = define_tags(buf)
    link_uris: dict[str, tuple[str, str]] = {}
    anchor_marks: dict[str, Gtk.TextMark] = {}
    link_counter = [0]

    def make_link_tag(style: str, uri: str) -> Gtk.TextTag:
        link_counter[0] += 1
        name = f"_link_{link_counter[0]}"
        fg, bg = _LINK_STYLE_COLOURS.get(style, _LINK_STYLE_COLOURS["hyperlink"])
        kw: dict = {"foreground": fg, "underline": Pango.Underline.SINGLE}
        if bg:
            kw["background"] = bg
        new_tag = buf.create_tag(name, **kw)
        link_uris[name] = (uri, style)
        return new_tag

    segments = parse_markdown(md_text, default_icon_style=default_icon_style)
    it = buf.get_end_iter()
    current_style_ctx = textview.get_style_context()

    for seg in segments:
        if seg.table_data:
            columns, align, body_rows, sep_widths = seg.table_data
            tbl_widget = build_table_widget(
                columns,
                align,
                body_rows,
                sep_widths,
                default_icon_style=default_icon_style,
            )
            anchor = buf.create_child_anchor(it)
            textview.add_child_at_anchor(tbl_widget, anchor)
            tbl_widget.show_all()

        elif seg.gramps_icon:
            icon_name, size, icon_style = seg.gramps_icon
            pixbuf = resolve_icon_pixbuf(
                icon_name, size, style_context=current_style_ctx, icon_style=icon_style
            )
            if pixbuf:
                buf.insert_pixbuf(it, pixbuf)
            else:
                start_mark = buf.create_mark(None, it, True)
                buf.insert(it, f"[{icon_name}]")
                start_it = buf.get_iter_at_mark(start_mark)
                quote_tag = tags.get("blockquote")
                if quote_tag:
                    buf.apply_tag(quote_tag, start_it, it)
                buf.delete_mark(start_mark)

        elif seg.image_path:
            img_path = resolve_path(seg.image_path)
            inserted = False
            if os.path.isfile(img_path):
                inserted = _insert_image_into_buffer(
                    buf,
                    it,
                    tags,
                    img_path,
                    seg.text,
                    image_max_width,
                    center=center_images,
                    show_caption=show_image_captions,
                    add_trailing_newline=image_adds_newline,
                )
            if not inserted:
                display = f"[image: {seg.text or seg.image_path}]"
                link_tag = make_link_tag("image_link", seg.image_path)
                start_mark = buf.create_mark(None, it, True)
                buf.insert(it, display)
                start_it = buf.get_iter_at_mark(start_mark)
                buf.apply_tag(link_tag, start_it, it)
                buf.delete_mark(start_mark)

        elif seg.url:
            resolved_url = seg.url
            if seg.url.startswith("mailto:"):
                style = "mailto_link"
            elif seg.url.startswith("file://"):
                style = "file_link"
            elif seg.url.startswith("#"):
                style = "anchor_link"
            elif seg.url.startswith("gramps:"):
                style = "gramps_link"
            elif seg.url.startswith("image:"):
                style = "image_link"
            elif seg.url.startswith(("http://", "https://")):
                style = "hyperlink"
            else:
                # A bare relative reference (e.g. a README's own
                # navigation link to a sibling doc file) has no scheme
                # at all. Opening it as-is via
                # Gio.AppInfo.launch_default_for_uri()/xdg-open resolves
                # it against the *process's* current working directory,
                # not this document's own folder -- producing a
                # file:///home/<user>/... "No such file or directory"
                # error. Resolve it against the caller's own base
                # directory instead; if that lands on another local
                # .md file, the caller can navigate to it in-pane
                # instead of shelling out to the OS.
                candidate = resolve_path(seg.url)
                if candidate != seg.url and os.path.isfile(candidate):
                    resolved_url = candidate
                    style = (
                        "md_link" if candidate.lower().endswith(".md") else "file_link"
                    )
                else:
                    style = "hyperlink"
            link_tag = make_link_tag(style, resolved_url)
            start_mark = buf.create_mark(None, it, True)
            buf.insert(it, seg.text)
            start_it = buf.get_iter_at_mark(start_mark)
            buf.apply_tag(link_tag, start_it, it)
            buf.delete_mark(start_mark)

            if seg.anchor:
                anchor_marks[seg.anchor] = buf.create_mark(
                    f"anchor:{seg.anchor}", start_it, True
                )

        else:
            start_mark = buf.create_mark(None, it, True)
            buf.insert(it, seg.text)
            start_it = buf.get_iter_at_mark(start_mark)

            if seg.anchor:
                anchor_marks[seg.anchor] = buf.create_mark(
                    f"anchor:{seg.anchor}", start_it, True
                )

            for attr in seg.attrs:
                attr_tag = tags.get(attr)
                if attr_tag:
                    buf.apply_tag(attr_tag, start_it, it)
            buf.delete_mark(start_mark)

        it = buf.get_end_iter()

    return {"tags": tags, "link_uris": link_uris, "anchor_marks": anchor_marks}


def markdown_link_at(
    textview: Gtk.TextView, link_uris: dict[str, tuple[str, str]], x: int, y: int
) -> tuple[str | None, str | None]:
    """
    Return the ``(style, uri)`` of the link under widget point *(x, y)*.

    The matching lookup half of :func:`render_markdown`'s own
    ``link_uris`` return value — call this from a ``"motion-notify-
    event"``/``"button-press-event"`` handler on the same *textview* to
    drive hover-cursor switching and click-to-open, the same way in
    every caller.

    :param textview: the same view :func:`render_markdown` was called on
    :param link_uris: the ``"link_uris"`` dict :func:`render_markdown`
                       returned
    :param x: widget-relative pointer X, from the GDK event
    :param y: widget-relative pointer Y, from the GDK event
    :returns: ``(style, uri)`` if a link tag covers this point, else
              ``(None, None)``
    """
    buf_x, buf_y = textview.window_to_buffer_coords(Gtk.TextWindowType.WIDGET, x, y)
    it = textview.get_iter_at_position(buf_x, buf_y)[1]
    for text_tag in it.get_tags():
        name = text_tag.get_property("name")
        entry = link_uris.get(name)
        if entry is not None:
            uri, style = entry
            return style, uri
    return None, None


# ---------------------------------------------------------------------------
#
# inline_to_pango  (used for table cell rendering)
#
# ---------------------------------------------------------------------------
def inline_to_pango(text: str) -> str:
    """Convert inline Markdown in *text* to a Pango markup string.

    Handles: ``**bold**``, ``*italic*``, ``***bold-italic***``, `` `code` ``,
    ``~~strike~~``, ``[label](url)`` links, and plain text.  Images inside
    table cells are shown as their alt text in italics.  The result is always
    XML-safe.

    :param text: Inline Markdown text.
    :returns: Pango markup string.
    """
    result: list[str] = []
    pos = 0

    while pos < len(text):
        m = _INLINE_RE.search(text, pos)
        if not m:
            result.append(_esc(text[pos:]))
            break
        if m.start() > pos:
            result.append(_esc(text[pos : m.start()]))
        kind = m.lastgroup
        if kind == "img":
            alt = m.group("img_alt") or m.group("img_url")
            result.append("<i>{}</i>".format(_esc(alt)))
        elif kind == "link":
            label = m.group("link_label")
            result.append(
                '<span foreground="#0055cc" underline="single">{}</span>'.format(
                    inline_to_pango(label)
                )
            )
        elif kind in ("bold3", "und3"):
            t = m.group("bold3_t") if kind == "bold3" else m.group("und3_t")
            result.append("<b><i>{}</i></b>".format(inline_to_pango(t)))
        elif kind in ("bold2", "und2"):
            t = m.group("bold2_t") if kind == "bold2" else m.group("und2_t")
            result.append("<b>{}</b>".format(inline_to_pango(t)))
        elif kind == "code":
            result.append("<tt>{}</tt>".format(_esc(m.group("code_t"))))
        elif kind == "strike":
            result.append("<s>{}</s>".format(inline_to_pango(m.group("strike_t"))))
        elif kind in ("em1", "em2"):
            t = m.group("em1_t") if kind == "em1" else m.group("em2_t")
            result.append("<i>{}</i>".format(inline_to_pango(t)))
        else:
            result.append(_esc(m.group(0)))
        pos = m.end()

    return "".join(result)


# ---------------------------------------------------------------------------
#
# build_table_widget
#
# ---------------------------------------------------------------------------
def build_table_widget(
    columns: list[str],
    align: list[str],
    body_rows: list[list[str]],
    sep_widths: list[int] | None = None,
    default_icon_style: str = ICON_STYLE_AUTO,
) -> Gtk.Frame:
    """Return a :class:`Gtk.Frame` containing a :class:`Gtk.TreeView` for a GFM table.

    Each cell's raw Markdown is rendered in two parts: the first
    ``![...](gramps:icon:...)`` reference (if any) becomes a real
    ``GdkPixbuf.Pixbuf`` drawn by a ``Gtk.CellRendererPixbuf``, resolved
    via :func:`resolve_icon_pixbuf`; everything else is rendered as Pango
    markup by :func:`inline_to_pango` in a paired ``Gtk.CellRendererText``
    -- so ``| ![](gramps:icon:person/16) John Smith |`` shows an actual
    person icon followed by the name, rather than the icon's alt text in
    italics. Header cells get the same treatment via a small
    icon+label ``Gtk.Box`` in place of the plain title string.  A cell can
    only carry *one* real icon this way (a TreeView column has one pixbuf
    slot); additional icon/image references in the same cell still fall
    back to italicized alt text, as before.

    Column widths are derived from whichever is larger:
    1. Content measure — max plain-text length across header + all body
       cells for that column (after icon extraction), multiplied by an
       estimated ~7 px per character, plus an icon-width allowance for any
       column that has at least one resolved icon.
    2. Separator hint — the number of dashes in the GFM separator row
       (``|---|:-----:|``).

    :param columns:    List of header cell strings (may contain inline Markdown).
    :param align:      Per-column alignment strings: ``'left'``, ``'center'``,
                       or ``'right'``.
    :param body_rows:  List of rows; each row is a list of cell strings.
    :param sep_widths: Per-column dash count from the GFM separator row, used
                       as a minimum-width hint.  Defaults to 5 per column.
    :param default_icon_style: :data:`ICON_STYLE_AUTO` (default), ``'color'``,
                       or ``'symbolic'`` -- applies to any
                       ``gramps:icon:NAME[:SIZE]`` reference in a cell that
                       doesn't specify its own ``:STYLE`` suffix. Table
                       cells are rendered outside :func:`parse_markdown`'s
                       call, so (unlike inline document text) this must be
                       passed explicitly by the caller if a non-default
                       document-wide style is in effect.
    :returns: A :class:`Gtk.Frame` containing the styled :class:`Gtk.TreeView`.
    """
    _PX_PER_CHAR = 7
    _MIN_COL_PX = 40
    _CELL_XPAD = 12
    _ROW_PX = 28  # ~cell ypad*2 + default font line height

    ncols = len(columns)
    if sep_widths is None:
        sep_widths = [5] * ncols
    # Defensive backstop, independent of the header/separator mismatch
    # check parse_markdown now performs before ever building table_data:
    # this function is itself public and reusable, so pad align/
    # sep_widths (each usually built from the separator row's own cell
    # count) up to ncols (usually the header row's) for any other
    # caller that hands in mismatched lists directly, the same way
    # parse_markdown's own flush_table already pads header_row/body_rows
    # -- rather than raising IndexError below when this loop reaches an
    # index neither list actually has.
    if len(align) < ncols:
        align = align + ["left"] * (ncols - len(align))
    if len(sep_widths) < ncols:
        sep_widths = sep_widths + [5] * (ncols - len(sep_widths))

    def plain(markup_str: str) -> str:
        """Strip basic Pango tags to get approximate display length."""
        return re.sub(r"<[^>]+>", "", markup_str)

    def render_cell(raw: str) -> tuple:
        """Split *raw* cell Markdown into (pixbuf-or-None, Pango markup)."""
        icon_info, remaining = _extract_leading_icon(raw, default_icon_style)
        pixbuf = None
        if icon_info is not None:
            icon_name, size, icon_style = icon_info
            pixbuf = resolve_icon_pixbuf(icon_name, size, icon_style=icon_style)
        return pixbuf, inline_to_pango(remaining)

    header_cells = [render_cell(c) for c in columns]
    body_cells = [[render_cell(str(cell)) for cell in row] for row in body_rows]

    col_char_widths: list[int] = []
    col_icon_px: list[int] = []
    for ci in range(ncols):
        hdr_pb, hdr_markup = header_cells[ci]
        hdr_len = len(plain(hdr_markup))
        cell_max = 0
        icon_px = hdr_pb.get_width() if hdr_pb is not None else 0
        for row in body_cells:
            if ci < len(row):
                pb, markup = row[ci]
                cell_max = max(cell_max, len(plain(markup)))
                if pb is not None:
                    icon_px = max(icon_px, pb.get_width())
        col_char_widths.append(max(hdr_len, cell_max))
        col_icon_px.append(icon_px)

    # Icons are never scaled here (see build_table_widget's own
    # docstring note above render_cell): a "gramps:icon:name:SIZE"
    # reference is the document author's own explicit, deliberate size
    # choice, not a hint for this renderer to second-guess -- if a
    # chosen size doesn't fit well, that's exactly the kind of thing
    # proofreading the document is for, not something to silently
    # correct out from under the author. Each icon column's own budget
    # is therefore sized to whichever icon actually found in it is
    # largest (col_icon_px above, taken directly from the real resolved
    # pixbuf's own width) rather than one fixed guess at "an icon" --
    # that's what previously let an icon larger than the guess get
    # squeezed into less room than its own real size, clipping it
    # (understood at the time as the likely source of the Cairo/pixman
    # "invalid rectangle" warnings while scrolling).
    col_min_px: list[int] = []
    for ci in range(ncols):
        content_px = col_char_widths[ci] * _PX_PER_CHAR + _CELL_XPAD
        sep_px = sep_widths[ci] * _PX_PER_CHAR + _CELL_XPAD
        icon_px = col_icon_px[ci] + _CELL_XPAD if col_icon_px[ci] else 0
        col_min_px.append(max(content_px, sep_px, _MIN_COL_PX, icon_px))

    # Two ListStore columns per data column: [pixbuf, markup, pixbuf, markup, ...]
    store_types = [GdkPixbuf.Pixbuf, str] * ncols
    store = Gtk.ListStore(*store_types)
    for row in body_cells:
        store_row: list = []
        for ci in range(ncols):
            pb, markup = row[ci] if ci < len(row) else (None, "")
            store_row.extend([pb, markup])
        store.append(store_row)

    tv = Gtk.TreeView(model=store)
    tv.set_headers_visible(True)
    tv.set_grid_lines(Gtk.TreeViewGridLines.BOTH)
    tv.set_enable_search(False)
    tv.set_reorderable(False)
    tv.set_rubber_banding(False)

    _xalign = {"left": 0.0, "center": 0.5, "right": 1.0}

    for ci in range(ncols):
        col_align = align[ci] if ci < len(align) else "left"
        xalign = _xalign.get(col_align, 0.0)

        tvc = Gtk.TreeViewColumn()
        tvc.set_resizable(True)
        # NOT set_expand(True): an expanding column stretches to fill
        # whatever width its parent actually offers -- a text-view
        # child anchor easily offers 700px+ in a normal-sized reader
        # window -- which silently overrides col_min_px's own carefully
        # computed budget (including the compression above for a wide
        # table) with however much room happens to be available. The
        # icon-shrink factor above was computed against that *budget*,
        # not against whatever wider width an expanding column would
        # actually claim, so the two could end up inconsistent -- e.g. a
        # table compressed to fit 560px, with icons shrunk to match,
        # then visibly stretched back out past 1200px anyway. A
        # non-expanding column instead sticks to its own min_width, so
        # the table's actual rendered size stays the one this function
        # just computed and shrank its icons for.
        tvc.set_min_width(col_min_px[ci])
        tvc.set_clickable(False)
        tvc.set_alignment(xalign)

        pixbuf_renderer = Gtk.CellRendererPixbuf()
        pixbuf_renderer.set_property("xalign", xalign)
        tvc.pack_start(pixbuf_renderer, False)
        tvc.add_attribute(pixbuf_renderer, "pixbuf", ci * 2)

        text_renderer = Gtk.CellRendererText()
        text_renderer.set_property("xalign", xalign)
        text_renderer.set_property("xpad", 6)
        text_renderer.set_property("ypad", 3)
        text_renderer.set_property("ellipsize", Pango.EllipsizeMode.END)
        tvc.pack_start(text_renderer, True)
        tvc.add_attribute(text_renderer, "markup", ci * 2 + 1)

        hdr_pb, hdr_markup = header_cells[ci]
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        if hdr_pb is not None:
            header_box.pack_start(Gtk.Image.new_from_pixbuf(hdr_pb), False, False, 0)
        hdr_label = Gtk.Label()
        hdr_label.set_markup("<b>{}</b>".format(hdr_markup))
        header_box.pack_start(hdr_label, False, False, 0)
        header_box.show_all()
        tvc.set_widget(header_box)

        tv.append_column(tvc)

    # A bare Gtk.TreeView reports no fixed natural height to a
    # Gtk.TextView child anchor, which can make GTK compute a *negative*
    # allocation on relayout (e.g. during scroll) instead of clamping to
    # zero -- give it an explicit height so the anchor always negotiates a
    # sane, stable size.
    n_rows = len(body_rows) + 1  # +1 for the header row
    table_height_px = n_rows * _ROW_PX
    tv.set_size_request(-1, table_height_px)

    # GTK3's "Negative content height ... gadget (node border, owner
    # GtkFrame)" warning names the FRAME's own themed-border CSS gadget,
    # not the TreeView inside it -- constraining only the child's size
    # (above) does not guarantee the frame's border allocation gets a
    # matching floor during a Gtk.TextView child-anchor's incremental
    # layout pass, which is exactly what recurs while scrolling brings
    # previously-unrealized anchors into view for the first time. Two
    # changes address the actual widget named in the warning:
    #  1. NONE shadow type sidesteps GTK's themed-border "node border"
    #     gadget computation entirely, rather than relying on its
    #     arithmetic staying non-negative during a transient layout pass.
    #  2. An explicit size_request on the Frame itself -- not just the
    #     TreeView -- gives the exact widget the warning names its own
    #     floor, independent of whatever the child's request propagates
    #     as through the frame's border/padding.
    # Trade-off: NONE drops the boxed/shadowed look IN provided. If that
    # visual is wanted back, prefer a CSS provider (background + border
    # via Gtk.StyleContext) over reverting to IN, since IN is the shadow
    # type that triggers this warning in the first place.
    frame = Gtk.Frame()
    frame.set_shadow_type(Gtk.ShadowType.NONE)
    frame.set_size_request(-1, table_height_px)
    frame.add(tv)
    frame.set_margin_top(4)
    frame.set_margin_bottom(4)
    # Halign START (not FILL, GTK's own default) is what actually keeps
    # this Frame from being stretched to match whatever width its own
    # parent has available -- a Gtk.TextView child anchor easily offers
    # 700px+ in a normal-sized reader window, and a FILL-aligned widget
    # claims all of it regardless of anything set on its own children
    # (set_expand(False) on the TreeViewColumns above only stops *them*
    # stretching to fill the TreeView's own allocation -- it does
    # nothing to stop the TreeView/Frame itself being stretched by
    # *its* parent, confirmed directly: the Frame still claimed a full
    # 1233px allocation with that alone). START keeps the Frame at its
    # own requested size — the column-width budget already computed
    # above — regardless of how much wider its parent actually is.
    frame.set_halign(Gtk.Align.START)
    frame.show_all()
    return frame


# ---------------------------------------------------------------------------
#
# GRAMPS_ICONS  -- short-name alias map
#
# ---------------------------------------------------------------------------
GRAMPS_ICONS: dict[str, list[str]] = {
    # Object types
    "person": ["gramps-person"],
    "family": ["gramps-family"],
    "event": ["gramps-event"],
    "place": ["gramps-place"],
    "source": ["gramps-source"],
    "citation": ["gramps-citation"],
    "repository": ["gramps-repository"],
    "media": ["gramps-media", "gramps-mediaobject"],
    "note": ["gramps-notes", "gramps-note"],
    "tag": ["gramps-tag"],
    # Views / Dashboard
    "dashboard": ["gramps-gramplet"],
    "gramplet": ["gramps-gramplet"],
    "pedigree": ["gramps-pedigree"],
    "fanchart": ["gramps-fanchart"],
    "fan": ["gramps-fanchart"],
    "geo": ["gramps-geo", "gramps-geography"],
    "geography": ["gramps-geo", "gramps-geography"],
    "relation": ["gramps-relation", "gramps-relationship"],
    "relationship": ["gramps-relation", "gramps-relationship"],
    "reports": ["gramps-reports"],
    "tools": ["gramps-tools"],
    "date": ["gramps-date"],
    # Actions
    "merge": ["gramps-merge"],
    "lock": ["gramps-lock"],
    "unlock": ["gramps-unlock"],
}


# ---------------------------------------------------------------------------
#
# resolve_icon_pixbuf (Theme and Context-Aware Alignment Revision)
#
# ---------------------------------------------------------------------------
def resolve_icon_pixbuf(
    icon_name: str,
    size: int,
    icon_theme: Gtk.IconTheme | None = None,
    style_context: Gtk.StyleContext | None = None,
    icon_style: str = ICON_STYLE_AUTO,
) -> GdkPixbuf.Pixbuf | None:
    """Return a styled :class:`GdkPixbuf.Pixbuf` matching active GUI theme properties.

    Uses the *live* default :class:`Gtk.IconTheme` (or a caller-supplied theme)
    so the rendered icon always matches what the running Gramps GUI displays.

    If a style_context is provided, symbolic assets are automatically colorized
    using the theme's active palette (preventing dark-on-dark invisible renderings).

    Resolution order:
    1. Exact GTK named icon via current theme cascade, parsing variants dynamically.
    2. All candidate names from :data:`GRAMPS_ICONS` alias list.
    3. Raster PNG fallback from Gramps installation ``DATA_DIR``.
    4. Scalable SVG fallback from Gramps installation ``DATA_DIR``.
    5. Gramps local fallback ``IMAGE_DIR`` files.

    Within each of those, the color vs. symbolic (B&W) variant tried first
    -- and whether the *other* variant is tried at all as a fallback -- is
    controlled by *icon_style*:

    - ``'auto'`` (default): prefer symbolic for icon sizes <=32px, color
      above that (matching every previous release's fixed behavior);
      falls back to whichever variant actually exists for that icon.
    - ``'color'``: always prefer the full-color asset regardless of size;
      falls back to symbolic only if no color asset exists anywhere for
      that icon.
    - ``'symbolic'``: always prefer the symbolic/B&W asset regardless of
      size; falls back to color only if no symbolic asset exists anywhere
      for that icon.

    :param icon_name:     GTK or Gramps short icon name.
    :param size:          Desired pixel size.
    :param icon_theme:    Optional :class:`Gtk.IconTheme` to query; when ``None``
                          the process-wide default theme is used.
    :param style_context: Optional active window :class:`Gtk.StyleContext` to drive
                          contextual re-coloration palettes across dark mode shifts.
    :param icon_style:    :data:`ICON_STYLE_AUTO` (default), ``'color'``, or
                          ``'symbolic'``. An unrecognized value is treated
                          as ``'auto'``.
    :returns: :class:`GdkPixbuf.Pixbuf` or ``None`` if not found anywhere.
    """
    if icon_theme is None:
        icon_theme = Gtk.IconTheme.get_default()
    if icon_style not in _VALID_ICON_STYLES:
        icon_style = ICON_STYLE_AUTO

    if icon_style == ICON_STYLE_COLOR:
        prefer_symbolic = False
    elif icon_style == ICON_STYLE_SYMBOLIC:
        prefer_symbolic = True
    else:
        # PRESENTATION HEURISTIC: symbolic for small layouts only.
        prefer_symbolic = size <= 32

    _FLAGS = (
        Gtk.IconLookupFlags.GENERIC_FALLBACK
        | Gtk.IconLookupFlags.USE_BUILTIN
        | Gtk.IconLookupFlags.FORCE_SIZE
    )

    def _name_variants(name: str) -> list[str]:
        """Return [name] candidates for *name*, in style-preference order.

        Under ``icon_style='auto'`` only the single preferred style is
        ever tried, matching every previous release's behavior exactly
        (no cross-style fallback). The two *forced* styles additionally
        try the other style as a last resort, so requesting a style that
        simply doesn't have an asset for this particular icon still shows
        something rather than nothing.
        """
        if "missing" in name or name.endswith("-symbolic"):
            return [name]
        symbolic_name = name + "-symbolic"
        if icon_style == ICON_STYLE_AUTO:
            return [symbolic_name] if prefer_symbolic else [name]
        return [symbolic_name, name] if prefer_symbolic else [name, symbolic_name]

    def _load_named(lookup_name: str, px_size: int) -> GdkPixbuf.Pixbuf | None:
        """Try to load *lookup_name* verbatim from the theme cascade at *px_size*."""
        try:
            info = icon_theme.lookup_icon(lookup_name, px_size, _FLAGS)
            if info:
                # CONTEXT SYNCHRONIZATION: colorize only when GTK actually
                # resolved a genuine symbolic asset. Icon theme fixed-size
                # directories exist almost exclusively at conventional even
                # pixel sizes (16/22/24/32/...); an odd-size request often
                # has no matching bucket for one style, and with
                # GENERIC_FALLBACK set, GTK can silently substitute the
                # other style's asset. info.is_symbolic() asks GTK
                # directly what it actually resolved, rather than trusting
                # the name we asked for.
                if style_context is not None and info.is_symbolic():
                    pb, _ = info.load_symbolic_for_context(style_context)
                    if pb:
                        return pb
                pb = info.load_icon()
                if pb:
                    return pb
        except Exception:
            pass
        return None

    def _load_any(name: str, px_size: int) -> GdkPixbuf.Pixbuf | None:
        """Try each style variant of *name*, in preference order, via the theme cascade."""
        for variant in _name_variants(name):
            pb = _load_named(variant, px_size)
            if pb:
                return pb
        return None

    # Step 1 & 2: Process through the synchronized theme cascade
    pb = _load_any(icon_name, size)
    if pb:
        return pb

    candidates = GRAMPS_ICONS.get(icon_name.lower(), [])
    for cand in candidates:
        pb = _load_any(cand, size)
        if pb:
            return pb

    # Fallback to local files if theme layers miss entirely
    try:
        from gramps.gen.const import DATA_DIR, IMAGE_DIR

        icon_base = os.path.join(DATA_DIR, "icons", "hicolor")
        raster_sizes = [size, 22, 48, 16, 24, 32, 64]
        seen_sizes: list[int] = []
        for s in raster_sizes:
            if s not in seen_sizes:
                seen_sizes.append(s)
        subdirs_raster = [
            os.path.join(icon_base, "{}x{}".format(s, s), cat)
            for s in seen_sizes
            for cat in ("actions", "apps", "places", "categories", "status")
        ]
        subdirs_svg = [
            os.path.join(icon_base, "scalable", cat)
            for cat in ("actions", "apps", "places", "categories", "status")
        ]
        all_names = [icon_name] + candidates

        # Odd/uncommon pixel sizes routinely fall outside every icon
        # theme's fixed-size buckets (which are conventionally even --
        # 16/22/24/32/...), so the live Gtk.IconTheme cascade above often
        # returns None entirely at those sizes -- for both styles alike --
        # and execution reaches this local-file tier. Apply the same
        # per-icon style-preference order here, via _name_variants(), so a
        # size that merely missed the live theme doesn't silently ignore
        # icon_style. Files loaded this way bypass
        # Gtk.IconTheme/load_symbolic_for_context entirely, so a symbolic
        # SVG renders in its own baked-in default color rather than being
        # dynamically recolored to match the active foreground -- still
        # visually "symbolic" (flat, low-saturation), just not
        # theme-reactive the way a genuine theme-cascade hit is.
        search_names: list[str] = []
        for name in all_names:
            search_names.extend(_name_variants(name))
        seen_names: set[str] = set()
        search_names = [
            n for n in search_names if not (n in seen_names or seen_names.add(n))
        ]

        for d in subdirs_raster:
            for name in search_names:
                fp = os.path.join(d, name + ".png")
                if os.path.isfile(fp):
                    try:
                        pb = GdkPixbuf.Pixbuf.new_from_file_at_size(fp, size, size)
                        if pb:
                            return pb
                    except Exception:
                        pass

        for d in subdirs_svg:
            for name in search_names:
                fp = os.path.join(d, name + ".svg")
                if os.path.isfile(fp):
                    try:
                        pb = GdkPixbuf.Pixbuf.new_from_file_at_size(fp, size, size)
                        if pb:
                            return pb
                    except Exception:
                        pass

        for name in search_names:
            for ext in (".png", ".svg", ".jpg"):
                fp = os.path.join(IMAGE_DIR, name + ext)
                if os.path.isfile(fp):
                    try:
                        pb = GdkPixbuf.Pixbuf.new_from_file_at_size(fp, size, size)
                        if pb:
                            return pb
                    except Exception:
                        pass
    except ImportError:
        pass

    return None


# ---------------------------------------------------------------------------
#
# list_icons_by_context
#
# ---------------------------------------------------------------------------
def list_icons_by_context(
    context: str | None = None,
    icon_theme: Gtk.IconTheme | None = None,
) -> list[str]:
    """Return a sorted list of icon names available in the current theme cascade.

    Wraps :meth:`Gtk.IconTheme.list_icons` so callers (e.g. :class:`IconBrowserGramplet`)
    do not need to import GTK directly. The enumeration follows the full freedesktop
    inheritance chain — current theme → parent themes → hicolor.

    :param context:    Freedesktop context name (e.g. ``'Actions'``), or
                       ``None`` to return every icon in the cascade.
    :param icon_theme: Optional :class:`Gtk.IconTheme` to query; when ``None``
                       the process-wide default theme is used.
    :returns: Alphabetically sorted (case-insensitive) list of icon name strings.
    """
    if icon_theme is None:
        icon_theme = Gtk.IconTheme.get_default()
    names: list[str] = icon_theme.list_icons(context) or []
    return sorted(names, key=str.casefold)


# ---------------------------------------------------------------------------
# Gramps object-type maps (shared by any consumer of this library)
# ---------------------------------------------------------------------------

#: Mapping from Gramps object-type name to
#: ``(gramps_id_getter, handle_getter, editor_class_name)``.
NAMESPACE_MAP: dict[str, tuple[str, str, str]] = {
    "Person": ("get_person_from_gramps_id", "get_person_from_handle", "EditPerson"),
    "Family": ("get_family_from_gramps_id", "get_family_from_handle", "EditFamily"),
    "Event": ("get_event_from_gramps_id", "get_event_from_handle", "EditEvent"),
    "Place": ("get_place_from_gramps_id", "get_place_from_handle", "EditPlace"),
    "Source": ("get_source_from_gramps_id", "get_source_from_handle", "EditSource"),
    "Citation": (
        "get_citation_from_gramps_id",
        "get_citation_from_handle",
        "EditCitation",
    ),
    "Repository": (
        "get_repository_from_gramps_id",
        "get_repository_from_handle",
        "EditRepository",
    ),
    "Media": ("get_media_from_gramps_id", "get_media_from_handle", "EditMedia"),
    "Note": ("get_note_from_gramps_id", "get_note_from_handle", "EditNote"),
}

#: Lowercase category alias → canonical Gramps view-category name.
VIEW_NAMES: dict[str, str] = {
    "people": "People",
    "person": "People",
    "families": "Families",
    "family": "Families",
    "events": "Events",
    "event": "Events",
    "places": "Places",
    "place": "Places",
    "sources": "Sources",
    "source": "Sources",
    "citations": "Citations",
    "citation": "Citations",
    "repositories": "Repositories",
    "repository": "Repositories",
    "media": "Media",
    "notes": "Notes",
    "note": "Notes",
    "geography": "Geography",
    "charts": "Charts",
    "dashboard": "Dashboard",
}
