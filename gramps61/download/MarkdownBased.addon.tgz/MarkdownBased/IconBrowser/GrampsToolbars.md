# Gramps Icons (Gtk)


|Module|Icon|path|tooltip|
|---|---|---|---|
|![](gramps:icon:gramps-gramplet:48) Dashboard | ![](gramps:icon:gramps-pedigree:48) ![](gramps:icon:menu-sort-down)  ![](gramps:icon:edit-paste)|

|Category|Toolbar|
|---|---|
|![](gramps:icon:gramps-gramplet:48) Dashboard | ![](gramps:icon:gramps-pedigree:48) ![](gramps:icon:menu-sort-down)  ![](gramps:icon:edit-paste)|
|![](gramps:icon:gramps-person:48) People| ![](gramps:icon:gtk-go-back-ltr) ![](gramps:icon:gtk-go-back-rtl) ![](gramps:icon:go-home) ![](gramps:icon:add) ![](gramps:icon:gtk-edit) ![](gramps:icon:gtk-remove) ![](gramps:icon:gramps-merge) ![](gramps:icon:gramps-tag) ![](gramps:icon:gramps-tree-group) ![](gramps:icon:gramps-tree-list) ![](gramps:icon:menu-sort-right) |
|![](gramps:icon:gramps-relation:48) Relationships| ![](gramps:icon:view-sort-ascending) |
|![](gramps:icon:gramps-family:48) Families||
|![](gramps:icon:gramps-pedigree:48) Charts| ![](gramps:icon:gramps-pedigree) ![](gramps:icon:gramps-fanchart) ![](gramps:icon:gramps-fanchartdesc2) ![](gramps:icon:gramps-fanchart2way) |
|![](gramps:icon:gramps-event:48) Events||
|![](gramps:icon:gramps-place:48) Places||
|![](gramps:icon:gramps-geo:48) Geography| ![](gramps:icon:gramps-printer:48)|
|![](gramps:icon:gramps-source:48) Sources||
|![](gramps:icon:gramps-citation:48) Citations||
|![](gramps:icon:gramps-repository:48) Repositories||
|![](gramps:icon:gramps-viewmedia:48) Media||
|![](gramps:icon:gramps-notes:48) Notes||


![](gramps:icon:gramps-gramplet:48) Dashboard 
![](gramps:icon:gramps-pedigree:32) ![](gramps:icon:menu-sort-down:32)  ![](gramps:icon:gramps-config:32) ![](gramps:icon:edit-paste:32:symbolic) ![](gramps:icon:edit-paste:32:color) ![](gramps:icon:gramps-reports:32) ![](gramps:icon:gramps-tools:32) ![](gramps:icon:gramps-addon:32) ![](gramps:icon:gramps-preferences:32)


![](gramps:icon:gramps-person:48) People
![](gramps:icon:gtk-go-back-ltr:32:symbolic) ![](gramps:icon:gtk-go-back-rtl:32:symbolic)  ![](gramps:icon:go-home:48:color) ![](gramps:icon:add:32) ![](gramps:icon:gtk-edit:32) ![](gramps:icon:gtk-remove:32) ![](gramps:icon:gramps-merge:32) ![](gramps:icon:gramps-tag:32) ![](gramps:icon:gramps-tree-group:32) ![](gramps:icon:gramps-tree-list:32) ![](gramps:icon:menu-sort-right:32) 

![](gramps:icon:go-previous-symbolic:32) ![](gramps:icon:go-next-symbolic:32) ![](gramps:icon:go-home:32:symbolic) ![](gramps:icon:list-add-symbolic:32) ![](gramps:icon:gtk-edit:32) ![](gramps:icon:list-remove-symbolic:32) ![](gramps:icon:gramps-merge:32) ![](gramps:icon:gramps-tag:32) ![](gramps:icon:gramps-tree-group:32) ![](gramps:icon:gramps-tree-list:32) ![](gramps:icon:menu-sort-right:32) 

![](gramps:icon:gramps-relation:48) Relationships
![](gramps:icon:gramps-parents-add:32) ![](gramps:icon:gramps-parents-open:32) ![](gramps:icon:gramps-spouse:32) ![](gramps:icon:view-sort-ascending:32:color) ![](gramps:icon:view-sort-ascending-symbolic:32)


![](gramps:icon:gramps-family:48) Families


![](gramps:icon:gramps-pedigree:48) Charts
![](gramps:icon:gramps-pedigree:32) ![](gramps:icon:gramps-fanchart:32) ![](gramps:icon:gramps-fanchartdesc2:32) ![](gramps:icon:gramps-fanchart2way:32) ![](gramps:icon:gramps-timelinepedigree:32) ![](gramps:icon:gramps-quilt:32) ![](gramps:icon:gramps-lifelinedescendantchart-bw:32) ![](gramps:icon:gramps-lifelineancestorchart-bw:32) ![](gramps:icon:gramps-htree:32) ![](gramps:icon:descendants:32)


![](gramps:icon:gramps-event:48) Events
![](gramps:icon:gramps-date:32)

![](gramps:icon:gramps-place:48) Places
![](gramps:icon:go-jump:32)

![](gramps:icon:gramps-geo:48) Geography|
![](gramps:icon:gramps-printer:32) ![](gramps:icon:document-print-symbolic:32) ![](gramps:icon:cupsprinter:32) ![](gramps:icon:geo-timelines:32) ![](gramps:icon:gramps-geo-link:32) ![](gramps:icon:geo-show-event:32) ![](gramps:icon:geo-show-family:32) ![](gramps:icon:geo-show-family-down:32) ![](gramps:icon:geo-show-family-up:32) ![](gramps:icon:geo-show-person:32) ![](gramps:icon:geo-show-place:32) ![](gramps:icon:geo-timelines:32) ![](gramps:icon:gramps-geo-link:32) ![](gramps:icon:geo-ancestor:32)


![](gramps:icon:gramps-source:48) Sources
![](gramps:icon:gramps-tree-select:32)

![](gramps:icon:gramps-citation:48) Citations


![](gramps:icon:gramps-repository:48) Repositories


![](gramps:icon:gramps-viewmedia:48)![](gramps:icon:gramps-media:48) Media
![](gramps:icon:gramps-media:32)

![](gramps:icon:gramps-notes:48) Notes


![](gramps:icon:format-justify-fill)  ![](gramps:icon:format-justify-fill-symbolic:24)


![](gramps:icon:gramps-attribute:128)

![](gramps:icon:gramps_new-html:128)  ![](gramps:icon:gramps-url:128) ![](gramps:icon:io.github.shiftey.Desktop:128)

![](gramps:icon:cs-language:128) ![](gramps:icon:cs-region:128) ![](gramps:icon:cs-online-accounts:48)
![](gramps:icon:cs-themes:128) ![](gramps:icon:cs-tiling:128) 
![](gramps:icon:cs-user:128) ![](gramps:icon:cs-user-accounts:128)
![](gramps:icon:cs-applets:128) ![](gramps:icon:cs-date-time:128) ![](gramps:icon:cs-cat-prefs:128) ![](gramps:icon:cs-cat-hardware:128) ![](gramps:icon:cs-cat-appearance:128)  
![](gramps:icon:security-high:64)  ![](gramps:icon:starred:22)
![](gramps:icon:help-browser:32) ![](gramps:icon:help-faq-symbolic:32) ![](gramps:icon:kasumi:32)

![](gramps:icon:org.gnome.Evince:128) ![](gramps:icon:preferences-system-sharing:32)

[Theme Stencil](https://gramps.discourse.group/t/development-of-a-distinctive-gramps-icon-theme-stencil/2048/2)
