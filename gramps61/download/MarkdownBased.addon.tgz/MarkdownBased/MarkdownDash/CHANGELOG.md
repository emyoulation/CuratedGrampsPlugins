# Markdown Dash - Changelog
<!-- undocked=false -->
[Markdown Based tools](../README.md) ● [README.md](README.md) ● [CHANGELOG.md](CHANGELOG.md)

All notable changes to the Markdown Dash gramplet. The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [1.5.2]
### Fixed
- A document heading that matched the title of another Dashboard gramplet could remove that other gramplet from the Dashboard records. The other gramplet then disappeared from the Configure dialog and from the saved Dashboard layout. This happened, for example, with the built-in "What's Next?" gramplet.
- Adding a second Markdown Dash to the Dashboard could give two gramplets the same title. The Configure dialog then showed two tabs with the same name that changed the wrong gramplet, and the next start of Gramps could fail to load the Dashboard layout and reset it to the default gramplets.
- A heading that contains `&`, `<` or `>` left the gramplet title out of step with the Dashboard records. The gramplet now keeps its current title instead.

### Changed
- On the Dashboard, the title from the document heading is applied only after Gramps has finished adding the gramplet, and always through the standard Gramps title check. When another gramplet already uses the title, a number is added (for example `What's Next?-1`), the same way Gramps does when it loads the Dashboard.
- The gramplet frame label shows the title that was actually accepted, not the one requested.
- The README explains the unique-title rule, and its heading no longer includes a version number.

## [1.5.1]
- Publicly shared version. Starting point for this changelog.
