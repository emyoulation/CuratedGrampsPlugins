# Phonetic Filter Rules
This addon bundles four Person filter rules — **Soundex**, **NYSIIS**, **Match Rating Approach** (MRA) and **Metaphone** — that work anywhere Gramps filters do. Each can compare any combination of name fields you choose, not just the surname. Developed for use with the Fuzzy Matching gramplet but not limited to use only inside it. If you just want the gramplet's own Matches panel, you do not need this document at all; it is for building your *own* filters with these rules directly.

## Features
* [Finding the rules](#finding-the-rules) — where they show up in the Filter Editor
* [Choosing which name fields to match](#choosing-which-name-fields-to-match) — surname only, or given names, nicknames, alternate names and more
* [Building a filter with one of these rules](#building-a-filter-with-one-of-these-rules) — a worked example
* [Combining a rule with other conditions](#combining-a-rule-with-other-conditions) — why you would do this instead of using the gramplet's own shortcut
* The Rules
   * [Soundex](#soundex) — the classic genealogy code, now with name-field choices
   * [NYSIIS](#nysiis) — catches more spelling drift than Soundex, in exchange for a longer code
   * [Match Rating Approach](#match-rating-approach) — a compact code, best for near-identical spellings
   * [Metaphone](#metaphone) — models English pronunciation more closely than Soundex

## Finding the rules
Open **Edit ▸ Person Filter Editor** (or the "Edit" button next to the filter dropdown on the People view), create or edit a filter, and click **Add Rule...**. (Search for "match of People".) All four rules appear under **General filters**, alongside Gramps' own built-in rules, as:
![Add Rule Chooser](media/screenshot.png)
* `Soundex match of People with the <names>`
* `NYSIIS match of People with the <names>`
* `MRA match of People with the <names>`
* `Metaphone match of People with the <names>`

Short names and acronyms keep the list compact; each rule's description, shown when you select it, gives the full name of its encoding system. Gramps' own built-in rule, `Soundex match of People with the <name>`, also still appears — see [Soundex](#soundex) for how the two differ.

Each rule takes a **Name** to compare against, and a **Match in** choice of which name fields to compare it with.

## Choosing which name fields to match
The **Match in** option is two rows of check boxes, laid out like the Relationship Filter gramplet's name options:
* **Given name:** Title, Given, Call, Nick, and Alternatives
* **Surname:** Prefix, Surname, Suffix, Clan, and Alternatives

The default is **Surname** alone: the surname of each person's primary name, and nothing else. That is usually what you want. A search for "Johnson" should find the Johnsons and Jonsons, not also every John — and with Given ticked, it would find anyone whose given name encodes the same way.

* Tick **Given** (or Call, Nick) to also look for the name among given names.
* Tick **Alternatives** on a row to look in people's alternate names too, for the fields ticked on that row — for example, Surname plus the Surname row's Alternatives finds married and birth surnames recorded as alternate names.
* **Clan** is the family nickname field.

Every surname of a double or compound surname is compared on its own, so "Ann Thompson Johnson" is found by either "Thompson" or "Johnson". A multi-word given name is compared word by word, so "William" finds "Joseph William".

Filters saved before this option existed keep matching the primary surname only. Gramps may note "Too few arguments" once in its console when loading one; saving the filter again stores the new option.

## Soundex
Soundex is the classic four-character genealogy code, the same one Gramps' own SoundEx gramplet shows. It groups names that sound alike when spoken, such as "Smith" and "Smyth".
![Add Rule Chooser](media/soundex.png)
Gramps already has a built-in Soundex rule, **Soundex match of People with the \<name\>**. It always searches every name field — given, surname, call and nick names, in primary and alternate names — with no way to narrow it, so a search for the surname "Thomas" also returns everyone named Thomas. This addon's **Soundex match of People with the \<names\>** uses the same code but lets you choose the fields with **Match in**. Ticking every box gives the same reach as the built-in rule.

When this addon is installed, the Fuzzy Matching gramplet uses this rule for Soundex, so a filter made from its Soundex results returns the same people it showed.

## NYSIIS
NYSIIS (New York State Identification and Intelligence System) keeps more information about vowel position than Soundex does, which is both its strength and its one real quirk: it does not treat "Y" as a vowel, so some pairs Soundex considers a match — "Smith" and "Smythe" is the classic example — come out as different NYSIIS codes. That is not a bug to work around; it is simply a different, and often complementary, way of grouping spelling variants. If Soundex is not catching a variant you expect, NYSIIS sometimes will, and vice versa.
![Add Rule Chooser](media/nysiis.png)

## Match Rating Approach
Match Rating Approach (MRA) produces a shorter, more literal code: it drops non-leading vowels and collapses repeated consonants, without Soundex's or NYSIIS's broader letter-grouping rules. Worth knowing before you reach for it: Match Rating Approach's reputation for catching loose spelling variants comes from its own *comparison* algorithm, which tolerates codes that are similar but not identical — this rule does not implement that comparison, only the plain code. Used as an exact-match filter rule (the only kind Gramps supports), it will group truly identical spellings and very close variants, but is the most literal of the rules here — it won't catch as much drift as NYSIIS or Metaphone will.
![Add Rule Chooser](media/mra.png)

## Metaphone
Metaphone models English pronunciation more closely than Soundex: it accounts for silent letters and consonant clusters Soundex's simpler scheme misses — "PH" becoming an F sound, a silent "GH", and others — and produces a shorter, variable-length code rather than Soundex's fixed four characters. It agrees with Soundex on more pairs than NYSIIS does (both correctly group "Smith" and "Smyth", for example), while still catching some variants Soundex's cruder letter-grouping misses.
![Add Rule Chooser](media/metaphone.png)

## Building a filter with one of these rules
As a worked example, here is building a filter that finds everyone with a NYSIIS-equivalent surname to "Boucher", including surnames recorded as alternate names:

1. **Edit ▸ Person Filter Editor**, then **Add** to create a new filter (or pick an existing one to edit).
2. **Add Rule...**, find "NYSIIS match of People with the \<names\>" under *General filters*, and select it.
3. Type `Boucher` into the **Name** field.
4. Under **Match in**, leave **Surname** ticked and also tick the Alternatives box on the Surname row. Click **OK**.
5. Give the filter a name (e.g. "NYSIIS: Boucher") and click **OK**.
6. The new filter is now available anywhere Gramps lets you pick a Person filter — the filter side-bar on the People view, reports, and more.

Swap in any of the other three rules; everything else about the steps is identical.

## Combining a rule with other conditions
The Fuzzy Matching gramplet's own "Define filter" double-click action (see [README.md](README.md)) builds exactly this kind of single-rule filter for you automatically, pre-filled with whichever surname you double-click and whichever Encoding system is currently selected, matching surnames only — for a quick, one-off check, that is almost always faster than building one by hand here. Building a filter yourself is worth it when you want other name fields, or to combine one of these rules with something the gramplet's shortcut does not offer: AND'd with a birth-year range, OR'd with a second surname, restricted to a specific tag, and so on — anything the Filter Editor's own rule list and "All rules must apply"/"At least one rule must apply" options support.

## AI-assisted contribution disclosure
Portions of this addon were generated with AI assistance, per the Gramps project [AI-generated code guidelines](https://www.gramps-project.org/wiki/index.php/Howto:_Contribute_to_Gramps#AI_generated_code). Suggested commit-message trailers for whoever lands this as a real commit:

#### Generated-by: Clause Sonnet 5 medium
