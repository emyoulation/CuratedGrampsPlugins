#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026  Phonetic Matching Gramplet contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Soundex person filter rule with name-field granularity, standalone or
as the Fuzzy Matching Gramplet's Soundex encoding system.

Why a second Soundex rule
-------------------------

Gramps' built-in ``HasSoundexName`` ("Soundex match of People with the
<name>") always compares every name field - given, surname, call and
nick names, in the primary and every alternate name - with no way to
narrow it. A search for the surname "Thomas" therefore also returns
everyone whose *given* name is Thomas, and a filter made from the
Fuzzy Matching Gramplet's Soundex results could return more people
than the gramplet itself shows.

This rule uses the same Soundex code (``gramps.gen.soundex.soundex``)
but adds the "Match in:" option shared with the NYSIIS, MRA and
Metaphone rules (see ``phonetic_name_parts.py``). Its default is the
preferred name's surname pieces and call name; also ticking
Given, Nick and Alternatives reproduces the built-in rule's reach.

It registers with the ``FuzzyMatchingEncoder:`` id prefix, so when it
is installed the gramplet uses it for Soundex (encoding and "Define
filter") in place of its hardcoded fallback to the built-in rule. See
``phonetic_codes._load_encoders``.

The class is named ``HasSoundexNames``, not ``HasSoundexName``: rule
classes are made findable as ``gramps.gen.filters.rules.person.<Class>``
so saved filters reload, and reusing the built-in class name would
replace Gramps' own rule there.
"""

from __future__ import annotations

# ------------------------
# Python modules
# ------------------------
import logging

# ------------------------
# Gramps modules
# ------------------------
from gramps.gen.const import GRAMPS_LOCALE as glocale
from gramps.gen.filters.rules import Rule
from gramps.gen.soundex import soundex as _core_soundex


try:
    _trans = glocale.get_addon_translator(__file__)
except ValueError:
    _trans = glocale.translation
_ = _trans.gettext


LOG = logging.getLogger(__name__)

# "Match in:" option: shared module in this folder (phonetic_name_parts.py).
# Guarded: Gramps does not survive a rule addon that fails to import, so
# if the file is missing this rule still loads and matches the preferred
# surname only, without the option.
try:
    from phonetic_name_parts import (
        OPTION_LABEL,
        name_parts_widget,
        pad_args,
        parse_parts,
        person_matches,
    )

    _HAVE_NAME_PARTS = True
except ImportError:
    _HAVE_NAME_PARTS = False
    LOG.warning(
        "phonetic_name_parts.py not found next to %s; the Match in: option "
        "is unavailable and only the preferred surname is compared",
        __file__,
    )

    def pad_args(arg):
        """Fallback: arguments unchanged."""
        return list(arg or [])

    def parse_parts(_text):
        """Fallback: no name-field option."""
        return frozenset()

    def person_matches(person, _keys, target_codes, encode):
        """Fallback: compare each preferred surname piece."""
        if not target_codes:
            return False
        words = [s.get_surname() for s in person.get_primary_name().get_surname_list()]
        return any(encode(w) & target_codes for w in words if w and w.strip())


#: Registry key - the same id the gramplet's hardcoded Soundex entry
#: uses, so a saved "Encoding system: Soundex" choice keeps working
#: whether or not this rule is installed.
ALGORITHM_ID = "soundex"

#: Display label shown in the gramplet's "Encoding system" dropdown.
ALGORITHM_LABEL = "Soundex"

#: Tooltip for the Encoding system dropdown.
ALGORITHM_DESCRIPTION = (
    "The classic 4-character genealogy code (e.g. Gramps' own"
    " SoundEx gramplet). Groups names that sound alike when"
    ' spoken, such as "Smith" and "Smyth".'
)


def encode(name: str) -> set[str]:
    """
    Return the (single-element) Soundex code set for ``name``.

    :param name: The name (or any word) to encode.
    :returns: A one-element set with the four-character code that
        :func:`gramps.gen.soundex.soundex` returns.
    """
    try:
        return {_core_soundex(name)}
    except Exception:  # pylint: disable=broad-except
        LOG.debug("Soundex encoding failed for %r, falling back to empty", name)
        return {_core_soundex("")}


# -------------------------------------------------------------------------
#
# HasSoundexNames
#
# -------------------------------------------------------------------------
class HasSoundexNames(Rule):
    """
    Rule that checks for a Soundex match on a person's names, in the
    name fields selected by the "Match in:" option (the preferred
    name's surname pieces and call name by default).
    """

    labels = (
        [_("Name:"), (OPTION_LABEL, name_parts_widget)]
        if _HAVE_NAME_PARTS
        else [_("Name:")]
    )
    name = _("Soundex match of People with the <names>")
    description = _(
        "Matches people whose selected name fields (preferred surname and"
        " call name by default) have the same Soundex code as the given name"
    )
    category = _("General filters")
    allow_regex = False

    def __init__(self, arg, use_regex=False, use_case=False):
        super().__init__(arg, use_regex, use_case)
        self._target_codes = None
        self._parts = None

    def set_list(self, arg):
        """
        Store the rule values, filling in the "Match in:" option when a
        caller passes only the name (default: preferred surname and call name).
        """
        super().set_list(pad_args(arg))

    def prepare(self, _db, _user):
        """
        Encode the target name once.

        :param _db: The active database. Unused.
        :param _user: The active :class:`gramps.gen.user.User`. Unused.
        """
        self._target_codes = (
            encode(self.list[0]) if self.list and self.list[0] else set()
        )
        self._parts = parse_parts(self.list[1] if len(self.list) > 1 else "")

    def apply_to_one(self, _db, obj) -> bool:
        """
        Apply the rule. Return True on a match.

        :param _db: The active database. Unused.
        :param obj: The :class:`gramps.gen.lib.Person` being tested.
        :returns: True if any selected name field of ``obj`` encodes
            to one of the target codes.
        """
        if self._parts is None:  # apply without prepare
            self.prepare(_db, None)
        return person_matches(obj, self._parts, self._target_codes, encode)

    def apply(self, db, obj) -> bool:
        """
        Alias for :meth:`apply_to_one`: Gramps 5.2 calls ``apply``,
        Gramps 6.0+ calls ``apply_to_one``. See ``FuzzyDev.md``.
        """
        return self.apply_to_one(db, obj)
