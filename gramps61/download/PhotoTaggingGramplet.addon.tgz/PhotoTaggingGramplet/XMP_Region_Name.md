# Metadata Clues (formerly "XMP Region Name") — Photo Tagging Gramplet
[ReadMe](README.md) ● [Change Log](CHANGELOG.md) ● [XMP data](XMP_Region_Name.md) ● [Icon List](media/icons/ICONLIST.md)

This document describes the **Metadata clues** feature of the Photo Tagging gramplet (`PhotoTaggingGramplet.py`) in detail: what it is, the metadata standards it reads, exactly how it behaves (including edge cases visible in the source), its current limitations, and a recommended sample image for demonstrating it. As of version 1.1.1 the column is called **Metadata clues** rather than its original name, **XMP Region Name**, since it now surfaces two different kinds of embedded metadata rather than one — see [Section 4](#4-how-regions-are-loaded).

It is based on a source-level review of `PhotoTaggingGramplet.py` as currently written; behavior of GTK/GdkPixbuf image loading and of `gramps.gui.widgets.SelectionWidget` (both outside this file) is described only where it can be inferred from calls made against them.

---

## 1. What it is

Many photo tools — Windows Live Photo Gallery/Photos, Adobe Lightroom and Photoshop, digiKam, Picasa, ACDSee, Mylio, FotoStation, and others — can detect faces in a JPEG and let a person label them, e.g. "Marie Curie". When they save that label, they don't just keep it in their own private database; many of them also **embed it directly in the image file's XMP metadata**, in a standardized location, so that other, independent tools can read the same face boxes and names back out of the file.

The Photo Tagging gramplet's **Metadata clues** feature is the *read* side of that interoperability: when a photo is opened in the gramplet, it looks inside the image file for this embedded metadata and, for any named region it finds there, draws a selectable marquee on the photo and lists the embedded name in a dedicated **Metadata clues** column — *without* creating a Gramps `Person` or a `MediaRef` for it. It is a staging area: a hint, harvested from the file itself, that "someone already identified a face here, and called it *this*", left for a person to confirm by linking it to an actual Gramps `Person`. Since version 1.1.1, when a photo has no usable MWG region data at all, the gramplet additionally falls back to a much simpler, flatter kind of embedded metadata — `Xmp.dc.subject`, a plain list of names with no position information — rather than showing nothing; see [Section 4](#4-how-regions-are-loaded).

It complements, but is distinct from, the gramplet's normal region list, which is otherwise populated entirely from Gramps's own data (via `MediaRef` back-references from people's media galleries — see [Section 4](#4-how-regions-are-loaded)).

## 2. The underlying standard: MWG Regions

The metadata the gramplet reads is defined by the **Metadata Working Group (MWG) "Regions" schema** (namespace prefix `mwg-rs`), part of the MWG Guidelines for Handling Image Metadata. It's the same schema Lightroom, Photoshop, digiKam, Picasa, and several other tools use for both face tags and other named/typed regions, which is what makes it possible for the gramplet to read what another program wrote, and vice versa.

Each region in the list is stored as a small structured record giving:

| Field                              | Meaning                                                                 |
|-------------------------------------|--------------------------------------------------------------------------|
| `mwg-rs:Name`                      | Free-text label for the region (a person's name, in the face-tagging case) |
| `mwg-rs:Type`                      | The kind of region, e.g. `Face`, `Pet`, `BarCode`, `Focus`             |
| `mwg-rs:Area/stArea:x`             | Horizontal center of the region, normalized 0.0–1.0 across image width |
| `mwg-rs:Area/stArea:y`             | Vertical center of the region, normalized 0.0–1.0 across image height  |
| `mwg-rs:Area/stArea:w`             | Region width, normalized 0.0–1.0 of image width                        |
| `mwg-rs:Area/stArea:h`             | Region height, normalized 0.0–1.0 of image height                      |
| `mwg-rs:Area/stArea:unit`          | Normally `"normalized"`                                                |

Note that the area is stored as a **center point plus a size**, not as corner coordinates — this matters for the coordinate math in [Section 5](#5-coordinate-conversion).

### 2.1. Exiv2 tag paths used by the gramplet

The gramplet reads these fields through **GExiv2** (the GObject-introspected binding for the Exiv2 library), using the following indexed tag-path pattern, where `%s`/`%i` is the 1-based region index within the list:

```
Xmp.mwg-rs.Regions/mwg-rs:RegionList[%i]/mwg-rs:Name
Xmp.mwg-rs.Regions/mwg-rs:RegionList[%i]/mwg-rs:Type
Xmp.mwg-rs.Regions/mwg-rs:RegionList[%i]/mwg-rs:Area/stArea:x
Xmp.mwg-rs.Regions/mwg-rs:RegionList[%i]/mwg-rs:Area/stArea:y
Xmp.mwg-rs.Regions/mwg-rs:RegionList[%i]/mwg-rs:Area/stArea:w
Xmp.mwg-rs.Regions/mwg-rs:RegionList[%i]/mwg-rs:Area/stArea:h
Xmp.mwg-rs.Regions/mwg-rs:RegionList[%i]/mwg-rs:Area/stArea:unit
```

(See `get_xmp_regions()` in `PhotoTaggingGramplet.py`.)

### 2.2. Example embedded XMP (RDF/XML form)

For reference, this is what the gramplet's tag-path reads correspond to in the raw RDF/XML packet embedded in a JPEG's `APP1` segment (values abbreviated):

```xml
<mwg-rs:Regions>
  <mwg-rs:RegionList>
    <rdf:Seq>
      <rdf:li rdf:parseType="Resource">
        <mwg-rs:Name>Marie Curie</mwg-rs:Name>
        <mwg-rs:Type>Face</mwg-rs:Type>
        <mwg-rs:Area
            stArea:x="0.3079" stArea:y="0.6315"
            stArea:w="0.1986" stArea:h="0.1131"
            stArea:unit="normalized"/>
      </rdf:li>
      <rdf:li rdf:parseType="Resource">
        <mwg-rs:Name>Pierre Curie</mwg-rs:Name>
        <mwg-rs:Type>Face</mwg-rs:Type>
        <mwg-rs:Area
            stArea:x="0.2393" stArea:y="0.3125"
            stArea:w="0.2414" stArea:h="0.0964"
            stArea:unit="normalized"/>
      </rdf:li>
    </rdf:Seq>
  </mwg-rs:RegionList>
</mwg-rs:Regions>
```

A tool such as `exiftool -struct -j -G1 -RegionInfo photo.jpg` will print this in a friendlier flattened form and is the easiest way to inspect or hand-craft a test file.

## 3. Requirements

The whole Photo Tagging gramplet — not just this feature — has a **hard runtime dependency on GExiv2**. At import time, the module does:

```python
repository = gi.Repository.get_default()
v_array = repository.enumerate_versions("GExiv2")
if not v_array:
    raise ValueError("GExiv2 is not installed")
gi.require_version("GExiv2", v_array[-1])
from gi.repository import GExiv2
```

If the `GExiv2` GObject-introspection typelib is not installed, the gramplet raises `ValueError("GExiv2 is not installed")` while being imported, before any of its UI is built — i.e. it fails to load entirely, not just this one feature. On Debian/Ubuntu-family systems the required package is typically `gir1.2-gexiv2`; other distributions package it under similar names (e.g. `gobject-introspection` bindings for `exiv2`/`gexiv2`).

## 4. How regions are loaded

Every time the gramplet displays a different photo, `load_image()` builds `self.regions` from **up to three sources, in this order**:

1. **`retrieve_backrefs()`** — walks every `Person` in the database, looks at each person's media gallery for a `MediaRef` pointing at the current photo, and turns each one into a region backed by a real `person` and `mediaref`. This is the gramplet's normal, persistent, Gramps-native region data.
2. **`get_xmp_regions()`** — reads the MWG region list straight out of the image file's XMP metadata (see [Section 2](#2-the-underlying-standard-mwg-regions)) and turns each named entry into a region with `region.person = None` and `region.xmp_person` set to the name string read from the file.
3. **`get_xmp_keyword_regions()`** (new in 1.1.1) — only runs when steps 1 and 2 together produced *nothing at all* for this photo. Reads the flat list of names in `Xmp.dc.subject` (Dublin Core "Subject", commonly populated by keyword-tagging tools and usually labelled "Descriptive Tags" in general-purpose metadata viewers) and gives each name a region spanning the *entire image*, since this tag carries no position information at all — there's nothing to draw a real marquee around. Each such region is flagged with `region.xmp_whole_image = True`, which the Metadata clues column shows as "*name* (whole photo, no region)" to make clear it isn't a real, positioned region.

```python
self.retrieve_backrefs()
self.get_xmp_regions(image_path)
if not self.regions and not self.xmp_regions:
    self.get_xmp_keyword_regions(image_path)
self.regions = self.regions + self.xmp_regions
```

This three-tier fallback means the Metadata clues column now only ever comes up completely empty when the file genuinely has neither kind of metadata — a real improvement over 1.1.0, where a file with unreadable or absent MWG data simply showed nothing, even when a much more common, much more widely-supported tag like `Xmp.dc.subject` had the names all along. A toolbar toggle button (using `media/icons/XMP_logo.svg`) shows or hides the whole column, for anyone who finds it more distracting than useful once their own tagging is done; see the [Change Log](CHANGELOG.md) for the exact button behavior.

### 4.1. The "one-time" merge rule (important limitation)

`get_xmp_regions()` only *adds* its findings to `self.xmp_regions` when `self.regions` (i.e. the Gramps-backed regions from step 1) is **still completely empty**:

```python
# simple check to prevent infinite regions.  If regions are already
# defined ignore the XMP regions.  Probably there is a way to compare
# and merge the set of regions.
if not len(self.regions):
    self.xmp_regions.append(xmp_region)
```

In practice this means:

- On a **brand-new photo with no Gramps-linked people yet**, every named MWG region in the file is shown, unassigned, with its embedded name in the Metadata clues column.
- The moment **even a single region on that photo has been linked to a Gramps person** (by the gramplet itself, or by any other means that produces a matching `MediaRef`), XMP regions are **no longer read at all** for that photo — not just the one that was assigned, *all* of them, including ones nobody has looked at yet. This also means the `Xmp.dc.subject` fallback in step 3 above never gets a chance to run either, once any region exists.

This is a deliberate, acknowledged simplification (see the code comment above) rather than a per-region merge, and is the single most important behavioral quirk to know about before relying on this feature: **assign Gramps people to every embedded face you care about on a given photo in one pass**, since once you assign the first one, the rest of the embedded names disappear from the list on the next load (though the underlying XMP metadata in the file itself is untouched — see [Section 8](#8-what-this-feature-does-not-do)).

### 4.2. Order and persistence

Regions loaded this way get sorted by `sort_regions_by_stored_order()` using the `PhotoTagging Order` custom `Attribute` on the `Media` object (rows with a real Gramps person that were previously reordered come first, in their saved order; unassigned XMP-only regions, having no person, always sort after all of those, in file-discovery order).

## 5. Coordinate conversion

MWG stores each region's area as a **center point (`x`, `y`) plus a size (`w`, `h`)**, all normalized to the 0.0–1.0 range, whereas the gramplet's `Region`/`SelectionWidget` model works with **rectangle corners** in real image pixels. `get_xmp_regions()` performs this conversion for every region it reads:

1. Multiply `x`, `y`, `w`, `h` by 100 (working in percent instead of fractions).
2. Compute the box's edges from the center and size: `left = x - w/2`, `top = y - h/2`, `right = x + w/2`, `bottom = y + h/2`.
3. Clamp all four edges to the `[0, 100]` range, so a region whose stored center/size would place it partly outside the image is cropped to the image bounds instead of drawn off-canvas.
4. Convert the resulting percentage rectangle to real pixel coordinates for the currently loaded image via `self.selection_widget.proportional_to_real_rect(rect)`.

### 5.1. Malformed-value fallback

If `x`, `y`, `w`, or `h` cannot be parsed as a float (`ValueError` — e.g. a writer left the field blank or used an unexpected format), the gramplet does **not** skip the region or crash. Instead it falls back to:

```python
x = y = 50
w = h = 100
```

i.e. a region covering the **entire image**, still carrying whatever name was read. This means a malformed-but-named XMP region is never silently lost — it shows up (impossible to miss, since it covers the whole photo) rather than disappearing, at the cost of an unhelpful bounding box that the person will need to resize or discard manually.

### 5.2. `mwg-rs:Type` is read but not filtered on

The gramplet reads `mwg-rs:Type` (typically `Face`, but the schema also allows `Pet`, `BarCode`, `Focus`, `Area`, and vendor-specific values) into a local variable but currently does **not** use it to filter which regions are surfaced. Any named region of any type is treated the same way and shown with its name, whether or not it represents a human face.

## 6. What the person sees and does

### 6.1. The Metadata clues column

The region list (a `Gtk.TreeView`) has four columns as of 1.1.1 (previously five — the Person and Age columns were merged):

| # | Column header       | Source                                                          |
|---|----------------------|------------------------------------------------------------------|
| 1 | *(unlabeled)*        | 1-based row number                                               |
| 2 | Preview              | Thumbnail cropped from the region's rectangle                   |
| 3 | Name / (indented) Age on \<date\> | Two-line Pango markup cell — see the Change Log for the historically-aware name rendering and merged Age display; blank if unassigned |
| 4 | **Metadata clues**   | `region.xmp_person` — the name read from embedded metadata, from whichever of the sources in [Section 4](#4-how-regions-are-loaded) produced it |

The **Metadata clues** column is populated *only* for rows that:

- came from `get_xmp_regions()` or `get_xmp_keyword_regions()` (i.e. have not yet been linked to a Gramps person), **and**
- still have `region.xmp_person` set to a non-empty string.

Rows sourced from `get_xmp_keyword_regions()` (the whole-image `Xmp.dc.subject` fallback) additionally get "*(whole photo, no region)*" appended to the name, since those rows have no real spatial position to point at — see [Section 4](#4-how-regions-are-loaded).

For every other row — including a row created from a Gramps `MediaRef` backref, and an XMP-originated row that has since been assigned a person — `region.xmp_person` is the empty string, so the column is blank. The column is read-only display: there is no inline editing of it, and no code path writes to it other than the loaders themselves. A toolbar toggle button can hide this column entirely without affecting what data is loaded — see the Change Log for its exact behavior.

### 6.2. Turning a metadata clue into a real Gramps link

There is no automatic name-matching (the embedded string is never used to search or pre-fill a name lookup); a person confirms the identification manually, using the normal region-assignment workflow:

1. Select the unassigned marquee on the photo (its name is visible in the Metadata clues column).
2. Use **Add a new person** (creates and opens a new `Person` via `EditPerson`, then links it) or **Link** (opens the standard Person selector and links an existing `Person`) from the toolbar or the right-click context menu.
3. `set_person()` runs: a real `MediaRef` is created for that person and rectangle, `region.person` is set, and — crucially — `region.xmp_person` is reset to `""`, so the Metadata clues column clears for that row.

From that point on, the region behaves exactly like any other Gramps-backed region (draggable to reorder, included in "Move Up"/"Move Down", etc.), and — per [Section 4.1](#41-the-one-time-merge-rule-important-limitation) — any *other*, still-unassigned metadata-clue regions on that same photo will not be re-offered the next time the photo is loaded, since `self.regions` is no longer empty at that point.

### 6.3. Interaction with the "show ID" overlay

The toolbar's face-marquee ID overlay (`draw_ids_overlay`) cycles through three modes:

- **Row ID** (default): draws each region's 1-based list number on the photo, including unassigned metadata-clue regions.
- **Gramps ID**: draws `person.get_gramps_id()` over each region — since a metadata-clue-only region has `region.person is None`, `_draw_region_id()` returns immediately and **draws nothing** for it. Unassigned regions are effectively invisible in this mode (their marquee outline, drawn by `SelectionWidget` itself, still appears; only the gramplet's own ID label on top of it does not).
- **Hidden**: no overlay at all.

## 7. Data model summary (`Region` object)

The gramplet attaches two Gramps-agnostic and two XMP/Gramps-bridging attributes to each `gramps.gui.widgets.Region` instance it manages:

| Attribute        | Set by                                     | Meaning                                                     |
|-------------------|---------------------------------------------|---------------------------------------------------------------|
| `region.person`   | `retrieve_backrefs()`, `set_person()`       | The linked Gramps `Person`, or `None` if unassigned          |
| `region.mediaref` | `retrieve_backrefs()`, `set_person()`       | The `MediaRef` backing the link, or `None`                   |
| `region.xmp_person` | `get_xmp_regions()`, cleared by `set_person()`/`clear_ref()` | The name string read from embedded XMP metadata, or `""` |

`hasattr(region, 'xmp_person')` is used in `refresh_list()` as a belt-and-suspenders check (rather than assuming every region has the attribute), since a `Region` object as reused from the generic `SelectionWidget` API doesn't otherwise carry it.

## 8. What this feature does *not* do

To avoid surprises, it's worth being explicit about the boundaries of the current implementation:

- **It never writes back to the file.** There is no code path anywhere in `PhotoTaggingGramplet.py` that modifies `Xmp.mwg-rs.*` tags. Assigning a Gramps person to a region creates a `MediaRef` in the Gramps database; the original embedded XMP name and region in the *image file* are left untouched, permanently, even after the region is "claimed" in Gramps.
- **It does not merge or reconcile per-region.** As covered in [Section 4.1](#41-the-one-time-merge-rule-important-limitation), the presence of *any* Gramps-linked region suppresses *all* XMP regions for that photo on every subsequent load — there's no attempt to show only the still-unclaimed ones alongside already-linked ones.
- **It does not filter by region `Type`.** Non-face MWG regions (pets, barcodes, focus points, etc.) with a `Name` value are surfaced the same as faces (see [Section 5.2](#52-mwg-rstype-is-read-but-not-filtered-on)).
- **It does not itself compensate for EXIF `Orientation`.** MWG regions are defined relative to the image *as stored*; per the MWG guidelines, a viewer that rotates a photo for display based on its EXIF Orientation tag must apply the same rotation to region coordinates, or the boxes land on the wrong part of the (visually rotated) photo. Nothing in `get_xmp_regions()` reads or applies `Exif.Image.Orientation` — the raw, unrotated `x`/`y`/`w`/`h` values are used as-is. Whether this causes a visible mismatch in practice depends on whether the image is handed to `SelectionWidget.load_image()` already pre-rotated (e.g. by GdkPixbuf's own orientation handling) or not; this is worth explicitly testing with a rotated source file (see [Section 9.3](#93-a-second-file-to-specifically-exercise-the-orientation-edge-case)) rather than assumed either way.
- **No name matching/auto-suggest.** The embedded name string is displayed verbatim and is never used to search existing Gramps people or pre-fill the Person selector — matching a "Marie Curie" XMP tag to the correct Gramps `Person` record is entirely manual.

## 9. Demo / sample file

To see the feature in action you need a JPEG that already carries named MWG regions in its embedded XMP — a plain photo with no such metadata will simply show nothing in the XMP Region Name column.

### 9.1. Recommended sample

**[`skatsubo/exif-orientation-vs-face-regions`](https://github.com/skatsubo/exif-orientation-vs-face-regions)** is a small, purpose-built GitHub repository of JPEGs specifically created to test face-region handling. Its `images/photo.6.embedded.jpg` is a good match for demoing this feature:

- It carries **two named, embedded (not sidecar-only) MWG face regions**, confirmed via `exiftool -struct -j -G1 -RegionInfo`:
  - `Marie Curie` — area center `(0.3079, 0.6315)`, size `(0.1986 × 0.1131)`, normalized
  - `Pierre Curie` — area center `(0.2393, 0.3125)`, size `(0.2414 × 0.0964)`, normalized
- Both names will appear in the **XMP Region Name** column, as two unassigned marquees on the photo, the first time it's loaded into the Photo Tagging gramplet for a Media object that has no Gramps-linked people yet — a direct, reproducible demonstration of the feature end to end (see [Section 6.2](#62-turning-an-xmp-hint-into-a-real-gramps-link) for the follow-up "assign to a Person" step).
- The two names correspond to real historical figures, which makes the demo self-explanatory without needing invented test data.
- The underlying photo of Marie and Pierre Curie was contributed to the `immich-app/test-assets` project specifically as a face-region test image, and the repository author built the orientation-variant test set from it.

Add the file to a Gramps Media object in the usual way (Media view → Add → select the downloaded `photo.6.embedded.jpg`) and open the Photo Tagging gramplet on it.

### 9.2. Licensing note

The `exif-orientation-vs-face-regions` repository does not carry an explicit license file as of this writing. Treat the image as suitable for **local development/testing purposes** (verifying and demonstrating this feature) rather than for redistribution inside the Gramps codebase or an addon package; confirm licensing directly with the repository/upstream `immich-app/test-assets` project before bundling it anywhere.

If a license-clear, redistributable fixture is needed (e.g. to ship inside the addon's own test suite), the cleanest option is to generate one locally with `exiftool`, using any image the project already has rights to:

```bash
exiftool -config "" \
  -XMP-mwg-rs:RegionAppliedToDimensionsW=<image width in px> \
  -XMP-mwg-rs:RegionAppliedToDimensionsH=<image height in px> \
  -XMP-mwg-rs:RegionAppliedToDimensionsUnit=pixel \
  -XMP-mwg-rs:RegionName="Test Person" \
  -XMP-mwg-rs:RegionType=Face \
  -XMP-mwg-rs:RegionAreaX=0.5 \
  -XMP-mwg-rs:RegionAreaY=0.5 \
  -XMP-mwg-rs:RegionAreaW=0.3 \
  -XMP-mwg-rs:RegionAreaH=0.3 \
  -XMP-mwg-rs:RegionAreaUnit=normalized \
  your-photo.jpg
```

(Exact flat-tag names for `exiftool` vary by version; `exiftool -struct -j -G1 -RegionInfo` on a file already produced by Picasa/Lightroom/digiKam is the most reliable way to confirm the exact tag set your installed `exiftool` expects to write.)

### 9.3. A second file to specifically exercise the orientation edge case

Since `photo.6.embedded.jpg` carries EXIF orientation `6` (rotate 90° CW), it doubles as a useful check for the caveat in [Section 8](#8-what-this-feature-does-not-do): load it and confirm whether the two face marquees land on the actual faces or are offset/rotated relative to them. The same repository's `images/photo.6.embedded_sidecar.jpg` additionally carries the same region data in a sidecar `.xmp` file rather than embedded — since `get_xmp_regions()` only ever reads embedded XMP via `GExiv2.Metadata(image_path)` (never a sidecar file), this second file is a good check that sidecar-only metadata is correctly *not* picked up, rather than silently ignored due to some other bug.

### 9.4. A single file covering the full spectrum of behaviors

`photo.6.embedded.jpg` (Section 9.1) is a good *first* demo, but it only exercises the plain, well-formed, two-face case. To exercise every code path described in this document in one file, this project includes **`spectrum_demo.jpg`**, built by taking that same base photo, rotating it to upright orientation, and replacing its `Xmp.mwg-rs.Regions` metadata with seven hand-crafted regions:

![](media/spectrum_demo.jpg)

| # | XMP Region Name   | Type   | What it exercises                                                                 |
|---|--------------------|--------|--------------------------------------------------------------------------------------|
| 1 | Marie Curie        | Face   | Normal, well-formed region (re-derived for the now-upright image)                   |
| 2 | Pierre Curie       | Face   | Normal, well-formed region (re-derived for the now-upright image)                   |
| 3 | Ada Lovelace       | Face   | A third named region, to exercise a **multi-person** region list                    |
| 4 | Laika              | Pet    | Non-`Face` `mwg-rs:Type`, to confirm it's shown anyway (Section 5.2)                 |
| 5 | Edge Case Left     | Face   | Center near the left edge; box extends past `x=0` and must clamp there (Section 5)  |
| 6 | Edge Case Right    | Face   | Center near the right edge; box extends past `x=100%` and must clamp there          |
| 7 | Malformed Data     | Face   | `stArea:x` is the literal text `garbage`; `float()` raises `ValueError`, triggering the full-image fallback rect (Section 5.1) |

Because the base photo's original EXIF orientation (`6`, rotate 90° CW) would otherwise entangle the [orientation caveat](#8-what-this-feature-does-not-do) with everything else, `spectrum_demo.jpg` is first re-rotated to upright (`Orientation: Horizontal (normal)`) and Marie/Pierre Curie's region coordinates are algebraically re-derived for the rotated frame, so this file isolates the seven scenarios above without also being an orientation test case. (`photo.6.embedded.jpg` itself remains the file to use for the orientation caveat specifically — see [Section 9.3](#93-a-second-file-to-specifically-exercise-the-orientation-edge-case).)

This was verified two ways before being finalized:

- **Metadata verification** — `exiftool -struct -j -G1 -RegionInfo spectrum_demo.jpg` confirms all seven regions round-trip exactly as written, including the non-numeric `garbage` value (most tools, including `exiftool` itself, refuse to *write* a non-numeric value through its normal typed tag interface — this file's malformed value was injected by editing the raw XMP/RDF packet directly, since that's also how a real, buggy or hand-edited third-party writer could produce one "in the wild").
- **Logic simulation** — `get_xmp_regions()`'s conversion/clamp/fallback logic was re-implemented line-for-line in a standalone script (GExiv2 itself is a GTK/GObject-introspection library and wasn't available in the environment used to build this file) and run against the file's actual metadata. The resulting seven rectangles were then drawn onto the image for a visual sanity check:

| # | Name            | Type | Resulting rect, in % of image (L, T, R, B) | Fallback triggered? |
|---|------------------|------|-----------------------------------------------|------------------------|
| 1 | Marie Curie      | Face | (31.2, 20.9, 42.5, 40.7)                       | No                     |
| 2 | Pierre Curie     | Face | (63.9, 11.9, 73.6, 36.0)                       | No                     |
| 3 | Ada Lovelace     | Face | (46.0, 2.0, 54.0, 10.0)                        | No                     |
| 4 | Laika            | Pet  | (83.0, 85.0, 97.0, 99.0)                       | No                     |
| 5 | Edge Case Left   | Face | (**0**.0, 40.0, 17.0, 60.0)                    | No (clamped at left)   |
| 6 | Edge Case Right  | Face | (83.0, 40.0, **100**.0, 60.0)                  | No (clamped at right)  |
| 7 | Malformed Data   | Face | (0.0, 0.0, 100.0, 100.0)                       | **Yes**                |

`spectrum_demo_preview.png` (included alongside `spectrum_demo.jpg`) renders these seven boxes over the photo for a quick visual check — Marie's and Pierre's boxes should land tightly on their faces, Ada's sits near the top edge, Laika's sits near the bottom-right corner, "Edge Case Left"/"Right" are visibly cut off flush with the image's left/right border, and "Malformed Data" covers the entire photo.

![](media/spectrum_demo_preview.png)

**Reproducing or modifying it:** [build_spectrum_demo.sh](media/build_spectrum_demo.sh) (included alongside the image) is the exact, runnable recipe used to build `spectrum_demo.jpg` from the original `photo.6.embedded.jpg` — download the base photo, rotate it upright with ImageMagick, and splice a hand-written `mwg-rs:Regions` RDF block into its XMP packet with `exiftool`. Re-run it to regenerate the file identically, or edit the embedded RDF block in the script to add further scenarios (e.g. a region with `mwg-rs:Type` of `BarCode` or `Focus`, or one with `w`/`h` values of zero).

**Licensing note:** as this is a derivative of `photo.6.embedded.jpg`, the same caution in [Section 9.2](#92-licensing-note) applies.

## 10. Troubleshooting

### 10.1. Quick reference

| Symptom                                                        | Likely cause                                                                                   |
|-------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|
| Gramplet fails to load at all / "GExiv2 is not installed"       | The `GExiv2` GObject-introspection typelib isn't installed (see [Section 3](#3-requirements))   |
| XMP Region Name column is always blank on a photo you know has embedded names | The photo already has at least one Gramps-linked region — see [Section 4.1](#41-the-one-time-merge-rule-important-limitation) |
| Column blank even on a fresh photo with no Gramps people linked | The metadata may be in a **sidecar `.xmp` file** rather than embedded — not read by this feature (see [Section 9.3](#93-a-second-file-to-specifically-exercise-the-orientation-edge-case)); or see [Section 10.4](#104-confirmed-root-cause-a-missing-gexiv2-python-override-fixed-in-111) if it's blank even for files proven to carry good embedded data |
| Column blank on **every** file tried, including known-good ones, sometimes with a `CRITICAL **: XMP Toolkit error 201` / `Failed to decode XMP metadata` message in the terminal or `gramps.log` | Fixed in 1.1.1 — see [Section 10.4](#104-confirmed-root-cause-a-missing-gexiv2-python-override-fixed-in-111); if it recurs on a 1.1.1-or-later install, [Section 10.3](#103-earlier-hypothesis-gexiv2-built-against-exiv2-028-superseded--see-104)'s diagnostic process is still the right starting point |
| Marquee covers the entire photo instead of a face               | Malformed `x`/`y`/`w`/`h` values in the file triggered the full-image fallback (see [Section 5.1](#51-malformed-value-fallback)) |
| Marquee is offset from the actual face                          | Possible EXIF-orientation mismatch — see [Section 8](#8-what-this-feature-does-not-do)          |
| A non-face region's name shows up unexpectedly                  | `mwg-rs:Type` isn't filtered — see [Section 5.2](#52-mwg-rstype-is-read-but-not-filtered-on)     |

### 10.2. Diagnostic tools

Two small accompanying tools exist because the failure mode covered in [Section 10.4](#104-confirmed-root-cause-a-missing-gexiv2-python-override-fixed-in-111) turned out to be invisible from inside Gramps itself, for reasons that are themselves useful to understand:

- **`xmp_region_diagnostic.py`** reproduces `get_xmp_regions()` outside Gramps entirely, printing every step (import, `GExiv2.Metadata()` construction, a full XMP tag dump, and the indexed-path reads) so a silent failure can be isolated without touching Gramps at all. Run it with the *exact* Python interpreter Gramps itself uses — for a Flatpak install, that means running it *inside* the sandbox, e.g.:
  ```bash
  flatpak run --command=python3 org.gramps_project.Gramps \
      /path/to/xmp_region_diagnostic.py /path/to/photo.jpg
  ```
  A native/distro-packaged Gramps can just run it with the system `python3`.
- **`get_xmp_regions_patch.py`** is a drop-in replacement for the method of the same name, adding `LOG.exception()` / `LOG.warning()` / `LOG.debug()` calls at the points where the current code silently discards information (an unhandled exception constructing `GExiv2.Metadata`, the one-time-merge suppression firing, and the malformed-value fallback firing). **Superseded by the actual fix in 1.1.1** (see [Section 10.4](#104-confirmed-root-cause-a-missing-gexiv2-python-override-fixed-in-111)) — this patch only adds logging around the existing override-dependent code, so it would have surfaced the `TypeError`/`AttributeError` behind Section 10.4 as a loud error rather than fixing it; 1.1.1 ships the override-independent rewrite instead.

### 10.3. Earlier hypothesis: gexiv2 built against exiv2 0.28 (superseded — see 10.4)

> **This section documents the investigation as it stood at the time.** It correctly ruled out the file, the coordinate logic, and the one-time-merge rule, but its conclusion — a `libgexiv2` build incompatible with exiv2 0.28's ABI — turned out to be circumstantial rather than the actual mechanism. [Section 10.4](#104-confirmed-root-cause-a-missing-gexiv2-python-override-fixed-in-111) below found and fixed the real cause on the same reporter's system. Kept here for the diagnostic process itself, which remains a reasonable model for narrowing down a similarly silent failure elsewhere.

This was found and confirmed via an extended diagnostic session and is recorded here in full because it produces exactly the symptom this document is about — an empty XMP Region Name column — with **no indication anywhere in Gramps that anything is wrong**, for files that are provably valid and provably readable elsewhere.

**Symptom.** On a Flathub install of Gramps (confirmed on Gramps 5.2.1, `org.gramps_project.Gramps`, `stable` channel), the XMP Region Name column stayed empty for every MWG-region file tried — including files independently verified (via `xmllint` and via direct testing with an unrelated exiv2 binding) to be valid, well-formed, and perfectly readable. Larger/more complex files additionally logged:
```
** CRITICAL **: XMP Toolkit error 201: Error in XMLValidator
** WARNING **: Failed to decode XMP metadata.
```
while minimal, single-region test files produced no message at all — just silence, both in the gramplet and in the terminal.

**Diagnosis path** (each step ruling something out):

1. **The file's own coordinate math and edge cases** — clamping, malformed-value fallback, multi-region lists — were verified correct by re-implementing `get_xmp_regions()` standalone and running it against known-good metadata (see [Section 9.4](#94-a-single-file-covering-the-full-spectrum-of-behaviors)). Not the cause.
2. **The one-time-merge rule** ([Section 4.1](#41-the-one-time-merge-rule-important-limitation)) was ruled out by checking the Media object's References tab showed zero linked people.
3. **Malformed XML** was ruled out with `xmllint --noout` on the raw extracted XMP packet of every file involved (all valid, exit code 0), including the file that produced the `CRITICAL`/`XMLValidator` message above — proving that message wasn't describing an actual XML syntax error, despite its wording.
4. **A fully broken/unreadable XMP environment** was ruled out because *some* XMP consistently read correctly throughout — `Xmp.dc.subject` and keyword-list tags came through cleanly, every time, via a different gramplet (Edit Image Exif Metadata) reading the very same files that showed nothing for `mwg-rs:Regions`.
5. **exiv2 itself** (the C++ library both gexiv2 and the `exiv2` CLI are built on) was ruled out last: the failing Flatpak turned out to bundle **exiv2 0.28.2** internally (`/app/lib/libexiv2.so.0.28.2` — found via `flatpak run --command=sh org.gramps_project.Gramps -c "find /app -iname 'libexiv2*'"`), a different major version from the `exiv2` CLI on the host system (0.27.6) that earlier testing had been comparing against. Reading the same minimal test files directly through **exiv2 0.28.8** (a close later patch release, tested via the independent, non-gexiv2 `pyexiv2` Python binding) succeeded perfectly — every region, every field, even a deliberately malformed value — proving exiv2 0.28.x's own XMP parser handles this schema correctly.

**Conclusion at the time.** With the file, the coordinate logic, the one-time-merge rule, and exiv2 itself all cleared, the fault was narrowed to *some* incompatibility specific to the `libgexiv2` build bundled in that Flatpak (reported as version 2.14.2 — the same version number as a working Ubuntu-packaged `libgexiv2`, but necessarily a *different compiled artifact*, since exiv2 0.28 changed its SONAME as part of a deliberately ABI-breaking rewrite). This was a reasonable narrowing at the time, but — per Section 10.4 — the actual mechanism turned out to be simpler and one step higher up, in how the gramplet's own Python code called into `gexiv2`, not in `libgexiv2`/`libexiv2` themselves.

### 10.4. Confirmed root cause: a missing GExiv2 Python override (fixed in 1.1.1)

Continued debugging on the *same reporter's own system* (still Flathub Gramps 5.2.8) found the real, directly-observed mechanism, via two live tracebacks the previous investigation never surfaced because the failures it depended on had, up to that point, always been swallowed silently.

**What `GExiv2.Metadata(path)` actually is.** The convenient one-argument constructor used throughout the original `get_xmp_regions()` (`metadata = GExiv2.Metadata(image_path)`) is not part of the native, GObject-Introspection-generated `GExiv2.Metadata` class at all. It's added by an optional Python *override* module (`gi/overrides/GExiv2.py`, shipped by some `gexiv2` packages) that wraps the real constructor and calls the always-present `open_path()` method. The same override also adds the convenience `.get(key)` method used throughout the same function. **On this reporter's Flatpak, that override module is missing.** Calling `GExiv2.Metadata(path)` therefore falls straight through to the plain, autogenerated `GObject.__init__()` (which takes no arguments) and raises:
```
TypeError: GObject.__init__() takes exactly 0 arguments (1 given)
```
and, once that was fixed by calling `GExiv2.Metadata()` then `.open_path(path)` directly, the very next line's `metadata.get(...)` call raised a second, equally fundamental error:
```
AttributeError: 'Metadata' object has no attribute 'get'
```
— confirming the override genuinely isn't present at all, not just its constructor shortcut.

**Why Section 10.3's investigation never saw this.** Both of these are ordinary Python exceptions raised on the very first lines of `get_xmp_regions()`, and the original code wrapped that whole block in a bare `except:` with no logging of any kind:
```python
try:
    metadata = GExiv2.Metadata(image_path)
except:
    return
```
A bare `except` catches *everything*, indiscriminately — a genuine `libgexiv2`/exiv2 incompatibility (Section 10.3's hypothesis) and a simple `TypeError` from a missing convenience wrapper (the real cause) are completely indistinguishable from outside the function once caught this way. Nothing about the empty column, or the silence in the terminal, could ever have pointed at one over the other; only adding real logging and reading the resulting traceback did.

**The fix, shipped in 1.1.1:** `get_xmp_regions()` and the new `get_xmp_keyword_regions()` ([Section 4](#4-how-regions-are-loaded)) now both construct `Metadata` via the override-independent two-step form, and a new small helper, `get_xmp_tag_string(metadata, key)`, reimplements exactly what the override's `.get()` used to do (`get_tag_string(key)` if `has_tag(key)`, else `None`) using only native methods that exist regardless of whether the override is installed:
```python
metadata = GExiv2.Metadata()
metadata.open_path(image_path)
...
name = get_xmp_tag_string(metadata, region_name % i)
```
Both bare-`except:` blocks were also replaced with a two-tier `except GLib.GError` / `except Exception` split: a `GLib.GError` is exiv2's own well-defined "this isn't a format I can read metadata from" signal (e.g. an SVG file mistakenly added as Media) and is logged quietly at `DEBUG`, since it's routine and not a bug; anything else is logged at `ERROR` via `LOG.exception()`, so a failure like this one is visible in Gramps's own log the next time it happens, on any system, instead of vanishing without a trace.

**Practical implication.** This does not necessarily mean every occurrence of an empty Metadata clues column has this same cause — Section 10.3's diagnostic process (ruling out the file, the merge rule, and exiv2 itself in turn) remains the right way to approach a fresh report of this symptom, and a genuine `libgexiv2`/exiv2 ABI incompatibility of the kind hypothesized there hasn't been *ruled out* as a real, separate phenomenon that could affect a different install. But on at least this one real system, a missing Python override — not an ABI mismatch — was the actual, complete explanation, and 1.1.1's override-independent rewrite fixes that class of failure unconditionally, on any system, whether or not the override happens to be present.

## 11. Related source locations

For future maintenance, the relevant code in `PhotoTaggingGramplet.py` is concentrated around:

- `get_xmp_regions()` — the MWG XMP reader and coordinate conversion
- `get_xmp_keyword_regions()` — the `Xmp.dc.subject` whole-image fallback (new in 1.1.1)
- `get_xmp_tag_string()` — override-independent single-tag reader used by both of the above (new in 1.1.1; see [Section 10.4](#104-confirmed-root-cause-a-missing-gexiv2-python-override-fixed-in-111))
- `load_image()` — the load order and merge decision across all three sources
- `retrieve_backrefs()` — the Gramps-native region source it's merged with
- `set_person()` / `clear_ref()` — where `region.xmp_person` gets cleared
- `refresh_list()` — where the column value is displayed
- `NoteTextBuilder` / `transcribe_list_to_note_clicked()` — the "Transcribe list to a Note" feature, which includes the Metadata clues text for unassigned rows in the note it builds
- Column 4 setup (`column4`, `cell4`, `self.column_metadata_clues`) in the gramplet's UI-building method — this was column 5 before the Person/Age columns were merged into one in 1.1.1

## 12. Accompanying files

Referenced throughout this document, gathered here for convenience:

| File | Purpose |
|------|---------|
| `spectrum_demo.jpg` | Seven-region demo/test file covering the full behavioral spectrum ([Section 9.4](#94-a-single-file-covering-the-full-spectrum-of-behaviors)) |
| `spectrum_demo_preview.png` | Rendered preview of `spectrum_demo.jpg`'s seven regions — **not** itself a valid test fixture; has no embedded XMP |
| `build_spectrum_demo.sh` | Reproducible build script for `spectrum_demo.jpg` |
| `test_minimal_single_region.jpg` | Bare-minimum single-region file (no bonus namespaces); built to isolate [Section 10.3](#103-earlier-hypothesis-gexiv2-built-against-exiv2-028-superseded--see-104)'s hypothesis, ended up part of the trail that led to [Section 10.4](#104-confirmed-root-cause-a-missing-gexiv2-python-override-fixed-in-111)'s actual finding |
| `test_combined_dc_and_mwg.jpg` | Minimal one-working-tag / one-non-working-tag file, same history as above |
| `xmp_region_diagnostic.py` | Standalone diagnostic script ([Section 10.2](#102-diagnostic-tools)) — this is what actually surfaced the two tracebacks behind [Section 10.4](#104-confirmed-root-cause-a-missing-gexiv2-python-override-fixed-in-111) once logging was added |
| `get_xmp_regions_patch.py` | Superseded by the real fix shipped in 1.1.1 (see [Section 10.4](#104-confirmed-root-cause-a-missing-gexiv2-python-override-fixed-in-111)); kept for reference to the logging-only approach it took |
| `gexiv2_bug_report.md` | **Written for the Section 10.3 hypothesis, since superseded.** Do not file this as-is — it reports a `libgexiv2`/exiv2 ABI incompatibility that, per Section 10.4, was not the actual cause on the system it was written from. A corrected report, if one is still warranted, would need to start from the missing-override finding instead. |

---

*This document was drafted with AI assistance (an Anthropic Claude model, via the claude.ai chat interface) from a review of the uploaded `PhotoTaggingGramplet.py` source, public web research into the MWG Regions XMP schema, and two extended interactive debugging sessions — one that produced the since-superseded hypothesis in Section 10.3, and a later one that found and fixed the actual cause in Section 10.4. Per the Gramps project's AI-generated-content guidance, this should be disclosed in the commit message if/when this file is contributed, e.g. with a `Generated-by:` tag naming the tool/provider/version and a summary of the prompts used, and it should be reviewed by a human contributor for accuracy before being merged.*
