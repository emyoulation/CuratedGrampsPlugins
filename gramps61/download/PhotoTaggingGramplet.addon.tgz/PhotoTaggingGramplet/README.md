# Photo Tagging Gramplet
[ReadMe](README.md) ● [Change Log](CHANGELOG.md) ● [XMP data](XMP_Region_Name.md) ● [Icon List](media/icons/ICONLIST.md) 

The **Photo Tagging** is a Media category addon [**gramplet**](https://www.gramps-project.org/wiki/index.php/Gramps_Glossary#gramplet) for [Gramps](https://gramps-project.org), the free genealogy software. It lets you draw marquees directly on a photo overlay to mark where each person appears, and link each marquee to that person's Gramps record — similar to how photo-tagging works in most modern photo apps.

Tagging your photos this way means Gramps can tell you, and later generate reports showing, which people appear together in which pictures — turning a folder of scanned family photos into a searchable part of your family tree.
![The undocked Photo Tagging gramplet](media/screenshot.png)

## Features
- **Tag people in photos** by drawing a marquee (a rectangle) around them and linking it to a person in your tree, or by dragging a person directly onto the image or onto the list.
- **Turn those tags into a real photo caption**, not just an in-app label. A **Caption panel** below the photo shows a "Caption"-type Note, built from your tags and any Metadata clues, that you can rearrange into an actual caption — click the **Show/Hide Caption** toolbar button's dimmed state twice (double-click), or choose **Transcribe list to a Note**, to generate one. Every name in it is that person's own name *as of the photo's date* — the same tedious, easy-to-get-wrong lookup the tagged-people list itself already does for you (see below) — so getting a large photo archive accurately captioned no longer means hand-checking every name against a family tree. And because it's a normal Gramps Note attached to the Media object, not something private to this gramplet, it's available to Gramps's own narrative reports and books — the tagging itself stays inside this window, but the caption doesn't have to. See [Using the Caption panel](#using-the-caption-panel) below.
- **Optional automatic face detection** — one click finds faces in the photo and draws marquees for you, ready to be assigned to people. (Requires the OpenCV and NumPy libraries; see [Requirements](#requirements) below.)
- **Reorder tagged people** — drag and drop rows in the list, use the Move Up/Down toolbar buttons or right-click menu, or press Alt+↑ / Alt+↓<!--<kbd>Alt</kbd>+<kbd>Up</kbd> / <kbd>Alt</kbd>+<kbd>Down</kbd>-->. Your order is remembered the next time you open the photo.
- **The name shown for each person is the one they were actually using in that photo** — a birth name in a childhood photo, a married name in a later one — chosen from their Gramps Name records by the photo's own date, and rendered in that Name's own "Display As" format when one is set, not just whichever format is your overall Gramps default.
- **Age at time of photo** — shown right under the name, calculated from the photo's own date (falling back to today's date if the photo has none). An age that doesn't add up — for example, the photo predates the person's birth, or postdates their death — is flagged in red, which is a useful way to catch a wrong photo date or a wrongly tagged person.
- **Show/hide face marquees** and **cycle marquee labels** between row number, Gramps ID, or no label at all, via two toggle buttons on the toolbar.
- **Metadata clues column** — if a photo already has names embedded by another program, the gramplet surfaces them as a starting point, without creating anything in Gramps until you confirm them:
  - Named face regions written by a camera, phone, or photo organizer that uses Metadata Working Group (MWG) region tags — shown at their own position on the photo, if no regions are yet defined in Gramps; or, if none of those are present or readable,
  - A flat list of names from the file's `Xmp.dc.subject` tag (a much more commonly supported tag, without per-person positions) — shown as whole-photo placeholders.
  - A toolbar toggle button shows or hides this column entirely.
- **Right-click context menu** for the currently selected marquee, and for the list as a whole — see [Right-click menu reference](#right-click-menu-reference) below.
- **Selection is coupled across all three panels** — the tagged-people list, the marquees on the photo, and the Caption panel's own linked names. Selecting a person in any one highlights them in all three, and a double click on any one opens that person's editor.
- **Drag a person in** from the Clipboard or another Gramps view (such as the People list) straight onto the photo or onto the tagged-people list.
- Alternating rows in the list are lightly shaded for easier reading on longer lists.

## Prerequisites
- Gramps, with the [GExiv2 image-metadata library](https://wiki.gnome.org/Projects/gexiv2) available (this library is normally bundled with a standard Gramps install).
- **Automatic face detection is optional.** If you don't need it, the rest of the gramplet works fine without any extra setup. To enable it, install the [OpenCV](https://opencv.org/about/) and [NumPy](https://numpy.org/about/) Python libraries for the same Python that Gramps uses. Windows users in particular should note that these do not ship with Gramps by default; you can still tag photos manually by dragging a selection marquee even without them.

## Installation
Install the Photo Tagging Gramplet from within Gramps using the built-in **Addon Manager** (*Edit → Addon Manager*, or search for "Photo Tagging" in *Help → Check for updated addons*). Restart Gramps after installing, and the gramplet will be ready to add to a view.

## Usage
1. Open the **Media** category view (or any view with a media/photo sidebar).
2. Right-click the sidebar or bottombar and choose **Add a Gramplet → Photo Tagging**.
3. Select a photo. The gramplet shows the image on the left and the list of tagged people on the right.

### Tagging a person
- Drag a marquee (a rectangle) around the person's face or figure on the image.
- With the marquee selected, either:
  - Click **Add a new person** to create a new Person and link them, or
  - Click **Link** to link an existing Person from your tree, or
  - Drag a person from another Gramps view directly onto the marquee.
- Click **Edit referenced Person** (or double-click the row, or right-click it and choose **See the person details**) to open the linked person's editor, **Clear Reference** to unlink the person from that marquee (keeping the marquee), or **Remove Selection** to delete the marquee entirely.

### Using the Caption panel
The Caption panel sits below the photo preview and shows the photo's own "Caption"-type Note — the closest thing this gramplet has to a finished, human-readable caption, as opposed to the tags themselves (which only ever show up inside this window).

- **Creating a caption for a photo that doesn't have one yet**: the Show/Hide Caption toolbar button is dimmed when there's nothing to show. Double-click it (alternately, right-click the list and choose **Transcribe list to a Note**) to generate a Caption Note from your current tags and Metadata clues.
- The generated text is a **starting draft**, not a finished caption: it opens in the Note editor, unsaved, for you to rearrange, trim, or rewrite into an actual caption before it's saved to the photo. Every name in it is already that person's own name as of the photo's date, so you're editing wording, not looking up names.
- Once saved, it appears in the Caption panel automatically — and, being a normal Gramps Note, it will also show up wherever Gramps's own reports and books include Media notes.
- **Reading it**: the Caption panel is read-only there. Click a linked person's name to select them everywhere (their row, their marquee, and their highlighted name here); double-click their name to open their Person editor. Double-click any other linked object, or a plain web link, to open it the same way Ctrl+click would elsewhere in Gramps.
- **Editing it**: double-click anywhere in the Caption panel that *isn't* a link to open the Note editor for the whole caption.
- **Showing/hiding it**: click the Show/Hide Caption toolbar button. The divider between the photo and the Caption panel can be dragged to whatever split you prefer — it's remembered as a proportion of the available height, so it stays put whether you resize the gramplet or undock it into its own window.
- **Changing its font**: right-click inside the Caption panel and choose **Caption Font...** to pick its own base font family and size, independent of your overall Gramps font. Your choice is remembered for next time.

### Toolbar reference
![Toolbar buttons](media/PhotoTagging_toolbar.png) 
| Button Name | Action |
|-----|----------------------------|
| Show/Hide face marquees | Temporarily hides all marquees so you can see the photo clearly. |
| Show ID | Cycles the label shown in each marquee: row number, Gramps ID, or none. |
| Show/Hide Metadata clues | Shows or hides the Metadata clues column without discarding anything it found. |
| Show/Hide Caption | Shows or hides the Caption panel. Dimmed when the photo has no Caption Note yet — double-click it to generate one (see [Using the Caption panel](#using-the-caption-panel)). |
| Link | Link the selected marquee to an existing person in your tree. |
| Add a new person | Create a new person and link them to the selected marquee. |
| Clear Reference | Unlink the person from the selected marquee, keeping the marquee. |
| Remove Selection | Delete the selected marquee entirely. |
| Edit referenced Person | Open the Person Editor for whoever is linked to the selected marquee. |
| Move Up / Move Down | Reorder the selected person in the list. |
| Zoom In/Out | Zoom the photo in/out. |
| Detect faces | Automatically find faces in the photo and draw marquees for them. |
| Settings | Open the gramplet's settings dialog (see below). |
| Help | Open this gramplet's page in the Gramps wiki. |

### Right-click menu reference
Right-click a marquee on the photo, or a row in the list, for a context menu with the following, in order:

| Menu Item | Action |
|-----|----------------------------|
| See the person details | Opens the Person Editor for whoever is linked to the selected marquee — the same action as double-clicking the row. |
| Make the person active | Sets whoever is linked to the selected marquee as the active person elsewhere in Gramps. |
| Link | Link the selected marquee to an existing person in your tree. |
| Add a new person | Create a new person and link them to the selected marquee. |
| Clear Reference | Unlink the person from the selected marquee, keeping the marquee. |
| Remove Selection | Delete the selected marquee entirely. |
| Move Up / Move Down | Reorder the selected person in the list. |
| Swap with *(name)* | Only shown when at least one other tagged person exists on the same photo. Swaps person assignments between the selected marquee and that other person's marquee — both marquees stay exactly where they are; only who's linked to each one trades places. |
| Transcribe list to a Note | Creates the photo's Caption-type Note (the one the Caption panel shows — see [Using the Caption panel](#using-the-caption-panel)), attached to the photo the same way "create and add a new note" in the Media editor would — pre-filled with the photo's title/date/ID, the tagged people (each linked to their Gramps record, with the name they were using as of the photo's date), any Metadata clues for people not yet tagged, and the underlying tagging order, as a starting draft to rearrange into an actual caption. |

### Reordering people
Once more than one person is tagged, you can put them in whatever order makes sense to you (for example, left-to-right, or by age):

- Drag and drop a row in the list, or
- Select a row and click **Move Up** / **Move Down**, or use the right-click menu, or
- Select a row and press **Alt+Up** / **Alt+Down**.

The order is saved automatically when you move to a different photo or close Gramps, so it will still be there next time.

### Settings
Click the **Settings** toolbar button to adjust:

- **Selection** — whether to replace an existing reference to a person without asking for confirmation, when that person is already tagged elsewhere in the same photo.
- **Face detection** — the minimum face width and height (in pixels) to detect, whether to detect faces inside marquees that already exist, and a sensitivity setting from 1 (least sensitive) to 20 (most sensitive).

## Getting help
Click the **Help** toolbar button, or visit the [Photo Tagging Gramplet page](https://www.gramps-project.org/wiki/index.php/Addon:Photo_Tagging_Gramplet) on the Gramps wiki. For details on the Metadata clues column specifically — including a known, now-fixed issue with some Flatpak installs — see [XMP data](XMP_Region_Name.md).

Discuss the Photo Tagging Gramplet on the Gramps support forum (powered by Discourse)
* [https://gramps.discourse.group/t/gramps-resists-being-a-photo-detective/1889](Photo Detective gramplet)
* https://gramps.discourse.group/t/photo-tagging-attributes-not-being-written-to-the-media-file/7727/6
* https://gramps.discourse.group/t/cannot-find-photo-tagging-addon-gramplet/6853
* https://gramps.discourse.group/t/could-image-marquee-definition-have-higher-resolution/6795
* https://gramps.discourse.group/t/probleme-de-traduction-du-nom-du-gramplet-phototagging/4906
* [https://gramps.discourse.group/t/photo-tagging-in-gramps-more/3066](Metadata in PhotoTagging and elsewhere)
* https://gramps.discourse.group/t/suggested-update-to-phototagginggramplet-to-support-xmp-face-regions/1209
* https://gramps.discourse.group/t/utilize-media-metadata-date-and-face-tags-in-import-and-references/1430
* https://gramps.discourse.group/t/new-gramplet-to-show-all-images-for-a-person/1799

## License
This addon is free software, licensed under the GNU General Public License,
version 2 or later, consistent with Gramps itself.
