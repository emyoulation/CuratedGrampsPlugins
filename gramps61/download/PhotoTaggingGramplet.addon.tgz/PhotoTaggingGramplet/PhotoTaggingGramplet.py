#
# Gramps - a GTK+/GNOME based genealogy program
# http://gramps-project.org
# Gramplet registration - plug-in/add-on to extend Gramps
#
# Copyright (C) 2013    Artem Glebov <artem.glebov@gmail.com>
# Copyright (C) 2014    Nick Hall
# Copyright (C) 2021    Paul Culley
# Copyright (C) 2021    Bruce Jackson
# Copyright (C) 2026    Brian McCullough
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

# $Id: $

# -------------------------------------------------------------------------
#
# Standard python modules
#
# -------------------------------------------------------------------------
import sys
import os
import re
import json
import math
import pickle
import logging
import tempfile
from urllib.parse import quote
import cairo

LOG = logging.getLogger(".PhotoTaggingGramplet")

# -------------------------------------------------------------------------
#
# GTK/Gnome modules
#
# -------------------------------------------------------------------------
from gi.repository import Gio
from gi.repository import Gtk
from gi.repository import Gdk
from gi.repository import GdkPixbuf
from gi.repository import GLib
from gi.repository import GObject
from gi.repository import Pango

import gi

repository = gi.Repository.get_default()
v_array = repository.enumerate_versions("GExiv2")
if not v_array:
    raise ValueError("GExiv2 is not installed")
gi.require_version("GExiv2", v_array[-1])
from gi.repository import GExiv2

# -------------------------------------------------------------------------
#
# gramps modules
#
# -------------------------------------------------------------------------
from gramps.gen.utils.db import get_birth_or_fallback, get_death_or_fallback
from gramps.gen.utils.file import media_path_full
from gramps.gen.errors import WindowActiveError
from gramps.gen.config import config
from gramps.gen.db import DbTxn
from gramps.gen.display.name import displayer as name_displayer
from gramps.gen.datehandler import displayer as date_displayer
from gramps.gen.plug import BasePluginManager, Gramplet, MenuOptions, PluginRegister
from gramps.gen.lib import (
    Attribute,
    MediaRef,
    Name,
    Note,
    NoteType,
    Person,
    StyledText,
    StyledTextTag,
    StyledTextTagType,
    Surname,
)
from gramps.gen.lib.date import Today
from gramps.gui.dialog import OkDialog
from gramps.gui.editors import EditFamily, EditNote, EditObject
from gramps.gui.editors.editperson import EditPerson
from gramps.gui.selectors import SelectorFactory
from gramps.gen.plug.menu import BooleanOption, EnumeratedListOption, NumberOption
from gramps.gui.plug import PluginWindows
from gramps.gui.pluginmanager import GuiPluginManager
from gramps.gui.widgets import SelectionWidget, Region
from gramps.gui.widgets.styledtexteditor import StyledTextEditor
from gramps.gui.widgets.styledtextbuffer import MATCH_FLAVOR, MATCH_STRING
from gramps.gui.ddtargets import DdTargets

from gramps.gen.const import GRAMPS_LOCALE as glocale

try:
    _ = glocale.get_addon_translator(__file__).sgettext
except ValueError:
    _ = glocale.translation.sgettext

# -------------------------------------------------------------------------
#
# face detection module
#
# -------------------------------------------------------------------------
sys.path.append(os.path.abspath(os.path.dirname(__file__)))
import facedetection

# -------------------------------------------------------------------------
#
# Fuzzy Matching addon (optional)
#
# -------------------------------------------------------------------------


def _get_fuzzy_match_lookup():
    """
    Look up and import the Fuzzy Matching addon's "Fuzzy Match API"
    GENERAL plugin via Gramps' own plugin registry, returning its
    show_fuzzy_lookup function -- see _handle_pipe_icon_double_click()
    and, in the Fuzzy Matching addon's own folder, FuzzyMatchAPI.md
    for the calling convention it follows.

    Deliberately not a bare `import FuzzyMatchLookupWindow`: an
    earlier version of this did exactly that, both at this module's
    own top level and, when that turned out to fail silently even
    with Fuzzy Matching installed and working, again at click time
    instead -- neither worked. Gramps only adds an addon's own folder
    to sys.path *while it is itself importing that addon's registered
    module*, then resets it again immediately after (see
    BasePluginManager.import_plugin()'s own docstring: "this will add
    the pdata.fpath to sys.path first (if needed), import, and then
    reset path") -- it does not leave every addon's folder on
    sys.path for the rest of the session the way an earlier version
    of this comment assumed. A bare import from a *different* addon's
    code has no such guarantee at any point after Fuzzy Matching's own
    module has finished its own one-time load. Going through
    BasePluginManager's own get_plugin()/import_plugin() is what
    actually sets sys.path correctly for this one import, which is
    exactly what registering "Fuzzy Match API" as a GENERAL plugin
    (see FuzzyMatchingGramplet.gpr.py, in that addon's own folder) is
    for -- see the Gramps wiki's "Addons development" page, "General
    plugins" section, for the standard pattern this follows.

    :returns: The show_fuzzy_lookup function, or None if the Fuzzy
        Matching addon isn't installed/enabled, isn't new enough to
        register this plugin, or the import otherwise fails.
    """
    pmgr = BasePluginManager.get_instance()
    pdata = pmgr.get_plugin("Fuzzy Match API")
    if pdata is None:
        return None
    try:
        module = pmgr.import_plugin(pdata)
    except ImportError:
        return None
    if module is None:
        return None
    return getattr(module, "show_fuzzy_lookup", None)

# -------------------------------------------------------------------------
#
# configuration
#
# -------------------------------------------------------------------------

# This addon's own registered id (see PhotoTaggingGramplet.gpr.py), used
# both to look up its own PluginData (README path, help_url) when the
# Help button is clicked, and below as an identity check saved into
# PhotoTaggingGramplet.ini's own [meta] section.
MY_PLUGIN_ID = "Photo Tagging"

# Bumped whenever a change to the saved keys below would make an older
# PhotoTaggingGramplet.ini misleading rather than merely out of date
# (e.g. a renamed or repurposed key) -- see _CONFIG's own identity/schema
# check just below. Adding a brand new key with a sensible default (as
# opposed to renaming or repurposing an existing one) does not need a
# bump -- an older .ini simply won't have it, and it loads as that default.
_CONFIG_SCHEMA_VERSION = "1"

GRAMPLET_CONFIG_NAME = "phototagginggramplet"

# Registering with this module's own directory plus GRAMPLET_CONFIG_NAME
# (no ".ini" suffix -- Gramps adds that) places the resulting
# PhotoTaggingGramplet.ini alongside PhotoTaggingGramplet.py, matching
# RelationshipFilter.ini's own placement next to RelationshipFilter.py,
# rather than register_manager()'s own default location.
_PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG = config.register_manager(os.path.join(_PLUGIN_DIR, GRAMPLET_CONFIG_NAME))
CONFIG.register("meta.plugin_id", "")
CONFIG.register("meta.schema_version", "")
CONFIG.register("detection.box_size", (50, 50))
CONFIG.register("detection.inside_existing_boxes", False)
CONFIG.register("detection.sensitivity", 10)
CONFIG.register("selection.replace_without_asking", False)
# 0 (Name.DEF) means "no override" -- the Name column and the Caption
# generator fall back to each Name's own "Display as" field, and from
# there to whichever format Preferences > Data > Name format currently
# selects, exactly as they did before this setting existed. Any other
# value is one of name_displayer.get_name_format()'s own format ids,
# taking priority over both of those -- see
# display_name_respecting_format()'s own docstring.
CONFIG.register("selection.name_display_format", 0)
# The format string that "selection.name_display_format" pointed to the
# last time it was saved (see save_config()). A custom name format's
# own id is just its position in Preferences > Data > Name format's own
# list -- editing, reordering, or deleting *any* custom format there
# can silently repoint an unrelated id at a different format, or at
# nothing at all. Saving the string alongside the id, and treating a
# mismatch between them as "the id no longer means what it used to",
# is how validate_name_display_format_override() below catches that
# rather than silently mis-rendering names under a format the person
# never actually chose. Empty string is a valid value (matches
# Name.DEF's own permanent empty format_str, and also naturally covers
# a pre-upgrade config saved before this key existed).
CONFIG.register("selection.name_display_format_str", "")
# Empty string means "use the Caption panel's own default font" (see
# CaptionTextEditor.__init__()/cb_choose_font()); otherwise a
# Pango.FontDescription string, e.g. "Sans 10" or "Serif Bold 12".
CONFIG.register("caption.font", "")
CONFIG.load()

if (
    CONFIG.get("meta.plugin_id") != MY_PLUGIN_ID
    or CONFIG.get("meta.schema_version") != _CONFIG_SCHEMA_VERSION
):
    # Missing (a fresh install, nothing ever saved here yet) or from an
    # incompatible revision of this addon -- reset every saved setting to
    # its default rather than risk misinterpreting a value some future
    # (or, in principle, past) revision of this code saved with a
    # different meaning. This is also what writes PhotoTaggingGramplet.ini
    # for the very first time, with correct [meta] values, on a fresh
    # install -- see RelationshipFilter.ini's own identical pattern for
    # why both are registered with a default (an empty string) that can
    # never match a real saved value.
    LOG.info(
        "Photo Tagging settings are missing or from an incompatible "
        "version; resetting to defaults."
    )
    CONFIG.reset()
    CONFIG.set("meta.plugin_id", MY_PLUGIN_ID)
    CONFIG.set("meta.schema_version", _CONFIG_SCHEMA_VERSION)
    CONFIG.save()

MIN_FACE_SIZE = CONFIG.get("detection.box_size")
REPLACE_WITHOUT_ASKING = CONFIG.get("selection.replace_without_asking")
DETECT_INSIDE_EXISTING_BOXES = CONFIG.get("detection.inside_existing_boxes")
SENSITIVITY = CONFIG.get("detection.sensitivity")


def validate_name_display_format_override(number, expected_fmt_str):
    """
    Return `number` if it still means what it meant when saved,
    otherwise ``Name.DEF`` (0, "no override").

    A custom name format's own id in Gramps is just its position in
    Preferences > Data > Name format's own list -- there's nothing
    else identifying it. Adding, editing, reordering, or deleting any
    custom format there (not necessarily the one this addon is
    pointed at) can silently repoint a previously-valid id at a
    completely different format, or at nothing at all, with no error
    raised anywhere -- the Name column and Caption generator would
    just start rendering names under a format the person never chose,
    indistinguishable from correct output until someone happens to
    notice.

    Cross-checking the id against the format string saved alongside it
    (see ``selection.name_display_format_str``'s own CONFIG.register()
    comment) catches this: if Gramps' *current* list has no entry for
    `number`, or that entry's format string no longer matches
    `expected_fmt_str`, the id has been repointed since it was saved,
    and falling back to Name.DEF is the safe choice -- silently
    reverting to "use Gramps' regular preference" is far less harmful
    than silently rendering names under the wrong format indefinitely.

    ``Name.DEF`` itself is always considered valid regardless of
    `expected_fmt_str`: its own format_str is a permanent empty
    placeholder (see ``display_name_respecting_format()``'s docstring),
    not a real format that could ever go stale.

    :param number: A stored ``selection.name_display_format`` value.
    :param expected_fmt_str: The ``selection.name_display_format_str``
        saved alongside it.
    :returns: `number`, unchanged, if still valid; otherwise
        ``Name.DEF``.
    """
    if number == Name.DEF:
        return Name.DEF
    current_fmt_str = None
    for fmt_number, _label, fmt_str, _active in name_displayer.get_name_format(
        also_default=True
    ):
        if fmt_number == number:
            current_fmt_str = fmt_str
            break
    if current_fmt_str is None or current_fmt_str != expected_fmt_str:
        LOG.info(
            "Photo Tagging: saved name display format id %s no longer "
            "matches its saved format string (Preferences > Data > Name "
            "format has changed since); reverting to Default format.",
            number,
        )
        return Name.DEF
    return number


NAME_DISPLAY_FORMAT_OVERRIDE = validate_name_display_format_override(
    CONFIG.get("selection.name_display_format"),
    CONFIG.get("selection.name_display_format_str"),
)

# Markdown Dash's registered id (see that addon's own .gpr.py, if
# installed) -- its local README.md viewer is preferred, when available,
# over opening the wiki page below.
#
# NOTE: this assumes Markdown Dash is a registered addon. If/when
# MarkdownUtils/Markdown Dash are folded into Gramps core (discussed for
# 6.2/7.0), PluginRegister will no longer have this id at all, and
# resolve_markdown_dash_opener() will *silently* fall back to help_url
# forever, mistaking "now built in" for "not installed" -- not a crash,
# but a quiet loss of the in-app README viewer. Whoever does that merge
# should replace this addon-id lookup with however the core module is
# actually detected/imported at that point.
MARKDOWNDASH_ID = "markdowndash"

# Timing for flash_row()'s cross-fade (see _shade_cell()): total
# duration of the fade up to the theme's selected-row color and back
# down to normal, and how often (in ms) the fade is re-evaluated and
# the treeview told to redraw. 30ms is a plain GLib.timeout_add tick,
# not tied to a compositor frame clock -- smooth enough for a subtle
# background tint without pulling in Gtk's separate frame-clock API
# for what is otherwise a two-property cell_data_func.
ROW_FLASH_DURATION_MS = 500
ROW_FLASH_INTERVAL_MS = 30
# The flash never fully replaces the theme's selected-row color at
# its peak -- capped below its own alpha so row text stays legible
# against it regardless of the active GTK theme's chosen strength.
ROW_FLASH_MAX_ALPHA = 0.55

# Drag-and-drop target used to reorder rows within the region list itself.
# The value only needs to be unique; the source/destination match is done
# by comparing the id() of the gramplet, the same technique used by
# gramps.gui.editors.displaytabs.embeddedlist.EmbeddedList.
REORDER_TARGET_NAME = "PHOTOTAGGING_REGION_ROW"
REORDER_ATOM = Gdk.atom_intern(REORDER_TARGET_NAME, False)

# Arbitrary "info" code identifying a plain-text drop (see
# Gtk.TargetList.add_text_targets() where the treeview's drop targets
# are set up, and text_drag_received()) -- distinct from the pickled
# Person-drop payloads the same treeview also accepts.
TEXT_TARGET_INFO = 100

# Drag types that carry a *reference* to a Person rather than the
# Person itself, accepted on the photo and the list alongside
# PERSON_LINK/HANDLE_LIST. Their payload is the usual Gramps 4-tuple
# (drag_type, source id, obj, row), where obj is a ChildRef (Family
# editor Children tab) or PersonRef (Person editor Associations tab)
# -- resolved to the Person it points at by person_handle_from_drop().
# CHILD and SPOUSE carry a plain Person handle in the same slot.
PERSON_REFERENCE_DD_TYPES = (
    DdTargets.CHILDREF,
    DdTargets.PERSONREF,
    DdTargets.CHILD,
    DdTargets.SPOUSE,
)


def person_handle_from_drop(data):
    """
    Returns the Person handle carried by a Gramps 4-tuple drag payload
    -- either a plain handle string (PERSON_LINK, CHILD, SPOUSE), or a
    reference object pointing at a Person (ChildRef, PersonRef) -- or
    None if there is none.

    :param data: The unpickled drag payload.
    :returns: A Person handle string, or None.
    """
    if not isinstance(data, (tuple, list)) or len(data) != 4:
        return None
    _drag_type, _source_id, obj, _row = data
    if isinstance(obj, str):
        return obj or None
    get_ref = getattr(obj, "get_reference_handle", None)
    if callable(get_ref):
        return get_ref() or None
    return None


# The 3 states cycled through by the "show ID" toolbar button.
ID_MODE_ROW = "row"
ID_MODE_GRAMPS = "gramps"
ID_MODE_HIDDEN = "hidden"
ID_MODE_ORDER = [ID_MODE_ROW, ID_MODE_GRAMPS, ID_MODE_HIDDEN]

# Gramps has no built-in notion of "these people's display order
# within this photo", nor of "a face region embedded in the file that
# hasn't been linked to a Person yet". Both are persisted together in
# a single JSON-valued custom Attribute on the Media object itself
# (the photo) -- the standard way for an addon to attach its own data
# to a Gramps object without changing the database schema. Without
# this, the order and any unlinked embedded clues only survived in
# memory for the life of the gramplet instance, and were lost as soon
# as the photo was reloaded (switching away and back, or restarting
# Gramps).
#
# The per-region field names are borrowed directly from the
# Xmp.mwg-rs.Regions schema this gramplet already reads (see
# get_xmp_regions()) -- name/type/x/y/w/h/unit, normalized 0.0-1.0
# center-plus-size, exactly as a real MWG XMP tag would hold them --
# rather than inventing a parallel convention, so a future
# metadata-writing utility that flattens this layer together with the
# file's own embedded/sidecar XMP has one vocabulary to translate, not
# two. Two fields have no MWG equivalent and are this addon's own
# extension:
#
#   source      SOURCE_GRAMPS for a region confirmed and linked to a
#               Person in this tree (authoritative -- always wins over
#               an embedded region at/near the same position).
#               SOURCE_EMBEDDED for a region read from the file's own
#               embedded metadata that has not (yet) been linked to
#               anyone. A SOURCE_EMBEDDED entry is written even when a
#               SOURCE_GRAMPS region already covers the same photo --
#               the way a lower-specificity CSS rule survives being
#               overridden rather than being deleted -- so the clue is
#               still there to offer again if that link is ever
#               cleared, and so a future flattening utility sees the
#               full cascade, not just whichever layer currently wins.
#   gramps_ref  Gramps ID of the linked Person. SOURCE_GRAMPS entries
#               only.
#
# There is no separate "order" field: display order is simply array
# position in "regions", the same way Xmp.mwg-rs.Regions/
# mwg-rs:RegionList is itself an ordered rdf:Seq rather than carrying
# an explicit index of its own.
REGION_DATA_ATTR_TYPE = "PhotoTagging Regions"
REGION_DATA_SCHEMA = "gramps.phototagging.regions/1"

# Superseded by REGION_DATA_ATTR_TYPE above as of 1.2.0. A photo
# tagged by an older version of this gramplet still has its manual
# order stored this way -- a small human-readable table, one line per
# tagged region, "row, Gramps ID":
#
#   1, I1123
#   2, I0106
#   3, I1010
#
# get_stored_region_order() reads this once, the first time such a
# photo is opened under 1.2.0+, purely to recover the order a person
# already set up; persist_region_order() then writes a fresh
# REGION_DATA_ATTR_TYPE attribute and deletes this one, so the
# fallback only ever fires once per photo.
LEGACY_ORDER_ATTR_TYPE = "PhotoTagging Order"

SOURCE_GRAMPS = "gramps"
SOURCE_EMBEDDED = "embedded"
# A region with a name typed directly into this attribute (or, once
# there's a UI for it, entered through this gramplet some other way)
# rather than read from the file's own embedded metadata -- a
# placeholder for "I know who this is, I just haven't linked or
# created the Person yet." Unlike SOURCE_EMBEDDED, there is no live
# copy of this anywhere else to re-derive it from on the next load, so
# a "manual" entry is the one case where this attribute is read back
# as actual input, not just recorded for the record.
#
# "given" and "surname" are carried alongside "name" for
# SOURCE_EMBEDDED and SOURCE_MANUAL entries (but not SOURCE_GRAMPS
# ones, whose real name should always be looked up live via
# gramps_ref rather than trusted from a cached copy here) -- split
# out via split_placeholder_name() -- specifically so this data can
# be handed, structured, to something that wants name parts rather
# than a single string: pre-filling a new Person's primary Name (see
# add_person_clicked()) today, and -- the reason for splitting it out
# now rather than only when that's built -- other Gramps tools that
# take a given/surname pair as input (a Fuzzy Match-style gramplet's
# surname filter, a Relationship Filter's given/surname fields, the
# Data Entry gramplet's own "Surname, Given" field) tomorrow, without
# each of them needing to know this attribute's schema at all -- see
# split_placeholder_name()'s own docstring.
SOURCE_MANUAL = "manual"

# Single translatable string per task, reused for the context menu item,
# toolbar tooltip, and (for LINK_PERSON_TEXT) the Person selector dialog
# title, rather than three subtly different phrases for the same action.
LINK_PERSON_TEXT = _("Link")
ADD_NEW_PERSON_TEXT = _("Add a new person")
CLEAR_REFERENCE_TEXT = _("Clear Reference")

# The "Caption" Note type used by the Show/Hide Caption toolbar button
# and panel (see refresh_caption()) is a custom NoteType -- Gramps has
# no built-in NoteType for this -- identified purely by this string,
# the same way REGION_DATA_ATTR_TYPE above identifies this addon's own
# custom Attribute type. Not wrapped in _() since it is stored in the
# database as literal text (via NoteType((NoteType.CUSTOM,
# CAPTION_NOTE_TYPE_STRING))) and must match consistently regardless
# of the active display language, matching REGION_DATA_ATTR_TYPE's own
# reasoning.
CAPTION_NOTE_TYPE_STRING = "Caption"

# Prefix used by every "gramps://" object link this addon builds into
# Note text (see NoteTextBuilder.add_link() callers) and the one
# prefix CaptionTextEditor recognizes when handling a click -- kept as
# a single constant rather than repeating the literal string, so a
# link built here and a link parsed there can't silently drift apart.
GRAMPS_URL_PREFIX = "gramps://"

# Background color CaptionTextEditor.highlight_person() applies to a
# Person's linked text in the Caption panel, to match their selected
# row/marquee elsewhere in the gramplet (see
# PhotoTaggingGramplet.apply_selected_region()) -- a soft highlighter
# yellow, chosen (rather than reusing MARQUEE_BLUE elsewhere in this
# file, which is a foreground/outline color, not a fill) to read
# clearly as a text background against both light and dark Gramps
# themes.
CAPTION_HIGHLIGHT_BACKGROUND = "#fff3a0"


def get_region_data_attribute(media):
    for attr in media.get_attribute_list():
        if str(attr.get_type()) == REGION_DATA_ATTR_TYPE:
            return attr
    return None


def get_region_data_text(media):
    """
    Returns the current text of `media`'s "PhotoTagging Regions"
    attribute (see REGION_DATA_ATTR_TYPE), or "" if it has none.
    Shared by get_stored_region_order() and main()'s same-handle
    drift check, so both agree on exactly what "the stored value"
    means.
    """
    attr = get_region_data_attribute(media)
    return attr.get_value() if attr is not None else ""


def read_stored_region_entries(media):
    """
    Returns the list of entry dicts in `media`'s "PhotoTagging
    Regions" attribute, or None if there is no usable attribute (none
    at all, unparseable, or empty) -- in which case the original
    metadata is read instead.

    :param media: A Media object.
    """
    attr = get_region_data_attribute(media)
    if attr is None:
        return None
    try:
        entries = json.loads(attr.get_value())["regions"]
    except (json.JSONDecodeError, KeyError, TypeError):
        return None
    if not isinstance(entries, list):
        return None
    entries = [e for e in entries if isinstance(e, dict)]
    return entries or None


def clue_fields(region) -> dict:
    """
    The part of a stored entry that records what the original
    metadata said about `region`, kept even after the row is renamed
    or linked to a Person -- so the attribute holds the whole clue,
    not only the person's current answer (the basis for matching the
    same person across a group of photos):

    - ``clue``: the name as read from the metadata
    - ``clue_source``: where it was read from (a CLUE_SOURCE_* key)
    - ``clue_id``: the source's own id for the person, if it has one
      (Picasa's contact id)
    - ``whole_image``: true for a position-less keyword clue

    :param region: A gramplet Region.
    :returns: A dict, empty if the region has no clue.
    """
    clue = getattr(region, "xmp_person", "") or ""
    if not clue:
        return {}
    fields = {"clue": clue}
    if getattr(region, "xmp_source", ""):
        fields["clue_source"] = region.xmp_source
    if getattr(region, "xmp_clue_id", ""):
        fields["clue_id"] = region.xmp_clue_id
    if getattr(region, "xmp_whole_image", False):
        fields["whole_image"] = True
    return fields


def get_legacy_order_attribute(media):
    for attr in media.get_attribute_list():
        if str(attr.get_type()) == LEGACY_ORDER_ATTR_TYPE:
            return attr
    return None


def find_caption_note(media, db) -> Note | None:
    """
    Return the first Caption-type :class:`~gramps.gen.lib.note.Note`
    attached to `media` (in its own note list order), or ``None`` if
    it has none -- used to decide whether the Show/Hide Caption
    toolbar button should be dimmed and, when it isn't, what to
    render in the Caption panel (see
    ``PhotoTaggingGramplet.refresh_caption()``).

    :param media: The Media object to look for a Caption Note on, or
        ``None`` (e.g. no active Media), in which case ``None`` is
        returned.
    :param db: The database to look up Note handles in.
    :returns: The first Caption-type Note, or ``None``.
    """
    if media is None:
        return None
    for note_handle in media.get_note_list():
        note = db.get_note_from_handle(note_handle)
        if note is not None and str(note.get_type()) == CAPTION_NOTE_TYPE_STRING:
            return note
    return None


def parse_legacy_order_text(text, db):
    """
    Parses the pre-1.2.0 "row, Gramps ID" table (see
    LEGACY_ORDER_ATTR_TYPE) into {person_handle: row}. Kept only for
    get_stored_region_order()'s one-time migration fallback.

    Returns (order_by_handle, ok). Since a person could hand-edit this
    attribute (it was a normal, visible Attribute) and mangle it, ok
    is False whenever the text is structurally invalid -- the caller
    should then discard it and persist a fresh table reflecting the
    current natural order, rather than crash or let the corrupt text
    linger unfixed. A blank/absent attribute, or a row naming a Gramps
    ID with no matching person (e.g. that person was since deleted),
    is not treated as corruption -- those rows are simply skipped.
    """
    order_by_handle = {}
    if not text or not text.strip():
        return order_by_handle, True
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(",", 1)
        if len(parts) != 2:
            return {}, False
        row_text, gramps_id = parts[0].strip(), parts[1].strip()
        if not gramps_id:
            return {}, False
        try:
            row = int(row_text)
        except ValueError:
            return {}, False
        person = db.get_person_from_gramps_id(gramps_id)
        if person is not None:
            order_by_handle[person.get_handle()] = row
    return order_by_handle, True


def parse_region_data(text, db):
    """
    Parses the JSON stored in a Media object's "PhotoTagging Regions"
    attribute (see REGION_DATA_ATTR_TYPE) into (order_by_handle,
    order_by_name).

    `row` is now the entry's absolute position in the persisted list
    (1, 2, 3, ...) -- counting EVERY entry, not just "gramps"-sourced
    ones. Counting only linked entries used to mean that linking the
    2nd of 3 still-unlinked placeholders bumped it to row 1 (the only
    linked entry counts as "row 1" of the linked-only subsequence),
    which then sorted it ahead of the other two placeholders instead
    of leaving it at position 2 -- see sort_regions_by_stored_order().

    An unlinked ("embedded"/"manual") entry has no Gramps handle to
    key on, so it's tracked by placeholder name instead, in
    order_by_name: {name: [row, row, ...]} -- a FIFO queue per name,
    since more than one region can carry the same placeholder name
    (e.g. two different unrelated people who both happen to be named
    "John Smith" in the photo's metadata). sort_regions_by_stored_order()
    pops from the front of each name's queue as it encounters
    same-named regions, which pairs them back up in the same relative
    order they were originally persisted in.

    Returns (order_by_handle, order_by_name, ok). Since a person can
    hand-edit this attribute (it is a normal, visible Attribute) and
    mangle it, ok is False whenever the text is structurally invalid
    JSON or the wrong shape -- the caller should then discard it and
    persist a fresh attribute reflecting the current natural order,
    rather than crash or let the corrupt text linger unfixed. A
    blank/absent attribute, an unlinked entry with no name, or a
    "gramps"-sourced entry naming a Gramps ID with no matching person
    (e.g. that person was since deleted), is not treated as
    corruption -- those entries are simply skipped for ordering
    purposes.
    """
    order_by_handle = {}
    order_by_name = {}
    if not text or not text.strip():
        return order_by_handle, order_by_name, True
    try:
        regions = json.loads(text)["regions"]
    except (json.JSONDecodeError, KeyError, TypeError):
        return {}, {}, False
    if not isinstance(regions, list):
        return {}, {}, False
    for row, entry in enumerate(regions, start=1):
        if not isinstance(entry, dict):
            return {}, {}, False
        source = entry.get("source")
        if source == SOURCE_GRAMPS:
            handle = entry.get("person_handle")
            if handle and db.has_person_handle(handle):
                order_by_handle[handle] = row
                continue
            gramps_id = entry.get("gramps_ref")
            if not gramps_id:
                continue
            person = db.get_person_from_gramps_id(gramps_id)
            if person is not None:
                order_by_handle[person.get_handle()] = row
        elif source in (SOURCE_EMBEDDED, SOURCE_MANUAL):
            name = entry.get("name")
            if name:
                order_by_name.setdefault(name, []).append(row)
    return order_by_handle, order_by_name, True


def get_stored_region_order(media, db):
    """
    Returns (order_by_handle, order_by_name, ok) for `media`: parses
    its current "PhotoTagging Regions" JSON attribute if present (see
    REGION_DATA_ATTR_TYPE / parse_region_data()), else falls back once
    to a pre-1.2.0 "PhotoTagging Order" attribute if that's all the
    photo has (see LEGACY_ORDER_ATTR_TYPE / parse_legacy_order_text())
    so a photo tagged under the old format doesn't lose its manual
    order the first time it's opened under the new one. The legacy
    format never tracked unlinked placeholders at all, so its
    order_by_name is always empty.
    persist_region_order() writes the new attribute and removes the
    legacy one the next time this photo's data is persisted, so this
    fallback is only ever taken once per photo.
    """
    attr = get_region_data_attribute(media)
    if attr is not None:
        return parse_region_data(attr.get_value(), db)
    legacy_attr = get_legacy_order_attribute(media)
    if legacy_attr is not None:
        order_by_handle, ok = parse_legacy_order_text(legacy_attr.get_value(), db)
        return order_by_handle, {}, ok
    return {}, {}, True


def split_placeholder_name(name):
    """
    Splits a placeholder name -- an unlinked region's SOURCE_EMBEDDED
    or SOURCE_MANUAL name (see REGION_DATA_ATTR_TYPE) -- into (given,
    surname), matching both name conventions already in play around
    this data: the Data Entry gramplet's own "Surname, Given"
    quick-entry field, and a plain "Given Surname" display string --
    the shape MWG/XMP names and most embedded metadata actually
    arrive in. Used both to persist "given"/"surname" alongside
    "name" for those two sources, and to pre-fill a new Person's
    primary Name from one (see add_person_clicked()).

    :param name: The placeholder text.
    :returns: A (given, surname) tuple of strings, either of which may
        be "" if `name` doesn't clearly split -- a single word, for
        instance, is treated entirely as a surname, matching how
        Gramps treats an unparsed name for a new Person elsewhere.
    """
    name = name.strip()
    if not name:
        return "", ""
    if "," in name:
        surname, _, given = name.partition(",")
        return given.strip(), surname.strip()
    parts = name.split()
    if len(parts) == 1:
        return "", parts[0]
    return " ".join(parts[:-1]), parts[-1]


def effective_placeholder_name(region):
    """
    The name to show (and let a person edit) in the Name column for
    `region` when it has no linked Person yet: a previous manual edit
    (region.manual_name) if there is one -- even an empty string,
    which still means "deliberately cleared, don't re-suggest
    anything" -- else the embedded/keyword-derived clue
    (region.xmp_person), if any, else "".

    :param region: A gramplet Region with region.person is None.
    :returns: The placeholder text, possibly "".
    """
    manual = getattr(region, "manual_name", None)
    if manual is not None:
        return manual
    return getattr(region, "xmp_person", "")


def metadata_clue_name(region):
    """
    The raw name from `region`'s own embedded/keyword-derived metadata
    clue (region.xmp_person) -- deliberately *not*
    effective_placeholder_name(), which is a different thing: the Name
    column's own current value, which can be (and often is) a manual
    edit that has nothing to do with what the metadata actually said.
    Everything reading the Metadata Clues column specifically --
    cb_clue_icon_cell_data(), open_piping_options_dialog(),
    _handle_pipe_icon_double_click() -- needs this one, not that one:
    the whole point of that column and its icon is "here is what the
    metadata says", regardless of whatever the person has since typed
    into the Name column for the same row.

    Unlike metadata_clue_text_for() (the column's own *display* text),
    this never adds the "(whole photo, no region)" annotation -- that
    is a note for a human reading the column, not part of the name
    itself, and would otherwise end up copied to the clipboard or
    passed to a phonetic surname search as if it were.

    :param region: A gramplet Region.
    :returns: The raw clue text, possibly "".
    """
    return getattr(region, "xmp_person", "") or ""


def save_config():
    CONFIG.set("detection.box_size", MIN_FACE_SIZE)
    CONFIG.set("detection.inside_existing_boxes", DETECT_INSIDE_EXISTING_BOXES)
    CONFIG.set("detection.sensitivity", SENSITIVITY)
    CONFIG.set("selection.replace_without_asking", REPLACE_WITHOUT_ASKING)
    CONFIG.set("selection.name_display_format", NAME_DISPLAY_FORMAT_OVERRIDE)
    # Saved alongside the id so a future load can tell whether the id
    # still means what it means right now -- see
    # validate_name_display_format_override()'s own docstring for why
    # the id alone isn't trustworthy. Name.DEF's own entry always has
    # an empty format_str (see that function's docstring too), so this
    # naturally saves "" whenever NAME_DISPLAY_FORMAT_OVERRIDE is 0.
    current_fmt_str = ""
    for fmt_number, _label, fmt_str, _active in name_displayer.get_name_format(
        also_default=True
    ):
        if fmt_number == NAME_DISPLAY_FORMAT_OVERRIDE:
            current_fmt_str = fmt_str
            break
    CONFIG.set("selection.name_display_format_str", current_fmt_str)
    CONFIG.save()


# -------------------------------------------------------------------------
#
# Help button (see HelpDocButton.md)
#
# -------------------------------------------------------------------------


def find_local_readme(pdata):
    """
    Return the path to pdata's own README.md, or None if pdata has no
    on-disk folder or that folder has no README.md.
    """
    if pdata is None or not pdata.fpath:
        return None
    readme_path = os.path.join(pdata.fpath, "README.md")
    return readme_path if os.path.isfile(readme_path) else None


def resolve_markdown_dash_opener():
    """
    Return Markdown Dash's open_markdown_file() function, or None if
    Markdown Dash is not registered, fails to load, or does not (yet)
    provide that function -- each a distinct failure mode collapsed to
    None since every caller does the same thing either way: fall back
    to opening help_url in the browser instead.
    """
    gpm = GuiPluginManager.get_instance()
    if MARKDOWNDASH_ID in gpm.get_hidden_plugin_ids():
        return None
    pdata = PluginRegister.get_instance().get_plugin(MARKDOWNDASH_ID)
    if pdata is None or not pdata.fpath:
        return None
    mod = gpm.load_plugin(pdata)
    if not mod:
        return None
    return getattr(mod, "open_markdown_file", None)


def open_help_url(pdata, parent):
    """
    Open pdata's registered help_url in the desktop's default browser.
    A bare wiki page title is resolved against gramps-project.org and
    percent-encoded; a full http(s):// URL is used as-is.
    """
    help_url = getattr(pdata, "help_url", None)
    if not help_url:
        OkDialog(
            _("No documentation available"),
            _("This plugin has neither a README.md nor a registered " "help_url."),
            parent=parent,
        )
        return
    if help_url.startswith(("http://", "https://")):
        full_url = help_url
    else:
        full_url = "https://gramps-project.org/wiki/index.php?title=" + quote(
            help_url, safe=":"
        )
    try:
        Gio.AppInfo.launch_default_for_uri(full_url, None)
    except GLib.Error:
        LOG.exception("PhotoTaggingGramplet: could not open help_url: %s", full_url)


# -------------------------------------------------------------------------
#
# Gramplet Options
#
# -------------------------------------------------------------------------

THUMBNAIL_IMAGE_SIZE = (50, 50)

# Initial fraction of the left pane's height given to the image/
# marquee Preview area, the rest going to the Caption panel below it
# -- see build_gui()'s left_pane and cb_left_pane_size_allocate().
CAPTION_SPLIT_INITIAL_RATIO = 0.75

# Same blue gramps.gui.widgets.SelectionWidget._draw_region_frame() uses
# for its outer marquee border, so the Row/Gramps ID label drawn inside
# the box (see _draw_region_id()) matches it.
MARQUEE_BLUE = (0.0, 0.0, 1.0)

# Sentinel distinguishing "no explicit region was given" from a real
# argument value of None (itself a legitimate "select nothing") in
# PhotoTaggingGramplet._schedule_refresh_selection()/
# _refresh_selection_target -- see that method's own docstring.
_UNSET_REGION = object()

# Smallest width/height, in original-image pixels, a marquee is
# allowed to end up at after a resize (see region_modified()) before
# it's rejected rather than committed. gramps.gui.widgets.
# SelectionWidget enforces a minimum size (its own MIN_SELECTION_SIZE,
# 10 *screen* pixels) only when *creating* a brand new region by
# dragging out a selection -- it applies no floor at all when
# *resizing* an existing one via one of its handles, so a resize can
# collapse a marquee to zero width/height in a single click. This is
# a fixed threshold in image pixels rather than SelectionWidget's own
# screen-pixel one -- it isn't meant to precisely mirror that at every
# zoom level, only to catch an outright-collapsed marquee.
MIN_MARQUEE_SIZE = 10

# -------------------------------------------------------------------------
#
# Precise rectangles
#
# -------------------------------------------------------------------------
# Gramps' own MediaRef rectangle is four whole-number percentages (its
# JSON schema, XML importer and Media Reference editor all require
# integers), which is 60-pixel steps on a 6000-pixel scan. This addon
# keeps two copies of each linked box:
#
# - the MediaRef gets a whole-number copy, rounded OUTWARD so it always
#   contains the real box (see outward_int_rect()) -- everything else
#   in Gramps keeps working on it unchanged;
# - the "PhotoTagging Regions" attribute keeps the precise copy, as
#   MWG-style normalized floats (see region_to_mwg_area()).
#
# On load the precise copy is used only while it still rounds outward
# to exactly the MediaRef's current numbers (see
# precise_rect_matches()). If they differ, the MediaRef was edited
# somewhere else (e.g. the Media Reference editor) and wins. Data
# written before this change was itself derived from whole numbers, so
# it either matches (same box) or falls back to the MediaRef (same
# box) -- old photos load exactly as before.

# Decimal places kept for the normalized 0.0-1.0 MWG area values in
# the attribute: 6 places is 0.0001% of the image, finer than a pixel
# on any real photo.
MWG_AREA_DECIMALS = 6

# Tolerance (in percent) when rounding a precise box outward, so float
# noise -- including the center-plus-size round trip at
# MWG_AREA_DECIMALS -- doesn't push an edge to the next whole number.
# 0.001% is still under a pixel on a 100,000-pixel-wide image.
OUTWARD_ROUNDING_EPSILON = 1e-3

# TEMPORARY: logs every marquee draw/resize/release to the terminal
# (as WARNING, so it shows with Gramps' default log level) to track
# down the "big box mirrored around the image center" report. Set to
# False, or remove with the logging calls, once that is found.
DEBUG_MARQUEE_DRAW = True


def outward_int_rect(rect):
    """
    Rounds a (left, top, right, bottom) rectangle in 0-100 proportional
    space to whole numbers for a Gramps MediaRef, outward: left/top
    down, right/bottom up, so the whole-number box always contains the
    precise one.

    :param rect: A 4-tuple of numbers, 0-100.
    :returns: A 4-tuple of ints, clamped to 0-100.
    """
    left, top, right, bottom = rect
    eps = OUTWARD_ROUNDING_EPSILON
    return (
        max(0, math.floor(left + eps)),
        max(0, math.floor(top + eps)),
        min(100, math.ceil(right - eps)),
        min(100, math.ceil(bottom - eps)),
    )


def precise_rect_matches(precise_rect, mediaref_rect) -> bool:
    """
    Whether a precise (float) rectangle is still the one behind a
    MediaRef's whole-number rectangle -- i.e. it rounds outward to
    exactly those numbers. False means the MediaRef has been changed
    since the precise copy was saved, so the MediaRef wins.

    :param precise_rect: A 4-tuple, 0-100 floats.
    :param mediaref_rect: The MediaRef's rectangle, or None.
    :returns: True if the precise rectangle can be used.
    """
    if mediaref_rect is None:
        return False
    return outward_int_rect(precise_rect) == tuple(mediaref_rect)


# -------------------------------------------------------------------------
#
# PreciseSelectionWidget
#
# -------------------------------------------------------------------------
class PreciseSelectionWidget(SelectionWidget):
    """
    Gramps' SelectionWidget, without its whole-percent rounding.

    The core widget converts every drag point to whole percent and back
    (_truncate_to_image_size() goes through _real_to_proportional()),
    so a marquee snaps to a 1% grid while it is being drawn, and
    real_to_proportional_rect() returns whole numbers. Overriding the
    two point converters below makes both lossless: pixel coordinates
    stay pixels, and proportional coordinates are floats. Nothing else
    about the widget changes, and no core file is patched.
    """

    def _proportional_to_real(self, coord):
        width, height = self.original_image_size
        return (
            int(round(coord[0] * width / 100)),
            int(round(coord[1] * height / 100)),
        )

    def _real_to_proportional(self, coord):
        width, height = self.original_image_size
        return (coord[0] * 100 / width, coord[1] * 100 / height)


# The toolbar buttons live in a plain Gtk.HBox rather than a Gtk.Toolbar.
# Gtk.ToolButton silently re-resolves a stock/icon-name icon to its own
# ambient icon size when realized (24px by default outside of a real
# Gtk.Toolbar), discarding whatever size the icon was originally built
# at -- confirmed by testing set_icon_widget() with a
# Gtk.Image.new_from_stock()/new_from_icon_name() image explicitly built
# at a larger size, which still rendered at 24px. A concrete Gtk.Image
# built from a Pixbuf is not subject to that renegotiation, so icons are
# loaded to an explicit pixel size via the icon theme and wrapped as a
# plain pixbuf image instead.
TOOLBAR_ICON_PX = 32


def load_toolbar_icon(icon_name, size=TOOLBAR_ICON_PX):
    """
    Loads a themed icon as a concrete Pixbuf at an explicit pixel size,
    or None if the current icon theme has no such icon.
    """
    theme = Gtk.IconTheme.get_default()
    try:
        return theme.load_icon(icon_name, size, Gtk.IconLookupFlags.FORCE_SIZE)
    except GLib.GError:
        return None


def set_toolbar_icon(button, icon_names, size=TOOLBAR_ICON_PX):
    """
    Tries each name in icon_names (a string, or a list of fallback
    names in priority order) and uses the first one available in the
    current icon theme, loaded at an explicit pixel size. Leaves the
    button's current icon untouched if none of the names are available.
    """
    if isinstance(icon_names, str):
        icon_names = [icon_names]
    for name in icon_names:
        pixbuf = load_toolbar_icon(name, size)
        if pixbuf is not None:
            image = Gtk.Image.new_from_pixbuf(pixbuf)
            button.set_icon_widget(image)
            image.show()
            return True
    return False


def get_xmp_tag_string(metadata, key: str) -> str | None:
    """
    Read a single tag as a string, without depending on
    Metadata.get() -- a convenience method only provided by the
    optional Python override module (gi/overrides/GExiv2.py), which
    some GExiv2 packages/builds don't ship, in which case Metadata is
    the plain, override-less GObject-Introspection class and has no
    .get() at all (only its native methods, has_tag()/get_tag_string()
    among them, which this reimplements the same fallback-to-None
    behaviour on top of).

    :param metadata: An opened ``GExiv2.Metadata`` instance.
    :param key: Fully-qualified tag name, e.g. ``"Xmp.dc.subject"``.
    :returns: The tag's string value, or ``None`` if it isn't set.
    """
    try:
        if metadata.has_tag(key):
            return metadata.get_tag_string(key)
    except Exception:  # pylint: disable=broad-except
        LOG.exception("PhotoTagging: could not read tag %s", key)
    return None


def open_gexiv2_metadata(path: str):
    """
    Opens `path` -- an image file, or a standalone XMP sidecar file;
    GExiv2/exiv2 read both through the same API -- via the
    override-independent two-step form, returning the resulting
    GExiv2.Metadata, or None if it can't be read at all.

    Deliberately not the one-argument GExiv2.Metadata(path) shortcut:
    that only exists via a Python override module some GExiv2
    packages ship (gi/overrides/GExiv2.py), which wraps the real,
    always-present open_path() method. Where that override is missing
    or broken, the shortcut falls through to the plain autogenerated
    GObject constructor instead (which takes no arguments) and raises
    TypeError. Calling open_path() directly works either way.

    :param path: Path to the image or sidecar file.
    :returns: A GExiv2.Metadata, or None.
    """
    try:
        metadata = GExiv2.Metadata()
        metadata.open_path(path)
        return metadata
    except GLib.GError as err:
        # GExiv2's own well-defined "this isn't a format I can read
        # metadata from" signal -- e.g. an SVG icon or any other
        # non-photo file that happens to have an "image/*" MIME type
        # but no EXIF/XMP embedding GExiv2 understands. Expected and
        # routine, not a bug, so logged quietly rather than as an
        # alarming ERROR.
        LOG.debug("PhotoTagging: %s has no readable metadata (%s)", path, err)
        return None
    except Exception:  # pylint: disable=broad-except
        LOG.exception("PhotoTagging: could not read metadata from %s", path)
        return None


def sidecar_xmp_path(image_path: str) -> str | None:
    """
    Returns the conventional standalone XMP sidecar path for
    `image_path` -- the same directory and base filename, ".xmp"
    extension in place of the image's own (e.g. "photo.jpg" ->
    "photo.xmp") -- if a file actually exists there, else None.

    This is the convention Lightroom, digiKam, exiftool, and most
    other XMP-aware tools use for metadata kept alongside a file
    rather than written into it -- notably including archival photo
    distributions that ship the original image bytes untouched, with
    any added metadata (region tags among them) kept in a companion
    file specifically so the original is never modified.

    :param image_path: Path to the image file on disk.
    :returns: The sidecar path, or None if there isn't one.
    """
    base, _ext = os.path.splitext(image_path)
    sidecar_path = base + ".xmp"
    return sidecar_path if os.path.isfile(sidecar_path) else None


# Where a Metadata clue came from, shown in the Metadata clues column
# (see PhotoTaggingGramplet.metadata_clue_text_for()).
# The keys are what get stored in the "PhotoTagging Regions" attribute
# (so they must never be translated or renamed); CLUE_SOURCE_LABELS
# maps each to the text shown.
CLUE_SOURCE_XMP_EMBEDDED = "xmp-embedded"
CLUE_SOURCE_XMP_SIDECAR = "xmp-sidecar"
CLUE_SOURCE_KEYWORDS_EMBEDDED = "xmp-keywords-embedded"
CLUE_SOURCE_KEYWORDS_SIDECAR = "xmp-keywords-sidecar"
CLUE_SOURCE_PICASA = "picasa-sidecar"
CLUE_SOURCE_LABELS = {
    CLUE_SOURCE_XMP_EMBEDDED: _("XMP - embedded"),
    CLUE_SOURCE_XMP_SIDECAR: _("XMP - sidecar"),
    CLUE_SOURCE_KEYWORDS_EMBEDDED: _("XMP keywords - embedded"),
    CLUE_SOURCE_KEYWORDS_SIDECAR: _("XMP keywords - sidecar"),
    CLUE_SOURCE_PICASA: _("Picasa - sidecar"),
}

# Picasa's per-folder metadata file, in the spellings seen in the wild
# (Windows Picasa writes "Picasa.ini" or "picasa.ini"; Picasa for
# Linux wrote ".picasa.ini"). Matched case-insensitively.
PICASA_INI_NAMES = ("picasa.ini", ".picasa.ini")

# A contact id Picasa uses for a face rectangle nobody has named yet.
PICASA_UNNAMED_CONTACT = "ffffffffffffffff"

PICASA_FACE_RE = re.compile(
    r"rect64\(\s*([0-9a-fA-F]{1,16})\s*\)\s*,\s*([0-9a-fA-F]+)"
)


def picasa_ini_path(image_path: str) -> str | None:
    """
    Returns the path of the Picasa metadata file ("picasa.ini" or
    ".picasa.ini", any capitalisation) in the same folder as
    `image_path`, or None if there isn't one.

    :param image_path: Path to the image file on disk.
    """
    folder = os.path.dirname(image_path)
    try:
        for entry in os.listdir(folder):
            if entry.lower() in PICASA_INI_NAMES:
                full_path = os.path.join(folder, entry)
                if os.path.isfile(full_path):
                    return full_path
    except OSError as err:
        LOG.debug("PhotoTagging: could not list %r: %s", folder, err)
    return None


def parse_picasa_rect64(text: str) -> tuple[float, float, float, float] | None:
    """
    Decodes the hex payload of a Picasa ``rect64(...)`` value into a
    (left, top, right, bottom) rectangle in the 0-100 proportional
    space used throughout this file.

    The payload is one 64-bit number written in hex WITHOUT zero
    padding, holding four 16-bit fields -- left, top, right, bottom --
    each a fraction of the image size scaled to 0..65535. Because the
    leading zeros are dropped, a face near the top-left corner can come
    out shorter than 16 digits, so it is padded back before slicing.

    :param text: The hex digits between the parentheses.
    :returns: (left, top, right, bottom) in 0-100 space, or None if the
        value is malformed or has no area.
    """
    try:
        digits = text.strip().zfill(16)
        if len(digits) != 16:
            return None
        left, top, right, bottom = (
            int(digits[i : i + 4], 16) * 100 / 65535 for i in range(0, 16, 4)
        )
    except ValueError:
        return None
    if right <= left or bottom <= top:
        return None
    return (left, top, right, bottom)


def read_picasa_ini_text(ini_path: str) -> str:
    """
    Reads a picasa.ini as text. Picasa writes UTF-8 (sometimes with a
    BOM); anything that isn't valid UTF-8 is read as Latin-1 rather
    than failing, since a mangled accent in a name is better than
    losing every face in the folder.

    :param ini_path: Path to the picasa.ini file.
    """
    with open(ini_path, "rb") as handle:
        raw = handle.read()
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("latin-1")


def read_picasa_faces(image_path: str) -> list[tuple[str, tuple, str]]:
    """
    Returns the named faces Picasa recorded for `image_path` in the
    picasa.ini beside it, as a list of ``(name, rect, contact_id)``
    triples where ``rect`` is (left, top, right, bottom) in 0-100 space
    (see parse_picasa_rect64()) and ``contact_id`` is Picasa's own
    16-digit hex id for that person -- the same id in every photo of
    the folder, so a stable key for matching one person across photos.

    The file is a flat INI: a ``[Contacts2]`` section maps contact ids
    to display names (``id=Name;email;``), and a section per image
    (``[photo.jpg]``) has a ``faces=`` line of
    ``rect64(hex),contactid`` entries separated by semicolons. The
    file is parsed by hand rather than with configparser because
    Picasa's files are not reliably well-formed (duplicate keys,
    stray ``%``, mixed case file names).

    A face whose contact is unnamed, or whose contact id isn't in
    [Contacts2], is skipped -- there is no clue to show for it.

    :param image_path: Path to the image file on disk.
    :returns: A (possibly empty) list of (name, rect, contact_id) triples.
    """
    ini_path = picasa_ini_path(image_path)
    if ini_path is None:
        return []
    try:
        text = read_picasa_ini_text(ini_path)
    except OSError:
        LOG.exception("PhotoTagging: could not read %s", ini_path)
        return []

    wanted = os.path.basename(image_path).lower()
    contacts: dict[str, str] = {}
    faces_line = None
    section = None
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip().lower()
            continue
        if section is None or "=" not in line:
            continue
        key, _sep, value = line.partition("=")
        key = key.strip().lower()
        if section in ("contacts2", "contacts"):
            name = value.split(";")[0].strip()
            if name:
                contacts[key] = name
        elif section == wanted and key == "faces":
            faces_line = value

    if not faces_line:
        return []
    result = []
    for rect_text, contact_id in PICASA_FACE_RE.findall(faces_line):
        contact_id = contact_id.lower().zfill(16)
        if contact_id == PICASA_UNNAMED_CONTACT:
            continue
        name = contacts.get(contact_id)
        rect = parse_picasa_rect64(rect_text)
        if name and rect:
            result.append((name, rect, contact_id))
    return result


def read_xmp_subject_tag(metadata, path: str):
    """
    Returns the `Xmp.dc.subject` tag's values from an already-open
    `metadata`, or None if the tag is absent or unreadable. `path` is
    only used for the log message on a genuine read failure.

    :param metadata: An open GExiv2.Metadata (see open_gexiv2_metadata()).
    :param path: The path `metadata` was opened from, for logging.
    """
    try:
        # get_tag_multiple() is deprecated in favour of
        # try_get_tag_multiple() in newer GExiv2 releases, but is kept
        # here for compatibility with older ones still in use.
        return metadata.get_tag_multiple("Xmp.dc.subject")
    except Exception:  # pylint: disable=broad-except
        LOG.exception("PhotoTagging: could not read Xmp.dc.subject from %s", path)
        return None


# Clockwise rotation (degrees) needed to display an image upright,
# keyed by the standard Exif.Image.Orientation / Xmp.tiff.Orientation
# value (1-8; XMP mirrors the same codes for tools/formats with no
# real Exif segment). Codes 2/4/5/7 additionally call for a
# horizontal mirror, which this addon does not attempt to handle --
# an actual camera essentially never produces those (only a manual
# software edit does) -- so each is mapped to the same rotation as
# its non-mirrored counterpart (2->1, 4->3, 5->6, 7->8): the rotation
# still comes out right even though the mirror doesn't.
ROTATION_DEGREES_BY_ORIENTATION = {
    "1": 0,
    "2": 0,
    "3": 180,
    "4": 180,
    "5": 90,
    "6": 90,
    "7": 270,
    "8": 270,
}


def read_rotation_degrees(image_path: str) -> int:
    """
    Returns the clockwise rotation (0, 90, 180, or 270) needed to
    display `image_path` upright, from its Exif.Image.Orientation tag
    (or Xmp.tiff.Orientation if that's absent) -- checking a same-named
    ".xmp" sidecar (see sidecar_xmp_path()) too, if the file itself has
    neither. Returns 0 if none of that turns up a recognized
    orientation code, or the file has no metadata GExiv2 can read at
    all.
    """
    orientation = None
    metadata = open_gexiv2_metadata(image_path)
    if metadata is not None:
        orientation = get_xmp_tag_string(
            metadata, "Exif.Image.Orientation"
        ) or get_xmp_tag_string(metadata, "Xmp.tiff.Orientation")
    if orientation is None:
        sidecar_path = sidecar_xmp_path(image_path)
        if sidecar_path is not None:
            sidecar_metadata = open_gexiv2_metadata(sidecar_path)
            if sidecar_metadata is not None:
                orientation = get_xmp_tag_string(
                    sidecar_metadata, "Exif.Image.Orientation"
                ) or get_xmp_tag_string(sidecar_metadata, "Xmp.tiff.Orientation")
    return ROTATION_DEGREES_BY_ORIENTATION.get(orientation, 0)


def rotate_proportional_rect(rect, degrees: int):
    """
    Returns `rect` -- a (left, top, right, bottom) rectangle in the
    0-100 proportional space used throughout this file (see
    get_xmp_regions()) -- rotated `degrees` (0/90/180/270) clockwise,
    expressed in the *rotated* canvas's own 0-100 proportional space
    (width and height swap places for a 90 or 270 rotation).

    Proportional coordinates are already normalized to whatever the
    canvas's own actual pixel dimensions are, so this is a pure
    coordinate remapping independent of them -- worked out by
    tracking where each corner of the unit square ends up under a
    rotation of the canvas itself: e.g. rotating 90 degrees clockwise
    sends the original top-left corner (0, 0) to the new frame's
    top-right (100, 0), since what was the image's left edge becomes
    its new top edge.

    :param rect: A 4-tuple (left, top, right, bottom), 0-100 scale.
    :param degrees: 0, 90, 180, or 270.
    :returns: The rotated 4-tuple, same 0-100 scale.
    """
    left, top, right, bottom = rect
    if degrees == 0:
        return rect
    if degrees == 90:
        return (100 - bottom, left, 100 - top, right)
    if degrees == 180:
        return (100 - right, 100 - bottom, 100 - left, 100 - top)
    if degrees == 270:
        return (top, 100 - right, bottom, 100 - left)
    raise ValueError("degrees must be 0, 90, 180, or 270, not %r" % (degrees,))


def unrotate_proportional_rect(rect, degrees: int):
    """
    The inverse of rotate_proportional_rect(): converts a rect
    expressed in the rotated display's own proportional space back
    into the image's native (on-disk, unrotated) proportional space --
    what MediaRef rectangles and this addon's own "PhotoTagging
    Regions" JSON (see REGION_DATA_ATTR_TYPE) are always stored in,
    regardless of how the photo happens to be displayed.
    """
    return rotate_proportional_rect(rect, (360 - degrees) % 360)


# GdkPixbuf.Pixbuf.rotate_simple()'s angle parameter is a
# GdkPixbuf.PixbufRotation, whose members are used here strictly by
# NAME rather than their own famously confusing integer values (e.g.
# CLOCKWISE == 270, not 90) -- so this lookup never has to reason
# about that mismatch at all, only about "which named member rotates
# the way this many degrees clockwise should".
PIXBUF_ROTATION_BY_DEGREES = {
    0: GdkPixbuf.PixbufRotation.NONE,
    90: GdkPixbuf.PixbufRotation.CLOCKWISE,
    180: GdkPixbuf.PixbufRotation.UPSIDEDOWN,
    270: GdkPixbuf.PixbufRotation.COUNTERCLOCKWISE,
}


def rotated_pixbuf_and_temp_path(
    image_path: str, degrees: int
) -> tuple[GdkPixbuf.Pixbuf | None, str | None]:
    """
    Loads `image_path`, rotates it `degrees` clockwise, and returns
    (rotated_pixbuf, temp_path): temp_path is a new temporary PNG file
    holding those same rotated pixels, for SelectionWidget's own
    load_image() (which only takes a path); rotated_pixbuf is the
    in-memory bitmap itself, kept so safe_get_thumbnail() can crop
    full-resolution thumbnails directly from exactly what the Preview
    panel is showing, rather than through SelectionWidget's own
    get_thumbnail() -- which was observed to crop from the image's
    native, unrotated bytes regardless of what's actually displayed
    (see safe_get_thumbnail()'s own docstring).

    A temporary PNG rather than re-encoding back to the original
    format: the temp file is a throwaway purely for SelectionWidget's
    own display, never saved over the original or read by anything
    else, so there's no reason to accept a lossy format's
    re-compression on top of the original image's own.

    Returns (None, None) on any failure (a corrupt/unreadable file,
    one GdkPixbuf simply can't load, or a write failure) --
    load_image() falls back to showing the original, unrotated file
    in that case rather than nothing at all.

    :param image_path: Path to the original, unrotated image file.
    :param degrees: 0, 90, 180, or 270.
    """
    try:
        pixbuf = GdkPixbuf.Pixbuf.new_from_file(image_path)
        rotated = pixbuf.rotate_simple(PIXBUF_ROTATION_BY_DEGREES[degrees])
        descriptor, temp_path = tempfile.mkstemp(
            suffix=".png", prefix="phototagging-rotated-"
        )
        os.close(descriptor)
        rotated.savev(temp_path, "png", [], [])
        return rotated, temp_path
    except (GLib.GError, OSError):
        LOG.exception(
            "PhotoTagging: could not pre-rotate %s by %d degrees",
            image_path,
            degrees,
        )
        return None, None


def load_bundled_icon(
    icon_filename: str, size: int = TOOLBAR_ICON_PX
) -> GdkPixbuf.Pixbuf | None:
    """
    Load an SVG icon bundled with this addon as a concrete Pixbuf at an
    explicit pixel size.

    Bundled icons live under ``media/icons/`` next to this module, so
    the addon does not depend on names that may or may not exist in
    the user's current system icon theme.

    :param icon_filename: File name of the bundled icon, for example
        ``"gtk-index.svg"``.
    :param size: Target width/height in pixels.
    :returns: A ``GdkPixbuf.Pixbuf``, or ``None`` if the file is
        missing or unreadable.
    """
    addon_dir = os.path.dirname(__file__)
    icon_path = os.path.join(addon_dir, "media", "icons", icon_filename)
    try:
        return GdkPixbuf.Pixbuf.new_from_file_at_size(icon_path, size, size)
    except GLib.GError:
        return None


def set_bundled_toolbar_icon(
    button,
    icon_filename: str,
    fallback_names: list[str] | None = None,
    size: int = TOOLBAR_ICON_PX,
) -> bool:
    """
    Set a toolbar button's icon from a bundled SVG file under
    ``media/icons/``, falling back to themed icon names if the bundled
    file can't be loaded, so a broken or incomplete install still gets
    some icon rather than a blank button.

    :param button: The ``Gtk.ToolButton`` to set the icon on.
    :param icon_filename: File name of the bundled icon, for example
        ``"gtk-index.svg"``.
    :param fallback_names: Themed icon names to try, in priority
        order, if the bundled file can't be loaded.
    :param size: Target width/height in pixels.
    :returns: ``True`` if an icon was set on the button, ``False``
        otherwise.
    """
    pixbuf = load_bundled_icon(icon_filename, size)
    if pixbuf is not None:
        image = Gtk.Image.new_from_pixbuf(pixbuf)
        button.set_icon_widget(image)
        image.show()
        return True
    if fallback_names:
        return set_toolbar_icon(button, fallback_names, size)
    return False


class NoteTextBuilder:
    """
    Incrementally builds the plain text and styling spans for a
    Note's StyledText, tracking character offsets as each piece of
    text is appended -- one StyledTextTag(tag_type, value,
    [(start, end)]) per styled span (link or bold). PedigreeBreadcrumbs.py
    builds its link tags using the bare string "link" instead of the
    real StyledTextTagType.LINK enum value; that string form did not
    actually produce clickable links when tested live, hence always
    using the real enum constants here instead.

    Used by transcribe_list_to_note_clicked() to assemble a multi-line
    Note with a mix of plain, bold, and Gramps-object-linked text.
    """

    def __init__(self):
        self.text = ""
        self._tags = []  # list of (StyledTextTagType, value, start, end)

    def add_text(self, text):
        """Append plain, unstyled text (no trailing newline)."""
        self.text += text

    def add_styled(self, text, tag_type, value=None):
        """Append text and record a styling tag range over exactly it."""
        start = len(self.text)
        self.text += text
        self._tags.append((tag_type, value, start, len(self.text)))

    def add_link(self, text, url):
        """Append text and record a link tag range over exactly it."""
        self.add_styled(text, StyledTextTagType.LINK, url)

    def add_bold(self, text):
        """Append text and record a bold tag range over exactly it."""
        self.add_styled(text, StyledTextTagType.BOLD, True)

    def add_line(self, text=""):
        """Append plain text followed by a newline."""
        self.text += text + "\n"

    def add_linked_line(self, text, url):
        """Append a link-tagged line: link range covers just `text`."""
        self.add_link(text, url)
        self.text += "\n"

    def add_bold_line(self, text):
        """Append a bold-tagged line: bold range covers just `text`."""
        self.add_bold(text)
        self.text += "\n"

    def add_blank_lines(self, count=1):
        self.text += "\n" * count

    def build_styled_text(self):
        """
        :returns: A StyledText combining all appended text with one
            StyledTextTag per add_styled()/add_link()/add_bold() call
            (and their *_line() equivalents).
        """
        tags = [
            StyledTextTag(tag_type, value, [(start, end)])
            for tag_type, value, start, end in self._tags
        ]
        return StyledText(self.text, tags)


# ------------------------------------------------------------
#
# CaptionTextEditor
#
# ------------------------------------------------------------
class CaptionTextEditor(StyledTextEditor):
    """
    Read-only :class:`StyledTextEditor` used to render the Caption
    Note's content in the Caption panel (see
    ``PhotoTaggingGramplet.refresh_caption()``), changing how a click
    there behaves:

    - A plain (non-Ctrl) single left click on a Person link selects
      that person's row in the region list (see
      ``select_person_in_list()``) if they are tagged in this photo,
      and does nothing at all otherwise (any other link -- another
      gramps:// object link, or a plain web/mailto URL -- or a
      Person not tagged here).
    - A plain single left click anywhere else (not on a link) is
      unchanged from the base class -- normal cursor placement/text
      selection.
    - A plain double click on *any* link -- a gramps:// object link
      or a plain web/mailto URL -- additionally opens it for editing
      or in a browser/mail client, the same effect the base class's
      own Ctrl+click already has -- so double-clicking a Person link
      both selects their row and opens Edit Person.
    - A plain double click on unlinked space opens the Note editor
      for this Caption Note itself (see ``edit_caption_note()``),
      instead of the base class's own default of selecting the word
      under the pointer.
    - Ctrl+click is left entirely to the base class's own handling.
    - Right-clicking (or the Menu key) opens the base class's own
      context menu, with a "Caption Font..." item appended (see
      on_populate_popup()/cb_choose_font()) for choosing this panel's
      own base font family and size, persisted across sessions.

    This overrides on_button_press_event() itself, rather than
    merely adding a second handler alongside the base class's own
    (which was tried first): StyledTextEditor._connect_signals()
    connects it by looking up ``self.on_button_press_event`` at
    __init__ time, so Python's normal method resolution routes that
    straight here for a CaptionTextEditor instance, without needing
    a second, separately-connected handler racing it. That matters
    because the base handler's own Ctrl+click test --
    ``event.get_state() and Gdk.ModifierType.CONTROL_MASK``, an
    ``and`` where a bitwise ``&`` was surely intended -- treats *any*
    nonzero modifier state (e.g. NumLock simply being on) as if Ctrl
    were held, so merely adding a second handler left the base
    class's own "open link" action *also* firing on a plain single
    click alongside this one; fully replacing it, rather than only
    supplementing it, is what actually prevents that.
    """

    def __init__(self, gramplet: "PhotoTaggingGramplet") -> None:
        """
        :param gramplet: The owning PhotoTaggingGramplet, whose
            ``select_person_in_list()``, ``edit_caption_note()``,
            ``dbstate``, ``uistate``, and ``track`` this uses to
            react to a click.
        """
        self._gramplet = gramplet
        StyledTextEditor.__init__(self)
        # Created once and reused for the life of this editor: tags
        # stay registered in a Gtk.TextBuffer's tag table across
        # set_text() replacing its actual content (see
        # highlight_person()'s own docstring), so this never needs
        # recreating on refresh.
        self._highlight_tag = self.textbuffer.create_tag(
            "caption-person-highlight", background=CAPTION_HIGHLIGHT_BACKGROUND
        )
        # The base font family/size chosen via the popup menu's
        # "Caption Font..." item (see cb_choose_font()), persisted
        # across sessions in CONFIG so it doesn't need re-picking
        # every time -- None means "use the panel's own built-in
        # default", same as an empty saved value.
        self._base_font_desc = None
        saved_font = CONFIG.get("caption.font")
        if saved_font:
            self.apply_base_font(Pango.FontDescription.from_string(saved_font))

    def apply_base_font(self, font_desc: Pango.FontDescription) -> None:
        """
        Applies `font_desc` as the Caption panel's own base font
        (family and size) -- the action for choosing one via
        cb_choose_font(), and for restoring a previously saved choice
        at startup (see __init__()).

        Gtk.Widget.override_font(), while deprecated since Gtk 3.16
        in favor of CSS, remains the simplest reliable way to set a
        Gtk.TextView's own default font directly from a chosen
        Pango.FontDescription, and remains fully functional in the
        Gtk 3.x this addon targets.

        :param font_desc: The font to apply.
        """
        self._base_font_desc = font_desc
        self.override_font(font_desc)

    def on_populate_popup(self, widget: Gtk.TextView, menu: Gtk.Menu) -> None:
        """
        Overrides StyledTextEditor.on_populate_popup() -- adds a
        "Caption Font..." item (see cb_choose_font()) on top of
        whatever the base class's own implementation already adds
        (a spellcheck submenu, "Search selection on web", and any
        URL-specific items), using the same override-by-name trick
        as on_button_press_event() -- see that method's docstring --
        since StyledTextEditor connects this by looking up
        self.on_populate_popup.
        """
        StyledTextEditor.on_populate_popup(self, widget, menu)
        separator = Gtk.SeparatorMenuItem()
        separator.show()
        menu.append(separator)
        font_item = Gtk.MenuItem.new_with_label(_("Caption Font..."))
        font_item.connect("activate", self.cb_choose_font)
        font_item.show()
        menu.append(font_item)

    def cb_choose_font(self, menuitem: Gtk.MenuItem) -> None:
        """
        Callback for the popup menu's "Caption Font..." item (see
        on_populate_popup()): opens a Gtk.FontChooserDialog to pick
        the Caption panel's base font family and size, applies it
        immediately (see apply_base_font()), and persists the choice
        (CONFIG "caption.font") so it's remembered next time.

        :param menuitem: The activated menu item (unused; provided
            by the signal).
        """
        toplevel = self.get_toplevel()
        dialog = Gtk.FontChooserDialog(
            title=_("Select Caption Font"),
            transient_for=toplevel if isinstance(toplevel, Gtk.Window) else None,
        )
        if self._base_font_desc is not None:
            dialog.set_font_desc(self._base_font_desc)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            font_desc = dialog.get_font_desc()
            self.apply_base_font(font_desc)
            CONFIG.set("caption.font", font_desc.to_string())
            CONFIG.save()
        dialog.destroy()

    def highlight_person(self, person_handle: str | None) -> None:
        """
        Highlights every occurrence, in the currently displayed text,
        of a ``gramps://Person/handle/<person_handle>`` link, clearing
        any previous highlight first -- so a Person's linked text
        lights up together with their row/marquee selection (see
        PhotoTaggingGramplet.apply_selected_region()). A person can
        be linked more than once in the same Note (e.g. once in the
        title area, once in the name list); every occurrence is
        highlighted, not just the first.

        Must be re-called (see
        PhotoTaggingGramplet.refresh_caption()/sync_caption_highlight())
        any time set_text() replaces this editor's content outright,
        since that deletes the old text -- and with it, every
        previously highlighted range -- even though the tag itself
        (created once, in __init__) remains registered and does not
        need recreating.

        :param person_handle: Handle of the Person to highlight, or
            ``None`` to only clear the existing highlight.
        """
        start, end = self.textbuffer.get_bounds()
        self.textbuffer.remove_tag(self._highlight_tag, start, end)
        if not person_handle:
            return
        target_url = "%sPerson/handle/%s" % (GRAMPS_URL_PREFIX, person_handle)
        pos = self.textbuffer.get_start_iter()
        while not pos.is_end():
            next_pos = pos.copy()
            advanced = next_pos.forward_to_tag_toggle(None)
            if not advanced:
                next_pos = self.textbuffer.get_end_iter()
            for tag in pos.get_tags():
                name = tag.get_property("name") or ""
                if name.startswith("link") and getattr(tag, "data", None) == target_url:
                    self.textbuffer.apply_tag(self._highlight_tag, pos, next_pos)
                    break
            if not advanced:
                break
            pos = next_pos

    def on_button_press_event(
        self, widget: Gtk.TextView, event: Gdk.EventButton
    ) -> bool:
        """
        Overrides StyledTextEditor.on_button_press_event() -- see the
        class docstring for why overriding, rather than connecting a
        second handler, is what's needed here.

        :param widget: This editor (unused; provided by the signal).
        :param event: The Gdk.EventButton for the click.
        :returns: ``True`` if a plain click was handled here (either
            on a link, or a double click on unlinked space --
            consuming the event either way, so it doesn't also start
            or extend a text selection), otherwise whatever the base
            class's own handling of the same event returns.
        """
        if event.button == 1 and not event.get_state() & Gdk.ModifierType.CONTROL_MASK:
            # Gdk.EventType._2BUTTON_PRESS is GDK's own real, public
            # enum member -- its name simply can't start with a
            # digit, hence the leading underscore, which pylint
            # otherwise mistakes for a protected-access violation.
            is_double_click = (
                event.type
                == Gdk.EventType._2BUTTON_PRESS  # pylint: disable=protected-access
            )
            link = self._link_at_event(event)
            if link is not None:
                obj_class, prop, value = link
                if obj_class == "Person" and prop == "handle":
                    self._gramplet.select_person_in_list(value)
                if is_double_click:
                    try:
                        EditObject(
                            self._gramplet.dbstate,
                            self._gramplet.uistate,
                            self._gramplet.track,
                            obj_class,
                            prop,
                            value,
                        )
                    except WindowActiveError:
                        pass
                return True
            if self.url_match:
                # A plain web/mailto URL: unlike a gramps:// object
                # link (handled above via a GtkTextTag applied to its
                # exact range), these are recognized only via the
                # base class's own regex matching, refreshed on mouse
                # motion into self.url_match by its do_match_changed()
                # -- there's no tag for _link_at_event() to find here.
                # Only open it on a double click, via the base
                # class's own _open_url_cb(), the same as a gramps://
                # link above; a single click does nothing, same as
                # unlinked space below.
                if is_double_click:
                    self._open_url_cb(
                        None,
                        self.url_match[MATCH_STRING],
                        self.url_match[MATCH_FLAVOR],
                    )
                return True
            if is_double_click:
                self._gramplet.edit_caption_note()
                return True
        return StyledTextEditor.on_button_press_event(self, widget, event)

    def _link_at_event(self, event: Gdk.EventButton) -> tuple[str, str, str] | None:
        """
        Return the ``(obj_class, prop, value)`` parsed out of the
        ``gramps://`` link tag under `event`'s position, or ``None``
        if it isn't over such a link -- mirroring how the base
        class's own on_motion_notify_event() recognizes a LinkTag, by
        name prefix, and its own _open_url_cb() parses the link's
        three '/'-separated parts.
        """
        buffer_x, buffer_y = self.window_to_buffer_coords(
            Gtk.TextWindowType.WIDGET, int(event.x), int(event.y)
        )
        # PyGObject versions differ on whether this out-parameter
        # method returns a plain Gtk.TextIter or a (found, iter)
        # tuple -- accept either rather than depending on one.
        result = self.get_iter_at_location(buffer_x, buffer_y)
        if isinstance(result, tuple):
            found, text_iter = result[0], result[-1]
            if not found:
                return None
        else:
            text_iter = result
        for tag in text_iter.get_tags():
            name = tag.get_property("name") or ""
            if not name.startswith("link"):
                continue
            url = getattr(tag, "data", None)
            if not url or not url.startswith(GRAMPS_URL_PREFIX):
                continue
            try:
                obj_class, prop, value = url[len(GRAMPS_URL_PREFIX) :].split("/")
            except ValueError:
                continue
            return obj_class, prop, value
        return None


class PhotoTaggingOptions(MenuOptions):

    def __init__(self, refresh_callback=None):
        MenuOptions.__init__(self)
        # Called from update_settings() below, but only when the Name
        # display format override actually changed -- see there. None
        # (the default) when this options panel isn't tied to a live
        # gramplet instance to refresh, which no current call site
        # does, but keeps this class usable standalone.
        self._refresh_callback = refresh_callback

    def add_menu_options(self, menu):
        # Was "Selection" -- renamed since "Display as:" below isn't a
        # selection setting at all; "Options" is the closest existing
        # Gramps Preferences tab name that still fits both.
        category_name = _("Options")
        self.replace_without_asking = BooleanOption(
            # Was "Replace existing references to the person being
            # assigned without asking" -- reworded to match the
            # "Suppress warning when ..." style Preferences' own
            # Warnings tab uses for exactly this kind of "skip a
            # confirmation dialog" setting (e.g. "Suppress warning
            # when canceling with changed data").
            _("Suppress warning when re-assigning Person reference"),
            REPLACE_WITHOUT_ASKING,
        )
        menu.add_option(
            category_name, "replace_without_asking", self.replace_without_asking
        )

        format_list = [
            (number, name)
            for (number, name, _fmt_str, _act) in name_displayer.get_name_format(
                also_default=True
            )
        ]
        # Re-validate here too, not just at module load: Preferences >
        # Data > Name format can be edited at any time while this
        # gramplet is already running, which module load can't have
        # seen. Cheap enough to redo on every Options dialog open, and
        # this is the only other point where a stale in-memory value
        # would otherwise surface -- as a selection that's silently
        # fallen off format_list, in the dropdown built just above.
        global NAME_DISPLAY_FORMAT_OVERRIDE
        NAME_DISPLAY_FORMAT_OVERRIDE = validate_name_display_format_override(
            NAME_DISPLAY_FORMAT_OVERRIDE,
            CONFIG.get("selection.name_display_format_str"),
        )
        self.name_display_format = EnumeratedListOption(
            _("Display as"), NAME_DISPLAY_FORMAT_OVERRIDE
        )
        for number, name in format_list:
            self.name_display_format.add_item(number, name)
        self.name_display_format.set_help(
            _(
                "Overrides Preferences > Data > Name format for this "
                "gramplet's own Name column and Caption generator only "
                "-- everywhere else in Gramps keeps using the regular "
                "preference. Leave as \"Default format (defined by "
                "Gramps preferences)\" for no override."
            )
        )
        menu.add_option(
            category_name, "name_display_format", self.name_display_format
        )

        category_name = _("Face detection")
        width, height = MIN_FACE_SIZE
        sensitivity = SENSITIVITY
        self.min_face_width = NumberOption(
            _("Minimum face width (px)"), width, 1, 1000, 1
        )
        self.min_face_height = NumberOption(
            _("Minimum face height (px)"), height, 1, 1000, 1
        )
        self.detect_inside_existing_boxes = BooleanOption(
            _("Detect faces inside existing marquees"), DETECT_INSIDE_EXISTING_BOXES
        )
        self.sensitivity = NumberOption(
            _("Sensitivity (1 min .. 20 max)"), sensitivity, 1, 20, 1
        )

        menu.add_option(category_name, "min_face_width", self.min_face_width)
        menu.add_option(category_name, "min_face_height", self.min_face_height)
        menu.add_option(category_name, "sensitivity", self.sensitivity)
        menu.add_option(
            category_name,
            "detect_inside_existing_boxes",
            self.detect_inside_existing_boxes,
        )

    def update_settings(self):
        global REPLACE_WITHOUT_ASKING
        global DETECT_INSIDE_EXISTING_BOXES
        global MIN_FACE_SIZE
        global SENSITIVITY
        global NAME_DISPLAY_FORMAT_OVERRIDE
        REPLACE_WITHOUT_ASKING = self.replace_without_asking.get_value()
        old_name_display_format = NAME_DISPLAY_FORMAT_OVERRIDE
        NAME_DISPLAY_FORMAT_OVERRIDE = self.name_display_format.get_value()
        DETECT_INSIDE_EXISTING_BOXES = self.detect_inside_existing_boxes.get_value()
        width = self.min_face_width.get_value()
        height = self.min_face_height.get_value()
        MIN_FACE_SIZE = (width, height)
        SENSITIVITY = self.sensitivity.get_value()
        save_config()
        # Only when the Name display format override itself changed --
        # touching an unrelated setting (sensitivity, box size, ...)
        # has nothing for the Name column to redraw. Unlike
        # cb_global_name_format_changed() (the *global* Preferences
        # change case), this fires regardless of whether the new value
        # is Name.DEF or an explicit override -- both are changes this
        # gramplet's own Name column needs to reflect immediately
        # rather than waiting for the next unrelated redraw.
        if (
            NAME_DISPLAY_FORMAT_OVERRIDE != old_name_display_format
            and self._refresh_callback is not None
        ):
            self._refresh_callback()


# -------------------------------------------------------------------------
#
# Settings Dialog
#
# -------------------------------------------------------------------------


class SettingsDialog(PluginWindows.ToolManagedWindowBase):

    def __init__(self, dbstate, uistate, title, options):
        self.dbstate = dbstate
        self.uistate = uistate
        self.title = title
        self.options = options

        PluginWindows.ToolManagedWindowBase.__init__(
            self, dbstate, uistate, None, "SettingsDialog"
        )

        self.ok.set_label(_("OK"))

    def get_title(self):
        return self.title

    def build_menu_names(self, obj):
        """
        A single-level Windows-menu entry (this dialog's own title, no
        submenu) rather than ToolManagedWindowBase's own default two-
        level Category > Item grouping (observed as the unhelpful
        "Settings -> Main window"). That default exists for Gramps
        Tools that can have several simultaneous instances open at
        once, each needing a second-level label to tell them apart
        (which object each one is working on) -- this dialog is a
        singleton with nothing to disambiguate, so the second level is
        pure overhead. Mirrors FuzzyMatchLookupWindow's own
        single-level build_menu_names() for the same reason.

        :param obj: Unused (required by the base class' own call
            signature).
        :returns: ``(self.get_title(), None)``.
        """
        return (self.get_title(), None)

    def on_ok_clicked(self, obj):
        self.options.update_settings()
        self.close()


# -------------------------------------------------------------------------
#
# Photo Tagging Gramplet
#
# -------------------------------------------------------------------------


class PhotoTaggingGramplet(Gramplet):
    def init(self):
        self.regions = []
        self.marquees_visible = True
        self.metadata_clues_visible = True
        self.id_display_mode = ID_MODE_ROW

        # "Quick draw" mode (see quick_draw_toggled()) -- available
        # only as a substitute for the Detect faces button when
        # computer vision isn't (see build_gui()). While True,
        # region_created() skips its own automatic context-menu popup
        # after each new marquee, and marquees_visible/id_display_mode
        # are both forced on for the duration, saved here so they can
        # be restored to whatever they actually were once this mode is
        # turned back off.
        self.quick_draw_mode = False
        self._pre_quick_draw_marquees_visible = None
        self._pre_quick_draw_id_display_mode = None
        # Set by region_order_changed() when a reorder happens during
        # quick draw mode, and consumed by _cb_refresh_after_reorder()
        # once self.refresh() has rebuilt the treeview to match the
        # new order -- see region_order_changed()'s own docstring.
        self._quick_draw_reorder_target = None

        # Whether the Caption panel should be shown when a Caption
        # Note exists -- a plain user-facing toggle, like
        # marquees_visible/metadata_clues_visible above, except its
        # *initial* value additionally needs the current Media's own
        # Caption-Note status (see refresh_caption()), so it starts
        # True here and is set to reflect that before the panel is
        # ever first shown, in the first refresh_caption() call from
        # main().
        self.caption_panel_visible = True
        # Whether the current Media object has a Caption Note at all
        # -- refreshed by refresh_caption(); drives the toolbar
        # button's dimmed appearance and whether the panel can be
        # shown regardless of caption_panel_visible above.
        self.caption_note_exists = False
        # GLib.get_monotonic_time() timestamp of the previous click on
        # the Caption toolbar button, used by cb_caption_button_toggled()
        # to recognize a double-click.
        self._caption_last_toggle_us = 0

        # Current Preview:Caption height split of left_pane (see
        # build_gui()), as a fraction of its total height -- starts
        # at CAPTION_SPLIT_INITIAL_RATIO, then tracks wherever the
        # person last dragged the handle to (see
        # cb_left_pane_position_changed()), so a later resize of the
        # containing window/dock (cb_left_pane_size_allocate())
        # preserves that, rather than resetting to the initial split
        # every time.
        self._caption_split_ratio = CAPTION_SPLIT_INITIAL_RATIO
        # left_pane's own total allocated height as of the last time
        # cb_left_pane_size_allocate() acted on it, or None before
        # the first one -- lets that handler tell an actual resize
        # (height changed) apart from any other size-allocate.
        self._left_pane_last_height = None
        # True while cb_left_pane_size_allocate() itself is moving
        # the handle to reapply _caption_split_ratio, so
        # cb_left_pane_position_changed() can tell that apart from
        # the person actually dragging it (see that method).
        self._caption_split_ratio_lock = False

        # True while apply_selected_region() is itself moving the
        # treeview's cursor, so a re-entrant cursor_changed() call
        # (set_cursor() below can trigger one synchronously) knows to
        # do nothing rather than calling straight back into
        # apply_selected_region() again.
        self._syncing_selection = False
        # The most recent non-None region apply_selected_region() was
        # given -- used by cb_preview_panel_button_release() to restore
        # the selection after a single click on non-marquee space,
        # since SelectionWidget's own handling of that same click
        # clears it before that callback gets a chance to react.
        self._last_selected_region = None
        # The (x1, y1, x2, y2) coords() of the currently selected
        # region as of the last apply_selected_region() call that had
        # one -- used by region_modified() to snap a marquee back to
        # its last known-good size/position if a resize collapses it
        # below MIN_MARQUEE_SIZE, rather than committing a degenerate
        # marquee. Kept up to date on every real selection change, so
        # a *successful* resize's own new size becomes what the next
        # one is compared against, not the region's original size.
        self._selected_region_coords = None
        # Set by region_created()/region_modified(), which SelectionWidget
        # emits from inside its own button-release handling -- before
        # cb_preview_panel_button_release() runs for that same release.
        # Tells that callback the release ended a drag (a new or
        # resized marquee), not a click on empty space, so it must not
        # restore an old selection or count it toward a double click.
        self._release_ended_drag = False
        # GLib.get_monotonic_time() timestamp, and (event.x, event.y),
        # of the previous button release handled by
        # cb_preview_panel_button_release(), used to recognize a
        # double click there by elapsed time and distance between two
        # releases -- the same two thresholds ("gtk-double-click-
        # time"/"gtk-double-click-distance") Gdk itself uses to
        # recognize one, the same way cb_caption_button_toggled()'s
        # own _caption_last_toggle_us already uses elapsed time alone.
        # Unlike a normal Gtk widget, SelectionWidget's own event_box
        # handling of "button-press-event" always returns True (see
        # gramps.gui.widgets.SelectionWidget._button_press_event()),
        # which -- being connected first -- stops that signal's
        # emission before it would ever reach a second handler
        # connected here on top of it (Gtk's own "handled" event
        # signals stop calling further handlers, before *and* after,
        # once one has returned True); a GDK_2BUTTON_PRESS event's
        # type, the usual way to recognize a double click, is
        # therefore never actually observable here at all. Its own
        # "button-release-event" handling, by contrast, never returns
        # True, so a second handler connected there (see build_gui())
        # both runs and reliably sees SelectionWidget's already-
        # updated get_current() -- hence measuring the double click by
        # time and position between releases instead.
        self._preview_last_release_us = 0
        self._preview_last_release_pos = (0.0, 0.0)
        # True while a deferred (GLib.idle_add) call to
        # _schedule_refresh_selection() is pending, so main()/
        # region_modified()/region_created()/del_region_clicked()/
        # cb_person_edited() -- which can all fire in the same cascade
        # (see region_modified()'s own docstring) -- schedule at most
        # one, instead of stacking up redundant repeat calls. Also
        # what cursor_changed() checks to ignore a stray "cursor-
        # changed" of Gtk's own in the same window (see its own
        # docstring).
        self._refresh_selection_pending = False
        # The specific Region _schedule_refresh_selection() should
        # reselect once its defer completes, or the _UNSET_REGION
        # sentinel to instead reselect whatever
        # self.selection_widget.get_current() turns out to be by then
        # (see _schedule_refresh_selection()'s own docstring).
        self._refresh_selection_target = _UNSET_REGION
        # The handle of the Media object currently reflected in
        # self.regions, and a snapshot of its "PhotoTagging Regions"
        # attribute text as of the last time self.regions was loaded
        # from (or persisted to) it. Both are checked on every
        # refresh, not just when the handle itself changes -- editing
        # that attribute directly (e.g. via the Media object's own
        # Attribute tab) fires the same "media-update" signal as an
        # unrelated commit (a marquee resize, say) while this Media
        # object is still the active one, and the only way to tell
        # those apart is to compare the attribute's current text
        # against what was last actually loaded (see main()).
        self._loaded_media_handle = None
        self._loaded_region_data_text = None
        self._order_dirty = False
        # The Gtk.TreePath of the Name-column cell currently open for
        # editing (see cb_name_cell_editing_started()), or None. Used
        # by cb_name_cell_data() to skip re-filling that one row's
        # display text from self.regions while GTK's own live editor
        # widget already has the person's in-progress typing --
        # overwriting the "text" property out from under an open
        # Gtk.CellRendererText editor is exactly the kind of thing
        # that can silently clobber it or move the cursor.
        self._editing_name_path = None
        # Row-flash state for flash_row() -- a brief cross-fade to the
        # theme's selected-row color and back, used as one-click
        # confirmation for the Add-person and Copy-name icons (see
        # _handle_add_icon_click()/_handle_pipe_icon_click()). Only one
        # row can be mid-flash at a time; starting a new one cancels
        # whatever was already running (see flash_row()).
        self._flash_region = None
        self._flash_started_at = None
        self._flash_timeout_id = None
        # The clockwise rotation (0/90/180/270) applied to the
        # currently-loaded photo's display -- see load_image()/
        # read_rotation_degrees() -- and the temp file that rotation
        # was rendered into, if any, so it can be cleaned up (see
        # _cleanup_rotated_temp_file()) once it's no longer needed.
        self.rotation_degrees = 0
        self._rotated_temp_path = None
        self._rotated_pixbuf = None
        # Guards main()'s reload block against being entered from a
        # nested call to main() itself -- see main()'s own comment.
        self._reloading = False

        # Whichever Gtk.Window currently hosts this gramplet, tracked so
        # we can catch that window's maximize/unmaximize events -- see
        # on_hierarchy_changed()/on_toplevel_window_state_event().
        self._toplevel = None
        self._toplevel_handler_id = None

        self.age_precision = config.get("preferences.age-display-precision")

        self.build_context_menu()

        self.gui.WIDGET = self.build_gui()
        self.gui.get_container_widget().remove(self.gui.textview)
        self.gui.get_container_widget().add(self.gui.WIDGET)
        self.top.show_all()

    def cb_main_pane_sensitive(self, pane, _pspec) -> None:
        """
        Saves this photo's unsaved tagging (order, placeholder names,
        precise marquees -- see flush_region_order()) the moment the
        main Gramps window's content pane is made insensitive.

        Gramps' own quit sequence (ViewManager.quit(), the same in 5.2
        and 6.0) closes the database *before* it calls on_save() on
        each gramplet, so on_save() alone can never save anything at
        quit -- the database is already closed by then. Gramps has no
        "about to close" signal, but the very first step of quit is
        uistate.set_sensitive(False), which makes this pane
        insensitive while the database is still open (and before the
        backup-on-exit runs, so the backup includes the change).
        Gramps also makes the pane insensitive at a few other times;
        saving then as well is harmless.

        :param pane: The main window's content Gtk.Paned.
        :param _pspec: unused (the "sensitive" property spec)
        """
        if not pane.get_sensitive():
            self.flush_region_order()

    def cb_database_closing(self, *_args) -> None:
        """
        Saves this photo's unsaved tagging before the Family Tree is
        closed or another one is loaded -- DbState emits "no-database"
        just before it closes the current database (in 5.2 and 6.0).
        Without this, switching trees lost the same changes quitting
        did (see cb_main_pane_sensitive()).
        """
        self.flush_region_order()

    def cb_top_destroyed(self, _widget) -> None:
        """
        Disconnects cb_main_pane_sensitive() and cb_database_closing()
        when this gramplet is removed, so Gramps does not keep calling
        into it.
        """
        if self._main_pane is not None and self._main_pane_handler_id is not None:
            self._main_pane.disconnect(self._main_pane_handler_id)
        self._main_pane_handler_id = None
        if self._no_database_key is not None:
            self.dbstate.disconnect(self._no_database_key)
            self._no_database_key = None

    def on_save(self):
        self.flush_region_order()
        self._cleanup_rotated_temp_file()
        if self._flash_timeout_id is not None:
            # Belt-and-suspenders: a pending flash_row() tick is a
            # GLib.timeout_add source entirely independent of this
            # gramplet's own widgets, so it would otherwise keep
            # firing (and calling self.treeview.queue_draw()) even
            # after Gramps starts tearing this gramplet down.
            GLib.source_remove(self._flash_timeout_id)
            self._flash_timeout_id = None
        CONFIG.save()

    # ======================================================
    # building the GUI
    # ======================================================

    def build_gui(self):
        """
        Build the GUI interface.
        """
        self.top = Gtk.VBox()

        hpaned = Gtk.HPaned()
        self.hpaned = hpaned

        button_panel = Gtk.HBox()

        self.button_index = Gtk.ToolButton(stock_id=Gtk.STOCK_INDEX)
        self.button_add = Gtk.ToolButton(stock_id=Gtk.STOCK_ADD)
        self.button_del = Gtk.ToolButton(stock_id=Gtk.STOCK_REMOVE)
        self.button_clear = Gtk.ToolButton(stock_id=Gtk.STOCK_CLEAR)
        self.button_edit = Gtk.ToolButton(stock_id=Gtk.STOCK_EDIT)
        self.button_move_up = Gtk.ToolButton(stock_id=Gtk.STOCK_GO_UP)
        self.button_move_down = Gtk.ToolButton(stock_id=Gtk.STOCK_GO_DOWN)
        self.button_zoom_in = Gtk.ToolButton(stock_id=Gtk.STOCK_ZOOM_IN)
        self.button_zoom_out = Gtk.ToolButton(stock_id=Gtk.STOCK_ZOOM_OUT)
        self.button_settings = Gtk.ToolButton(stock_id=Gtk.STOCK_PREFERENCES)
        self.button_help = Gtk.ToolButton(stock_id=Gtk.STOCK_HELP)
        # Buttons whose icon is one of a small handful of names that are
        # reasonably common across system icon themes.
        for button, icon_names in (
            (self.button_clear, ["edit-clear", Gtk.STOCK_CLEAR]),
            (self.button_settings, ["preferences-system", Gtk.STOCK_PREFERENCES]),
            (self.button_help, ["help-browser", "help-contents", Gtk.STOCK_HELP]),
        ):
            set_toolbar_icon(button, icon_names)

        # Buttons whose icon is bundled with this addon under
        # media/icons/, since the desired artwork is not reliably
        # available (or not visually distinct enough) in system icon
        # themes. Each still falls back to a themed name if the
        # bundled file is missing, so the toolbar degrades gracefully
        # rather than showing a blank button.
        for button, icon_filename, fallback_names in (
            (
                self.button_index,
                "gtk-index.svg",
                [
                    "color-select-symbolic",
                    "edit-find",
                    "system-search",
                    Gtk.STOCK_INDEX,
                ],
            ),
            (self.button_add, "List-add.svg", ["list-add", Gtk.STOCK_ADD]),
            (self.button_del, "List-remove.svg", ["list-remove", Gtk.STOCK_REMOVE]),
            (self.button_edit, "gtk-edit.svg", ["document-edit", Gtk.STOCK_EDIT]),
            (
                self.button_move_up,
                "Gnome-view-sort-ascending.svg",
                ["go-up", Gtk.STOCK_GO_UP],
            ),
            (
                self.button_move_down,
                "Gnome-view-sort-descending.svg",
                ["go-down", Gtk.STOCK_GO_DOWN],
            ),
            (self.button_zoom_in, "gramps-zoom-in.svg", ["zoom-in", Gtk.STOCK_ZOOM_IN]),
            (
                self.button_zoom_out,
                "gramps-zoom-out.svg",
                ["zoom-out", Gtk.STOCK_ZOOM_OUT],
            ),
        ):
            set_bundled_toolbar_icon(button, icon_filename, fallback_names)

        # set custom icon for face detect button
        self.button_detect = Gtk.ToolButton()
        set_bundled_toolbar_icon(
            self.button_detect,
            "gramps-face-detection.svg",
            ["edit-find", "system-search", Gtk.STOCK_FIND],
        )

        # The default way of tagging a photo, whether or not computer
        # vision is available: quickly turning blank space into
        # several ready-to-name placeholder marquees, one after
        # another, with nothing popping up in between and every
        # already-tagged face visible the whole time. Leads the
        # toolbar (see button_panel.pack_start() below) and starts
        # active by default (see the end of build_gui()) -- see
        # quick_draw_toggled() for what toggling it actually does. A
        # dashed-rectangle icon rather than a plain "+" (list-add) was
        # deliberately chosen for this: a solid "+" reads too much
        # like the Add-a-new-person icon at toolbar size, for a button
        # that does something else entirely.
        self.button_quick_draw = Gtk.ToggleToolButton()
        set_bundled_toolbar_icon(
            self.button_quick_draw,
            "gramps-quick-draw.svg",
            ["selection-mode-symbolic", "edit-select-all-symbolic", Gtk.STOCK_ADD],
        )

        # marquee visibility is a 2-state toggle; the ID button cycles
        # through 3 states (Row ID / Gramps ID / hidden) on each click
        self.button_marquees = Gtk.ToggleToolButton()
        self.button_show_ids = Gtk.ToolButton()

        # Shows/hides the "Metadata clues" column. Like button_marquees
        # above (and for the same reason: a pressed/highlighted toggle
        # button should indicate the non-default, "hidden" state, not
        # the default, "data visible" one), active means "hidden" --
        # the inverse of self.metadata_clues_visible.
        self.button_metadata_clues = Gtk.ToggleToolButton()
        set_bundled_toolbar_icon(
            self.button_metadata_clues,
            "XMP_logo.svg",
            ["dialog-information-symbolic", Gtk.STOCK_INFO],
        )
        self.button_metadata_clues.set_active(not self.metadata_clues_visible)
        self.update_metadata_clues_button()

        # Shows/hides the Caption panel (see refresh_caption()).
        # Active likewise means "hidden", matching button_marquees/
        # button_metadata_clues above. Always left sensitive (never
        # set_sensitive(False)) even when there is no Caption Note to
        # show -- an insensitive Gtk widget stops receiving button
        # events entirely, which would also swallow the double-click
        # that is supposed to still work in that state (see
        # cb_caption_button_toggled()); set_caption_button_dimmed()
        # gives it a dimmed appearance instead, purely cosmetically.
        self.button_caption = Gtk.ToggleToolButton()
        set_bundled_toolbar_icon(
            self.button_caption,
            "ClosedCaption.svg",
            ["media-view-subtitles-symbolic", "insert-text", Gtk.STOCK_JUSTIFY_LEFT],
        )
        self.button_caption.set_active(not self.caption_panel_visible)
        self.update_caption_button()

        self.button_index.connect("clicked", self.sel_person_clicked)
        self.button_add.connect("clicked", self.add_person_clicked)
        self.button_del.connect("clicked", self.clear_ref_clicked)
        self.button_clear.connect("clicked", self.del_region_clicked)
        self.button_edit.connect("clicked", self.edit_person_clicked)
        self.button_move_up.connect("clicked", self.move_up_clicked)
        self.button_move_down.connect("clicked", self.move_down_clicked)
        self.button_zoom_in.connect("clicked", self.zoom_in_clicked)
        self.button_zoom_out.connect("clicked", self.zoom_out_clicked)
        self.button_detect.connect("clicked", self.detect_faces_clicked)
        self.button_quick_draw.connect("toggled", self.quick_draw_toggled)
        self.button_settings.connect("clicked", self.settings_clicked)
        self.button_help.connect("clicked", self.on_help_clicked)
        self.button_marquees.connect("toggled", self.marquees_toggled)
        self.button_show_ids.connect("clicked", self.show_ids_clicked)
        self.button_metadata_clues.connect("toggled", self.metadata_clues_toggled)
        self.button_caption.connect("toggled", self.cb_caption_button_toggled)

        # Quick draw mode leads the toolbar, and defaults to on (see
        # further down, after its icon/tooltip are set up): it's the
        # default way of tagging a photo now, not a fallback for when
        # face detection isn't available, so it comes before -- and no
        # longer shares a slot with -- Detect faces.
        button_panel.pack_start(
            self.button_quick_draw, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_marquees, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_show_ids, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_caption, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_metadata_clues, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(self.button_index, expand=False, fill=False, padding=5)
        button_panel.pack_start(self.button_add, expand=False, fill=False, padding=5)
        button_panel.pack_start(self.button_del, expand=False, fill=False, padding=5)
        button_panel.pack_start(self.button_clear, expand=False, fill=False, padding=5)
        button_panel.pack_start(self.button_edit, expand=False, fill=False, padding=5)
        button_panel.pack_start(
            self.button_move_up, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_move_down, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_zoom_in, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(
            self.button_zoom_out, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(self.button_detect, expand=False, fill=False, padding=5)
        button_panel.pack_start(
            self.button_settings, expand=False, fill=False, padding=5
        )
        button_panel.pack_start(self.button_help, expand=False, fill=False, padding=5)

        self.button_index.set_tooltip_text(LINK_PERSON_TEXT)
        self.button_add.set_tooltip_text(ADD_NEW_PERSON_TEXT)
        self.button_del.set_tooltip_text(CLEAR_REFERENCE_TEXT)
        self.button_clear.set_tooltip_text(_("Remove Selection"))
        self.button_edit.set_tooltip_text(_("Edit referenced Person"))
        self.button_move_up.set_tooltip_text(_("Move Up"))
        self.button_move_down.set_tooltip_text(_("Move Down"))
        self.button_zoom_in.set_tooltip_text(_("Zoom In"))
        self.button_zoom_out.set_tooltip_text(_("Zoom Out"))

        # active means "hidden"/"showing", the opposite of the default
        self.button_marquees.set_active(not self.marquees_visible)
        self.update_marquees_button()
        self.update_show_ids_button()

        if facedetection.computer_vision_available:
            self.button_detect.set_tooltip_text(_("Detect faces"))
        else:
            # No computer vision available at all -- hide the
            # permanently-unusable Detect faces button entirely rather
            # than leaving a dimmed icon in the toolbar for the whole
            # session. Quick draw mode (button_quick_draw) is always
            # shown regardless -- see its own construction comment --
            # it no longer shares a slot or a visibility toggle with
            # this button.
            self.button_detect.set_visible(False)

        # Quick draw mode defaults to on (see button_quick_draw's own
        # construction comment) -- set_active() here fires "toggled",
        # so quick_draw_toggled() itself applies every bit of the
        # mode's own setup (forcing marquees_visible/id_display_mode,
        # clearing the image selection) rather than duplicating any of
        # that here. The actual set_active(True) call is deferred to
        # the very end of this method (see just before its own
        # `return self.top`): quick_draw_toggled() reaches into
        # self.selection_widget, which doesn't exist yet at this point
        # in this method -- it's constructed further down.
        self.update_quick_draw_button()

        self.button_settings.set_tooltip_text(_("Settings"))
        self.button_help.set_tooltip_text(_("Help"))

        self.top.pack_start(button_panel, expand=False, fill=True, padding=5)

        self.selection_widget = PreciseSelectionWidget()
        self.selection_widget.set_size_request(200, -1)
        self.selection_widget.connect("region-modified", self.region_modified)
        self.selection_widget.connect("region-created", self.region_created)
        self.selection_widget.connect("region-selected", self.region_selected)
        self.selection_widget.connect("selection-cleared", self.selection_cleared)
        self.selection_widget.connect("right-button-clicked", self.right_button_clicked)
        self.selection_widget.connect("zoomed-in", self.zoomed)
        self.selection_widget.connect("zoomed-out", self.zoomed)

        # Opens the Media object editor on a double click that lands
        # on non-marquee space, and the Person editor on a double
        # click that lands on a marquee (see
        # cb_preview_panel_button_release()). Connected directly on
        # top of whatever SelectionWidget's own event_box already
        # does for drawing/selecting marquees -- the same widget
        # attribute drag-and-drop below already attaches extra
        # handlers to from outside -- rather than one of the signals
        # above, none of which fire for a plain click (as opposed to
        # a completed drag) on empty space.
        #
        # Deliberately "button-release-event", not "button-press-
        # event": SelectionWidget's own event_box handling of the
        # press always returns True, and Gtk's own "handled" event
        # signals (button-press-event among them) stop calling any
        # further handlers -- connected here on top of it, before or
        # after -- the moment one has returned True, so a handler
        # connected to that signal here would simply never run at
        # all. Its release handling never returns True, so a handler
        # added here on top of it both runs and, since it runs after
        # SelectionWidget's own release handling has already updated
        # its selection, sees an authoritative get_current() (see
        # cb_preview_panel_button_release()'s own docstring).
        self.selection_widget.event_box.connect(
            "button-release-event", self.cb_preview_panel_button_release
        )

        # Draws the person's Gramps ID over each region frame, on top of
        # whatever gramps.gui.widgets.SelectionWidget has already drawn for
        # the same "draw" event (connect_after runs after its own handler,
        # which is itself connected via connect_after in the widget's
        # __init__, so ours always paints last).
        self.selection_widget.image.connect_after("draw", self.draw_ids_overlay)

        # Can drop a PERSON here:
        tglist = Gtk.TargetList.new([])
        tglist.add(
            DdTargets.PERSON_LINK.atom_drag_type,
            DdTargets.PERSON_LINK.target_flags,
            DdTargets.PERSON_LINK.app_id,
        )
        # Can drop a LIST of HANDLES here:
        tglist.add(
            DdTargets.HANDLE_LIST.atom_drag_type,
            DdTargets.HANDLE_LIST.target_flags,
            DdTargets.HANDLE_LIST.app_id,
        )
        # Can drop a child (Family editor Children tab) or an
        # association (Person editor Associations tab) here -- see
        # PERSON_REFERENCE_DD_TYPES.
        for dd_type in PERSON_REFERENCE_DD_TYPES:
            tglist.add(dd_type.atom_drag_type, dd_type.target_flags, dd_type.app_id)

        # Drag and Drop for selection widget:
        self.selection_widget.event_box.drag_dest_set(
            Gtk.DestDefaults.MOTION | Gtk.DestDefaults.DROP, [], Gdk.DragAction.COPY
        )
        self.selection_widget.event_box.drag_dest_set_target_list(tglist)
        self.selection_widget.event_box.connect(
            "drag_data_received",
            lambda *args: self.drag_data_received(*args, on_image=True),
        )
        # End Drag and Drop for selection widget

        # The Caption panel (see refresh_caption()) sits below the
        # image/marquee Preview area, both stacked in a VPaned (a
        # draggable divider, so the person can resize the split by
        # hand) forming the HPaned's own left pane -- rather than,
        # say, the right pane alongside the region list -- since it
        # renders the *photo's* caption, not anything about an
        # individual tagged region.
        self.left_pane = Gtk.VPaned()

        self.caption_scrolled_window = Gtk.ScrolledWindow()
        self.caption_scrolled_window.set_policy(
            Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC
        )

        self.caption_editor = CaptionTextEditor(self)
        self.caption_editor.set_editable(False)
        self.caption_editor.set_wrap_mode(Gtk.WrapMode.WORD)
        self.caption_editor.set_justification(Gtk.Justification.CENTER)
        self.caption_editor.set_left_margin(6)
        self.caption_editor.set_right_margin(6)
        self.caption_scrolled_window.add(self.caption_editor)

        self.left_pane.pack1(self.selection_widget, resize=True, shrink=False)
        self.left_pane.pack2(self.caption_scrolled_window, resize=True, shrink=False)

        # Both panes are marked resize=True above (rather than, say,
        # holding the Caption panel to a fixed pixel height) since
        # the two handlers below take over positioning the divider
        # themselves on every resize, as a fraction of left_pane's
        # own total height (starting at CAPTION_SPLIT_INITIAL_RATIO)
        # -- native Gtk.Paned has no percentage-split notion of its
        # own, only ever remembering an absolute pixel offset.
        self.left_pane.connect("size-allocate", self.cb_left_pane_size_allocate)
        self.left_pane.connect("notify::position", self.cb_left_pane_position_changed)

        hpaned.pack1(self.left_pane, resize=True, shrink=False)

        # Columns: row number, preview thumbnail, combined Person+Age

        # (Pango markup -- see refresh_list()), Metadata clues text.
        # The separate boolean "suspicious age" flag column that used
        # to drive column4's foreground-set is gone: since Person and
        # Age are now one cell, the red highlight is baked directly
        # into the markup string built in refresh_list() instead.
        self.treestore = Gtk.TreeStore(int, GdkPixbuf.Pixbuf, str, str)

        self.treeview = Gtk.TreeView(model=self.treestore)
        self.treeview.set_size_request(400, -1)
        self.treeview.connect("cursor-changed", self.cursor_changed)
        self.treeview.connect("row-activated", self.row_activated)
        self.treeview.connect("button-press-event", self.row_mouse_click)
        self.treeview.connect("button-release-event", self.cb_row_button_release)
        # The Name column has its own inline cell editor for a
        # placeholder name (see cb_name_cell_data()/
        # cb_name_cell_editing_started()) -- GtkTreeView's own default
        # interactive (type-ahead) search would otherwise compete with
        # it for keystrokes typed while a row is merely selected but
        # not yet in edit mode, diverting them into its own floating
        # search popup instead of starting an edit.
        self.treeview.set_enable_search(False)
        column1 = Gtk.TreeViewColumn(title="")
        column2 = Gtk.TreeViewColumn(title=_("Preview"))
        # The Add-person and piping-options icons are each their own
        # narrow, header-less TreeViewColumn immediately before the
        # column they act on, rather than a second CellRenderer packed
        # into that same column. Gtk.TreeView has no real per-cell
        # "button" of its own (only Gtk.CellRendererToggle has a
        # built-in click signal), and telling an icon-cell click apart
        # from a text-cell click within a single shared column needs
        # Gtk.TreeViewColumn.cell_get_position()/cell_set_cell_data() --
        # low-level APIs meant for GTK's own internal rendering pass,
        # not ad-hoc use from a click handler; calling them that way
        # crashed the whole process outright rather than raising a
        # catchable Python exception. A separate column sidesteps this
        # entirely: get_path_at_pos() already reports exactly which
        # column was clicked, with no per-cell math needed at all (see
        # row_mouse_click()).
        column_add_icon = Gtk.TreeViewColumn(title="")
        column3 = Gtk.TreeViewColumn()
        column_pipe_icon = Gtk.TreeViewColumn(title="")
        column4 = Gtk.TreeViewColumn(title=_("Metadata clues"))
        self.column_row_id = column1
        self.column_add_icon = column_add_icon
        self.column_name = column3
        self.column_pipe_icon = column_pipe_icon
        self.column_metadata_clues = column4
        self.treeview.append_column(column1)
        self.treeview.append_column(column2)
        self.treeview.append_column(column_add_icon)
        self.treeview.append_column(column3)
        self.treeview.append_column(column_pipe_icon)
        self.treeview.append_column(column4)

        # column3's header is "Person" / "    Age on <date>" on two
        # lines (see format_person_age_header() / refresh_list()),
        # which needs a real widget rather than set_title()'s
        # single-line text.
        self.column_person_age_header = Gtk.Label()
        self.column_person_age_header.set_xalign(0)
        self.column_person_age_header.set_justify(Gtk.Justification.LEFT)
        self.column_person_age_header.show()
        column3.set_widget(self.column_person_age_header)

        cell1 = Gtk.CellRendererText()
        cell2 = Gtk.CellRendererPixbuf()
        cell3 = Gtk.CellRendererText()
        cell4 = Gtk.CellRendererText()
        self.cell_add_icon = Gtk.CellRendererPixbuf()
        self.cell_pipe_icon = Gtk.CellRendererPixbuf()
        column1.pack_start(cell1, expand=True)
        column1.add_attribute(cell1, "text", 0)
        column2.pack_start(cell2, expand=True)
        column2.add_attribute(cell2, "pixbuf", 1)
        column_add_icon.pack_start(self.cell_add_icon, expand=False)
        column_add_icon.set_cell_data_func(
            self.cell_add_icon, self.cb_name_icon_cell_data
        )
        column_add_icon.set_resizable(False)
        column_add_icon.set_clickable(False)
        column_add_icon.set_fixed_width(24)
        column_add_icon.set_sizing(Gtk.TreeViewColumnSizing.FIXED)
        column3.pack_start(cell3, expand=True)
        column3.set_cell_data_func(cell3, self.cb_name_cell_data)
        cell3.connect("editing-started", self.cb_name_cell_editing_started)
        cell3.connect("editing-canceled", self.cb_name_cell_editing_canceled)
        cell3.connect("edited", self.cb_name_cell_edited)
        column3.set_resizable(True)
        column3.set_reorderable(True)
        column3.set_min_width(20)
        column_pipe_icon.pack_start(self.cell_pipe_icon, expand=False)
        column_pipe_icon.set_cell_data_func(
            self.cell_pipe_icon, self.cb_clue_icon_cell_data
        )
        column_pipe_icon.set_resizable(False)
        column_pipe_icon.set_clickable(False)
        column_pipe_icon.set_fixed_width(24)
        column_pipe_icon.set_sizing(Gtk.TreeViewColumnSizing.FIXED)
        column4.pack_start(cell4, expand=False)
        column4.add_attribute(cell4, "text", 3)
        column4.set_resizable(True)
        column4.set_reorderable(True)
        column4.set_min_width(20)

        # column3/cell3 is deliberately NOT included below: it has its
        # own combined shading-plus-content cell_data_func above (see
        # cb_name_cell_data()) -- Gtk.TreeViewColumn.set_cell_data_func()
        # replaces whatever was previously registered for that exact
        # (column, cell) pair rather than adding to it, so shading and
        # per-row content can't be registered as two separate funcs on
        # the same cell. The two icon columns are the same way, each
        # already combining shading with its own icon-visibility logic
        # inside cb_name_icon_cell_data()/cb_clue_icon_cell_data().
        self.apply_alternating_row_shading(
            (column1, cell1), (column2, cell2), (column4, cell4)
        )

        self.treeview.set_search_column(0)
        # Columns are intentionally not made sortable-by-click: the row
        # order is the manual order the user sets via drag-and-drop or the
        # Move Up/Down buttons, and must always match self.regions.

        # Drag and Drop for tree view: accepts dropped people (same as the
        # image), plus its own rows dragged onto itself to reorder them.
        # NOTE: deliberately NOT calling self.treeview.set_reorderable(True)
        # here (it was previously enabled purely for the cosmetic native
        # drop-position indicator). Field testing showed a single physical
        # drag producing TWO full drag_data_get/drag_data_received cycles:
        # the first one performed the intended move correctly, and a second
        # one immediately followed, re-picking-up the just-moved row (now
        # re-selected by region_order_changed()) and re-dropping it using
        # the first drop's now-stale coordinates -- typically shoving it to
        # the end. That double-fire is consistent with set_reorderable()
        # additionally activating Gtk.TreeView's own internal row-drag
        # handling alongside our manual REORDER_ATOM-based handling below.
        # The manual handling alone (as in
        # gramps.gui.editors.displaytabs.embeddedlist.EmbeddedList, though
        # that class uses enable_model_drag_source/dest rather than the
        # plain drag_source_set/drag_dest_set used here, since this
        # treeview also needs to accept external Person drops) is
        # sufficient; the native indicator is not worth the double-fire.

        tree_tglist = Gtk.TargetList.new([])
        tree_tglist.add(
            DdTargets.PERSON_LINK.atom_drag_type,
            DdTargets.PERSON_LINK.target_flags,
            DdTargets.PERSON_LINK.app_id,
        )
        tree_tglist.add(
            DdTargets.HANDLE_LIST.atom_drag_type,
            DdTargets.HANDLE_LIST.target_flags,
            DdTargets.HANDLE_LIST.app_id,
        )
        for dd_type in PERSON_REFERENCE_DD_TYPES:
            tree_tglist.add(
                dd_type.atom_drag_type, dd_type.target_flags, dd_type.app_id
            )
        tree_tglist.add(REORDER_ATOM, Gtk.TargetFlags.SAME_WIDGET, 0)
        # Accepts plain text dropped from elsewhere -- e.g. a name
        # selected and dragged straight out of the Caption panel,
        # which needs no wiring of its own: a Gtk.TextView (which
        # CaptionTextEditor is) already supports dragging its current
        # selection out, editable or not, with no extra setup (see
        # text_drag_received()).
        tree_tglist.add_text_targets(TEXT_TARGET_INFO)

        self.treeview.drag_dest_set(
            Gtk.DestDefaults.MOTION | Gtk.DestDefaults.DROP,
            [],
            Gdk.DragAction.COPY | Gdk.DragAction.MOVE,
        )
        self.treeview.drag_dest_set_target_list(tree_tglist)
        self.treeview.connect("drag_data_received", self.drag_data_received)
        self.treeview.connect("drag-motion", self.cb_tree_drag_motion)
        self.treeview.connect("drag-leave", self.cb_tree_drag_leave)
        self.treeview.drag_source_set(
            Gdk.ModifierType.BUTTON1_MASK,
            [Gtk.TargetEntry.new(REORDER_TARGET_NAME, Gtk.TargetFlags.SAME_WIDGET, 0)],
            Gdk.DragAction.MOVE,
        )
        self.treeview.connect("drag_data_get", self.treeview_drag_data_get)
        # End Drag and Drop for tree_view

        scrolled_window2 = Gtk.ScrolledWindow()
        scrolled_window2.add(self.treeview)
        scrolled_window2.set_size_request(400, -1)
        scrolled_window2.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)

        hpaned.pack2(scrolled_window2, resize=False, shrink=False)

        self.top.pack_start(hpaned, True, True, 5)

        self.enable_buttons()

        self.top.connect("key-press-event", self.on_key_press_event)
        self.top.connect("hierarchy-changed", self.on_hierarchy_changed)

        # Save unsaved tagging when Gramps quits -- see
        # cb_main_pane_sensitive() for why this is the hook.
        self._main_pane = getattr(
            getattr(self.uistate, "viewmanager", None), "hpane", None
        )
        self._main_pane_handler_id = None
        if self._main_pane is not None:
            self._main_pane_handler_id = self._main_pane.connect(
                "notify::sensitive", self.cb_main_pane_sensitive
            )
        # And before the tree is closed or switched: DbState emits
        # "no-database" just before it closes the current database.
        self._no_database_key = self.dbstate.connect(
            "no-database", self.cb_database_closing
        )
        self.top.connect("destroy", self.cb_top_destroyed)

        # NameDisplay itself has no "format changed" signal to connect
        # to (verified against its actual source: none of
        # set_default_format()/set_name_format()/add_name_format()/
        # edit_name_format()/del_name_format() emit anything; the only
        # config.connect() inside NameDisplay.__init__() is for
        # "preferences.patronimic-surname", unrelated to format
        # choice). What Preferences > Data > Name format actually
        # changes is this config key -- connecting to it directly is
        # how the Name column and Caption panel notice a change to the
        # *global* default while already open and populated, for the
        # common case where NAME_DISPLAY_FORMAT_OVERRIDE is left at
        # Name.DEF (this gramplet's own override, when active, needs
        # no such connection: display_name_respecting_format() already
        # re-reads it fresh on every render, so changing it via this
        # gramplet's own Options and closing that dialog -- which
        # already redraws the tab -- is sufficient on its own).
        #
        # Unlike self.connect(self.dbstate.db, ...) above, ConfigManager
        # connections aren't tracked/disconnected by the Gramplet base
        # class automatically, and this file has no on_unload() of its
        # own to disconnect it manually either -- an undock/redock
        # cycle could in principle accumulate more than one of these
        # over a long session. The only consequence is a handful of
        # harmless extra refresh() calls, never incorrect output, so
        # left as-is rather than adding lifecycle-management machinery
        # for a cosmetic inefficiency.
        config.connect("preferences.name-format", self.cb_global_name_format_changed)

        # Quick draw mode defaults to on (see button_quick_draw's own
        # construction comment) -- set_active() fires "toggled", so
        # quick_draw_toggled() itself applies every bit of the mode's
        # own setup. Deliberately the last thing this method does:
        # quick_draw_toggled() reaches into self.selection_widget and
        # self.button_marquees/button_show_ids, all of which need to
        # already exist by the time it runs.
        self.button_quick_draw.set_active(True)

        return self.top

    def cb_global_name_format_changed(self, *args):
        """
        Redraw the Name column and Caption panel when Preferences >
        Data > Name format changes -- see the config.connect() call in
        build_gui() this is registered from for why this exists and
        what it deliberately does not handle.

        Only actually redraws when NAME_DISPLAY_FORMAT_OVERRIDE is at
        Name.DEF: an active override means this gramplet isn't using
        the global default in the first place, so a change to it has
        nothing here to redraw.
        """
        if NAME_DISPLAY_FORMAT_OVERRIDE == Name.DEF:
            self.refresh()

    def on_hierarchy_changed(self, widget, previous_toplevel):
        """
        Tracks whichever Gtk.Window currently hosts this gramplet (it
        moves between windows when undocked into its own dialog, or
        docked back into the main Gramps window), keeping a
        window-state-event handler connected to it -- see
        on_toplevel_window_state_event() for why.
        """
        toplevel = self.top.get_toplevel()
        if toplevel is self._toplevel:
            return
        if self._toplevel is not None and self._toplevel_handler_id:
            self._toplevel.disconnect(self._toplevel_handler_id)
        self._toplevel = None
        self._toplevel_handler_id = None
        if isinstance(toplevel, Gtk.Window):
            self._toplevel = toplevel
            self._toplevel_handler_id = toplevel.connect(
                "window-state-event", self.on_toplevel_window_state_event
            )

    def on_toplevel_window_state_event(self, window, event):
        """
        Works around SelectionWidget drawing the image (and hence the
        marquees) offset by a fixed amount after this gramplet's host
        window is maximized or unmaximized -- reported as ~20px to the
        left, not corrected until the HPaned divider between the image
        and the list is manually moved.

        SelectionWidget._resize() only recomputes its scale/offset when
        its own allocated size differs from the size it last saw, and
        manually dragging the HPaned divider "fixes" it only because
        that eventually changes the SelectionWidget's allocated width,
        forcing that check to see a difference and recompute. This
        schedules the same kind of nudge programmatically -- see
        nudge_selection_widget_layout() for why it is delayed and
        forces the recompute rather than relying on a lucky pixel
        difference.
        """
        if event.changed_mask & Gdk.WindowState.MAXIMIZED:
            GLib.timeout_add(150, self.nudge_selection_widget_layout)

    def nudge_selection_widget_layout(self):
        """
        Forces SelectionWidget to rescale its image to the (by now
        settled) real window size.

        Two things beyond a plain divider nudge turned out to matter:

        - Firing right on the window-state-event was too early -- a
          window-manager-driven maximize can still be settling its
          final geometry at that point, so a nudge done immediately
          could itself get rescaled against a transitional, not-yet-
          final size (the reported symptom: the ID/marquee overlay,
          which recomputes from the live widget size on every draw,
          ends up correct, but SelectionWidget's own cached image
          does not, leaving it offset with a spurious scrollbar until
          some unrelated event -- e.g. hovering the scrollbar --
          happens to trigger yet another size-allocate). Delaying via
          the timeout in on_toplevel_window_state_event() gives the
          resize time to finish first, mirroring the delay inherent
          in the user doing this by hand.
        - SelectionWidget.old_viewport_size (the "size it last saw")
          is reset to an impossible (0, 0) value first, so the
          size-allocate the divider nudge triggers is guaranteed to
          be treated as a real change and force a genuine rescale of
          the displayed image against whatever the current real
          allocation is -- rather than depending on the nudge's exact
          pixel delta happening to differ from a value that may itself
          already be stale.

        Nudges *both* panes that can affect SelectionWidget's own
        allocated size, not just self.hpaned (the width split between
        the photo/Caption column and the region list): self.left_pane
        (the height split between the photo and the Caption panel
        below it) affects it too, and is the one actually responsible
        for the initial-load symptom this is also used for now (see
        main()'s own call to this method) -- the photo initially sized
        as though the Caption panel weren't there. Nudging only
        self.hpaned, as an earlier version of this method did, forces
        a real size-allocate, but not necessarily one that reports a
        *different* height if self.left_pane's own divider was the
        thing actually still wrong -- width alone can genuinely be
        unchanged while height is not. Nudging both covers either
        cause with one call, at the cost of a second (equally
        imperceptible, single-pixel, immediately-restored) adjustment
        to whichever of the two didn't actually need it.

        The nudge-then-idle_add-restore shape genuinely needs two
        separate size-allocate passes to be reliable -- collapsing
        them into one synchronous move-and-move-back was tried and
        didn't reliably force SelectionWidget to recompute, presumably
        because GTK coalesces same-frame position changes into a
        single allocate at whatever position is left standing when it
        actually processes them, same as it does for any other widget
        property set twice before the next frame. Two genuine passes
        means two genuine repaints, though, which is visible as a
        brief double-refresh right as a photo loads. self.selection_
        widget.get_window().freeze_updates(), held across both passes
        and thawed only once the second (the real, final) one has
        actually happened, suppresses the screen from ever being
        updated with the first pass's intermediate, still-wrong
        result -- the person only ever sees the outcome of the second,
        correct one. A frozen GdkWindow is not itself redrawn at all
        for as long as it's frozen (not merely coalesced), so this
        costs nothing beyond briefly holding one repaint back by
        however long the idle_add takes to fire, normally imperceptible
        on its own.
        """
        if self.selection_widget.old_viewport_size is not None:
            self.selection_widget.old_viewport_size = Gdk.Rectangle()

        gdk_window = self.selection_widget.get_window()
        if gdk_window is not None:
            gdk_window.freeze_updates()

        hpaned_position = self.hpaned.get_position()
        self.hpaned.set_position(hpaned_position + 1)
        left_pane_position = self.left_pane.get_position()
        self.left_pane.set_position(left_pane_position + 1)
        GLib.idle_add(
            self._restore_paned_positions,
            hpaned_position,
            left_pane_position,
            gdk_window,
        )
        return False

    def _restore_paned_positions(
        self, hpaned_position, left_pane_position, gdk_window
    ):
        """
        The deferred half of nudge_selection_widget_layout() -- see
        its own docstring for the freeze_updates()/thaw_updates() pair
        this completes. `gdk_window` is the exact GdkWindow frozen
        there, passed through rather than re-fetched here: if
        SelectionWidget were ever unrealized and re-realized in
        between (not expected across a single idle_add, but cheap to
        guard against regardless), self.selection_widget.get_window()
        could by then return a different window than the one actually
        frozen, thawing the wrong one and leaving the one that matters
        stuck frozen -- no further redraws at all -- until something
        else happened to thaw it.
        """
        if self.selection_widget.old_viewport_size is not None:
            self.selection_widget.old_viewport_size = Gdk.Rectangle()
        self.hpaned.set_position(hpaned_position)
        self.left_pane.set_position(left_pane_position)
        if gdk_window is not None:
            gdk_window.thaw_updates()
        return False

    def on_key_press_event(self, widget, event):
        """
        Alt+Up / Alt+Down move the selected region up/down in the list,
        wherever the keyboard focus currently is within the gramplet.
        (Ctrl+Up/Down is already used elsewhere to move an indicator, not
        the selection, so Alt is used here instead.)
        """
        alt = bool(event.get_state() & Gdk.ModifierType.MOD1_MASK)
        if alt and event.keyval == Gdk.KEY_Up:
            self.move_up_clicked(None)
            return True
        if alt and event.keyval == Gdk.KEY_Down:
            self.move_down_clicked(None)
            return True
        return False

    def on_help_clicked(self, widget):
        """
        Show the closest documentation available for this addon: its own
        local README.md via Markdown Dash when available, else its
        registered help_url in the default browser (see HelpDocButton.md).
        """
        pdata = PluginRegister.get_instance().get_plugin(MY_PLUGIN_ID)
        readme_path = find_local_readme(pdata)
        if readme_path is not None:
            open_markdown_file = resolve_markdown_dash_opener()
            if open_markdown_file is not None:
                open_markdown_file(
                    readme_path,
                    self.uistate,
                    parent=self.uistate.window,
                    addon_name=pdata.name,
                )
                return
        open_help_url(pdata, self.uistate.window)

    def drag_data_received(
        self, widget, context, x, y, sel_data, info, time, on_image=None
    ):
        """
        Receive a dropped person onto the treeview.

        A drop onto the list links the person to the row actually
        dropped onto (via get_dest_row_at_pos()), not to whatever
        region happened to be selected before the drag started - an
        earlier version of this method computed the drop-target row
        and then discarded it, calling set_current_person() instead,
        which acts on self.selection_widget.get_current() regardless
        of where the drop landed. Dropping a person onto one row could
        end up linking a completely different one.

        A drop of plain text instead of a Person - e.g. a name
        selected and dragged straight out of the Caption panel - is
        handled separately by text_drag_received(): it sets a still-
        unlinked row's placeholder name rather than looking up a
        Person at all.
        """
        if sel_data:
            if not on_image and sel_data.get_data_type() == REORDER_ATOM:
                self.reorder_drag_received(sel_data, x, y)
                return
            if not on_image and info == TEXT_TARGET_INFO:
                self.text_drag_received(sel_data, x, y)
                return
            pickled_data = sel_data.get_data()
            if not pickled_data:
                return
            data = pickle.loads(pickled_data)
            # Perhaps allow multiple person drops
            # Sometimes, more than one person could be in a selected area
            people = []
            # Just get the first one for now:, if a list:
            if sel_data.get_data_type() == DdTargets.HANDLE_LIST.atom_drag_type:
                if data[0][0] == "Person":
                    handle = data[0][1]
                    person = self.dbstate.db.get_person_from_handle(handle)
                    if person:
                        people.append(person)
                elif data[0][0] == "Event":
                    # get first, primary person of event:
                    event_handle = data[0][1]
                    event = self.dbstate.db.get_event_from_handle(event_handle)
                    for obj_class, handle in event.get_referenced_handles():
                        if obj_class == "Person":
                            person = self.dbstate.db.get_person_from_handle(handle)
                            if person:
                                people.append(person)
                                break
            else:
                # PERSON_LINK (People view, spouse boxes in the Family
                # editor) and the reference types in
                # PERSON_REFERENCE_DD_TYPES (children, associations).
                handle = person_handle_from_drop(data)
                person = (
                    self.dbstate.db.get_person_from_handle(handle)
                    if handle and self.dbstate.db.has_person_handle(handle)
                    else None
                )
                if person:
                    people.append(person)
                else:
                    LOG.warning(
                        "PhotoTagging: can't use this drop: '%s'",
                        sel_data.get_data_type(),
                    )
                    return
            for person in people:
                if on_image:  # drop on image
                    region = self._image_drop_region(x, y)
                    self._log_drop_debug(on_image, x, y, region, person)
                    if region is not None:
                        self.ask_and_set_person(region, person)
                        self.selection_widget.clear_selection()
                        GLib.idle_add(self._cb_refresh_after_drop)
                else:  # drop on list
                    self.treeview.set_drag_dest_row(
                        None, Gtk.TreeViewDropPosition.BEFORE
                    )
                    drop_info = self.treeview.get_dest_row_at_pos(x, y)
                    self._log_drop_debug(on_image, x, y, drop_info, person)
                    if drop_info:
                        path, _position = drop_info
                        index = path.get_indices()[0]
                        if 0 <= index < len(self.regions):
                            self.ask_and_set_person(self.regions[index], person)
                            self.selection_widget.clear_selection()
                            GLib.idle_add(self._cb_refresh_after_drop)

    def _image_drop_region(self, x, y):
        """
        The marquee a Person dropped on the photo at (x, y) should be
        linked to: the selected marquee if the drop is inside it (when
        a marquee is selected, it is the only one drawn), otherwise
        the smallest marquee under the pointer. An earlier version
        ignored the drop entirely whenever any *other* marquee was
        selected, which made dropping onto the photo seem to fail at
        random.

        :param x: Drop x, in the photo event box coordinates.
        :param y: Drop y, in the photo event box coordinates.
        :returns: A Region, or None if the drop missed every marquee.
        """
        widget = self.selection_widget
        current = widget.get_current()
        if current is not None and current in self.regions:
            point = widget._screen_to_image(  # pylint: disable=protected-access
                (x, y)
            )
            if current.contains(*point):
                return current
        region = widget.find_region(x, y)
        return region if region in self.regions else None

    def cb_tree_drag_motion(self, treeview, context, x, y, time) -> bool:
        """
        Highlights the row a Person drop would land on while dragging
        over the list, so it is clear which row receives the drop
        (nothing showed before, and a drop between rows or past the
        last one silently did nothing). Skipped for a row-reorder drag
        within the list, which shows its own insertion point.

        :returns: ``False``, so the default drag-motion handling
            (Gtk.DestDefaults.MOTION) still decides the drag status.
        """
        if self._is_reorder_drag(context):
            return False
        drop_info = treeview.get_dest_row_at_pos(x, y)
        if drop_info:
            treeview.set_drag_dest_row(
                drop_info[0], Gtk.TreeViewDropPosition.INTO_OR_BEFORE
            )
        else:
            treeview.set_drag_dest_row(None, Gtk.TreeViewDropPosition.BEFORE)
        return False

    @staticmethod
    def _is_reorder_drag(context) -> bool:
        """
        Whether a drag over the list is one of its own rows being
        moved (see REORDER_TARGET_NAME), compared by atom name since
        Gdk.Atom objects do not reliably compare equal in Python.
        """
        return any(
            atom.name() == REORDER_TARGET_NAME for atom in context.list_targets()
        )

    def cb_tree_drag_leave(self, treeview, context, time) -> None:
        """
        Clears the drop-row highlight set by cb_tree_drag_motion().
        """
        if not self._is_reorder_drag(context):
            treeview.set_drag_dest_row(None, Gtk.TreeViewDropPosition.BEFORE)

    def _log_drop_debug(self, on_image, x, y, target, person) -> None:
        """
        TEMPORARY diagnostic (see DEBUG_MARQUEE_DRAW): logs where a
        Person drop landed and what it resolved to, to track down
        drops from the Family editor that do not attach.
        """
        if not DEBUG_MARQUEE_DRAW:
            return
        LOG.warning(
            "PhotoTagging drop-debug: on_%s at (%.1f, %.1f) -> %s, person=%s",
            "image" if on_image else "list",
            x,
            y,
            target.coords() if hasattr(target, "coords") else target,
            person.get_gramps_id() if person else None,
        )

    def _cb_refresh_after_drop(self) -> bool:
        """
        The deferred half of drag_data_received() - refreshing right
        there, synchronously, would run self.refresh_list()'s
        self.treestore.clear()/rebuild while GTK is still unwinding
        its own drag-and-drop handling on that same treeview - the
        same class of reentrancy cb_name_cell_edited() already avoids
        this same way (see its own docstring), and plausibly the
        proximate cause of at least one crash report against this
        addon.

        :returns: ``GLib.SOURCE_REMOVE``, so this one-shot idle
            callback is not called again.
        """
        self.refresh()
        self.enable_buttons()
        return GLib.SOURCE_REMOVE

    def text_drag_received(self, sel_data, x, y):
        """
        Handles plain text dropped onto a row of the region list --
        e.g. a name selected and dragged straight out of the Caption
        panel - by setting it as that row's manual placeholder name,
        the same as typing it into the Name cell directly (see
        cb_name_cell_edited()). No wiring was needed on the Caption
        panel's own side: a Gtk.TextView already supports dragging its
        current text selection out, whether or not it's editable.

        Only applies to a still-unlinked row: dropping text onto an
        already-linked row does nothing, the same as that row's Name
        cell isn't editable either.

        Deferred via the same _cb_refresh_after_drop() this method's
        own caller, drag_data_received(), already uses for a Person
        drop, and for the same reason: mutating self.treestore from
        inside a "drag-data-received" handler before GTK has finished
        its own drag/drop teardown risks the identical GtkTreeView
        row-height corruption that already once crashed the whole
        process from a different signal handler (see
        cb_name_cell_edited()'s own docstring).
        """
        text = sel_data.get_text()
        if not text:
            return
        text = text.strip()
        if not text:
            return
        drop_info = self.treeview.get_dest_row_at_pos(x, y)
        if not drop_info:
            return
        path, _position = drop_info
        index = path.get_indices()[0]
        if not 0 <= index < len(self.regions):
            return
        region = self.regions[index]
        if region.person is not None:
            return
        region.manual_name = text
        self._order_dirty = True
        GLib.idle_add(self._cb_refresh_after_drop)

    def build_context_menu(self):
        self.context_menu = Gtk.Menu()
        self.context_menu.set_reserve_toggle_size(False)

        self.context_button_details = Gtk.MenuItem.new_with_label(
            _("See the person details")
        )
        self.context_button_details.connect("activate", self.edit_person_clicked)

        self.context_button_ancestor_family = Gtk.MenuItem.new_with_label(
            _("See ancestor family details")
        )
        self.context_button_ancestor_family.connect(
            "activate", self.cb_edit_ancestor_families
        )

        self.context_button_descendant_family = Gtk.MenuItem.new_with_label(
            _("See descendant family details")
        )
        self.context_button_descendant_family.connect(
            "activate", self.cb_edit_descendant_families
        )

        self.context_button_active = Gtk.MenuItem.new_with_label(
            _("Make the person active")
        )
        self.context_button_active.connect("activate", self.set_active_person)

        self.context_button_select = Gtk.MenuItem.new_with_label(
            LINK_PERSON_TEXT
        )
        self.context_button_select.connect("activate", self.sel_person_clicked)

        self.context_button_add = Gtk.MenuItem.new_with_label(
            ADD_NEW_PERSON_TEXT
        )
        self.context_button_add.connect("activate", self.add_person_clicked)

        self.context_button_clear = Gtk.MenuItem.new_with_label(
            CLEAR_REFERENCE_TEXT
        )
        self.context_button_clear.connect("activate", self.clear_ref_clicked)

        self.context_button_fuzzy_lookup = Gtk.MenuItem.new_with_label(
            _("Fuzzy Match Lookup…")
        )
        self.context_button_fuzzy_lookup.connect(
            "activate", self.cb_fuzzy_lookup_clicked
        )

        self.context_button_remove = Gtk.MenuItem.new_with_label(_("Remove"))
        self.context_button_remove.connect("activate", self.del_region_clicked)

        self.context_button_move_up = Gtk.MenuItem.new_with_label(_("Move Up"))
        self.context_button_move_up.connect("activate", self.move_up_clicked)

        self.context_button_move_down = Gtk.MenuItem.new_with_label(_("Move Down"))
        self.context_button_move_down.connect("activate", self.move_down_clicked)

        self.context_button_transcribe = Gtk.MenuItem.new_with_label(
            _("Transcribe list to a Note")
        )
        self.context_button_transcribe.connect(
            "activate", self.transcribe_list_to_note_clicked
        )

        self.context_menu.append(self.context_button_details)
        self.context_menu.append(self.context_button_ancestor_family)
        self.context_menu.append(self.context_button_descendant_family)
        self.context_menu.append(self.context_button_active)
        self.context_menu.append(self.context_button_select)
        self.context_menu.append(self.context_button_add)
        self.context_menu.append(self.context_button_clear)
        self.context_menu.append(Gtk.SeparatorMenuItem())
        self.context_menu.append(self.context_button_fuzzy_lookup)
        self.context_menu.append(Gtk.SeparatorMenuItem())
        self.context_menu.append(self.context_button_remove)
        self.context_menu.append(self.context_button_move_up)
        self.context_menu.append(self.context_button_move_down)
        self.context_menu.append(Gtk.SeparatorMenuItem())
        self.context_menu.append(self.context_button_transcribe)

        self.additional_items = []

    def refresh(self):
        self.selection_widget.refresh()
        self.refresh_list()
        self.refresh_selection()

    # ======================================================
    # gramplet event handlers
    # ======================================================

    def db_changed(self):
        self.connect(self.dbstate.db, "media-update", self.update)
        self.connect(self.dbstate.db, "person-update", self.update)
        self.connect(self.dbstate.db, "person-delete", self.cb_person_deleted)
        # A Caption Note can be added, edited, or removed from
        # elsewhere in Gramps (e.g. the Media editor's own Notes tab)
        # without that necessarily also touching the Media object
        # itself, so the Caption panel/button need their own refresh
        # hook on Note signals -- not just the "media-update" above --
        # to reliably reflect that (see refresh_caption()).
        self.connect(self.dbstate.db, "note-add", self.cb_note_changed)
        self.connect(self.dbstate.db, "note-update", self.cb_note_changed)
        self.connect(self.dbstate.db, "note-delete", self.cb_note_changed)
        self.connect_signal("Media", self.update)

    def main(self):
        media = self.get_current_object()
        self.top.hide()
        is_image = media is not None and media.mime.startswith("image")
        new_handle = media.get_handle() if media else None
        current_text = get_region_data_text(media) if is_image else None
        reload_needed = new_handle != self._loaded_media_handle or (
            is_image and current_text != self._loaded_region_data_text
        )
        if reload_needed and not self._reloading:
            # Entering a different Media object (or leaving to no
            # active media), or the same object's own "PhotoTagging
            # Regions" attribute has changed since it was last read --
            # most likely a hand edit made directly in its Attribute
            # tab, since this gramplet's own writes always update
            # self._loaded_region_data_text in step (see below):
            # flush any unsaved order for the one being left, then
            # load the (new, or newly-edited) one fresh, including
            # reading its stored order. A refresh triggered for some
            # other reason (e.g. a commit from resizing a marquee,
            # which does not touch this attribute) leaves self.regions
            # as they already are.
            #
            # self._reloading guards against main() being re-entered
            # from inside itself -- e.g. region_modified()'s own
            # commit_person() call fires a "person-update" db signal
            # synchronously, which db_changed() routes straight back
            # to main() before this outer call has even returned (see
            # region_modified()'s own docstring). load_image() below
            # resets SelectionWidget's own internal selection/drag
            # state; doing that from a nested call while the person
            # may still be mid-drag on a resize handle crashed Gramps
            # outright (inside Gramps's own core widget code, so not
            # even catchable here) rather than raising an exception.
            # Skipping the reload here is safe: the next non-nested
            # call to main(), once whatever's currently in progress
            # settles, sees the same drift and reloads then instead.
            self._reloading = True
            try:
                if is_image and not self._selection_widget_ready_to_load():
                    # self.selection_widget hasn't been given a real
                    # size by GTK yet -- most likely this gramplet's
                    # view/tab was the one restored as active at
                    # Gramps startup, and this first main() run landed
                    # before the window finished laying out. Its own
                    # load_image() scales the photo to fit whatever
                    # self.selection_widget.get_allocated_height() (or
                    # width) currently reports; scaling into 0 there
                    # logs a "GdkPixbuf-CRITICAL **: gdk_pixbuf_scale_
                    # simple: assertion 'dest_height > 0' failed" (or
                    # the width equivalent) to the console and shows a
                    # blank/wrong preview, though it isn't otherwise
                    # fatal. Neither self._loaded_media_handle nor
                    # self._reloading's caller-visible state changes
                    # below, so reload_needed is still True next time
                    # main() runs; self.update() reschedules that next
                    # run for the next idle slot (the same mechanism
                    # region_created()/region_deleted() already use to
                    # rerun main(), not a direct recursive main() call)
                    # rather than spinning here immediately, so this
                    # naturally waits out however many idle cycles GTK
                    # needs to actually size the widget instead of
                    # guessing a fixed delay.
                    self.update()
                    return
                self.flush_region_order()
                entering_new_media = new_handle != self._loaded_media_handle
                self._loaded_media_handle = new_handle
                if is_image:
                    self.load_image(media)
                    if entering_new_media:
                        self._set_quick_draw_for_loaded_photo()
                    # Re-read rather than reuse current_text:
                    # load_image() can itself rewrite the attribute
                    # (see sort_regions_by_stored_order()'s self-repair
                    # of a structurally invalid value), and the
                    # snapshot must reflect whatever is actually stored
                    # now, not what was there before that possible
                    # rewrite.
                    self._loaded_region_data_text = get_region_data_text(media)
                else:
                    self.regions = []
                    self.sync_selection_widget_regions()
                    self._loaded_region_data_text = None
            finally:
                self._reloading = False
        if not is_image:
            self.selection_widget.show_missing()
        self.refresh_list()
        self.refresh_caption()
        self.enable_buttons()
        self.top.show()
        # refresh_list() just cleared and rebuilt the treeview's
        # model, which drops its row selection entirely (self.regions
        # itself is untouched here, so refresh_selection() restores
        # it to the same region as before -- self.selection_widget's
        # own current-region state, unlike the treeview's, isn't tied
        # to that model and so survives the rebuild). Without this,
        # a refresh triggered by, say, clicking OK in the editor
        # opened by double-clicking a row -- which re-enters here via
        # the resulting db signal -- left the list with no selection
        # restored.
        #
        # Deliberately called only now, after self.top.show() above
        # (and even then via a deferred call, not directly), rather
        # than right after refresh_list() like region_modified()/
        # region_created() below do: this whole gramplet is hidden
        # via self.top.hide() at the very top of this method, and
        # Gtk.TreeView.set_cursor() -- which apply_selected_region()
        # uses to restore the selection -- does not reliably take
        # effect on a widget that isn't realized/mapped, which it
        # isn't while still hidden here. Deferring past the coming
        # show() means the row's own geometry has settled by the time
        # set_cursor()/scroll_to_selected_row() run, the same
        # reasoning scroll_to_selected_row() itself already relies on.
        self._schedule_refresh_selection()
        if reload_needed and is_image:
            # See nudge_selection_widget_layout()'s own docstring: the
            # same "SelectionWidget's cached image size doesn't match
            # its real allocation" problem that shows up after a
            # window maximize also shows up right here, for a related
            # reason -- this whole gramplet is hidden (self.top.hide(),
            # at the very top of this method) for the entire reload, so
            # self.selection_widget.load_image() (inside load_image()
            # above) scales the image against whatever allocation a
            # hidden widget happens to report, which can predate
            # refresh_caption() changing the Caption panel's own
            # visibility just above it -- and that, in turn, changes
            # how much height is actually left for the image once
            # self.top.show() makes everything visible again. Without
            # this, the image showed scaled/positioned as if the
            # Caption panel weren't there at all, self-correcting only
            # once some unrelated later event (a window resize,
            # dragging a scrollbar) happened to trigger a real
            # size-allocate that finally disagreed with the stale
            # cached size. The same delayed nudge used for the
            # maximize case forces that recompute immediately, against
            # the now-settled real allocation, instead of waiting on
            # one of those to happen by chance.
            GLib.timeout_add(150, self.nudge_selection_widget_layout)

    def cb_note_changed(self, *args) -> None:
        """
        Callback for the "note-add"/"note-update"/"note-delete" db
        signals connected in db_changed() -- refreshes just the
        Caption panel/button, without reloading the image and region
        list that a full self.update()/main() would (unnecessary here,
        since a Note by itself never affects those).

        :param args: The signal's own arguments (typically a list of
            the affected Note handles), ignored: refresh_caption()
            always re-reads the current Media's Caption Note fresh
            rather than trying to determine from `args` alone whether
            the change was actually relevant to it.
        """
        self.refresh_caption()

    def cb_person_deleted(self, handles) -> None:
        """
        Callback for the db's own "person-delete" signal (connected in
        db_changed()). Unlike a Media-object edit, deleting a Person
        doesn't touch this photo's own "PhotoTagging Regions"
        attribute text at all, so main()'s same-object fast path (see
        its own docstring) has no way to notice on its own that one of
        self.regions' Person references just went stale -- a plain
        self.update() here would leave those regions pointing at a
        Person no longer in the database until the next time this
        photo's handle actually changes.

        Deliberately filtered to only the deleted person(s) actually
        tagged in the *current* photo, unlike cb_note_changed()'s own
        always-refresh approach: a full reload here re-reads the
        image file's own embedded metadata from disk (see
        load_image()/get_xmp_regions()), which is not free, and a
        Person deleted elsewhere in a large tree has nothing to do
        with whichever photo happens to be open right now.

        :param handles: The signal's own argument -- the deleted
            person(s)' handle(s).
        """
        deleted = set(handles)
        if any(
            person.get_handle() in deleted for person in self.all_referenced_persons()
        ):
            # Force main() to treat this like entering a different
            # Media object -- the only branch that actually calls
            # load_image() again -- rather than relying on the
            # region-data-attribute drift check, which has nothing to
            # detect here (see this method's own docstring).
            self._loaded_media_handle = None
            self.update()

    # ======================================================
    # loading the image
    # ======================================================

    def _cleanup_rotated_temp_file(self):
        """
        Deletes the temp file rotated_pixbuf_and_temp_path() rendered
        for whichever photo was loaded before this one, if any, and
        drops the in-memory rotated pixbuf that came with it (see
        safe_get_thumbnail()) -- called both when moving on to load a
        new photo (load_image()) and when the gramplet itself is torn
        down (on_save()), so neither just accumulates for the life of
        the Gramps session.
        """
        self._rotated_pixbuf = None
        if self._rotated_temp_path is not None:
            try:
                os.remove(self._rotated_temp_path)
            except OSError:
                pass
            self._rotated_temp_path = None

    def _selection_widget_ready_to_load(self) -> bool:
        """
        Whether self.selection_widget currently has a real (nonzero)
        allocated size -- see main()'s own comment for why load_image()
        needs to wait for this rather than run unconditionally: it
        scales the photo to fit whatever size GTK has actually given
        the widget, and scaling to fit a 0-sized one is what produces
        the "dest_height > 0" (or width) GdkPixbuf-CRITICAL.

        Gtk.Widget.get_allocated_width()/get_allocated_height() return
        whatever the widget's last size-allocate reported, which is 0
        for both before it has ever been through one at all (not, for
        instance, 1x1 or some other placeholder) -- the case this
        exists to catch is specifically "hasn't been laid out yet",
        not "has been laid out unusually small".

        :returns: True once the widget has a real size to fit into.
        """
        return (
            self.selection_widget.get_allocated_width() > 0
            and self.selection_widget.get_allocated_height() > 0
        )

    def load_image(self, media):
        self.regions = []
        self.xmp_regions = []
        # Every Region object is rebuilt below, so nothing remembered
        # about the previous photo's (or previous load's) selection
        # may be reused -- see cb_preview_panel_button_release().
        self._last_selected_region = None
        self._selected_region_coords = None
        self._release_ended_drag = False
        image_path = media_path_full(self.dbstate.db, media.get_path())
        self._cleanup_rotated_temp_file()
        self.rotation_degrees = read_rotation_degrees(image_path)
        display_path = image_path
        if self.rotation_degrees:
            rotated_pixbuf, rotated_path = rotated_pixbuf_and_temp_path(
                image_path, self.rotation_degrees
            )
            if rotated_path is not None:
                self._rotated_temp_path = rotated_path
                self._rotated_pixbuf = rotated_pixbuf
                display_path = rotated_path
            else:
                # Couldn't render the rotated copy -- fall back to
                # showing (and treating) the photo as unrotated,
                # rather than lying to every region-rect conversion
                # below about what self.selection_widget actually has
                # loaded.
                self.rotation_degrees = 0
        self.selection_widget.loaded = False
        self.selection_widget.load_image(display_path)
        if self.selection_widget.loaded:
            self.retrieve_backrefs()
            stored_entries = read_stored_region_entries(media)
            if stored_entries is not None:
                # The attribute is the authority while it exists: what
                # it holds -- including the clues it recorded from XMP,
                # a sidecar or picasa.ini -- is used as-is, and the
                # original files are NOT consulted again. Deleting the
                # attribute is how to make them be read afresh.
                self.restore_stored_regions(stored_entries)
            else:
                if not self.get_xmp_regions(image_path):
                    # No MWG regions in the file or its .xmp sidecar --
                    # try the folder's picasa.ini. Same "one source or
                    # the other, never merged" rule as the sidecar.
                    self.get_picasa_regions(image_path)
                if not self.regions and not self.xmp_regions:
                    # Last resort: no Gramps-linked region and no
                    # Xmp.mwg-rs / picasa.ini region for this photo
                    # at all. Xmp.dc.subject is a much simpler, far
                    # more commonly supported flat tag that at least
                    # carries the names, even with no position -- see
                    # get_xmp_keyword_regions() for the trade-offs of
                    # surfacing it this way.
                    self.get_xmp_keyword_regions(image_path)
            clues_read_live = stored_entries is None and bool(self.xmp_regions)
            self.regions = self.regions + self.xmp_regions
            self.sort_regions_by_stored_order(media)
            if clues_read_live:
                # First time this photo's metadata has been read:
                # snapshot all of it into the attribute right away
                # (not only once the person next edits something), so
                # the attribute holds the full record from then on.
                self.persist_region_order(media)
            self.sync_selection_widget_regions()

    def sort_regions_by_stored_order(self, media):
        """
        Orders self.regions by the order persisted in the Media
        object's "PhotoTagging Regions" attribute (see
        persist_region_order() / get_stored_region_order()), so a
        manual reorder set via drag-and-drop or the Move Up/Down
        buttons survives navigating away from this Media object and
        back, or restarting Gramps -- not just a same-session refresh.

        A still-unlinked placeholder region keeps its own persisted
        position too, matched back up by placeholder name via
        order_by_name (see get_stored_region_order()) -- rather than
        always sorting after every linked Person the way an earlier
        version of this method did. That older behaviour is what
        caused linking, say, the 2nd of 3 XMP placeholders to jump it
        to row 1 instead of leaving it at row 2: every "gramps"-sourced
        region sorted ahead of every not-yet-linked one, regardless of
        where either had actually been sitting.

        A region with no stored order at all (never persisted before,
        or its placeholder name no longer matches anything in the
        stored data -- e.g. it was renamed) sorts after every region
        that does, in natural discovery order.
        """
        order_by_handle, order_by_name, ok = get_stored_region_order(
            media, self.dbstate.db
        )

        def sort_key(region):
            if region.person is not None:
                row = order_by_handle.get(region.person.get_handle())
                if row is not None:
                    return (0, row)
            else:
                name = effective_placeholder_name(region)
                queue = order_by_name.get(name) if name else None
                if queue:
                    return (0, queue.pop(0))
            return (1, 0)

        self.regions.sort(key=sort_key)

        if not ok:
            # The attribute's text was structurally invalid (most
            # likely hand-edited into something else) -- replace it
            # with a clean table reflecting the natural order just
            # fallen back to, instead of leaving bad data in place to
            # fail the same way again next time.
            self.persist_region_order(media)

    def retrieve_backrefs(self):
        """
        Finds the media references pointing to the current image
        """
        backrefs = self.dbstate.db.find_backlink_handles(self.get_current_handle())
        for reftype, ref in backrefs:
            if reftype == "Person":
                person = self.dbstate.db.get_person_from_handle(ref)
                gallery = person.get_media_list()
                for mediaref in gallery:
                    referenced_handles = mediaref.get_referenced_handles()
                    for referens_item in referenced_handles:
                        handle_type, handle = referens_item
                        if (
                            handle_type == "Media"
                            and handle == self.get_current_handle()
                        ):
                            rect = mediaref.get_rectangle()
                            if rect is None:
                                rect = (0, 0, 100, 100)
                            rect = rotate_proportional_rect(rect, self.rotation_degrees)
                            coords = self.selection_widget.proportional_to_real_rect(
                                rect
                            )
                            region = Region(*coords)
                            region.person = person
                            region.xmp_person = ""
                            region.mediaref = mediaref
                            self.regions.append(region)

    def get_xmp_regions(self, image_path):
        """
        Get named regions from Xmp metadata -- read from the image
        file's own embedded XMP if it has usable mwg-rs:Regions data,
        else from a same-named ".xmp" sidecar file next to it, if one
        exists (see sidecar_xmp_path()). Some workflows -- notably
        archival scans distributed as a pristine, unmodified original
        plus a separate metadata file -- only ever carry region data
        the second way.
        """
        metadata = open_gexiv2_metadata(image_path)

        region_tag = "Xmp.mwg-rs.Regions/mwg-rs:RegionList[%s]/"
        region_name = region_tag + "mwg-rs:Name"

        has_regions = metadata is not None and (
            get_xmp_tag_string(metadata, region_name % 1) is not None
        )
        clue_source = CLUE_SOURCE_XMP_EMBEDDED
        if not has_regions:
            sidecar_path = sidecar_xmp_path(image_path)
            if sidecar_path is not None:
                sidecar_metadata = open_gexiv2_metadata(sidecar_path)
                if sidecar_metadata is not None and (
                    get_xmp_tag_string(sidecar_metadata, region_name % 1) is not None
                ):
                    metadata = sidecar_metadata
                    clue_source = CLUE_SOURCE_XMP_SIDECAR

        if metadata is None:
            return False

        region_type = region_tag + "mwg-rs:Type"
        region_x = region_tag + "mwg-rs:Area/stArea:x"
        region_y = region_tag + "mwg-rs:Area/stArea:y"
        region_w = region_tag + "mwg-rs:Area/stArea:w"
        region_h = region_tag + "mwg-rs:Area/stArea:h"
        region_unit = region_tag + "mwg-rs:Area/stArea:unit"

        i = 1
        while True:
            name = get_xmp_tag_string(metadata, region_name % i)
            if name is None:
                break

            try:
                x = float(get_xmp_tag_string(metadata, region_x % i)) * 100
                y = float(get_xmp_tag_string(metadata, region_y % i)) * 100
                w = float(get_xmp_tag_string(metadata, region_w % i)) * 100
                h = float(get_xmp_tag_string(metadata, region_h % i)) * 100
            except (ValueError, TypeError):
                # ValueError: a present-but-non-numeric value (e.g. a
                # hand-edited or corrupted tag). TypeError: the tag
                # was missing entirely, so get_xmp_tag_string()
                # returned None and float(None) itself raises
                # TypeError rather than ValueError.
                x = y = 50
                w = h = 100

            rtype = get_xmp_tag_string(metadata, region_type % i)
            unit = get_xmp_tag_string(metadata, region_unit % i)

            # ensure region does not exceed bounds of image
            rect_p1 = x - (w / 2)
            if rect_p1 < 0:
                rect_p1 = 0
            rect_p2 = y - (h / 2)
            if rect_p2 < 0:
                rect_p2 = 0
            rect_p3 = x + (w / 2)
            if rect_p3 > 100:
                rect_p3 = 100
            rect_p4 = y + (h / 2)
            if rect_p4 > 100:
                rect_p4 = 100

            rect = (rect_p1, rect_p2, rect_p3, rect_p4)
            rect = rotate_proportional_rect(rect, self.rotation_degrees)
            coords = self.selection_widget.proportional_to_real_rect(rect)
            xmp_region = Region(*coords)
            xmp_region.xmp_person = name
            xmp_region.xmp_type = rtype or "Face"
            xmp_region.xmp_source = clue_source

            # Per-region cascade (see REGION_DATA_ATTR_TYPE): an
            # embedded region is only suppressed by a Gramps region
            # that actually covers the same spot, not by the mere
            # presence of *some* Gramps region elsewhere on the same
            # photo -- so a photo with one person already tagged still
            # surfaces embedded clues for anyone else the file already
            # knows about.
            if not self.intersects_any(xmp_region):
                self.xmp_regions.append(xmp_region)
            i += 1
        return i > 1

    def get_picasa_regions(self, image_path: str) -> int:
        """
        Get named face regions from the folder's picasa.ini (see
        read_picasa_faces()) and add them as unlinked Metadata clues,
        exactly like regions read from XMP: xmp_person holds the name,
        xmp_type is "Face". They are persisted in the "PhotoTagging
        Regions" attribute as SOURCE_EMBEDDED entries in the same
        center-plus-size MWG form (via region_to_mwg_area()), so
        nothing downstream needs to know where a clue came from.

        Picasa's rectangles are assumed to be in the photo's native
        (unrotated) coordinate space, like MWG regions, so they get
        the same rotate_proportional_rect() treatment.

        :param image_path: Absolute path to the image file on disk.
        :returns: How many regions were added.
        """
        added = 0
        for name, rect, contact_id in read_picasa_faces(image_path):
            rect = rotate_proportional_rect(rect, self.rotation_degrees)
            coords = self.selection_widget.proportional_to_real_rect(rect)
            picasa_region = Region(*coords)
            picasa_region.xmp_person = name
            picasa_region.xmp_type = "Face"
            picasa_region.xmp_source = CLUE_SOURCE_PICASA
            picasa_region.xmp_clue_id = contact_id
            if not self.intersects_any(picasa_region):
                self.xmp_regions.append(picasa_region)
                added += 1
        return added

    def get_xmp_keyword_regions(self, image_path: str) -> None:
        """
        Fall back to the flat name list in Xmp.dc.subject when no
        per-person MWG region was found at all (see load_image()).
        Xmp.dc.subject carries no position information -- there's no
        real box to draw -- so each name is given a region spanning
        the entire image, the same "no known rectangle" convention
        already used in retrieve_backrefs() for a MediaRef with no
        stored rectangle of its own.

        This is a deliberate trade-off: every row built this way
        shares the exact same whole-image rectangle, so their Preview
        thumbnails are identical and their marquees exactly overlap
        on the canvas (selecting one via its row in the list works
        fine; telling them apart by clicking the canvas does not).
        It only ever runs when the gramplet would otherwise show
        nothing at all for this photo.

        :param image_path: Absolute path to the image file on disk.
        """
        metadata = open_gexiv2_metadata(image_path)
        names = read_xmp_subject_tag(metadata, image_path) if metadata else None
        clue_source = CLUE_SOURCE_KEYWORDS_EMBEDDED
        if not names:
            sidecar_path = sidecar_xmp_path(image_path)
            if sidecar_path is not None:
                sidecar_metadata = open_gexiv2_metadata(sidecar_path)
                if sidecar_metadata is not None:
                    names = read_xmp_subject_tag(sidecar_metadata, sidecar_path)
                    clue_source = CLUE_SOURCE_KEYWORDS_SIDECAR

        if not names:
            return

        whole_image_rect = self.selection_widget.proportional_to_real_rect(
            (0, 0, 100, 100)
        )
        for name in names:
            if not name:
                continue
            keyword_region = Region(*whole_image_rect)
            keyword_region.xmp_person = name
            keyword_region.xmp_whole_image = True
            keyword_region.xmp_source = clue_source
            keyword_region.xmp_type = "Face"
            self.xmp_regions.append(keyword_region)

    def regions_nearly_equal(self, coords_a, coords_b) -> bool:
        """
        True when two real-pixel rectangles are the same box to within
        about a pixel -- used instead of an overlap test when restoring
        stored regions, so neighbours that merely touch in a tight
        group photo are never mistaken for each other.
        """
        return all(abs(a - b) <= 1.5 for a, b in zip(coords_a, coords_b))

    def restore_stored_regions(self, entries):
        """
        Rebuilds this photo's regions from its "PhotoTagging Regions"
        attribute instead of re-reading XMP / a sidecar / picasa.ini.
        While the attribute exists it is the authority; deleting it
        makes the next load read the original metadata again.

        Linked regions still come from the Persons' MediaRefs
        (retrieve_backrefs(), which must already have run); each one
        gets its original metadata clue back from its stored "gramps"
        entry. Every unlinked entry ("embedded" or "manual") becomes a
        placeholder region with its clue, clue source and typed name
        restored. A "gramps" entry that no longer has a live link but
        remembers a clue comes back as an unlinked clue.

        An entry is skipped only if a linked region already sits on
        the very same box (the person was linked from elsewhere).

        :param entries: The list of entry dicts (see
            read_stored_region_entries()).
        """
        pending_links = [e for e in entries if e.get("source") == SOURCE_GRAMPS]
        for region in self.regions:
            handle = region.person.get_handle()
            gramps_id = region.person.get_gramps_id()
            match = None
            for entry in pending_links:
                if entry.get("person_handle") == handle:
                    match = entry
                    break
            if match is None:
                # Entries written before person_handle existed.
                for entry in pending_links:
                    if not entry.get("person_handle") and (
                        entry.get("gramps_ref") == gramps_id
                    ):
                        match = entry
                        break
            if match is not None:
                pending_links.remove(match)
                self.apply_stored_clue(region, match)
                self.apply_stored_precise_rect(region, match)

        candidates = [
            e for e in entries if e.get("source") in (SOURCE_EMBEDDED, SOURCE_MANUAL)
        ] + [e for e in pending_links if e.get("clue")]
        for entry in candidates:
            name = entry.get("name") or ""
            clue = entry.get("clue") or ""
            is_manual = entry.get("source") == SOURCE_MANUAL
            if not clue and not is_manual:
                clue = name
            if not clue and not name:
                continue
            try:
                area = {key: float(entry[key]) for key in ("x", "y", "w", "h")}
            except (KeyError, TypeError, ValueError):
                continue
            rect = self.mwg_area_to_proportional_rect(area)
            rect = rotate_proportional_rect(rect, self.rotation_degrees)
            coords = self.selection_widget.proportional_to_real_rect(rect)
            if any(
                self.regions_nearly_equal(r.coords(), coords)
                for r in self.regions
                if r.person is not None
            ):
                continue
            stored_region = Region(*coords)
            self.apply_stored_clue(stored_region, entry, clue)
            if is_manual:
                # A typed name (even a deliberately emptied one), as
                # opposed to a clue shown as it was read.
                stored_region.manual_name = name
            self.xmp_regions.append(stored_region)

    def apply_stored_precise_rect(self, region, entry):
        """
        Replaces a linked region's whole-number box (as built from its
        MediaRef by retrieve_backrefs()) with the precise box stored in
        its "gramps" entry -- but only if that precise box still rounds
        outward to the MediaRef's current numbers (see
        precise_rect_matches()). If not, the MediaRef was changed
        elsewhere since, and its box is kept as it is.

        :param region: A linked Region with a mediaref.
        :param entry: Its stored "gramps" entry dict.
        """
        mediaref = getattr(region, "mediaref", None)
        if mediaref is None:
            return
        try:
            area = {key: float(entry[key]) for key in ("x", "y", "w", "h")}
        except (KeyError, TypeError, ValueError):
            return
        precise = self.mwg_area_to_proportional_rect(area)
        if not precise_rect_matches(precise, mediaref.get_rectangle()):
            return
        rect = rotate_proportional_rect(precise, self.rotation_degrees)
        region.set_coords(*self.selection_widget.proportional_to_real_rect(rect))

    def apply_stored_clue(self, region, entry, clue=None):
        """
        Copies the metadata-clue fields of a stored entry onto
        `region` (see clue_fields() for what is stored).

        :param region: The Region to update.
        :param entry: The stored entry dict.
        :param clue: The clue text, if the caller worked it out;
            defaults to the entry's own "clue".
        """
        region.xmp_person = clue if clue is not None else entry.get("clue", "")
        region.xmp_type = entry.get("type") or "Face"
        region.xmp_source = entry.get("clue_source", "")
        region.xmp_clue_id = entry.get("clue_id", "")
        if entry.get("whole_image"):
            region.xmp_whole_image = True

    # ======================================================
    # managing regions
    # ======================================================

    def check_and_translate_to_proportional(self, mediaref, rect):
        # Always from the region's own (precise) pixel coords, never
        # from the old MediaRef's whole numbers -- the region's coords
        # are where the box actually is on screen. `mediaref` is kept
        # in the signature for existing callers.
        display_rect = self.selection_widget.real_to_proportional_rect(rect)
        return unrotate_proportional_rect(display_rect, self.rotation_degrees)

    def intersects_any(self, region):
        for r in self.regions:
            if r.intersects(region):
                return True
        return False

    def enclosing_region(self, region):
        for r in self.regions:
            if r.contains_rect(region):
                return r
        return None

    def regions_referencing_person(self, person):
        # By handle, not object identity -- see prepare_context_menu().
        result = []
        if person is None:
            return result
        handle = person.get_handle()
        for r in self.regions:
            if r.person is not None and r.person.get_handle() == handle:
                result.append(r)
        return result

    def all_referenced_persons(self):
        result = []
        for r in self.regions:
            if r.person is not None:
                result.append(r.person)
        return result

    # ======================================================
    # reordering regions
    # ======================================================
    # The list-move logic below follows the same pop/insert approach used
    # by gramps.gui.editors.editperson.EditPerson.reorder_child_ref_list
    # and by the row Up/Down buttons and drag-and-drop in
    # gramps.gui.editors.displaytabs.embeddedlist.EmbeddedList.

    def move_region_up(self, region):
        row_from = self.regions.index(region)
        if row_from > 0:
            del self.regions[row_from]
            self.regions.insert(row_from - 1, region)
            self.region_order_changed(region)

    def move_region_down(self, region):
        row_from = self.regions.index(region)
        if row_from < len(self.regions) - 1:
            del self.regions[row_from]
            self.regions.insert(row_from + 1, region)
            self.region_order_changed(region)

    def move_region(self, row_from, row_to, region):
        """
        Move a region from row_from to row_to, where row_to is the target
        drop slot in the list as it stands before the move (i.e. before
        row_from is removed).
        """
        if row_from == row_to:
            return
        if row_from < row_to:
            self.regions.insert(row_to, region)
            del self.regions[row_from]
        else:
            del self.regions[row_from]
            self.regions.insert(row_to, region)
        self.region_order_changed(region)

    def _handle_row_id_double_click(self, path):
        """
        Handles a double-click on the Row ID column (see
        row_mouse_click()): opens a small popover, pointing at that
        row number, asking for the row number to move the row to -- a
        keyboard-driven alternative to drag-and-drop reordering, for a
        move too fussy to land precisely by dragging.

        Enter applies the number, and so does clicking anywhere
        outside the popover after changing it; Esc cancels.

        A popover rather than a dialog: the earlier modal Move Row
        dialog was a child of the main Gramps window, so when another
        window (e.g. an Edit Person editor opened by a mis-aimed
        double-click) was already on top, the dialog opened *behind*
        it while still blocking it -- Gramps looked locked up unless
        you thought to press Esc. A popover belongs to this gramplet
        itself, always appears where it was opened, and blocks
        nothing. It also avoids running a nested dialog.run() loop
        from inside this button-press handler.

        Still not an inline edit of the Row ID cell itself: that was
        tried twice and crashed inside GtkTreeView (see
        cb_name_cell_edited() for the same class of crash). The move
        itself is deferred to idle, after the popover has closed, for
        the same reason.

        :param path: The Gtk.TreePath of the double-clicked row.
        :returns: ``True``, so the double-click goes no further.
        """
        index = path.get_indices()[0]
        if not 0 <= index < len(self.regions):
            return True
        region = self.regions[index]
        current_row = index + 1

        cell = self.treeview.get_cell_area(path, self.column_row_id)
        cell_x, cell_y = self.treeview.convert_bin_window_to_widget_coords(
            cell.x, cell.y
        )
        pointing_to = Gdk.Rectangle()
        pointing_to.x = cell_x
        pointing_to.y = cell_y
        pointing_to.width = cell.width
        pointing_to.height = cell.height

        popover = Gtk.Popover.new(self.treeview)
        popover.set_pointing_to(pointing_to)
        popover.set_position(Gtk.PositionType.RIGHT)

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        box.set_border_width(6)
        box.pack_start(Gtk.Label(label=_("Move to row:")), False, False, 0)
        adjustment = Gtk.Adjustment(
            value=current_row, lower=1, upper=len(self.regions), step_increment=1
        )
        spin = Gtk.SpinButton(adjustment=adjustment, climb_rate=1, digits=0)
        spin.set_numeric(True)
        box.pack_start(spin, False, False, 0)
        popover.add(box)

        state = {"cancelled": False}

        def cb_spin_activate(_spin):
            popover.popdown()

        def cb_key_press(_widget, event):
            if event.keyval == Gdk.KEY_Escape:
                state["cancelled"] = True
            return False

        def cb_closed(_popover):
            spin.update()
            number = spin.get_value_as_int()
            if state["cancelled"] or number == current_row:
                number = None
            GLib.idle_add(self._cb_apply_row_move, popover, region, number)

        spin.connect("activate", cb_spin_activate)
        popover.connect("key-press-event", cb_key_press)
        popover.connect("closed", cb_closed)
        popover.show_all()
        popover.popup()
        spin.grab_focus()
        return True

    def _cb_apply_row_move(self, popover, region, number) -> bool:
        """
        The deferred half of _handle_row_id_double_click(): destroys
        the closed popover and, if a new row number was chosen, moves
        `region` there.

        A number below 1 or above the row count is clamped to the
        first or last row. See move_region() for the row_from/row_to
        convention: row_to is a slot in the list as it stands before
        the move, so it is the final index when moving a row earlier,
        and final index + 1 when moving it later.

        :param popover: The closed Gtk.Popover.
        :param region: The Region whose row number was double-clicked.
        :param number: The 1-based row number to move it to, or None.
        :returns: ``GLib.SOURCE_REMOVE``.
        """
        popover.destroy()
        if number is None or region not in self.regions:
            return GLib.SOURCE_REMOVE
        index = self.regions.index(region)
        final_index = max(0, min(number - 1, len(self.regions) - 1))
        if final_index != index:
            row_to = final_index if final_index <= index else final_index + 1
            self.move_region(index, row_to, region)
        return GLib.SOURCE_REMOVE

    def region_order_changed(self, region):
        """
        Refreshes after a move, keeping the moved region focused (in
        both the image and the list, outside quick_draw_toggled()'s
        quick draw mode -- see below) so further moves can be chained.
        The new order is kept in memory only for now (see
        flush_region_order()) -- there's no reason to write it to the
        database until leaving this Media object or closing Gramps, so
        a move doesn't trigger a database commit (which would otherwise
        cause an async gramplet refresh that clears the treeview's
        selection right back out from under this method).

        self.selection_widget.select(region) below, ahead of the
        deferred self.refresh(), is what makes that reselection land on
        `region`'s own new row: self.refresh() -> refresh_selection()
        re-applies whatever self.selection_widget.get_current() is at
        that point (see apply_selected_region(), which also handles
        the row/marquee/Caption highlight together and calls
        enable_buttons() itself as its last step) -- a separate,
        unguarded self.treeview.set_cursor() call used to be made here
        as well, entirely redundant with that, and a risk of its own:
        unlike apply_selected_region()'s own set_cursor() call, it
        was not guarded against cursor_changed() reacting to it.

        While quick draw mode is active, though, selecting `region` on
        SelectionWidget at all is exactly what this method must NOT do
        -- doing so is what made every reorder narrow the photo down
        to just the moved region, with the rest dimmed out, undoing
        the mode's whole "show every marquee at once" promise the same
        way a freshly drawn marquee once did (see cursor_changed()'s
        own quick_draw_mode branch for that half of the same bug).
        Instead, `region` is stashed in self._quick_draw_reorder_target
        for _cb_refresh_after_reorder() to apply via
        _focus_treeview_row_only() -- list-cursor only, nothing
        selected on the image -- but only *after* self.refresh() has
        rebuilt the treeview to match self.regions' new order: applying
        it here, before that rebuild, would compute the right index
        against the still-stale (pre-move) row list and land the
        cursor on the wrong row.

        self.refresh() itself is deferred via GLib.idle_add (see
        _cb_refresh_after_reorder()), for the same reason
        del_region_clicked() defers it (see that method's own
        docstring): this method is called from move_region_up()/
        move_region_down(), both context menu item "activate" signal
        handlers firing mid-teardown of that menu's own popdown, and
        from the treeview's own drag-and-drop row-reorder handling,
        which carries the equivalent risk for the equivalent reason
        (see cb_person_drag_data_get()'s own deferred refresh for the
        person-drop case this mirrors).
        """
        self._order_dirty = True
        self.sync_selection_widget_regions()
        if self.quick_draw_mode:
            self._quick_draw_reorder_target = region
        else:
            self.selection_widget.select(region)
        GLib.idle_add(self._cb_refresh_after_reorder)

    def _cb_refresh_after_reorder(self) -> bool:
        """
        The deferred half of region_order_changed() -- see its own
        docstring for why self.refresh() can't be called directly
        from there, and for why quick draw mode's own reselection is
        applied separately here, after self.refresh() has already
        rebuilt the treeview to match self.regions' new order.

        :returns: ``GLib.SOURCE_REMOVE``, so this one-shot idle
            callback is not called again.
        """
        self.refresh()
        if self.quick_draw_mode and self._quick_draw_reorder_target is not None:
            self._focus_treeview_row_only(self._quick_draw_reorder_target)
            self._quick_draw_reorder_target = None
        return GLib.SOURCE_REMOVE

    def flush_region_order(self):
        """
        Writes the in-memory order to the currently-loaded Media
        object's PhotoTagging Order attribute if it has changed since
        it was last read or written. Called when leaving a Media
        object (including to no active media) and when Gramps is
        closing (via on_save(), which Gramps calls on every open
        gramplet during its shutdown sequence -- observed to happen
        after the database connection itself has already been closed,
        raising sqlite3.ProgrammingError on any further use of it, so
        both an is_open() check and a broad try/except guard the actual
        database access here rather than letting that crash the
        shutdown).
        """
        if not self._order_dirty:
            return
        self._order_dirty = False
        if not self._loaded_media_handle:
            return
        if not self.dbstate.db.is_open():
            return
        try:
            media = self.dbstate.db.get_media_from_handle(self._loaded_media_handle)
            if media is not None:
                self.persist_region_order(media)
        except Exception:
            # The database can be closed out from under this call
            # (see docstring) at any point up to and including the
            # commit itself; there's nothing to save to at that point.
            pass

    def region_to_proportional_rect(self, region):
        """
        Returns `region`'s rectangle as (left, top, right, bottom) in
        the same 0-100 proportional space used throughout this file
        for MediaRef rectangles and Xmp.mwg-rs Area math (see
        get_xmp_regions()).

        Uses the region's own precise pixel coordinates. For a linked
        region, those are only trusted while they still round outward
        to the MediaRef's whole-number rectangle (see
        precise_rect_matches()); otherwise the MediaRef -- the
        Gramps-authoritative value -- is returned, as before.

        :param region: A gramplet Region -- see retrieve_backrefs(),
            get_xmp_regions(), and get_xmp_keyword_regions() for how
            these are constructed.
        :returns: A 4-tuple of floats.
        """
        display_rect = self.selection_widget.real_to_proportional_rect(region.coords())
        precise = unrotate_proportional_rect(display_rect, self.rotation_degrees)
        mediaref = getattr(region, "mediaref", None)
        if mediaref is not None:
            rect = mediaref.get_rectangle()
            if rect is not None and not precise_rect_matches(precise, rect):
                return rect
        return precise

    def region_to_mwg_area(self, region):
        """
        Converts `region`'s rectangle to the mwg-rs:Area convention
        this gramplet already reads in get_xmp_regions() -- a
        normalized (0.0-1.0) center point plus size -- rather than the
        corner-based, 0-100-scaled rectangle used internally, so an
        entry written into the "PhotoTagging Regions" attribute (see
        REGION_DATA_ATTR_TYPE) matches what a real Xmp.mwg-rs.Regions
        tag would hold, with no unit conversion left for a future
        metadata-writing utility to get wrong.

        :param region: A gramplet Region.
        :returns: A dict with "x", "y", "w", "h", and "unit" keys.
        """
        left, top, right, bottom = self.region_to_proportional_rect(region)
        width = (right - left) / 100
        height = (bottom - top) / 100
        return {
            "x": round((left / 100) + width / 2, MWG_AREA_DECIMALS),
            "y": round((top / 100) + height / 2, MWG_AREA_DECIMALS),
            "w": round(width, MWG_AREA_DECIMALS),
            "h": round(height, MWG_AREA_DECIMALS),
            "unit": "normalized",
        }

    def mwg_area_to_proportional_rect(self, area):
        """
        The inverse of region_to_mwg_area(): converts a normalized
        (0.0-1.0) center point plus size -- the mwg-rs:Area convention
        used both in a real Xmp.mwg-rs.Regions tag (see
        get_xmp_regions()) and in the "PhotoTagging Regions" attribute
        (see REGION_DATA_ATTR_TYPE) -- back to a (left, top, right,
        bottom) rectangle in the 0-100 proportional space used
        throughout this file, clamped to the image's own bounds the
        same way get_xmp_regions() already clamps a freshly-read XMP
        region.

        :param area: A dict with "x", "y", "w", and "h" keys, each
            0.0-1.0 (as region_to_mwg_area() produces, "unit" ignored).
        :returns: A 4-tuple of floats in 0-100 space.
        """
        x = area["x"] * 100
        y = area["y"] * 100
        w = area["w"] * 100
        h = area["h"] * 100
        left = max(0, x - (w / 2))
        top = max(0, y - (h / 2))
        right = min(100, x + (w / 2))
        bottom = min(100, y + (h / 2))
        return (left, top, right, bottom)

    def serialize_region_data(self, regions):
        """
        Builds the JSON value for the "PhotoTagging Regions" attribute
        (see REGION_DATA_ATTR_TYPE) from the current region list: one
        entry per region, in display order -- order is array position,
        not a separate field, see that constant's own docstring --
        each tagged with which cascade layer it came from. A linked
        region with no Gramps ID yet (shouldn't normally happen) and
        an unlinked region with no embedded name at all carry nothing
        worth persisting, so both are skipped.

        :param regions: self.regions, in display order.
        :returns: The JSON text, or "" if there is nothing to persist.
        """
        entries = []
        for region in regions:
            area = self.region_to_mwg_area(region)
            if region.person is not None:
                gramps_id = region.person.get_gramps_id()
                if not gramps_id:
                    continue
                entries.append(
                    {
                        "name": display_name_respecting_format(
                            region.person.get_primary_name()
                        ),
                        "type": "Face",
                        "source": SOURCE_GRAMPS,
                        "gramps_ref": gramps_id,
                        # Handles never change; Gramps IDs can be
                        # renumbered. Older versions ignore this field.
                        "person_handle": region.person.get_handle(),
                        **area,
                        **clue_fields(region),
                    }
                )
            else:
                name = effective_placeholder_name(region)
                if not name and not getattr(region, "xmp_person", ""):
                    continue
                given, surname = split_placeholder_name(name)
                is_manual = getattr(region, "manual_name", None) is not None
                entries.append(
                    {
                        "name": name,
                        "given": given,
                        "surname": surname,
                        "type": getattr(region, "xmp_type", "Face"),
                        "source": SOURCE_MANUAL if is_manual else SOURCE_EMBEDDED,
                        **area,
                        **clue_fields(region),
                    }
                )
        if not entries:
            return ""
        return json.dumps({"schema": REGION_DATA_SCHEMA, "regions": entries})

    def persist_region_order(self, media=None):
        """
        Writes the current region cascade -- display order, confirmed
        Gramps links, and any still-unlinked embedded clues -- into
        the Media object's "PhotoTagging Regions" attribute (see
        REGION_DATA_ATTR_TYPE / serialize_region_data()) and commits
        it, if that text actually changed. Also removes any leftover
        pre-1.2.0 "PhotoTagging Order" attribute the first time this
        runs against a given photo, since the new attribute fully
        supersedes it (see get_stored_region_order()).
        """
        if media is None:
            media = self.get_current_object()
        if media is None:
            return
        new_text = self.serialize_region_data(self.regions)
        attr = get_region_data_attribute(media)
        legacy_attr = get_legacy_order_attribute(media)
        changed = False
        if attr is not None:
            if attr.get_value() != new_text:
                if new_text:
                    attr.set_value(new_text)
                else:
                    media.get_attribute_list().remove(attr)
                changed = True
        elif new_text:
            attr = Attribute()
            attr.set_type(REGION_DATA_ATTR_TYPE)
            attr.set_value(new_text)
            media.add_attribute(attr)
            changed = True
        if legacy_attr is not None:
            media.get_attribute_list().remove(legacy_attr)
            changed = True
        if changed:
            self.commit_media(media)
        if media.get_handle() == self._loaded_media_handle:
            self._loaded_region_data_text = new_text

    def scroll_to_selected_row(self):
        """
        Scrolls the list the minimum amount necessary to bring the
        selected row into view, doing nothing if it's already fully
        visible -- e.g. after selecting a region by clicking its
        marquee, moving the selection with Alt+Up/Down, or reordering
        the list. Deliberately not scroll_to_cell()'s own
        use_align=True/row_align=0.5 (forcibly recentering the row
        every time, regardless of whether it was already in view),
        which read as the list unpredictably sliding around on a
        click that didn't call for any scrolling at all -- and, for
        consistency, the same "only if out of view" rule
        scroll_marquee_into_view() applies to the Preview panel for
        the same selection.

        Deferred via GLib.idle_add: row geometry isn't necessarily up
        to date yet immediately after a selection or model change (the
        same reason gramps.gui.editors.displaytabs.embeddedlist.
        EmbeddedList's own _move_up()/_move_down() defer their
        scroll_to_cell() call the same way).
        """
        selection = self.treeview.get_selection()
        model, tree_iter = selection.get_selected()
        if tree_iter is None:
            return
        path = model.get_path(tree_iter)
        GLib.idle_add(self.treeview.scroll_to_cell, path, None, False)

    def scroll_marquee_into_view(self, region) -> None:
        """
        Scrolls the Preview panel the minimum amount necessary to
        bring `region`'s marquee into view, doing nothing if it's
        already fully visible -- the same "only if out of view" rule
        scroll_to_selected_row() applies to the region list's own row
        for the same selection (see its own docstring for why), so
        selecting a region by any means (a row, a marquee, or a
        Person link in the Caption panel -- see
        apply_selected_region(), which calls both) brings it into
        view consistently in both panels, never just one.

        SelectionWidget is itself a Gtk.ScrolledWindow around the
        image, so its own inherited get_hadjustment()/
        get_vadjustment() -- the same pair a plain Gtk.ScrolledWindow
        exposes for any child -- already carry everything needed to
        tell whether a given point is currently in view and, if not,
        the minimum scroll to bring it there.

        Deferred via GLib.idle_add, same as scroll_to_selected_row()
        and for the same reason: this gramplet's own top-level widget
        can be mid-hide/show (see main()) when a selection is applied,
        and the ScrolledWindow's adjustments aren't necessarily
        settled to its post-show geometry yet at that exact point.
        """
        GLib.idle_add(self._cb_scroll_marquee_into_view, region)

    def _cb_scroll_marquee_into_view(self, region) -> bool:
        """
        The deferred half of scroll_marquee_into_view() above.

        :returns: ``GLib.SOURCE_REMOVE``, so this one-shot idle
            callback is not called again.
        """
        hadjustment = self.selection_widget.get_hadjustment()
        vadjustment = self.selection_widget.get_vadjustment()
        if hadjustment is not None and vadjustment is not None:
            # A protected method, but already relied on the same way
            # elsewhere in this file (see _draw_region_id()): there is
            # no public equivalent, and it is exactly SelectionWidget's
            # own image-to-screen transform that its marquee frames
            # are themselves drawn with, so reusing it is what keeps
            # this in lockstep with where a region's marquee is
            # actually painted.
            x1, y1, x2, y2 = (
                self.selection_widget._rect_image_to_screen(  # pylint: disable=protected-access
                    region.coords()
                )
            )
            self._scroll_adjustment_into_view(hadjustment, x1, x2)
            self._scroll_adjustment_into_view(vadjustment, y1, y2)
        return GLib.SOURCE_REMOVE

    @staticmethod
    def _scroll_adjustment_into_view(
        adjustment: Gtk.Adjustment, start: int, end: int
    ) -> None:
        """
        Adjusts a single Gtk.Adjustment (see scroll_marquee_into_view())
        by the minimum amount needed so that the [start, end) range
        (in the adjustment's own units) is fully within its current
        [value, value + page_size) visible window -- doing nothing if
        it already is, and, for a range wider than the window itself,
        preferring to show its start over its end.
        """
        value = adjustment.get_value()
        page_size = adjustment.get_page_size()
        if start < value:
            adjustment.set_value(max(start, adjustment.get_lower()))
        elif end > value + page_size:
            adjustment.set_value(
                min(end - page_size, adjustment.get_upper() - page_size)
            )

    def find_drop_row(self, x, y):
        """
        Find the row index that a drag-and-drop at (x, y) targets: a
        drop above a row's own vertical centerline places it before
        that row, at or below the centerline places it after -- treating
        the result as a slot in the current (pre-move) list.

        (x, y) here are in treeview *widget* coordinates (including the
        column headers), as delivered by the drag_data_received signal.
        get_path_at_pos()/get_background_area() instead expect *bin
        window* coordinates -- the scrollable content area below the
        headers -- per their own docs, so they need converting first
        with convert_widget_to_bin_window_coords(). Skipping that
        conversion (as an earlier version of this method did) offsets
        every lookup downward by the header's height, silently
        returning no row (and so falling back to "append at the end")
        for any drop whose shifted position falls past the last row --
        which for a short list is effectively every drop, regardless of
        where it actually landed.

        Deliberately does not use Gtk.TreeView.get_dest_row_at_pos():
        in testing, its reported path was consistently one row earlier
        than the row actually under the given (bin-window) position --
        e.g. the vertical center of row 2 was reported as row 1 -- and
        it returned no result at all for the first row.
        """
        try:
            bin_x, bin_y = self.treeview.convert_widget_to_bin_window_coords(x, y)
            result = self.treeview.get_path_at_pos(bin_x, bin_y)
            if result is None:
                return len(self.regions)
            path, column, cell_x, cell_y = result
            index = path.get_indices()[0]
            rect = self.treeview.get_background_area(path, column)
            if bin_y < rect.y + rect.height / 2:
                return index
            return index + 1
        except Exception:
            # Never let a reorder drop silently do nothing because of
            # an unexpected exception here -- log it (so the exact
            # cause can be diagnosed) and fall back to appending at the
            # end, same as the plain "no row under the pointer" case
            # above.
            LOG.exception("find_drop_row failed for (x=%r, y=%r)", x, y)
            return len(self.regions)

    # ======================================================
    # utility functions for retrieving properties
    # ======================================================

    def get_current_handle(self):
        return self.get_active("Media")

    def get_current_object(self):
        # get_active() can return '' (e.g. no active Media, or the dummy
        # database with no tree open) -- looking that up directly logs a
        # "handle  does not exist" warning, so skip the lookup entirely.
        handle = self.get_current_handle()
        if not handle:
            return None
        try:
            return self.dbstate.db.get_media_from_handle(handle)
        except:
            return None

    # ======================================================
    # helpers for updating database objects
    # ======================================================

    def add_reference(self, person, rect):
        """
        Add a reference to the media object to the specified person.
        """
        mediaref = MediaRef()
        mediaref.ref = self.get_current_handle()
        # Whole numbers for Gramps; the precise box is kept in the
        # region's own pixel coords and persisted to the attribute
        # (see "Precise rectangles" near the top of this file).
        mediaref.set_rectangle(outward_int_rect(rect))
        person.add_media_reference(mediaref)
        self._order_dirty = True
        self.commit_person(person)
        return mediaref

    def remove_reference(self, person, mediaref):
        """
        Removes the reference to the media object from the person.
        """
        if mediaref in person.get_media_list():
            person.get_media_list().remove(mediaref)
            self.commit_person(person)

    def commit_person(self, person):
        """
        Save the modifications made to a Person object to the database.
        """
        with DbTxn("", self.dbstate.db) as trans:
            self.dbstate.db.commit_person(person, trans)
            msg = _("Edit Person (%s)") % name_displayer.display(person)
            trans.set_description(msg)

    def commit_media(self, media):
        """
        Save the modifications made to a Media object to the database.
        """
        with DbTxn("", self.dbstate.db) as trans:
            self.dbstate.db.commit_media(media, trans)
            trans.set_description(_("Edit Media Object"))

    # ======================================================
    # managing toolbar buttons
    # ======================================================
    def enable_buttons(self):
        selected = self._effective_selected_region()
        self.button_index.set_sensitive(selected is not None)
        self.button_add.set_sensitive(selected is not None)
        self.button_del.set_sensitive(
            selected is not None and selected.person is not None
        )
        self.button_clear.set_sensitive(selected is not None)
        self.button_edit.set_sensitive(
            selected is not None and selected.person is not None
        )
        index = self.regions.index(selected) if selected in self.regions else -1
        self.button_move_up.set_sensitive(index > 0)
        self.button_move_down.set_sensitive(
            index >= 0 and index < len(self.regions) - 1
        )
        self.button_zoom_in.set_sensitive(
            self.selection_widget.is_image_loaded()
            and self.selection_widget.can_zoom_in()
        )
        self.button_zoom_out.set_sensitive(
            self.selection_widget.is_image_loaded()
            and self.selection_widget.can_zoom_out()
        )
        self.button_detect.set_sensitive(
            self.selection_widget.is_image_loaded()
            and facedetection.computer_vision_available
        )
        self.button_quick_draw.set_sensitive(self.selection_widget.is_image_loaded())
        # Belt-and-suspenders against a stale-looking icon: the
        # sensitivity changes above are supposed to be enough on
        # their own -- Gtk normally redraws a button's icon dimmed or
        # not to match -- but that was observed not always keeping up
        # (e.g. right after drawing a new marquee, several buttons
        # that had just become valid still looked dimmed). Explicitly
        # queuing a redraw here costs nothing and guarantees each
        # icon's look actually matches the sensitivity just set,
        # regardless of what Gtk's own timing was doing.
        for button in (
            self.button_index,
            self.button_add,
            self.button_del,
            self.button_clear,
            self.button_edit,
            self.button_move_up,
            self.button_move_down,
            self.button_zoom_in,
            self.button_zoom_out,
            self.button_detect,
            self.button_quick_draw,
        ):
            button.queue_draw()

    # ======================================================
    # marquee visibility and ID overlay
    # ======================================================

    def sync_selection_widget_regions(self):
        """
        Give the SelectionWidget the region list to draw, respecting the
        current marquee show/hide state (it has no visibility flag of its
        own, so hiding is done by handing it an empty list).
        """
        self.selection_widget.set_regions(self.regions if self.marquees_visible else [])

    def show_marquees(self):
        """
        Force the marquees back to visible, e.g. after selecting a row or
        drawing a new region.
        """
        if self.button_marquees.get_active():
            self.button_marquees.set_active(False)

    def marquees_toggled(self, button):
        self.marquees_visible = not button.get_active()
        self.update_marquees_button()
        if not self.marquees_visible:
            # SelectionWidget draws the single actively-selected region
            # (with shading) regardless of its own regions list whenever
            # something is selected -- see sync_selection_widget_regions()
            # -- so hiding the marquees while a row/region is selected
            # has to also clear that selection, or its one box stays
            # visible no matter what regions we hand the widget.
            self.selection_widget.clear_selection()
            self.treeview.get_selection().unselect_all()
        self.sync_selection_widget_regions()
        self.selection_widget.refresh()
        self.enable_buttons()

    def metadata_clues_toggled(self, button):
        """
        Shows or hides the "Metadata clues" column. Like
        marquees_toggled(), active means "hidden": the button is
        pressed/highlighted only in the non-default state.
        """
        self.metadata_clues_visible = not button.get_active()
        self.column_metadata_clues.set_visible(self.metadata_clues_visible)
        self.column_pipe_icon.set_visible(self.metadata_clues_visible)
        self.update_metadata_clues_button()

    def update_metadata_clues_button(self):
        """
        Updates the "Metadata clues" toggle button's tooltip to
        reflect its current Hide/Show state, matching the pattern
        used by update_marquees_button()/update_show_ids_button().
        """
        if self.metadata_clues_visible:
            tooltip = _("Hide the Metadata clues column")
        else:
            tooltip = _("Show the Metadata clues column")
        self.button_metadata_clues.set_tooltip_text(tooltip)

    # ======================================================
    # Caption panel
    # ======================================================

    def refresh_caption(self) -> None:
        """
        Re-reads the active Media object's first Caption-type Note
        (see find_caption_note()) and updates the Caption panel/
        button to match: called from main() on every refresh (Media
        switched, or any db signal main() is connected to), and from
        cb_note_changed() specifically for Note signals.
        """
        media = self.get_current_object()
        note = find_caption_note(media, self.dbstate.db)
        self.caption_note_exists = note is not None
        if note is not None:
            self.caption_editor.set_text(note.get_styledtext())
        else:
            self.caption_editor.set_text(StyledText())
        self.update_caption_button()
        self.update_caption_panel_visibility()
        # set_text() above just replaced the panel's content outright,
        # discarding whatever range was highlighted in the old text
        # (see CaptionTextEditor.highlight_person()) -- reapply it for
        # whichever region is currently selected, rather than letting
        # it silently vanish until the selection itself next changes.
        self.sync_caption_highlight()

    def sync_caption_highlight(self) -> None:
        """
        Re-applies the Caption panel's highlight for whichever person
        the region list/marquee currently have selected (see
        apply_selected_region()) -- called after refresh_caption()
        replaces the panel's text outright.
        """
        current = self._effective_selected_region()
        person = current.person if current is not None else None
        self.caption_editor.highlight_person(person.get_handle() if person else None)

    def edit_caption_note(self) -> None:
        """
        Opens the Note editor for the Caption Note currently shown in
        the Caption panel -- the action for a double click on
        unlinked space there (see
        CaptionTextEditor.on_button_press_event()). Does nothing if
        there is currently no Caption Note (the panel is hidden and
        dimmed in that case anyway, so there is nothing to
        double-click on).

        Re-reads the Note fresh via find_caption_note() rather than
        keeping a cached reference from refresh_caption(), the same
        reasoning cb_note_changed() already relies on: it's always
        the current one, and simpler than keeping a second copy of
        the same state in sync.
        """
        media = self.get_current_object()
        note = find_caption_note(media, self.dbstate.db)
        if note is None:
            return
        try:
            EditNote(self.dbstate, self.uistate, self.track, note)
        except WindowActiveError:
            pass

    def _click_is_in_preview_gutter(self, x, y) -> bool:
        """
        Whether (x, y) -- in the Preview panel's own event_box
        coordinates, as delivered by its "button-press-event"/
        "button-release-event" signals -- falls outside the actual
        displayed image: the letterboxed "dead space"/gutter left and
        right, or top and bottom, that appears whenever the panel's
        own allocated size doesn't match the image's aspect ratio
        (a wide panel around a tall image, or vice versa).

        self.selection_widget.proportional_to_real_rect((0, 0, 100,
        100)) -- the same call get_xmp_keyword_regions() already uses
        to place a whole-image region -- gives exactly this: the
        image's own displayed rectangle, in real (event-box)
        coordinates, regardless of the panel's current size or the
        image's rotation/zoom, since 0-100 proportional space is
        defined as spanning the full image, gutters excluded, no
        matter how it's currently being shown.

        :param x: Event x, in the Preview panel's event_box coordinates.
        :param y: Event y, in the Preview panel's event_box coordinates.
        :returns: True if (x, y) is outside the displayed image.
        """
        left, top, right, bottom = self.selection_widget.proportional_to_real_rect(
            (0, 0, 100, 100)
        )
        return not (left <= x <= right and top <= y <= bottom)

    def cb_preview_panel_button_release(
        self, widget: Gtk.Widget, event: Gdk.EventButton
    ) -> bool:
        """
        Callback for the Preview panel's own event_box "button-
        release-event" (connected in build_gui(), on top of whatever
        SelectionWidget already does with the same event internally
        for drawing/selecting marquees, which -- being connected
        first -- has already run, and already updated get_current()
        to the final outcome of this click, by the time this does --
        see build_gui()'s own comment on why this is a "button-
        release-event" handler, not a "button-press-event" one).
        Handles every plain (button 1) click here, split by what it
        landed on and whether it's a single or double click:

        - Double click *on* a marquee: acts exactly like
          double-clicking that marquee's own region list row (see
          row_activated()/edit_person_clicked()) -- opens Edit Person
          if one is tagged there, otherwise does nothing, the same as
          the row's own double-click would.
        - Single click on non-marquee ("mask"/dimmed) space:
          SelectionWidget's own handling of this same click already
          cleared its selection (get_current() is None here) -- this
          restores it (see self._last_selected_region), making a
          single click here a no-op from the person's perspective,
          rather than silently dropping the selection.
        - Double click on non-marquee space: confirms that clear (it
          stays cleared) and additionally opens the Media object
          editor for the active Media (see edit_media_clicked()).
        - Any click that lands outside the displayed image entirely --
          the letterboxed "dead space"/gutter left/right or top/bottom
          whenever the panel's own allocated size doesn't match the
          image's aspect ratio (see _click_is_in_preview_gutter()) --
          is treated as equivalent to clicking the Show/Hide face
          marquees toolbar button, single or double click alike, and
          none of the above applies: there's no marquee, no image
          content, and no Media object under a gutter click for any of
          those cases to act on anyway.

        Unlike a GDK_2BUTTON_PRESS event's type (unusable here -- see
        build_gui()'s own comment), there is no equivalent "this was
        the second release of a double click" event type at all, so a
        double click is instead recognized the same way
        cb_caption_button_toggled() already recognizes one: by
        elapsed time and distance since the previous release, against
        the desktop's own configured double-click thresholds -- the
        same two Gdk itself uses to recognize one.

        :param widget: This editor (unused; provided by the signal).
        :param event: The Gdk.EventButton for the release.
        :returns: ``False`` always, to let SelectionWidget's own
            handling of the same event proceed unaffected.
        """
        if event.button != 1:
            return False
        self._log_marquee_debug(
            "button-release at screen (%.1f, %.1f)" % (event.x, event.y),
            self.selection_widget.get_current(),
        )
        if self._release_ended_drag:
            # This release finished drawing or resizing a marquee (see
            # _release_ended_drag in __init__). Without this check it
            # was treated as a click on empty space: the old selection
            # was restored over the new marquee -- even one remembered
            # from a previous photo, drawn at that photo's coordinates
            # -- and a drag ending in the gutter toggled the marquees.
            self._release_ended_drag = False
            self._preview_last_release_us = 0
            return False
        if self._click_is_in_preview_gutter(event.x, event.y):
            self.button_marquees.set_active(not self.button_marquees.get_active())
            return False
        now = GLib.get_monotonic_time()
        settings = Gtk.Settings.get_default()
        interval_us = settings.get_property("gtk-double-click-time") * 1000
        distance = settings.get_property("gtk-double-click-distance")
        last_x, last_y = self._preview_last_release_pos
        is_double_click = (
            (now - self._preview_last_release_us) <= interval_us
            and abs(event.x - last_x) <= distance
            and abs(event.y - last_y) <= distance
        )
        self._preview_last_release_us = now
        self._preview_last_release_pos = (event.x, event.y)

        region = self.selection_widget.get_current()
        if region is not None:
            # Landed on a marquee -- SelectionWidget's own handling,
            # and region_selected() (for a single click), already
            # cover selecting it; only the double-click case needs
            # anything further here. `region` is passed through as
            # edit_person_clicked()'s own sanity check on what it's
            # about to open an editor for -- see its own docstring.
            if is_double_click:
                self.edit_person_clicked(None, region)
            return False

        # Landed on non-marquee ("mask"/dimmed) space.
        if is_double_click:
            self.apply_selected_region(None)
            self.edit_media_clicked(None)
        elif self._last_selected_region in self.regions:
            # Only a region that is still part of this photo -- never a
            # leftover from a previous photo or a reload.
            self.apply_selected_region(self._last_selected_region)
        return False

    def edit_media_clicked(self, event) -> None:
        """
        Opens the Media object editor for the active Media object --
        the action for a double click on non-marquee space in the
        Preview panel (see cb_preview_panel_button_release()). Does
        nothing if there is no active Media, or if it already has an
        editor open (e.g. from a previous double click landing on
        mask space again before that one was closed).
        """
        media = self.get_current_object()
        if media is None:
            return
        try:
            EditObject(
                self.dbstate,
                self.uistate,
                self.track,
                "Media",
                "handle",
                media.get_handle(),
            )
        except WindowActiveError:
            pass

    def update_caption_panel_visibility(self) -> None:
        """
        Shows or hides the Caption panel to match caption_panel_visible
        -- except there is never anything to show without a Caption
        Note at all, regardless of that flag.

        Native Gtk.Paned does not reclaim a hidden child's share of
        the space on its own -- the divider itself would otherwise
        stay right where it was, still draggable, with the Caption
        panel just an empty strip below it -- so hiding additionally
        pushes the divider all the way down (giving the Preview panel
        the freed height), and showing restores it to the last known
        Preview:Caption split (see _caption_split_ratio). Both are
        done through the same lock cb_left_pane_size_allocate() uses,
        so this repositioning is never mistaken for the person having
        dragged the handle to a new ratio (see
        cb_left_pane_position_changed()).
        """
        show = self.caption_panel_visible and self.caption_note_exists
        if show:
            self.caption_scrolled_window.show_all()
        else:
            self.caption_scrolled_window.hide()
        if not self._left_pane_last_height:
            return
        self._caption_split_ratio_lock = True
        try:
            if show:
                position = round(
                    self._left_pane_last_height * self._caption_split_ratio
                )
            else:
                position = self._left_pane_last_height
            self.left_pane.set_position(position)
        finally:
            self._caption_split_ratio_lock = False

    def update_caption_button(self) -> None:
        """
        Updates the Show/Hide Caption toggle button's tooltip and
        dimmed appearance to reflect whether the active Media has a
        Caption Note at all, and -- when it does -- the panel's
        current Show/Hide state, matching the pattern used by
        update_marquees_button()/update_metadata_clues_button().
        """
        if not self.caption_note_exists:
            tooltip = _(
                "No Caption note for this media "
                "(double-click to create one from the region list)"
            )
        elif self.caption_panel_visible:
            tooltip = _("Hide the Caption panel")
        else:
            tooltip = _("Show the Caption panel")
        self.button_caption.set_tooltip_text(tooltip)
        self.set_caption_button_dimmed(not self.caption_note_exists)

    def set_caption_button_dimmed(self, dimmed: bool) -> None:
        """
        Gives the Caption button's icon a dimmed appearance without
        actually disabling the button itself (see the comment on
        self.button_caption in build_gui() for why it stays
        sensitive): applies GTK's own INSENSITIVE state flag -- the
        same visual state a themed icon renders when its widget really
        is insensitive -- to just the icon widget.

        :param dimmed: bool
        """
        icon_widget = self.button_caption.get_icon_widget()
        if icon_widget is None:
            return
        if dimmed:
            icon_widget.set_state_flags(Gtk.StateFlags.INSENSITIVE, False)
        else:
            icon_widget.unset_state_flags(Gtk.StateFlags.INSENSITIVE)

    def cb_caption_button_toggled(self, button: Gtk.ToggleToolButton) -> None:
        """
        Callback for the Caption toggle button's "toggled" signal.

        A Gtk.ToggleToolButton fires "toggled" on every click,
        including both halves of a double-click -- which, being a
        toggle, leaves button.get_active() right back where it
        started. That quirk is used deliberately here: when there is
        no Caption Note to show at all (the button is dimmed), a
        single click has nothing useful left to toggle, so it is
        simply ignored rather than flipping caption_panel_visible for
        no visible effect; a double click -- this handler firing
        twice within the desktop's own configured double-click
        interval -- is instead treated as a request to create one,
        via the same action as the "Transcribe list to a Note"
        context menu item (which now always creates a Caption-type
        Note; see transcribe_list_to_note_clicked()).
        """
        now = GLib.get_monotonic_time()
        interval_us = (
            Gtk.Settings.get_default().get_property("gtk-double-click-time") * 1000
        )
        is_double_click = (now - self._caption_last_toggle_us) <= interval_us
        self._caption_last_toggle_us = now

        if not self.caption_note_exists:
            if is_double_click:
                self.transcribe_list_to_note_clicked(None)
            return

        self.caption_panel_visible = not button.get_active()
        self.update_caption_button()
        self.update_caption_panel_visibility()

    def select_person_in_list(self, person_handle: str) -> None:
        """
        Selects -- everywhere: the region list row, the marquee, and
        the Caption panel's own highlight (see
        apply_selected_region()) -- the region tagged with the Person
        identified by `person_handle`, if one of the currently listed
        regions is tagged with them. This is the action for a plain
        click on a Person link inside the Caption panel (see
        CaptionTextEditor.on_button_press_event()). Does nothing if
        no region names that person.

        :param person_handle: Handle of the Person to search for.
        """
        for region in self.regions:
            if (
                region.person is not None
                and region.person.get_handle() == person_handle
            ):
                self._leave_quick_draw()
                self.apply_selected_region(region)
                return

    def apply_selected_region(self, region) -> None:
        """
        The single place responsible for keeping the region list's
        row selection, the image's marquee highlight, and the
        Caption panel's matching linked text all showing the same
        selection at once -- called any time that selection changes,
        regardless of which of the three the person actually
        interacted with (a row, a marquee, or a Person link in the
        Caption panel).

        Guarded against re-entrancy (self._syncing_selection):
        set_cursor() below can itself synchronously re-trigger
        cursor_changed(), which would otherwise call straight back in
        here for no further effect.

        :param region: The Region to select everywhere, or ``None``
            to clear the selection everywhere.
        """
        if self._syncing_selection:
            return
        self._syncing_selection = True
        try:
            if region is not None:
                self._last_selected_region = region
                self._selected_region_coords = region.coords()
            if region is not None and region in self.regions:
                path = Gtk.TreePath.new_from_indices([self.regions.index(region)])
                self.treeview.set_cursor(path)
                self.scroll_to_selected_row()
            else:
                self.treeview.get_selection().unselect_all()
            # Skipped when SelectionWidget already has this exact
            # region current (e.g. this call originated from its own
            # "region-selected" signal, which fires only after it has
            # already updated its own selection internally):
            # select()ing the same region again is pure overhead that
            # can only ever add a redundant clear-then-redraw pass on
            # top of whatever transition SelectionWidget's own click
            # handling just painted, which was observed as a visible
            # flash when switching directly between two marquees.
            if self.selection_widget.get_current() is not region:
                self.selection_widget.select(region)
            if region is not None:
                self.show_marquees()
                self.scroll_marquee_into_view(region)
            self.caption_editor.highlight_person(
                region.person.get_handle()
                if region is not None and region.person is not None
                else None
            )
            # Matches the existing "Make the person active" context
            # menu item's own effect (see set_active_person()), just
            # applied automatically on every selection change rather
            # than only when explicitly asked for. Deliberately not
            # cleared back to no active person when region is None or
            # unlinked -- elsewhere in Gramps, the active person is
            # expected to persist until something else takes over, not
            # blank out just because this gramplet's own selection
            # moved off a tagged region.
            if region is not None and region.person is not None:
                self.set_active("Person", region.person.get_handle())
        finally:
            self._syncing_selection = False
        self.enable_buttons()

    def cb_left_pane_size_allocate(
        self, paned: Gtk.Paned, allocation: Gdk.Rectangle
    ) -> None:
        """
        Rescales the draggable split between the Preview (image) and
        Caption panels to preserve their current proportion --
        whatever the person last dragged it to, defaulting to
        CAPTION_SPLIT_INITIAL_RATIO the first time -- as the
        gramplet's docked height, or its floating window, is resized.
        Native Gtk.Paned has no percentage-split notion of its own:
        left alone, it holds one side to a fixed pixel size and lets
        the other absorb the entire change, which this corrects for.

        Guarded to only act when left_pane's own total allocated
        height has actually changed since the last call -- this
        handler is also (harmlessly) re-entered by the very
        set_position() call it makes below, and would otherwise also
        fire on every unrelated size-allocate (e.g. a horizontal-only
        resize, or the divider itself being dragged).
        """
        total = allocation.height
        if total <= 1 or total == self._left_pane_last_height:
            return
        self._left_pane_last_height = total
        self._caption_split_ratio_lock = True
        try:
            paned.set_position(round(total * self._caption_split_ratio))
        finally:
            self._caption_split_ratio_lock = False

    def cb_left_pane_position_changed(
        self, paned: Gtk.Paned, gparam: GObject.ParamSpec
    ) -> None:
        """
        Tracks the current Preview:Caption split ratio whenever the
        person drags the handle themselves, so
        cb_left_pane_size_allocate() above preserves *that*
        proportion on a later resize, instead of resetting back to
        CAPTION_SPLIT_INITIAL_RATIO every time.

        Ignored while cb_left_pane_size_allocate() itself is the one
        moving the handle (see self._caption_split_ratio_lock): that
        is an existing ratio being reapplied after a resize, not a
        new one being set.
        """
        if self._caption_split_ratio_lock:
            return
        total = self._left_pane_last_height
        if not total:
            return
        self._caption_split_ratio = paned.get_position() / total

    def update_marquees_button(self):
        if self.marquees_visible:
            names = ["view-reveal-symbolic", Gtk.STOCK_INDEX]
            tooltip = _("Hide face marquees")
        else:
            names = ["view-conceal-symbolic", "process-stop", Gtk.STOCK_CLEAR]
            tooltip = _("Show face marquees")
        set_toolbar_icon(self.button_marquees, names)
        self.button_marquees.set_tooltip_text(tooltip)

    def quick_draw_toggled(self, button):
        """
        Toggles "quick draw" mode. Only reachable at all when computer
        vision isn't available (see build_gui(), where button_
        quick_draw takes button_detect's place in the toolbar in that
        case) -- this is a substitute workflow for the same underlying
        need automated face detection would otherwise serve: quickly
        turning blank space in the photo into several ready-to-name
        placeholder marquees, one right after another, rather than one
        at a time with something else demanding attention in between
        each one.

        While active:

        - region_created() skips its own automatic show_context_menu()
          call after each newly drawn marquee (see its own docstring),
          so several marquees can be drawn back to back with nothing
          popping up in the way of the next one's starting corner.
        - Every existing marquee is forced visible, with the Row ID
          overlay forced on too (see draw_ids_overlay()), regardless
          of whatever the Show/Hide marquees and Show ID toolbar
          buttons were separately set to -- the point of drawing
          several new placeholders in one pass is seeing exactly which
          faces are already tagged, and in what order, while doing it.
          Both are restored to whatever they were actually set to the
          moment this mode is turned back off, via
          self._pre_quick_draw_marquees_visible/_id_display_mode --
          not simply flipped back to their own defaults, in case the
          person had them set to something else already (e.g.
          marquees already hidden, or the Gramps ID overlay already
          selected) before turning this mode on.
        - The region list's own row selection still tracks the last
          drawn (or otherwise most recently affected) marquee, same as
          always (see region_created()) -- but, deliberately, without
          also selecting it on the image itself (see
          _focus_treeview_row_only()): marquees_toggled()'s own
          docstring already explains why -- SelectionWidget draws only
          the single actively-selected region, dropping every other
          one from its own regions list, the instant anything is
          selected on it. Showing every marquee at once and having the
          list track the newest one are only both possible together by
          keeping SelectionWidget's own "current" region out of it
          entirely while this mode is on.

        Turning the Show/Hide marquees button on or off by hand while
        this mode is active overrides the forced-visible state for as
        long as this mode stays on (there's nothing here reconciling
        the two) -- exiting this mode afterward still restores
        whatever marquees_visible was before this mode was entered,
        not whatever it was left at by that manual click.
        """
        self.quick_draw_mode = button.get_active()
        if self.quick_draw_mode:
            self._pre_quick_draw_marquees_visible = self.marquees_visible
            self._pre_quick_draw_id_display_mode = self.id_display_mode
            self.marquees_visible = True
            self.id_display_mode = ID_MODE_ROW
            # Whatever was already selected on the image right now
            # (from before this mode was turned on) would otherwise
            # keep SelectionWidget narrowed to that one region alone
            # until the next redraw event happened to clear it - see
            # this method's own docstring, and _focus_treeview_row_
            # only()'s, for why this mode keeps it cleared throughout.
            self.selection_widget.clear_selection()
        else:
            if self._pre_quick_draw_marquees_visible is not None:
                self.marquees_visible = self._pre_quick_draw_marquees_visible
            if self._pre_quick_draw_id_display_mode is not None:
                self.id_display_mode = self._pre_quick_draw_id_display_mode
            self._pre_quick_draw_marquees_visible = None
            self._pre_quick_draw_id_display_mode = None
            # Re-sync the on-image selection and Caption highlight
            # (deliberately left out of step with the list's own row
            # selection for as long as this mode was on) to whichever
            # row the list actually ended up on.
            model, tree_iter = self.treeview.get_selection().get_selected()
            if tree_iter is not None:
                index = model.get_path(tree_iter).get_indices()[0]
                if 0 <= index < len(self.regions):
                    self.apply_selected_region(self.regions[index])
        self.update_quick_draw_button()
        self.update_marquees_button()
        self.update_show_ids_button()
        self.sync_selection_widget_regions()
        self.selection_widget.refresh()

    def _set_quick_draw_for_loaded_photo(self) -> None:
        """
        Called once each time a different photo is loaded: Quick Draw
        mode is switched on only for a photo with nothing on it yet --
        no linked people, no saved placeholders, and no clues read
        from its metadata -- and off for any photo that already has
        marquees, where selecting and reviewing them is the more
        likely task.

        The list selection is cleared first: turning the mode off
        re-applies whichever row is selected (see
        quick_draw_toggled()), and at this point that would still be
        a row index from the previous photo.
        """
        want = not self.regions
        if self.button_quick_draw.get_active() == want:
            return
        self.treeview.get_selection().unselect_all()
        self.button_quick_draw.set_active(want)

    def _leave_quick_draw(self) -> None:
        """
        Switches Quick Draw mode off, if it is on -- used when the
        person selects a specific marquee from the list or the
        Caption panel, which means reviewing rather than drawing.
        """
        if self.button_quick_draw.get_active():
            self.button_quick_draw.set_active(False)

    def update_quick_draw_button(self):
        if self.quick_draw_mode:
            tooltip = _(
                "Quick draw mode: on -- draw several marquees in a row "
                "with no popup in between (click to turn off)"
            )
        else:
            tooltip = _(
                "Quick draw mode: off -- draw several marquees in a "
                "row with no popup in between (click to turn on)"
            )
        self.button_quick_draw.set_tooltip_text(tooltip)

    def show_ids_clicked(self, button):
        """
        Cycles the ID-in-face-box display through its 3 states on each
        click: Row ID (default) -> Gramps ID -> hidden -> Row ID ...
        """
        idx = ID_MODE_ORDER.index(self.id_display_mode)
        self.id_display_mode = ID_MODE_ORDER[(idx + 1) % len(ID_MODE_ORDER)]
        self.update_show_ids_button()
        self.show_marquees()
        self.selection_widget.refresh()

    def update_show_ids_button(self):
        if self.id_display_mode == ID_MODE_HIDDEN:
            names = ["user-offline", "process-stop", Gtk.STOCK_CLEAR]
            tooltip = _("Face marquee ID: hidden (click for Row ID)")
        else:
            # Row ID and Gramps ID share the same icon; only the tooltip
            # differs, since both are "on" states.
            names = ["user-idle", Gtk.STOCK_INDEX]
            if self.id_display_mode == ID_MODE_ROW:
                tooltip = _("Face marquee ID: Row ID (click for Person ID)")
            else:
                tooltip = _("Face marquee ID: Person ID (click to hide)")
        set_toolbar_icon(self.button_show_ids, names)
        self.button_show_ids.set_tooltip_text(tooltip)

    def draw_ids_overlay(self, widget, cr):
        """
        Draws the row number or Gramps ID of each tagged person on top of
        whatever SelectionWidget has already drawn, mirroring exactly
        which region(s) it drew: either the single active selection (with
        shading), or all regions when nothing is selected.

        No special case for quick_draw_toggled()'s quick draw mode is
        needed here at all: that mode already forces marquees_visible
        (so SelectionWidget is handed every region, not an empty list)
        and keeps its own "current" selection cleared throughout (see
        _focus_treeview_row_only()) -- which is exactly the same
        "nothing selected" state the plain Show/Hide marquees button
        already relies on to show every marquee with no dimming, the
        same way it always has. An earlier revision of this method
        added its own separate rectangle-drawing here specifically for
        quick draw mode, on the (wrong) assumption that clearing the
        selection wasn't enough on its own to reach that branch -- it
        was, and drawing a second, redundant rectangle over
        SelectionWidget's own for the same region was the entire cause
        of the doubled, all-blue border reported against it (the
        boxes were never missing to begin with).
        """
        if self.id_display_mode == ID_MODE_HIDDEN:
            return
        selwidget = self.selection_widget
        if not selwidget.pixbuf:
            return
        if selwidget.selection and selwidget.current is not None:
            self._draw_region_id(cr, selwidget.current)
        elif not selwidget.selection:
            for region in selwidget.regions:
                self._draw_region_id(cr, region)

    def _draw_region_id(self, cr, region):
        if self.id_display_mode == ID_MODE_GRAMPS:
            person = region.person
            if not person:
                return
            text = person.get_gramps_id()
            if not text:
                return
            font_size = 12
        else:
            # ID_MODE_ROW: the same 1-based number shown in the list's
            # first column. It's normally just 1-2 digits, so it can
            # afford to be drawn twice as large as the Gramps ID text.
            if region not in self.regions:
                return
            text = str(self.regions.index(region) + 1)
            font_size = 24

        # Reuses SelectionWidget's own (private) image-to-screen transform
        # so the label lines up exactly with the frame it draws for the
        # same region.
        x1, y1, x2, y2 = self.selection_widget._rect_image_to_screen(region.coords())
        cr.save()
        cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
        cr.set_font_size(font_size)

        # A white plate behind the text keeps MARQUEE_BLUE legible
        # against any part of the photo.
        pad = 2
        extents = cr.text_extents(text)
        box_x = x1 + 2
        box_y = y1 + 2
        cr.set_source_rgb(1.0, 1.0, 1.0)
        cr.rectangle(
            box_x - pad, box_y - pad, extents.width + 2 * pad, extents.height + 2 * pad
        )
        cr.fill()

        cr.set_source_rgb(*MARQUEE_BLUE)
        cr.move_to(box_x - extents.x_bearing, box_y - extents.y_bearing)
        cr.show_text(text)
        cr.restore()

    # ======================================================
    # managing context menu buttons
    # ======================================================

    def _effective_selected_region(self):
        """
        The region a toolbar button, context-menu item, or menu-driven
        action should act on: SelectionWidget's own "current" region
        normally, or -- since quick_draw_toggled()'s quick draw mode
        deliberately leaves that cleared throughout (see
        _focus_treeview_row_only()'s own docstring) -- whichever row
        the region list itself currently has focused.

        Without this fallback, every action that reads self.selection_
        widget.get_current() directly to decide what to act on (the
        toolbar's Add/Delete/Clear/Edit/Move buttons via
        enable_buttons(), the context menu's equivalent items via
        prepare_context_menu(), and the click handlers behind all of
        them -- add_person_clicked(), sel_person_clicked(),
        clear_ref_clicked(), del_region_clicked(), move_up_clicked(),
        move_down_clicked(), set_active_person(), replace_reference())
        stayed permanently disabled -- or, for a handler not gated by
        a sensitivity check first, silently did nothing at all -- for
        as long as quick draw mode was on, regardless of which row was
        actually focused in the list. The whole point of that mode is
        that nothing is ever "selected" on the image; a row can still
        be clearly focused in the list, and every one of these should
        still be able to act on it.

        Deliberately NOT used by region_modified(), apply_selected_
        region(), refresh_selection(), or the drag-and-drop handlers
        that check SelectionWidget's own current selection to avoid
        an ambiguous drop target -- those are all specifically about
        SelectionWidget's own literal state, not "whatever the user
        probably means by 'the selected row' right now", and using
        this fallback in any of them would be wrong.

        SelectionWidget's "current" region is only trusted while it is
        still one of self.regions: load_image() rebuilds every Region
        object on a reload, but SelectionWidget.set_regions() does not
        reset its own current region, so it can still point at a stale
        Region from before the reload. In quick draw mode the focused
        list row is checked first, since cursor_changed() deliberately
        does not push row clicks to SelectionWidget in that mode -- a
        right-clicked row would otherwise lose to a stale or unrelated
        image selection (the cause of a "list.remove(x): x not in list"
        crash in prepare_context_menu()).

        :returns: A Region, or None if nothing is meaningfully
            selected either way.
        """
        current = self.selection_widget.get_current()
        if current is not None and current not in self.regions:
            current = None
        row_region = None
        model, tree_iter = self.treeview.get_selection().get_selected()
        if tree_iter is not None:
            index = model.get_path(tree_iter).get_indices()[0]
            if 0 <= index < len(self.regions):
                row_region = self.regions[index]
        if self.quick_draw_mode:
            return row_region if row_region is not None else current
        return current if current is not None else row_region

    def cb_edit_ancestor_families(self, _menu_item) -> None:
        """
        "See ancestor family details": opens a Family editor for every
        family the selected person is a child in (birth, adoptive, and
        any other parent family), in the order Gramps lists them.

        :param _menu_item: unused (the context-menu item itself)
        """
        region = self._effective_selected_region()
        if region is None or region.person is None:
            return
        self._edit_families(region.person.get_parent_family_handle_list())

    def cb_edit_descendant_families(self, _menu_item) -> None:
        """
        "See descendant family details": opens a Family editor for
        every family the selected person is a parent/spouse in (one
        per spouse or partnership), in the order Gramps lists them.

        :param _menu_item: unused (the context-menu item itself)
        """
        region = self._effective_selected_region()
        if region is None or region.person is None:
            return
        self._edit_families(region.person.get_family_handle_list())

    def _edit_families(self, family_handles) -> None:
        """
        Opens a Family editor for each handle in `family_handles`. A
        family whose editor is already open is skipped (Gramps raises
        WindowActiveError and brings that window forward instead).

        :param family_handles: A list of Family handles.
        """
        for handle in family_handles:
            family = self.dbstate.db.get_family_from_handle(handle)
            if family is None:
                continue
            try:
                EditFamily(self.dbstate, self.uistate, self.track, family)
            except WindowActiveError:
                pass

    def prepare_context_menu(self):
        selected = self._effective_selected_region()
        has_person = selected is not None and selected.person is not None

        self.context_button_details.set_sensitive(has_person)
        self.context_button_ancestor_family.set_sensitive(
            has_person and bool(selected.person.get_parent_family_handle_list())
        )
        self.context_button_descendant_family.set_sensitive(
            has_person and bool(selected.person.get_family_handle_list())
        )
        self.context_button_active.set_sensitive(has_person)
        self.context_button_add.set_sensitive(selected is not None)
        self.context_button_select.set_sensitive(selected is not None)
        self.context_button_clear.set_sensitive(has_person)
        self.context_button_fuzzy_lookup.set_sensitive(selected is not None)
        self.context_button_remove.set_sensitive(selected is not None)
        index = self.regions.index(selected) if selected in self.regions else -1
        self.context_button_move_up.set_sensitive(index > 0)
        self.context_button_move_down.set_sensitive(
            index >= 0 and index < len(self.regions) - 1
        )
        self.context_button_transcribe.set_sensitive(
            self.get_current_object() is not None and bool(self.regions)
        )

        # clear temporary items
        for item in self.additional_items:
            self.context_menu.remove(item)

        self.additional_items = []

        # populate the context menu
        # Compared by handle, not by object: the same Person can be
        # held as two different Python objects (e.g. one fetched before
        # a reload, one after), and list.remove() raised ValueError
        # when they were not the identical object.
        persons = self.all_referenced_persons()
        if selected is not None and selected.person is not None:
            selected_handle = selected.person.get_handle()
            persons = [p for p in persons if p.get_handle() != selected_handle]
        if persons:
            media = self.get_current_object()
            name_as_of_date = self.name_as_of_date_for(media)

            def display_name_for(person):
                return display_name_respecting_format(
                    get_name_at_date(person, name_as_of_date)
                )

            self.additional_items.append(Gtk.SeparatorMenuItem())
            sorted_persons = sorted(list(persons), key=display_name_for)
            for person in sorted_persons:
                item = Gtk.MenuItem(_("Swap with {0}").format(display_name_for(person)))
                item.connect("activate", self.replace_reference, person)
                self.additional_items.append(item)
            for item in self.additional_items:
                self.context_menu.append(item)

    def show_context_menu(self):
        """
        Show popup menu using different functions according to Gtk version.
        'Gtk.Menu.popup' is deprecated since version 3.22, see:
        https://lazka.github.io/pgi-docs/index.html#Gtk-3.0/classes/Menu.html#Gtk.Menu.popup
        """
        self.prepare_context_menu()
        self.context_menu.show_all()
        if (Gtk.MAJOR_VERSION >= 3) and (Gtk.MINOR_VERSION >= 22):
            self.context_menu.popup_at_pointer(None)
        else:
            self.context_menu.popup(None, None, None, None, 0, 0)

    # ======================================================
    # selection event handlers
    # ======================================================

    def _log_marquee_debug(self, what, region) -> None:
        """
        TEMPORARY diagnostic for the "mirrored big box" report -- see
        DEBUG_MARQUEE_DRAW. Logs the SelectionWidget's drawing state
        so one bad draw shows which number goes wrong: the drag start
        point (screen), the selection being built (image pixels), the
        region's resulting coords, and the scale/size values used to
        convert between them.

        :param what: Which event this is, for the log line.
        :param region: The Region involved, or None.
        """
        if not DEBUG_MARQUEE_DRAW:
            return
        widget = self.selection_widget
        try:
            alloc = widget.get_allocation()
            LOG.warning(
                "PhotoTagging draw-debug: %s | start_screen=%s selection=%s "
                "region=%s | scale=%s scaled_size=%s original_size=%s "
                "viewport=%dx%d event_box=%dx%d | rotation=%s quick_draw=%s "
                "session=%s",
                what,
                widget.start_point_screen,
                widget.selection,
                region.coords() if region is not None else None,
                getattr(widget, "scale", None),
                getattr(widget, "scaled_size", None),
                getattr(widget, "original_image_size", None),
                alloc.width,
                alloc.height,
                widget.event_box.get_allocated_width(),
                widget.event_box.get_allocated_height(),
                self.rotation_degrees,
                self.quick_draw_mode,
                os.environ.get("XDG_SESSION_TYPE", "?"),
            )
        except Exception:  # pylint: disable=broad-except
            LOG.exception("PhotoTagging draw-debug: logging failed")

    def region_modified(self, sender):
        region = self.selection_widget.get_current()
        self._release_ended_drag = True
        self._log_marquee_debug("region-modified", region)
        if (
            region.x2 - region.x1 < MIN_MARQUEE_SIZE
            or region.y2 - region.y1 < MIN_MARQUEE_SIZE
        ):
            # A resize that collapses the marquee below a sane size
            # is rejected outright rather than committed -- see
            # MIN_MARQUEE_SIZE's own comment for why SelectionWidget
            # itself allows this to happen in the first place. Snaps
            # the marquee back to its last known-good size/position
            # (self._selected_region_coords, kept current by
            # apply_selected_region()) instead of merely refusing to
            # persist the bad size, since otherwise the visibly
            # collapsed marquee -- SelectionWidget has already drawn
            # it this small -- would just stay that way on screen.
            if self._selected_region_coords is not None:
                region.set_coords(*self._selected_region_coords)
            self.selection_widget.select(region)
            return
        # The precise box is only saved with the attribute, so a moved
        # or resized marquee must be written out when leaving the
        # photo (see flush_region_order()).
        self._order_dirty = True
        person = region.person
        mediaref = region.mediaref
        if person and mediaref:
            selection = self.selection_widget.get_selection()
            rect = self.selection_widget.real_to_proportional_rect(selection)
            rect = unrotate_proportional_rect(rect, self.rotation_degrees)
            mediaref.set_rectangle(outward_int_rect(rect))
            # commit_person() below fires a "person-update" db signal
            # synchronously, which db_changed() has connected straight
            # to main() -- meaning main() (hide self.top, rebuild the
            # list, show self.top again) runs *nested inside* this
            # very call, right here, before execution even reaches the
            # refresh_list()/refresh_selection() below. Calling
            # refresh_selection() -- which ends in
            # Gtk.TreeView.set_cursor() -- immediately after that
            # nested main() has just re-shown self.top, without first
            # letting the row's geometry settle, was the cause of
            # resizing a marquee (via one of its handles) sporadically
            # selecting the wrong (typically the next) row instead of
            # leaving the same one selected; deferring below via
            # self._schedule_refresh_selection(), the same as main()
            # already defers its own refresh_selection() call for the
            # same reason, is what fixes that.
            self.commit_person(person)
        self.refresh_list()
        # refresh_selection() -> apply_selected_region() already calls
        # enable_buttons() itself, as the last step once the row/
        # marquee/caption highlight are all settled -- an earlier
        # separate call here, before refresh_list() had even rebuilt
        # the row list, could only ever compute sensitivities that
        # this later one immediately supersedes anyway.
        self._schedule_refresh_selection()

    def region_created(self, sender):
        self._release_ended_drag = True
        self._log_marquee_debug("region-created", self.selection_widget.get_current())
        self.show_marquees()
        self.refresh_list()
        # Deferred for the same reason as region_modified() above,
        # even though region_created() itself has no db-commit of its
        # own to trigger a nested main() call: kept consistent with
        # it regardless, rather than relying on this one particular
        # call site happening to be safe to leave undeferred.
        #
        # Explicitly targets self.regions[-1] -- the region just
        # drawn always lands at the end of this list (nothing between
        # a fresh draw and this handler running re-sorts it) -- rather
        # than leaving the target unset and letting the deferred call
        # resolve it from self.selection_widget.get_current() instead,
        # the way region_selected()/main() do: get_current() reflects
        # a *clicked-to-select* marquee reliably, but isn't guaranteed
        # to already agree with which one was just *drawn* by the
        # time this fires. This matters most in quick_draw_toggled()'s
        # quick draw mode, where several marquees can be drawn in
        # quick succession -- each one's explicit target here
        # overrides whatever an earlier, still-pending one staged (see
        # _schedule_refresh_selection()'s own docstring: "last
        # explicit request wins"), so the list's selection always ends
        # up settling on the *last* one drawn, not an earlier one.
        if self.regions:
            self._schedule_refresh_selection(self.regions[-1])
        else:
            self._schedule_refresh_selection()
        if self.quick_draw_mode:
            # SelectionWidget itself treats a freshly drawn marquee as
            # its own new "current" region, drawing it in its own
            # distinct "selected" style -- clearing it again here,
            # right after every single new marquee (not just once when
            # this mode was first turned on, which only covered
            # whatever was already selected *before* that), is what
            # keeps every region rendered the same plain way this
            # mode promises for the rest of the session (see
            # draw_ids_overlay()'s own docstring for why that alone is
            # enough, with nothing further needed here to make it so).
            # The trade-off is that a marquee's resize handles (which
            # also only ever show up on SelectionWidget's own
            # "current" region) aren't reachable on a just-drawn
            # marquee without leaving this mode first.
            self.selection_widget.clear_selection()
            # See quick_draw_toggled()'s own docstring: the entire
            # point of this mode is drawing several marquees back to
            # back with nothing popping up in the way of the next
            # one's starting corner, so the context-menu popup below
            # is deliberately skipped for as long as it's active.
            return
        # show_context_menu() itself must stay synchronous, called
        # directly here, not deferred via GLib.idle_add: an earlier
        # revision of this method did defer it, on the theory that
        # prepare_context_menu()'s sensitivity was reading stale
        # treeview cursor state before self._schedule_refresh_
        # selection() above had actually run. That theory was wrong -
        # prepare_context_menu() reads self.selection_widget.
        # get_current() and self.regions, neither of which depends on
        # the treeview's own cursor/selection at all, both of which
        # are already correct by the time region_created() runs - and
        # deferring the call broke something real:
        # show_context_menu()'s own Gtk.Menu.popup_at_pointer(None)
        # needs a live trigger event/window to anchor itself to, which
        # only exists while still inside the mouse-release handling
        # that fired this signal in the first place. Called from a
        # GLib.idle_add callback instead, with that event long gone,
        # it failed with "Gtk-WARNING: no trigger event for menu
        # popup" / "Gtk-CRITICAL: gtk_menu_popup_at_rect: assertion
        # 'GDK_IS_WINDOW (rect_window)' failed", immediately followed
        # by a segfault.
        self.show_context_menu()

    def right_button_clicked(self, sender):
        self.show_context_menu()

    def region_selected(self, sender):
        self.apply_selected_region(self.selection_widget.get_current())

    def selection_cleared(self, sender):
        """
        Callback for SelectionWidget's own "selection-cleared" signal.

        SelectionWidget's own button-press handling fires this --
        clearing its current region first -- on *every* left click
        that doesn't land on the currently selected region's own
        resize handle, even when the click is about to land on a
        *different* marquee, which its own button-release handling
        alone actually determines afterwards (by then firing
        "region-selected" instead). Applying the clear here
        immediately would paint the row selection/marquee mask/
        Caption highlight as cleared, only to paint them right back a
        moment later once that release re-selects -- visibly
        flashing the mask off and back on for every click that
        switches from one marquee to another.

        Deferred via GLib.idle_add instead: by the time this actually
        runs, the click's own button-release handling (which happens
        synchronously, immediately after the press that fired this)
        has already run to completion, so re-checking
        SelectionWidget's own current selection at that point tells
        this whether the clear was real (a click that landed on mask
        space, where it's still ``None``) or merely transient (a
        click that landed on another marquee, which has since
        replaced it) -- applying it only in the former case avoids
        ever painting the intermediate "nothing selected" state for
        the latter.
        """
        GLib.idle_add(self._cb_apply_deferred_clear)

    def _cb_apply_deferred_clear(self) -> bool:
        """
        The deferred half of selection_cleared() above: applies the
        clear everywhere (see apply_selected_region()) only if
        SelectionWidget's own selection is, by now, still actually
        empty.

        :returns: ``GLib.SOURCE_REMOVE``, so this one-shot idle
            callback is not called again.
        """
        if self.selection_widget.get_current() is None:
            self.apply_selected_region(None)
        return GLib.SOURCE_REMOVE

    def zoomed(self, sender):
        self.enable_buttons()

    # ======================================================
    # toolbar button event handles
    # ======================================================
    def add_person_clicked(self, event):
        region = self._effective_selected_region()
        if region:
            person = Person()
            placeholder = (
                effective_placeholder_name(region) if region.person is None else ""
            )
            if placeholder:
                given, surname = split_placeholder_name(placeholder)
                name = Name()
                name.set_first_name(given)
                if surname:
                    surname_obj = Surname()
                    surname_obj.set_surname(surname)
                    name.set_surname_list([surname_obj])
                person.set_primary_name(name)
            try:
                EditPerson(
                    self.dbstate,
                    self.uistate,
                    self.track,
                    person,
                    self.new_person_added,
                )
            except WindowActiveError:
                pass

    def sel_person_clicked(self, event):
        if self._effective_selected_region():
            SelectPerson = SelectorFactory("Person")
            sel = SelectPerson(
                self.dbstate,
                self.uistate,
                self.track,
                LINK_PERSON_TEXT,
                show_search_bar=True,
            )
            person = sel.run()
            if person:
                self.set_current_person(person)
                self.selection_widget.clear_selection()
                self.refresh()
                self.enable_buttons()

    def del_region_clicked(self, event):
        """
        Removes the currently selected region/row entirely (unlike
        clear_ref_clicked(), which only detaches its Person, leaving
        the row itself in place).

        Afterwards, selects (row, marquee, and Caption panel
        highlight -- see apply_selected_region()) whichever region
        slides into the removed one's place: the next row if there is
        one, otherwise the new last row, otherwise nothing if the list
        is now empty -- rather than leaving the selection cleared.

        self.refresh() itself is deferred via GLib.idle_add (see
        _cb_refresh_after_delete()), for the same reason
        cb_name_cell_edited() already defers its own call to it: this
        method is a context menu item's "activate" signal handler,
        which fires while GTK is still unwinding that same menu's own
        popdown/teardown. self.refresh() clears and fully rebuilds
        self.treestore (see refresh_list()) -- mutating the model
        synchronously at that point doesn't necessarily fail right
        away, but was observed (there, for a Name-cell edit; here, for
        a Remove click) to corrupt GtkTreeView's internal row-height
        bookkeeping and crash the whole process (SIGSEGV, inside
        gtk_tree_view_size_allocate -> _gtk_tree_path_new_from_rbtree)
        the next time anything forced a relayout -- often well after
        the click itself, which is what made this so hard to pin down
        from symptoms alone. Letting the menu's own signal handling
        finish unwinding first avoids the reentrancy entirely.

        `target` is resolved *before* the defer, not left for
        _schedule_refresh_selection() to resolve fresh the way
        main()/region_modified()/region_created() do: it must be a
        specific region other than whatever self.selection_widget.
        get_current() still is by the time the deferred call actually
        runs (the just-deleted one, until something else changes it).
        """
        region = self._effective_selected_region()
        if region is None:
            return
        index = self.regions.index(region) if region in self.regions else -1
        self.delete_region(region)
        if self.regions and index >= 0:
            target = self.regions[min(index, len(self.regions) - 1)]
        else:
            target = None
        GLib.idle_add(self._cb_refresh_after_delete, target)

    def _cb_refresh_after_delete(self, target) -> bool:
        """
        The deferred half of del_region_clicked() -- see its own
        docstring for why self.refresh() can't be called directly
        from there.

        :param target: The Region to reselect once self.refresh() has
            rebuilt the list, or None to leave nothing selected (the
            list is now empty).
        :returns: ``GLib.SOURCE_REMOVE``, so this one-shot idle
            callback is not called again.
        """
        self.refresh()
        self._schedule_refresh_selection(target)
        return GLib.SOURCE_REMOVE

    def clear_ref_clicked(self, event):
        """
        Detaches the currently selected region's Person, leaving the
        row itself in place (unlike del_region_clicked(), which
        removes the row entirely).

        self.refresh() is deferred via GLib.idle_add, for the same
        reason del_region_clicked() defers it (see that method's own
        docstring): this is also a context menu item's "activate"
        signal handler, firing while GTK is still unwinding that same
        menu's own popdown/teardown.
        """
        if self.clear_ref(self._effective_selected_region()):
            GLib.idle_add(self._cb_refresh_after_drop)

    def edit_person_clicked(self, event, expected_region=_UNSET_REGION):
        """
        Opens the Person editor for the currently selected region's
        tagged person -- the action for a double click on a marquee
        or its own row (see cb_preview_panel_button_release()/
        row_activated()), or the "See the person details" context
        menu item (button_edit and context_button_details, both of
        which call this directly, leaving expected_region at its
        default). Does nothing if the region has no person tagged, or
        if that person already has an editor open -- reachable by
        double-clicking the same marquee (or, per its own generous
        resize-handle hit zone -- see MIN_MARQUEE_SIZE's own comment
        -- one right next to it) again before closing the first one.

        :param expected_region: A sanity check for row_activated()/
            cb_preview_panel_button_release(), whose own double click
            already committed to a specific region (a row's own path,
            or a marquee's click coordinates -- both ground truth for
            that exact click) before this runs -- if
            self._effective_selected_region() no longer agrees with
            it by the time this actually runs, something moved the
            selection out from under the double click in between (its
            own two clicks, or the row/marquee/Caption panel's three
            separate, independent paths to the same selection, are
            each one more opportunity for that), and opening an editor
            for whatever is *currently* selected instead would be for
            the wrong person entirely; left at the _UNSET_REGION
            sentinel for a caller with no such specific double click
            of its own to check against (a toolbar/context-menu
            action on whatever is deliberately, already selected).

            self._effective_selected_region(), not self.selection_
            widget.get_current() directly: during quick_draw_toggled()'s
            quick draw mode, get_current() is always None (see that
            method's own docstring), which used to mean this sanity
            check failed unconditionally for *every* double click on a
            row while that mode was on, silently refusing to ever open
            the Person editor that way.
        """
        region = self._effective_selected_region()
        if expected_region is not _UNSET_REGION and region is not expected_region:
            return
        person = region.person
        if person:
            try:
                EditPerson(
                    self.dbstate,
                    self.uistate,
                    self.track,
                    person,
                    lambda edited_person, region=region: self.cb_person_edited(region),
                )
            except WindowActiveError:
                return
            # Deferred via GLib.idle_add, same as del_region_clicked()
            # and for the same reason (see its own docstring): opening
            # a new top-level EditPerson window triggers its own
            # realize/show reflow, and mutating self.treestore (via
            # self.refresh() -> refresh_list()) synchronously while
            # that's still settling carries the same
            # gtk_tree_view_size_allocate corruption risk.
            GLib.idle_add(self._cb_refresh_after_drop)

    def cb_person_edited(self, region) -> None:
        """
        Callback for the Edit Person window opened by
        edit_person_clicked() (a double-clicked row, or the "See the
        person details" context menu item) -- re-applies the
        selection to `region` (row, marquee, and Caption panel
        highlight; see apply_selected_region()) once its Person has
        actually been saved.

        This is on top of, not instead of, the same reselection
        db-signal-triggered refreshes already do (see main()): that
        alone was observed to get overwritten again right after,
        apparently by the Edit Person window's own close/focus-
        handoff back to the region list -- leaving no row selected,
        with only the marquee still showing (whichever region
        happened to be last, not the one just edited). Going through
        self._schedule_refresh_selection() -- the same one main()
        itself schedules its own reselection through, rather than a
        separate, unguarded GLib.idle_add() of its own -- runs this
        after whatever that close-triggered reset does, instead of
        racing it, which is what actually makes the reselection
        stick; it also means cursor_changed() ignoring a stray
        "cursor-changed" while a reselection is pending (see its own
        docstring) covers this path too, not just main()'s.

        Passed `region` explicitly, rather than left for
        self._schedule_refresh_selection() to resolve at defer time:
        self.selection_widget.get_current() is not guaranteed to
        still agree with it by the time the deferred call actually
        runs, which is the entire reason this method exists rather
        than relying on main()'s own reselection alone.
        """
        self._schedule_refresh_selection(region)

    def move_up_clicked(self, event):
        region = self._effective_selected_region()
        if region:
            self.move_region_up(region)

    def move_down_clicked(self, event):
        region = self._effective_selected_region()
        if region:
            self.move_region_down(region)

    def zoom_in_clicked(self, event):
        self.selection_widget.zoom_in()

    def zoom_out_clicked(self, event):
        self.selection_widget.zoom_out()

    def detect_faces_clicked(self, event):
        self.uistate.push_message(self.dbstate, _("Detecting faces..."))
        media = self.get_current_object()
        image_path = media_path_full(self.dbstate.db, media.get_path())
        faces, img_size = facedetection.detect_faces(
            image_path, MIN_FACE_SIZE, SENSITIVITY
        )
        # verify and enlarge found faces regions
        for x, y, width, height in faces:
            # calculate enlarged region
            new_x1 = x - width / 5
            new_y1 = y - height / 3
            new_x2 = x + width * 6 / 5
            new_y2 = y + height * 7 / 5
            # prevent overflow image size
            new_y1 = 0 if new_y1 < 0 else new_y1
            new_y2 = img_size[0] if img_size[0] < new_y2 else new_y2
            new_x1 = 0 if new_x1 < 0 else new_x1
            new_x2 = img_size[1] if img_size[1] < new_x2 else new_x2

            region = Region(new_x1, new_y1, new_x2, new_y2)

            if DETECT_INSIDE_EXISTING_BOXES or self.enclosing_region(region) is None:
                self.regions.append(region)

        self.refresh()
        self.uistate.push_message(self.dbstate, _("Detection finished"))

    def settings_clicked(self, event):
        try:
            SettingsDialog(
                self.gui.dbstate,
                self.gui.uistate,
                _("Photo Tagging Settings"),
                PhotoTaggingOptions(refresh_callback=self.refresh),
            )
        except WindowActiveError:
            pass

    def set_active_person(self, event):
        """
        Set selected person as active.
        """
        region = self._effective_selected_region()
        person = region.person if region is not None else None
        if person:
            person_handle = person.get_handle()
            self.set_active("Person", person_handle)

    # ======================================================
    # helpers for toolbar event handlers
    # ======================================================

    def delete_region(self, region):
        self.regions.remove(region)
        if region.person is not None:
            self.remove_reference(region.person, region.mediaref)

    def delete_regions(self, regions):
        for r in regions:
            self.delete_region(r)

    def new_person_added(self, person):
        self.set_current_person(person)
        self.selection_widget.clear_selection()
        self.refresh()
        self.enable_buttons()

    def set_current_person(self, person):
        self.ask_and_set_person(self._effective_selected_region(), person)

    def ask_and_set_person(self, region, person):
        if region and person:
            other_references = self.regions_referencing_person(person)
            ref_count = len(other_references)
            if ref_count > 0:
                person = other_references[0].person
                if REPLACE_WITHOUT_ASKING:
                    self.delete_regions(other_references)
                else:
                    if ref_count == 1:
                        text = _(
                            "Another region of this image "
                            "is associated with {name}. Remove it?"
                        )
                    else:
                        text = _(
                            "{count} other regions of this image "
                            "are associated with {name}. Remove them?"
                        )
                    message = text.format(
                        name=name_displayer.display(person), count=ref_count
                    )
                    dialog = Gtk.MessageDialog(
                        parent=None,
                        type=Gtk.MessageType.QUESTION,
                        buttons=Gtk.ButtonsType.YES_NO,
                        message_format=message,
                    )
                    response = dialog.run()
                    dialog.destroy()
                    if response == Gtk.ResponseType.YES:
                        self.delete_regions(other_references)
            self.set_person(region, person)

    def set_person(self, region, person):
        """
        Links ``region`` to ``person``: clears any existing reference
        first, adds the new one, and updates the region in place.

        Deliberately leaves ``region.xmp_person`` untouched - it is
        *not* cleared just because the region now has a Person linked.
        This matches the invariant documented on
        ``metadata_clue_text_for()`` and relied on by
        ``_handle_pipe_icon_double_click()``/``open_piping_options_
        dialog()`` (via ``metadata_clue_name()``): a row's metadata
        clue survives linking, so the Metadata Clues column - and
        anything piped or looked up from it - keeps showing what the
        metadata actually said even after the row's been tagged. An
        earlier version of this method cleared it here, which silently
        dropped that row from the Metadata Clues column, from
        transcribe_list_to_note_clicked()'s block 3, and from any
        later fuzzy-match lookup for that row, the moment it was
        linked - a real content loss, not just a cosmetic one.
        """
        rect = self.check_and_translate_to_proportional(
            region.mediaref, region.coords()
        )
        self.clear_ref(region)
        mediaref = self.add_reference(person, rect)
        region.person = person
        region.mediaref = mediaref

    def clear_ref(self, region):
        if region:
            if region.person:
                self.remove_reference(region.person, region.mediaref)
                region.person = None
                region.mediaref = None
                return True
        return False

    # ======================================================
    # context menu event handles
    # ======================================================

    def replace_reference(self, event, person):
        """
        Swaps person assignments between the currently selected region
        and whichever region `person` is already assigned to: their
        rectangles/positions/index in the list are untouched -- only
        which person each one is linked to trades places. E.g. if row
        5 (some person, or none) is selected and "Swap with" row 18's
        person is chosen, row 5 ends up with row 18's former person
        and vice versa; every other row is unaffected.

        The target region (region_b below) is set first, using
        region_a's *original* person, before region_a itself is
        touched -- set_person() always reads a region's rectangle
        from its own current, unmodified mediaref/coords, so ordering
        it this way naturally avoids having to manipulate any
        MediaRef rectangle directly to achieve the swap.

        Both region_a and person_a are captured up front, not
        re-queried mid-method: as in the crash this replaced, each
        set_person()/clear_ref() call below commits a Person, and
        Gramps fires its database update signal synchronously on
        commit -- which re-enters this same gramplet's own refresh
        cycle while this method is still on the call stack.
        """
        region_a = self._effective_selected_region()
        if region_a is None:
            return
        person_a = region_a.person

        other_regions = self.regions_referencing_person(person)
        region_b = other_regions[0] if other_regions else None

        if region_b is not None:
            if person_a is not None:
                self.set_person(region_b, person_a)
            else:
                self.clear_ref(region_b)
        self.set_person(region_a, person)

        self.selection_widget.clear_selection()
        self.refresh()
        self.enable_buttons()

    def transcribe_list_to_note_clicked(self, event):
        """
        Creates a new Note -- as if the Media editor's own "create and
        add a new note" button had been clicked for the active Media
        object -- pre-populated with a transcription of the region
        list, as three separate draft blocks a person can then pick
        between (or combine) while writing the actual caption -- more
        raw material to work from is better than too little, even
        where two of the three inevitably overlap for a row that's
        both named and linked:

        1. Title (bold), date, and (linked) Gramps ID of the media,
           one per line, then a blank line.
        2. The Name column, transcribed: every row with a name at all
           -- linked or not -- "; "-joined in true row order, then two
           blank lines. A linked row is rendered exactly as its Name
           cell is (the date-aware, display_as-respecting name from
           get_name_at_date()/display_name_respecting_format()) and
           linked to that Person; an unlinked row is rendered exactly
           as its own Name cell is too (effective_placeholder_name()/
           display_placeholder_name()), as plain unlinked text, since
           there's no Person to link to yet. A row with no name at all
           (an empty, still-unconfirmed placeholder) is skipped, same
           as it shows no text in that column either.
        3. The Metadata clues column, transcribed the same way: every
           row's own clue text (see metadata_clue_text_for()), one per
           line, in true row order -- shown for a row regardless of
           whether it's since been linked, same as the column itself
           doesn't hide a clue just because its row got tagged. A row
           with no clue text at all is skipped, then two blank lines.
        4. The Gramps ID cross-reference list: each linked row's
           number (its own position among ALL rows, matching the Row
           ID column), Gramps ID (linked), and name -- useful for
           pasting into a Fuzzy Match-style surname filter or similar,
           but the least human-readable of the four, so it stays at
           the end.

        Every block walks self.regions once, in true row order, rather
        than filtering to "linked" vs. "unlinked" subsets first -- an
        earlier version of this method did that (and numbered block 4
        by position *among linked rows only*, not each row's real
        position -- so linking the 2nd of 3 rows had it show up
        captioned as row 1), and an even earlier one dropped linked
        rows from the Name-column list entirely. See
        metadata_clue_text_for() and sort_regions_by_stored_order()
        for where each block's content and ordering actually come
        from.

        The Note is opened for editing unsaved; only once the person
        clicks OK in the Note editor is it actually created and added
        to the media object's own note list, matching what clicking
        "create and add a new note" in the Media editor would do.

        Its type is always set to the custom Caption type (see
        CAPTION_NOTE_TYPE_STRING) rather than General, since this is
        also the action invoked by double-clicking the Show/Hide
        Caption toolbar button while it is dimmed (see
        cb_caption_button_toggled()) -- the whole point there being to
        create a Note that button/panel will immediately recognize.
        """
        media = self.get_current_object()
        if media is None or not self.regions:
            return

        builder = NoteTextBuilder()
        media_date = media.get_date_object()
        name_as_of_date = self.name_as_of_date_for(media)

        # 1. Title (bold), date, ID (linked), blank line
        builder.add_bold_line(media.get_description())
        if date_has_value(media_date):
            builder.add_line(date_displayer.display(media_date))
        else:
            builder.add_line(_("undefined date"))
        media_gramps_id = media.get_gramps_id()
        builder.add_linked_line(
            media_gramps_id,
            "gramps://Media/handle/%s" % media.get_handle(),
        )
        builder.add_blank_lines(1)

        # 2. Name column, "; "-joined, in true row order -- linked
        # rows shown linked, unlinked rows shown as plain text in
        # their own Name-Display-formatted placeholder text (see this
        # method's own docstring for why linked and unlinked rows
        # aren't filtered into two separate lists here).
        first = True
        for region in self.regions:
            if region.person is not None:
                text = display_name_respecting_format(
                    get_name_at_date(region.person, name_as_of_date)
                )
            else:
                placeholder = effective_placeholder_name(region)
                if not placeholder:
                    continue
                text = display_placeholder_name(placeholder)
            if not first:
                builder.add_text("; ")
            if region.person is not None:
                builder.add_link(
                    text, "gramps://Person/handle/%s" % region.person.get_handle()
                )
            else:
                builder.add_text(text)
            first = False
        builder.add_line()
        builder.add_blank_lines(2)

        # 3. Metadata clues column, one row per line, in true row
        # order -- see metadata_clue_text_for() for what counts as a
        # row's clue text (the same thing refresh_list() shows in that
        # column, whether or not the row has since been linked).
        for region in self.regions:
            clue = self.metadata_clue_text_for(region)
            if clue:
                builder.add_line(clue)
        builder.add_blank_lines(2)

        # 4. Gramps ID cross-reference list, IDs linked, each followed
        # by that person's own name -- moved to the end since it's the
        # least human-readable of the blocks. The row number is each
        # region's own position within self.regions (already in
        # display order -- see sort_regions_by_stored_order()), not a
        # fresh count of only the linked rows reached so far -- see
        # this method's own docstring for the bug that numbering used
        # to cause.
        for row, region in enumerate(self.regions, start=1):
            if region.person is None:
                continue
            gramps_id = region.person.get_gramps_id()
            builder.add_text("%d, " % row)
            builder.add_link(
                gramps_id, "gramps://Person/handle/%s" % region.person.get_handle()
            )
            name = display_name_respecting_format(
                get_name_at_date(region.person, name_as_of_date)
            )
            builder.add_line(", %s" % name)

        note = Note()
        note.set_type((NoteType.CUSTOM, CAPTION_NOTE_TYPE_STRING))
        # NOTE: set() takes a plain string and stores clear text only,
        # silently discarding any StyledTextTag formatting -- including
        # every link built above. set_styledtext() is the method that
        # actually preserves it.
        note.set_styledtext(builder.build_styled_text())
        try:
            EditNote(
                self.dbstate,
                self.uistate,
                self.track,
                note,
                self.note_added_to_media_callback,
            )
        except WindowActiveError:
            pass

    def note_added_to_media_callback(self, note_handle):
        """
        Commits the new note as a reference on the active Media object,
        the same effect as the Media editor's own "create and add a
        new note" button -- called once the person clicks OK in the
        Note editor opened by transcribe_list_to_note_clicked().
        """
        media = self.get_current_object()
        if media is None:
            return
        with DbTxn(_("Add Note"), self.dbstate.db) as trans:
            media.add_note(note_handle)
            self.dbstate.db.commit_media(media, trans)

    # ======================================================
    # list event handles
    # ======================================================

    def cursor_changed(self, treeview):
        """
        Callback for the treeview's own "cursor-changed" signal --
        the person clicking a row directly, arrow-key navigation, and
        apply_selected_region()'s own Gtk.TreeView.set_cursor() calls
        all raise it alike.

        Ignored while self._refresh_selection_pending is set: between
        refresh_list() rebuilding the treestore and the deferred
        apply_selected_region() call self._schedule_refresh_selection()
        has already queued to restore the correct row on it (see that
        method's own docstring for why it's deferred at all), Gtk can
        apparently still raise a stray "cursor-changed" of its own for
        a row this hasn't gotten to correct yet -- suspected, from
        reports of the row selection landing on row 1 specifically
        after a marquee resize, to be Gtk defaulting the treeview's
        cursor to row 0 on its own once refresh_list() gives it rows
        again, ahead of the deferred call actually restoring the
        right one. Since a real, deliberate row click can't happen in
        that same window (nothing to click: the row list is still
        mid-rebuild at that point), ignoring "cursor-changed" entirely
        while the flag is set costs nothing either way.

        Also ignored while self._editing_name_path is set (a Name
        cell is actively being edited): the second of the two clicks
        it takes to start editing an already-selected row's Name
        cell (the first click only selects the row; Gtk requires the
        cell to already be the selected one before a click on it
        starts editing, rather than just selecting it again) itself
        re-raises "cursor-changed" - and apply_selected_region()'s own
        Gtk.TreeView.set_cursor() call, even repositioning to the
        exact row/cell already being edited, cancels that in-progress
        edit as a documented Gtk side effect. That cancellation left
        the actual Gtk.Entry editor widget on screen, live and
        focused, but permanently detached from the cell renderer's
        own edit-commit bookkeeping - so typing into it and pressing
        Enter appeared to do nothing (edited() never fires once
        editing has been cancelled), and left that stray widget
        intercepting later clicks (including its own right-click
        menu showing plain cut/copy/paste instead of this treeview's
        row context menu) until something else finally reclaimed
        focus. Confirmed via temporary diagnostic logging on
        cb_name_cell_editing_started()/_edited()/_editing_canceled():
        editing_started was immediately followed by editing_canceled,
        with nothing typed in between.
        """
        if self._refresh_selection_pending:
            return
        if self._editing_name_path is not None:
            return
        if self.quick_draw_mode:
            # _focus_treeview_row_only()'s own Gtk.TreeView.set_cursor()
            # call -- used specifically to avoid calling
            # apply_selected_region() (see its own docstring) --
            # raises this same "cursor-changed" signal synchronously,
            # landing right back here with neither guard above set by
            # then (_refresh_selection_pending was already cleared
            # before _focus_treeview_row_only() ran). Falling through
            # to apply_selected_region() here would select `region` on
            # SelectionWidget after all, defeating the whole point --
            # and the same signal fires just as unhelpfully for a
            # genuine row click while this mode is on. Genuine mouse
            # clicks on a row are handled separately instead, by
            # cb_row_button_release(), so they still select the
            # marquee and Caption link like a click on the photo does.
            return
        self.apply_selected_region(self.get_selected_region())

    def cb_row_button_release(self, treeview, event) -> bool:
        """
        Callback for the region list's "button-release-event". In
        quick draw mode only, a plain left click on a row switches
        quick draw mode off (selecting a row means reviewing, not
        drawing) and selects that row's marquee and Caption panel
        link. cursor_changed() can't do this, since it cannot tell a
        real click from the list's own programmatic cursor moves (see
        _focus_treeview_row_only()).

        Clicks on the two icon columns are left to row_mouse_click().
        Deferred to idle so GTK finishes its own click handling first.

        :param treeview: The region list (unused).
        :param event: The Gdk.EventButton for the release.
        :returns: ``False`` always, so GTK's own handling continues.
        """
        if not self.quick_draw_mode or event.button != 1:
            return False
        pthinfo = self.treeview.get_path_at_pos(event.x, event.y)
        if pthinfo is None:
            return False
        path, col, _cellx, _celly = pthinfo
        if col in (self.column_add_icon, self.column_pipe_icon):
            return False
        index = path.get_indices()[0]
        if not 0 <= index < len(self.regions):
            return False
        region = self.regions[index]
        self._leave_quick_draw()
        GLib.idle_add(self._cb_apply_clicked_row, region)
        return False

    def _cb_apply_clicked_row(self, region) -> bool:
        """
        The deferred half of cb_row_button_release(). Does nothing if
        that region is already the selected one -- the second click
        that starts editing a row's Name cell must not move the list
        cursor again, which would cancel the edit (see
        cursor_changed()'s docstring) -- or if a Name edit is in
        progress, or the region is gone.

        :param region: The clicked row's Region.
        :returns: ``GLib.SOURCE_REMOVE``.
        """
        if (
            self._editing_name_path is None
            and region in self.regions
            and self.selection_widget.get_current() is not region
        ):
            self.apply_selected_region(region)
        return GLib.SOURCE_REMOVE

    def row_activated(self, treeview, path, view_column):
        """
        Callback for the treeview's own "row-activated" signal (a
        double click on a row, or Enter/Space on the focused one).

        Passes the double-clicked row's own region to
        edit_person_clicked() as its sanity check (see that method's
        own docstring): `path` is ground truth for exactly which row
        this double click landed on, independent of whatever
        self.selection_widget.get_current() is by the time this runs.

        A mouse double-click on the Row ID column is ignored here: it
        opens the Move Row popover instead (see row_mouse_click() /
        _handle_row_id_double_click()). GTK 3 recognizes the double
        click for "row-activated" separately from the
        "button-press-event" handler, so that handler returning True
        did not stop this one -- both ran, opening the person editor
        as well. Enter on the keyboard still activates the row from
        any column.
        """
        if view_column is self.column_row_id:
            event = Gtk.get_current_event()
            if event is not None and event.type in (
                Gdk.EventType.BUTTON_PRESS,
                Gdk.EventType._2BUTTON_PRESS,  # pylint: disable=protected-access
                Gdk.EventType.BUTTON_RELEASE,
            ):
                return
        index = path.get_indices()[0]
        expected_region = (
            self.regions[index] if 0 <= index < len(self.regions) else None
        )
        self.edit_person_clicked(None, expected_region)

    def treeview_drag_data_get(self, widget, context, sel_data, info, time):
        """
        Provide the row index of the currently selected region so that
        drag_data_received can tell this is a reorder within the same list.
        """
        region = self.get_selected_region()
        if region is None:
            return
        row_from = self.regions.index(region)
        sel_data.set(REORDER_ATOM, 8, pickle.dumps(row_from))

    def reorder_drag_received(self, sel_data, x, y):
        """
        Handle a row of this treeview being dropped back onto itself,
        reordering self.regions accordingly.
        """
        try:
            row_from = pickle.loads(sel_data.get_data())
            if row_from < 0 or row_from >= len(self.regions):
                return
            region = self.regions[row_from]
            row_to = self.find_drop_row(x, y)
            self.move_region(row_from, row_to, region)
        except Exception:
            # A silent no-op here is indistinguishable from GTK simply
            # not registering the drop, so log the full traceback
            # rather than letting a reorder drag just appear to do
            # nothing with no clue why.
            LOG.exception("reorder_drag_received failed")

    def row_mouse_click(self, treeview, event):
        """
        Handles a left click landing on the Add-person or
        piping-options icon columns (see column_add_icon/
        column_pipe_icon, each its own narrow TreeViewColumn -- so
        which one was clicked is exactly what get_path_at_pos()
        already reports, no per-cell position math needed), and the
        existing right-click context menu.

        A double-click on the piping-options icon additionally opens
        the Fuzzy Matching addon's lookup window (see
        _handle_pipe_icon_double_click()) -- GTK delivers this as a
        normal single click first (so open_piping_options_dialog()
        still runs and copies to the clipboard, same as ever) and then
        a second event of type Gdk.EventType._2BUTTON_PRESS for the
        second click, which is what actually triggers the extra
        behavior.

        A double-click on the Row ID column instead opens a small
        dialog to move that row to a typed row number (see
        _handle_row_id_double_click() for why that's a separate dialog
        rather than an inline cell edit).
        """
        pthinfo = self.treeview.get_path_at_pos(event.x, event.y)
        if pthinfo is None:
            return False
        path, col, cellx, celly = pthinfo
        button = event.get_button()[1]
        if button == 1:
            if (
                col is self.column_row_id
                and event.type
                == Gdk.EventType._2BUTTON_PRESS  # pylint: disable=protected-access
            ):
                return self._handle_row_id_double_click(path)
            if col is self.column_add_icon:
                return self._handle_add_icon_click(path)
            if col is self.column_pipe_icon:
                # Gdk.EventType._2BUTTON_PRESS is GDK's own real,
                # public enum member -- its name simply can't start
                # with a digit, hence the leading underscore, which
                # pylint otherwise mistakes for a protected-access
                # violation.
                if (
                    event.type
                    == Gdk.EventType._2BUTTON_PRESS  # pylint: disable=protected-access
                ):
                    return self._handle_pipe_icon_double_click(path)
                return self._handle_pipe_icon_click(path)
            return False
        # right mouse button
        if button == 3:
            # change cursor position to apply row selection
            self.treeview.grab_focus()
            self.treeview.set_cursor(path, col, 0)
            self.show_context_menu()
            # stop signal emission
            return True
        return False

    # ======================================================
    # helpers for list event handlers
    # ======================================================

    def get_selected_region(self):
        """
        Returns the Region behind the treeview's currently selected
        row, or ``None`` if none is selected.

        Uses the TreePath's own (0-based) row index -- the same one
        apply_selected_region() computes via self.regions.index(region)
        to build the TreePath it selects in the first place -- rather
        than column 0's displayed value: that column shows the
        1-based "Row ID" the person sees (see refresh_list()), and
        translating it back with "- 1" to index into self.regions
        needlessly coupled a display detail to this lookup, silently
        handing back the wrong (typically adjacent) region if the two
        were ever even briefly out of step.
        """
        selection = self.treeview.get_selection()
        if selection:
            model, pathlist = selection.get_selected_rows()
            for path in pathlist:
                index = path.get_indices()[0]
                try:
                    return self.regions[index]
                except IndexError:
                    return None
        return None

    # ======================================================
    # refreshing the list
    # ======================================================

    def name_as_of_date_for(self, media):
        """
        The date to select and display a person's name as of: the
        media's own date when it actually has one (see
        date_has_value() -- not media_date.get_valid(), which is true
        even for a media object with no date at all), otherwise today
        -- used both for the table (refresh_list()) and the "Swap
        with" context menu entries (prepare_context_menu()), so both
        always show the same name for the same person on the same
        photo.
        """
        media_date = media.get_date_object() if media else None
        if date_has_value(media_date):
            return media_date
        return Today()

    def apply_alternating_row_shading(self, *column_cell_pairs):
        """
        Lightly shades every other row of the region list, and (via
        _shade_cell(), see its own docstring) blends in flash_row()'s
        selected-color cross-fade for whichever row is currently
        flashing.

        Deliberately not Gtk.TreeView.set_rules_hint() (deprecated
        since GTK 3.14, and even before that only did anything if the
        current theme chose to honor it) or CSS row:nth-child(even)
        selectors (support for which has historically been
        inconsistent across GTK3 versions/theme engines). Setting each
        cell renderer's own cell-background-rgba directly, based on
        the row's own index, always renders regardless of theme or
        GTK version.

        :param column_cell_pairs: Any number of (TreeViewColumn,
            CellRenderer) pairs to shade identically, so every column
            in a shaded (or flashing) row looks the same, not just one.
        """

        def cb(_column, cell, _model, tree_iter, _data=None):
            self._shade_cell(cell, tree_iter)

        for column, cell in column_cell_pairs:
            column.set_cell_data_func(cell, cb)

    def _shade_cell(self, cell, tree_iter):
        """
        The per-row background for one cell: apply_alternating_row_
        shading()'s own alternating-row tint, cross-faded towards the
        theme's selected-row color for whichever row flash_row() is
        currently flashing (see flash_fraction_for()) -- factored out
        so cb_name_cell_data(), cb_name_icon_cell_data(), and
        cb_clue_icon_cell_data() can each combine it with their own
        per-row content logic in a single cell_data_func -- a
        (column, cell) pair can only have one registered at a time
        (see the comment where those three are wired up), so this
        can't be registered separately for these cells the way it is
        for column1/column2/column4's own plain cells.

        A mostly-transparent medium gray overlay is used for the
        alternating shade rather than a fixed opaque color, so it
        stays neutral -- readable on both light and dark themes --
        instead of a black overlay, which can read as muddy rather
        than a clean shade on dark themes. The flash color comes from
        the GTK theme itself (see _selected_row_rgba()) for the same
        reason.
        """
        index = self.treestore.get_path(tree_iter).get_indices()[0]
        shaded = index % 2 == 1
        base = Gdk.RGBA(0.5, 0.5, 0.5, 0.10) if shaded else Gdk.RGBA(0, 0, 0, 0)
        region = self._region_for_iter(tree_iter)
        fraction = self.flash_fraction_for(region) if region is not None else 0.0
        if fraction <= 0:
            cell.set_property("cell-background-set", shaded)
            if shaded:
                cell.set_property("cell-background-rgba", base)
            return
        target = self._selected_row_rgba()
        target_alpha = min(target.alpha, ROW_FLASH_MAX_ALPHA)
        cell.set_property("cell-background-set", True)
        cell.set_property(
            "cell-background-rgba",
            Gdk.RGBA(
                base.red + (target.red - base.red) * fraction,
                base.green + (target.green - base.green) * fraction,
                base.blue + (target.blue - base.blue) * fraction,
                base.alpha + (target_alpha - base.alpha) * fraction,
            ),
        )

    def _selected_row_rgba(self):
        """
        The current GTK theme's selected-row background color, used
        as flash_row()'s cross-fade target -- so a flashed row looks
        like a native selection highlight rather than a hardcoded
        color that could clash with a light or dark theme.
        """
        context = self.treeview.get_style_context()
        return context.get_background_color(Gtk.StateFlags.SELECTED)

    def flash_row(self, region):
        """
        Briefly cross-fades `region`'s row to the theme's
        selected-row color and back to normal over
        ROW_FLASH_DURATION_MS -- visual confirmation that a one-click
        row action (the Add-person or Copy-name icon; see
        _handle_add_icon_click()/_handle_pipe_icon_click()) actually
        did something, since neither one changes the row's own
        treeview selection and add_person_clicked()'s own EditPerson
        dialog can take a moment to appear.

        Only one row flashes at a time; starting a new flash cancels
        whatever was already running rather than layering timeouts.
        """
        if region not in self.regions:
            return
        if self._flash_timeout_id is not None:
            GLib.source_remove(self._flash_timeout_id)
        self._flash_region = region
        self._flash_started_at = GLib.get_monotonic_time()
        self._flash_timeout_id = GLib.timeout_add(
            ROW_FLASH_INTERVAL_MS, self.cb_flash_tick
        )

    def cb_flash_tick(self):
        """
        GLib.timeout_add callback driving flash_row()'s cross-fade:
        asks the treeview to redraw (so the cell_data_funcs that call
        _shade_cell() re-evaluate flash_fraction_for() with the
        current elapsed time) and unregisters itself once
        ROW_FLASH_DURATION_MS has fully elapsed.

        :returns: GLib.SOURCE_CONTINUE to keep ticking, or
            GLib.SOURCE_REMOVE once the flash has finished.
        """
        if self._flash_region is None:
            return GLib.SOURCE_REMOVE
        elapsed_ms = (GLib.get_monotonic_time() - self._flash_started_at) / 1000
        self.treeview.queue_draw()
        if elapsed_ms >= ROW_FLASH_DURATION_MS:
            self._flash_region = None
            self._flash_started_at = None
            self._flash_timeout_id = None
            return GLib.SOURCE_REMOVE
        return GLib.SOURCE_CONTINUE

    def flash_fraction_for(self, region):
        """
        How "selected" `region`'s row should currently look for
        flash_row()'s cross-fade: 0.0 is normal, 1.0 is fully the
        selected-row color. Follows a triangular envelope -- rising
        for the first half of ROW_FLASH_DURATION_MS and falling back
        for the second half -- so the row fades smoothly up and back
        down rather than snapping in and out.

        :param region: The region to check, or None (always 0.0).
        :returns: A float from 0.0 to 1.0.
        """
        if region is None or region is not self._flash_region:
            return 0.0
        if self._flash_started_at is None:
            return 0.0
        elapsed_ms = (GLib.get_monotonic_time() - self._flash_started_at) / 1000
        half = ROW_FLASH_DURATION_MS / 2
        if elapsed_ms >= ROW_FLASH_DURATION_MS:
            return 0.0
        if elapsed_ms <= half:
            return elapsed_ms / half
        return (ROW_FLASH_DURATION_MS - elapsed_ms) / half

    def _region_for_iter(self, tree_iter):
        """
        The Region behind a treestore row, or None if the row's index
        is somehow out of step with self.regions (shouldn't normally
        happen -- refresh_list() always builds one treestore row per
        self.regions entry, in the same order -- but a cell_data_func
        firing mid-rebuild is exactly the kind of transient state
        worth guarding rather than trusting).
        """
        index = self.treestore.get_path(tree_iter).get_indices()[0]
        return self.regions[index] if 0 <= index < len(self.regions) else None

    def cb_name_cell_data(self, _column, cell, model, tree_iter, _data=None):
        """
        Per-row content for the Name cell (column3/cell3): a linked
        row keeps the existing read-only Person+Age Pango markup
        (built into treestore column 2 by refresh_list()); an
        unlinked row instead becomes a plain, editable text field --
        so a placeholder name can be typed in (or accepted as-is)
        before a Person exists at all, rather than only ever after
        one is linked.

        An unlinked row's text is shown in red, the same "needs
        attention" signal format_person_age_markup() already uses for
        a suspicious age -- a placeholder (whether it's an XMP-derived
        suggestion or still blank) hasn't been confirmed against a
        real Person yet, so it's flagged as needing further research
        rather than looking like an ordinary, already-settled name.

        The placeholder text itself is rendered through
        display_placeholder_name() -- the user's own Name Display
        format (Preferences' Surname/Given order, or whatever else it
        is set to), the same as a linked row's own name -- rather than
        showing the raw "Given Surname" (or "Surname, Given") string
        exactly as XMP/MWG happened to store it. It's still read live
        from self.regions (via effective_placeholder_name()), not from
        the treestore, so it always reflects the latest manual edit
        without needing refresh_list() to rebuild the whole row for a
        one-cell change -- except for whichever row is currently open
        for editing (see self._editing_name_path), which is left alone
        entirely so this doesn't fight the live Gtk.CellRendererText
        editor the person is actively typing into.
        """
        self._shade_cell(cell, tree_iter)
        region = self._region_for_iter(tree_iter)
        if region is not None and region.person is not None:
            cell.set_property("foreground-set", False)
            cell.set_property("markup", model.get_value(tree_iter, 2))
            cell.set_property("editable", False)
            return
        cell.set_property("foreground-set", True)
        cell.set_property("foreground", "red")
        cell.set_property("editable", region is not None)
        path = model.get_path(tree_iter)
        if (
            self._editing_name_path is not None
            and path.compare(self._editing_name_path) == 0
        ):
            return
        placeholder = effective_placeholder_name(region) if region else ""
        cell.set_property("text", display_placeholder_name(placeholder))

    def cb_name_cell_editing_started(self, _cell, _editable, path_string):
        self._editing_name_path = Gtk.TreePath.new_from_string(path_string)

    def cb_name_cell_editing_canceled(self, _cell):
        self._editing_name_path = None

    def cb_name_cell_edited(self, _cell, path_string, new_text):
        """
        Commits a Name-cell edit on an unlinked row as a manual
        placeholder: split into given/surname (see
        split_placeholder_name()) and persisted the next time this
        photo's region data is flushed (see flush_region_order()) --
        the same deferred-write pattern region_order_changed() already
        uses for a drag reorder, and for the same reason: writing
        straight to the database from here would cause an async
        gramplet refresh that could clear the treeview's selection/
        edit state right back out from under this method.

        An edit that leaves the text empty still counts as a manual
        edit (region.manual_name = ""), not "no edit at all" --
        deliberately clearing a suggested name is itself meaningful:
        it means "not this", and should stick rather than silently
        reverting to showing the same suggestion again next refresh
        (see effective_placeholder_name()).

        self.refresh() itself is deferred via GLib.idle_add (see
        _cb_refresh_after_name_edit()) rather than called directly
        here: this method is GtkCellRendererText's own "edited"
        signal handler, which fires while GTK is still unwinding that
        same cell's editing-widget teardown. self.refresh() clears
        and fully rebuilds self.treestore (see refresh_list()) --
        mutating the model synchronously at that point doesn't
        necessarily fail right away, but was observed to corrupt
        GtkTreeView's internal row-height bookkeeping and crash the
        whole process (SIGSEGV, inside gtk_tree_view_size_allocate ->
        _gtk_tree_path_new_from_rbtree) the next time anything forced
        a relayout -- often a dialog opened well after the edit
        itself, which is what made this so hard to pin down from
        symptoms alone. Letting the edit's own signal handling finish
        unwinding first avoids the reentrancy entirely.
        """
        self._editing_name_path = None
        path = Gtk.TreePath.new_from_string(path_string)
        index = path.get_indices()[0]
        if not 0 <= index < len(self.regions):
            return
        region = self.regions[index]
        if region.person is not None:
            return
        region.manual_name = new_text.strip()
        self._order_dirty = True
        GLib.idle_add(self._cb_refresh_after_name_edit)

    def _cb_refresh_after_name_edit(self) -> bool:
        """
        The deferred half of cb_name_cell_edited() -- see its own
        docstring for why this can't just be a direct self.refresh()
        call there.

        :returns: ``GLib.SOURCE_REMOVE``, so this one-shot idle
            callback is not called again.
        """
        self.refresh()
        return GLib.SOURCE_REMOVE

    def cb_name_icon_cell_data(self, _column, cell, _model, tree_iter, _data=None):
        """
        Shows the "add a new person" icon (see row_mouse_click()) only
        for an unlinked row -- there is nothing to prefill/link for a
        row that already has a Person.
        """
        self._shade_cell(cell, tree_iter)
        region = self._region_for_iter(tree_iter)
        if region is not None and region.person is None:
            cell.set_property("icon-name", "add")
        else:
            cell.set_property("icon-name", None)

    def cb_clue_icon_cell_data(self, _column, cell, _model, tree_iter, _data=None):
        """
        Shows the "piping options" icon (see row_mouse_click() /
        open_piping_options_dialog()) only where there is actually a
        metadata clue that could be piped somewhere -- an unlinked row
        with a non-empty metadata_clue_name(). Deliberately not
        effective_placeholder_name(): a manual Name-column edit with
        no metadata clue behind it at all is not something this
        Metadata Clues column icon has anything to do with.
        """
        self._shade_cell(cell, tree_iter)
        region = self._region_for_iter(tree_iter)
        if (
            region is not None
            and region.person is None
            and metadata_clue_name(region)
        ):
            cell.set_property("icon-name", "edit-find")
        else:
            cell.set_property("icon-name", None)

    def _ensure_region_selected(self, region, path):
        """
        Selects ``region``'s row -- in both the treeview and the image
        preview's own selection overlay -- if it isn't already the
        selected one. Mirrors the selection step
        _handle_add_icon_click() already does unconditionally; factored
        out here since both _handle_pipe_icon_click() and
        _handle_pipe_icon_double_click() need it too, but only when
        the click landed on a row other than whatever's currently
        selected -- re-selecting an already-selected row is harmless,
        but needless churn (and a redundant flash_row() cross-fade
        restart) for the by-far-most-common case of clicking an icon
        on the row you'd already selected.

        :param region: The clicked row's Region.
        :param path: That row's Gtk.TreePath.
        """
        if self.get_selected_region() is region:
            return
        self.treeview.set_cursor(path)
        self.selection_widget.select(region)

    def _handle_add_icon_click(self, path):
        """
        Handles a click on the Name column's "add a new person" icon
        (see cb_name_icon_cell_data()): selects that row's region --
        add_person_clicked() itself only ever acts on whatever
        self.selection_widget currently considers selected, the same
        as the existing toolbar button/context menu item -- then
        launches it exactly as those do. flash_row() gives immediate
        feedback that the click registered, since selecting the row
        and opening the Person editor can otherwise be the only (and,
        for the dialog, slightly delayed) sign anything happened.
        """
        index = path.get_indices()[0]
        if not 0 <= index < len(self.regions):
            return True
        region = self.regions[index]
        if region.person is not None:
            return True
        self._ensure_region_selected(region, path)
        self.flash_row(region)
        self.add_person_clicked(None)
        return True

    def _handle_pipe_icon_click(self, path):
        """
        Handles a click on the Metadata clues column's "piping
        options" icon (see cb_clue_icon_cell_data()). Also selects the
        row (see _ensure_region_selected()) if it wasn't already
        selected, the same as the Name column's "add" icon does --
        clicking either icon acts on this specific row, so leaving a
        *different* row selected afterward would be surprising.
        flash_row() gives immediate feedback that the name was
        actually copied, since open_piping_options_dialog() itself has
        no other visible effect -- it writes straight to the clipboard
        with no dialog of its own.
        """
        index = path.get_indices()[0]
        if not 0 <= index < len(self.regions):
            return True
        region = self.regions[index]
        self._ensure_region_selected(region, path)
        self.open_piping_options_dialog(region)
        self.flash_row(region)
        return True

    def _handle_pipe_icon_double_click(self, path):
        """
        Handles a double-click on the Metadata clues column's icon
        (see cb_clue_icon_cell_data()/row_mouse_click()): opens the
        Fuzzy Matching addon's standalone lookup window, if installed
        and enabled, seeded with this row's metadata clue name (see
        metadata_clue_name() -- not effective_placeholder_name(),
        for the same reason open_piping_options_dialog() doesn't use
        it either) -- selecting the surname in that window's left
        column, if there's an exact phonetic match, which populates
        the right column with every person who has it -- and
        scrolled/selected as close as possible to the given name. See
        FuzzyMatchAPI.md (in the Fuzzy Matching addon's own folder)
        for the full calling convention this follows. Also selects the
        row here (see _ensure_region_selected()) if it wasn't already,
        same as the single-click handler above.

        Passes on_select=self._apply_fuzzy_match bound to this row's
        own `region` (see _apply_fuzzy_match()'s own docstring): the
        earlier version of this call passed no on_select at all, so a
        double-click on a match in that window only ever opened that
        person's own editor -- there was no way to actually apply the
        pick back to the row that asked for it, and the only way to
        get a match onto this row from that window at all was to drag
        it out by hand.

        Looked up via Gramps' own plugin registry
        (_get_fuzzy_match_lookup(), see its own docstring for why a
        bare cross-addon import does not work reliably here), not a
        direct `import FuzzyMatchLookupWindow`.

        A no-op (still consuming the event, so it doesn't also start
        editing the cell) if the Fuzzy Matching addon isn't installed,
        enabled, or new enough to register the "Fuzzy Match API"
        plugin this looks up, or if this row has no usable metadata
        clue surname to look up -- the addon's own lookup window has
        nothing surname-based to search for on a given-name-only clue,
        so there is nothing worth opening it for in that case either.
        """
        index = path.get_indices()[0]
        if not 0 <= index < len(self.regions):
            return True
        region = self.regions[index]
        self._ensure_region_selected(region, path)
        given, surname = split_placeholder_name(metadata_clue_name(region))
        if not surname:
            return True
        show_fuzzy_lookup = _get_fuzzy_match_lookup()
        if show_fuzzy_lookup is None:
            return True
        show_fuzzy_lookup(
            self.dbstate,
            self.uistate,
            self.track,
            surname=surname,
            given_name=given,
            on_select=lambda person: self._apply_fuzzy_match(region, person),
        )
        return True

    def cb_fuzzy_lookup_clicked(self, _menu_item) -> None:
        """
        Context-menu equivalent of _handle_pipe_icon_double_click(),
        for a row that has no way to reach that icon at all: it only
        ever appears when metadata_clue_name() is non-empty (see
        cb_clue_icon_cell_data()), so a row with no metadata clue --
        an ordinary photo with no embedded/keyword name, which is the
        common case, not the exception -- has no other route to this
        feature.

        Deliberately effective_placeholder_name(), not
        metadata_clue_name(): with no metadata clue to fall back on,
        whatever's actually sitting in the Name column (a manual edit,
        or nothing at all) is the only name this row has to offer a
        search with.

        Unlike the icon's double-click, this always opens the window
        even with a blank Surname - the double-click's own
        `if not surname: return True` guard exists because that icon
        is only visible when there's already a name to search with, so
        an empty one there means something went wrong; this menu item
        exists specifically for rows that never had one, and the
        window's own Surname field is perfectly usable empty, ready
        for the person to type into by hand.

        Passes on_select=self._apply_fuzzy_match bound to whichever
        region was selected here, same as the icon's own double-click
        (see its own docstring) and for the same reason.

        A no-op if nothing is selected, or if the Fuzzy Matching addon
        isn't installed, enabled, or new enough to register the "Fuzzy
        Match API" plugin this looks up (see
        _get_fuzzy_match_lookup()'s own docstring).

        :param _menu_item: unused (the context-menu item itself)
        """
        region = self._effective_selected_region()
        if region is None:
            return
        show_fuzzy_lookup = _get_fuzzy_match_lookup()
        if show_fuzzy_lookup is None:
            return
        given, surname = split_placeholder_name(effective_placeholder_name(region))
        show_fuzzy_lookup(
            self.dbstate,
            self.uistate,
            self.track,
            surname=surname,
            given_name=given,
            on_select=lambda person: self._apply_fuzzy_match(region, person),
        )

    def _apply_fuzzy_match(self, region, person):
        """
        on_select callback handed to the Fuzzy Matching addon's
        show_fuzzy_lookup() by _handle_pipe_icon_double_click()/
        cb_fuzzy_lookup_clicked(): applies a person double-clicked in
        that addon's own Fuzzy Match Lookup window back to `region`,
        the specific row that opened it -- see FuzzyMatchAPI.md (in
        the Fuzzy Matching addon's own folder) for that window's
        on_select calling convention.

        Without this, that window had no way to report a pick back to
        this addon at all: double-clicking a match there only opened
        that person's own editor, so the only way to actually apply a
        match to a row here was to drag it out of that window and drop
        it onto the row by hand (already-supported drag-and-drop is
        unaffected by any of this -- it's a second, independent way to
        get a match out of that window, not a fallback for this one).

        `region` is captured by the lambda built at each call site
        above, at the moment that specific lookup was opened -- not
        re-derived here from "whichever row is currently selected".
        That matters because the Fuzzy Match Lookup window re-seeds
        itself for a *different* row's lookup rather than opening a
        second window (see show_fuzzy_lookup()'s own docstring), so by
        the time someone actually double-clicks a match, the window
        could already have been re-seeded for a different row entirely
        if re-derived at call time here instead.

        Deferred via GLib.idle_add (reusing _cb_refresh_after_drop(),
        the same as every other place a Person gets set on a region
        from outside a plain button click) rather than refreshing
        directly: this callback runs from inside the Fuzzy Match
        Lookup window's own "row-activated" signal handler, and
        refreshing self.treestore synchronously from there risks the
        same GtkTreeView row-height corruption documented on
        cb_name_cell_edited().

        :param region: The region this lookup was originally opened
            for.
        :param person: The gramps.gen.lib.Person double-clicked in the
            Fuzzy Match Lookup window.
        """
        self.ask_and_set_person(region, person)
        GLib.idle_add(self._cb_refresh_after_drop)

    def open_piping_options_dialog(self, region):
        """
        Copies this row's metadata clue name to the clipboard,
        formatted as "Surname, Given" -- matching the Data Entry
        gramplet's own quick-entry field convention, and pasteable
        straight into it, or into a Fuzzy Match-style surname filter,
        or a Relationship Filter's given/surname fields. Deliberately
        metadata_clue_name(region), not effective_placeholder_name():
        this is the Metadata Clues column's own icon, so what it
        copies should be what the metadata actually said, not
        whatever's currently sitting in the (possibly hand-edited)
        Name column for the same row.

        This is currently the only implemented piping destination, so
        it's performed directly with no picker; a real chooser dialog
        belongs here once a second destination exists (see this
        method's own original design note in earlier revisions).
        """
        given, surname = split_placeholder_name(metadata_clue_name(region))
        text = ", ".join(part for part in (surname, given) if part)
        if not text:
            return
        clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        clipboard.set_text(text, -1)

    def metadata_clue_text_for(self, region, with_source=False):
        """
        The text shown in `region`'s row of the Metadata clues column
        (see refresh_list()): its own embedded/keyword-derived clue
        (region.xmp_person), annotated as "(whole photo, no region)"
        for a keyword-derived, position-less clue (see
        get_xmp_keyword_regions()), or "" if it has none -- shown
        whether or not the row has since been linked to a Person,
        same as the column itself doesn't hide a clue just because
        its row got tagged (xmp_person is never cleared by linking).

        Factored out so refresh_list() and
        transcribe_list_to_note_clicked() can't drift apart on what
        counts as a row's clue text.

        :param region: A gramplet Region.
        :param with_source: Append where the clue came from, e.g.
            "[XMP - embedded]" or "[Picasa - sidecar]" (see
            region.xmp_source). Only the Metadata clues column asks
            for this; the Note transcription keeps the bare clue.
        :returns: The clue text, possibly "".
        """
        clue = getattr(region, "xmp_person", "") or ""
        if clue and getattr(region, "xmp_whole_image", False):
            clue = _("%s (whole photo, no region)") % clue
        source = CLUE_SOURCE_LABELS.get(getattr(region, "xmp_source", ""), "")
        if clue and with_source and source:
            clue = "%s [%s]" % (clue, source)
        return clue

    def refresh_list(self):
        self.treestore.clear()
        media = self.get_current_object()
        media_date = media.get_date_object() if media else None
        # The name shown for each person is the one that was actually
        # in use as of the media's own date -- see get_name_at_date()
        # -- falling back to today when the media has no usable date
        # of its own, so a person's most current name is still shown
        # rather than an arbitrary historical one.
        name_as_of_date = self.name_as_of_date_for(media)
        self.column_person_age_header.set_text(
            self.format_person_age_header(media_date)
        )
        for i, region in enumerate(self.regions, start=1):
            metadata_clues = self.metadata_clue_text_for(region, with_source=True)
            if region.person:
                name = display_name_respecting_format(
                    get_name_at_date(region.person, name_as_of_date)
                )
                age = get_person_age(
                    region.person, self.dbstate.db, self.age_precision, media_date
                )
                age_is_suspicious = is_media_date_suspicious(
                    self.dbstate.db, region.person, media_date
                )
                person_age_markup = self.format_person_age_markup(
                    name, age, age_is_suspicious
                )
            else:
                person_age_markup = ""
            thumbnail = self.safe_get_thumbnail(region, THUMBNAIL_IMAGE_SIZE)
            self.treestore.append(
                None, (i, thumbnail, person_age_markup, metadata_clues)
            )

    def format_person_age_header(self, media_date):
        """
        Builds the 2-line "Name" / "    Age on <date>" column header.
        The age line is meaningless without knowing what date it's
        calculated as of, so it's named explicitly; it's indented 4
        spaces to visually subordinate it to the Name line above,
        matching the per-row markup built by format_person_age_markup().
        Deliberately date_has_value(), not media_date.get_valid() (see
        its own docstring) -- an empty, never-set media date used to
        pass get_valid() and be displayed/used as if it were a real
        date, which is also why no age ever showed here previously
        regardless of whether the media actually had a date: the same
        mistake in get_person_age() meant an empty birth date was
        treated as usable too, producing a nonsensical span between
        two effectively-zero dates rather than no age at all.
        """
        if date_has_value(media_date):
            date_text = date_displayer.display(media_date)
        else:
            date_text = _("undefined date")
        return "%s\n    %s" % (_("Name"), _("Age on %s") % date_text)

    def format_person_age_markup(self, name, age, age_is_suspicious):
        """
        Builds the Pango markup for a row's combined Person+Age cell:
        the person's name, then the age indented 4 spaces on its own
        line, coloured red when is_media_date_suspicious() flagged it
        (replacing the old separate Age column's foreground-set
        attribute, now that both live in a single cell).

        `age` is None whenever get_person_age() couldn't compute one
        at all (most commonly a freshly-added Person with no birth
        date yet) -- GLib.markup_escape_text() raises TypeError on
        None, so that's coerced to an empty string first rather than
        crashing the whole refresh mid-loop.
        """
        escaped_name = GLib.markup_escape_text(name or "")
        escaped_age = GLib.markup_escape_text(age or "")
        if age_is_suspicious:
            age_part = '<span foreground="red">%s</span>' % escaped_age
        else:
            age_part = escaped_age
        return "%s\n    %s" % (escaped_name, age_part)

    def safe_get_thumbnail(self, region, thumbnail_size):
        """
        For an unrotated photo, wraps SelectionWidget.get_thumbnail()
        with the same width/height check it already does, plus a
        check it is missing: its own resize_keep_aspect() computes the
        scaled size with integer division, which rounds down to 0 for
        a very thin/wide region (e.g. width 1000, height 1 scaling
        into a 50x50 box) and that 0 then reaches
        gdk_pixbuf_scale_simple(), which logs a 'dest_height > 0' (or
        width) GdkPixbuf-CRITICAL to the console.

        For a rotated one, bypasses SelectionWidget.get_thumbnail()
        entirely: it was observed to still crop from the image's own
        native, unrotated bytes regardless of what's actually being
        displayed -- not just the wrong orientation, but the wrong
        crop, since the region's own coordinates are relative to the
        *rotated* canvas. self._rotated_pixbuf (see load_image()) is
        the exact full-resolution bitmap the Preview panel shows, so
        thumbnails are cropped from that directly instead (see
        _crop_rotated_thumbnail()).
        """
        width = region.x2 - region.x1
        height = region.y2 - region.y1
        if width < 1 or height < 1:
            return None
        target_x, target_y = thumbnail_size
        if width / height > target_x / target_y:
            scaled_height = target_x * height // width
            if scaled_height < 1:
                return None
        else:
            scaled_width = target_y * width // height
            if scaled_width < 1:
                return None
        if self.rotation_degrees and self._rotated_pixbuf is not None:
            return self._crop_rotated_thumbnail(region, thumbnail_size)
        return self.selection_widget.get_thumbnail(region, thumbnail_size)

    def _crop_rotated_thumbnail(self, region, thumbnail_size):
        """
        Crops a thumbnail directly from self._rotated_pixbuf -- the
        exact full-resolution bitmap the Preview panel is currently
        showing -- rather than through SelectionWidget.get_thumbnail()
        (see safe_get_thumbnail()'s own docstring for why that isn't
        safe to use once the photo is rotated).

        :param region: A gramplet Region, in the same real/display
            coordinates SelectionWidget itself uses (region.coords()).
        :param thumbnail_size: (width, height) target box, aspect
            preserved -- same contract as SelectionWidget's own
            get_thumbnail().
        :returns: A GdkPixbuf.Pixbuf, or None on failure.
        """
        try:
            left, top, right, bottom = self.selection_widget.real_to_proportional_rect(
                region.coords()
            )
            pixbuf = self._rotated_pixbuf
            full_width = pixbuf.get_width()
            full_height = pixbuf.get_height()
            x = max(0, round(left / 100 * full_width))
            y = max(0, round(top / 100 * full_height))
            crop_width = min(full_width - x, round((right - left) / 100 * full_width))
            crop_height = min(
                full_height - y, round((bottom - top) / 100 * full_height)
            )
            if crop_width < 1 or crop_height < 1:
                return None
            cropped = pixbuf.new_subpixbuf(x, y, crop_width, crop_height)
            target_x, target_y = thumbnail_size
            if crop_width / crop_height > target_x / target_y:
                scaled_width = target_x
                scaled_height = max(1, round(target_x * crop_height / crop_width))
            else:
                scaled_height = target_y
                scaled_width = max(1, round(target_y * crop_width / crop_height))
            return cropped.scale_simple(
                scaled_width, scaled_height, GdkPixbuf.InterpType.BILINEAR
            )
        except (GLib.GError, ValueError):
            LOG.exception("PhotoTagging: could not crop rotated thumbnail")
            return None

    def _focus_treeview_row_only(self, region) -> None:
        """
        The treeview-cursor half of apply_selected_region(), without
        the rest of it: used by _cb_refresh_selection_once() and
        _cb_refresh_after_reorder() in place of apply_selected_region()
        while quick_draw_toggled()'s quick draw mode is active, so the
        region list's own row selection can still track the last-drawn
        or last-reordered region without also calling
        self.selection_widget.select(region) -- which, per
        marquees_toggled()'s own
        docstring, is exactly what makes SelectionWidget narrow its
        own drawing down to that one region alone, regardless of what
        full regions list it was handed. Quick draw mode's whole point
        is seeing every already-tagged marquee at once while placing
        new ones, so the on-image widget's own "current" region is
        deliberately left alone here (cleared, on entry, by
        quick_draw_toggled() itself) rather than switched to `region`
        the way it normally would be.

        :param region: The Region whose row should be focused, or
            None (nothing to focus).
        """
        if region is None or region not in self.regions:
            return
        path = Gtk.TreePath.new_from_indices([self.regions.index(region)])
        self.treeview.set_cursor(path)
        self.scroll_to_selected_row()

    def refresh_selection(self):
        """
        Re-applies the currently selected region (self.selection_widget's
        own current-region state, which -- unlike the treeview's row
        selection -- survives refresh_list() clearing and rebuilding
        the treestore) everywhere via apply_selected_region(): the
        region list, the marquee, and the Caption panel highlight.
        Called by refresh() directly; everywhere else, always through
        self._schedule_refresh_selection() below, never directly.
        """
        self.apply_selected_region(self.selection_widget.get_current())

    def _schedule_refresh_selection(self, region=_UNSET_REGION) -> None:
        """
        Schedules a single, doubly-deferred reselection, coalescing
        repeat requests within the same event cascade into one.

        main(), region_modified(), region_created(), del_region_
        clicked(), and cb_person_edited() can all end up firing within
        the very same click or edit -- region_modified(), in
        particular, can itself trigger a *nested* call to main() (see
        its own docstring) -- each independently wanting a reselection
        once the dust settles; calling through here rather than
        GLib.idle_add() directly, guarded by
        self._refresh_selection_pending, ensures only one such call is
        actually scheduled per cascade, not one per site that asked.

        :param region: The specific Region to reselect once the defer
            completes -- for del_region_clicked() and
            cb_person_edited(), where it must be a specific one that
            self.selection_widget.get_current() is not guaranteed to
            still agree with by the time the deferred call actually
            runs (particularly for del_region_clicked(), which is
            reselecting a region other than the one just deleted).
            Left at the _UNSET_REGION sentinel (region cannot be
            passed as plain ``None`` for this -- selecting *no*
            region is itself a legitimate, real value for it, as
            del_region_clicked() also relies on when the list becomes
            empty) by main()/region_modified()/region_created(),
            which just want whatever self.selection_widget.
            get_current() turns out to be by then, resolved fresh
            only once the deferred call actually runs, the same as
            refresh_selection() itself already does.

            There is only ever one pending reselection at a time, for
            one target, so a second call while one is already pending
            (e.g. main()'s own nested call inside region_modified(),
            or main()'s db-signal-triggered reselection and
            cb_person_edited()'s racing each other -- the relative
            order between an Edit Person save's db-commit signal and
            its own save callback isn't nailed down here) has to
            reconcile against whatever the first already staged: an
            explicit region always overrides it, whether the first
            call was explicit or not (last explicit request wins);
            *not* passing one never overrides an explicit region an
            earlier call in the same still-pending cascade already
            staged, so a specific target set by del_region_clicked()/
            cb_person_edited() survives a later, less specific
            request from main()/region_modified()/region_created()
            regardless of which happened to run first.

        Deferred *twice* (one idle callback scheduling a second),
        rather than once: this ends in Gtk.TreeView.set_cursor(), and
        a single idle_add -- enough to get past the treeview's model
        having just been rebuilt by refresh_list(), and, for main(),
        past self.top.show() -- was not always enough extra settle
        time to prevent set_cursor() from sporadically landing on the
        wrong (typically the next) row after resizing a marquee via
        one of its handles. The second idle_add here gives it one
        more full main-loop pass, the same extra margin
        scroll_to_selected_row()'s own nested idle_add already relies
        on for the same underlying reason.
        """
        if region is not _UNSET_REGION or not self._refresh_selection_pending:
            self._refresh_selection_target = region
        if self._refresh_selection_pending:
            return
        self._refresh_selection_pending = True
        GLib.idle_add(self._cb_refresh_selection_settle)

    def _cb_refresh_selection_settle(self) -> bool:
        """
        First of the two deferred steps self._schedule_refresh_
        selection() above schedules -- see its own docstring for why
        two are needed.

        :returns: ``GLib.SOURCE_REMOVE``, so this one-shot idle
            callback is not called again.
        """
        GLib.idle_add(self._cb_refresh_selection_once)
        return GLib.SOURCE_REMOVE

    def _cb_refresh_selection_once(self) -> bool:
        """
        Second of the two deferred steps self._schedule_refresh_
        selection() above schedules -- see its own docstring for why
        two are needed.

        :returns: ``GLib.SOURCE_REMOVE``, so this one-shot idle
            callback is not called again.
        """
        self._refresh_selection_pending = False
        target = self._refresh_selection_target
        self._refresh_selection_target = _UNSET_REGION
        if self.quick_draw_mode:
            if target is _UNSET_REGION:
                target = self.selection_widget.get_current()
            self._focus_treeview_row_only(target)
            return GLib.SOURCE_REMOVE
        if target is _UNSET_REGION:
            self.refresh_selection()
        else:
            self.apply_selected_region(target)
        return GLib.SOURCE_REMOVE


def date_has_value(date) -> bool:
    """
    Whether `date` (a gramps.gen.lib.Date, as returned by any
    DateBase.get_date_object() -- a Media object's, an Event's, a
    Name's) actually has date information entered on it at all.

    Deliberately NOT date.get_valid(): per Gramps' own gen/lib/date.py,
    ``get_valid()`` returns ``self.modifier != Date.MOD_TEXTONLY or
    self.get_text() == ""`` -- true for almost anything, including a
    completely empty, never-touched ``Date()``, which is what
    ``get_date_object()`` returns (never ``None``) for a Media/Event/
    Name that has no date set at all. "Valid" here means "not an
    unparseable text-only date", not "has actual content" -- so
    ``get_valid()`` was never the right check for "does this object
    have a usable date", and every place in this file that used it
    that way (deciding whether to use the media's own date vs. Today,
    whether a birth/death date is usable for an age or a suspicious-
    date check, whether a Name has a date to compete with another
    Name's) was silently treating "no date at all" the same as "a
    real, specific date" throughout.

    ``Date.is_empty()`` (used internally by Gramps' own
    ``gen/lib/datebase.py``) is the actual "was anything entered here"
    check.

    :param date: A Date instance, or None.
    :returns: True if `date` is present and has real content.
    """
    return date is not None and not date.is_empty()


# Average days per month, close enough for the plausibility check below.
AVG_MONTH_DAYS = 30.44


def is_media_date_suspicious(dbstate_db, person, media_date):
    """
    Returns True if media_date is more than 10 months before the
    person's fallback birthdate, or more than a month after their
    fallback death date -- flagging an age that suggests the photo's
    date, or the person tagged, may be wrong.

    Deliberately date_has_value(), not .get_valid(), throughout (see
    its own docstring) -- an empty birth/death/media date used to pass
    get_valid() and compete here as if it were a real date at sort
    value 0, which could flag an entirely undated person as "10 months
    before" any media with a real date, or vice versa.
    """
    if not date_has_value(media_date):
        return False
    media_sort = media_date.get_sort_value()

    birth = get_birth_or_fallback(dbstate_db, person)
    if birth:
        birth_date = birth.get_date_object()
        if date_has_value(birth_date):
            if birth_date.get_sort_value() - media_sort > 10 * AVG_MONTH_DAYS:
                return True

    death = get_death_or_fallback(dbstate_db, person)
    if death:
        death_date = death.get_date_object()
        if date_has_value(death_date):
            if media_sort - death_date.get_sort_value() > AVG_MONTH_DAYS:
                return True

    return False


def get_person_age(person, dbstate_db, age_precision, media_date=None):
    """
    Function to get the person's age, calculated from the fallback
    birthdate. When media_date actually has date information on it
    (see date_has_value() -- not media_date.get_valid(), which is true
    even for a media object with no date at all), the age is
    calculated as of that date (i.e. the person's age in the photo).
    Otherwise this falls back to today's date -- the same rule
    refresh_list() already applies to name selection (see
    name_as_of_date) -- rather than distinguishing a living person's
    current age from a deceased person's age at death.

    Also date_has_value() for birth_date, for the same reason: an
    empty birth date (a birth Event recorded with no actual date
    entered on it) used to pass get_valid() and be subtracted from
    as-of-date as if it were a real date -- as_of_date minus an
    effectively-year-zero date -- which is likely why no age ever
    showed here at all, for anyone whose birth event has no date
    filled in, regardless of whether the media itself had one.

    Returns string for age column.
    """
    birth = get_birth_or_fallback(dbstate_db, person)

    if birth:
        birth_date = birth.get_date_object()
        if date_has_value(birth_date):
            if date_has_value(media_date):
                as_of_date = media_date
            else:
                as_of_date = Today()
            age = as_of_date - birth_date
            return age.format(precision=age_precision)
    return None


def display_name_respecting_format(name):
    """
    Render a Name using its own "Display As" format, working around
    an apparent gap in Gramps 5.2's name-evaluation system: testing
    showed NameDisplay.display_name(name) silently falls back to the
    global default format -- ignoring a Name's own display_as -- for
    any Name that has no date set on it, whether that Name is a
    Person's primary name or an alternate. Since that happens even
    for an unmodified primary name (nothing in get_name_at_date()
    touches how a name gets rendered, only which Name object is
    chosen), the gap must live inside display_name() itself, not in
    this file -- so this bypasses it entirely rather than trying to
    work around whatever internal date logic causes it, using only
    the lower-level, purely mechanical pieces of the same public
    NameDisplay API: resolve display_as to a concrete format string
    ourselves (get_name_format()/get_default_format()), then apply it
    with format_str(), which does no format *selection* of its own.

    NAME_DISPLAY_FORMAT_OVERRIDE (see the "Display as:" option on the
    Options tab of this gramplet's own settings) takes priority over
    both of the above when set to anything other than Name.DEF: this
    gramplet's own Name column and Caption generator - the only two
    callers of this function - then render every name the same way
    regardless of that Name's own display_as field or the current
    Preferences > Data > Name format, exactly as if this were the
    format Preferences itself had selected. Left at Name.DEF (its
    default - "Default format (defined by Gramps preferences)" in
    that option's own dropdown), behaviour is unchanged from before
    this setting existed: each Name's own display_as field still
    takes priority over the global default, per-Name, the way Gramps
    itself does everywhere else.

    :param name: The Name instance to render.
    :returns: The formatted name string.
    """
    if name is None:
        return ""
    try:
        display_as = NAME_DISPLAY_FORMAT_OVERRIDE or Name.DEF
        if display_as == Name.DEF:
            display_as = getattr(name, "display_as", 0) or 0
        if display_as == Name.DEF:
            # Name.DEF's own format_str is a permanent empty
            # placeholder (see get_name_format()'s "also_default"
            # entry) -- the *actual* format it stands for is whatever
            # get_default_format() currently points at.
            display_as = name_displayer.get_default_format()
        format_by_num = {
            num: fmt_str
            for num, _label, fmt_str, _active in name_displayer.get_name_format(
                also_default=False
            )
        }
        fmt_str = format_by_num.get(display_as) or format_by_num.get(
            name_displayer.get_default_format()
        )
        if not fmt_str:
            raise LookupError("no usable name format found")
        return name_displayer.format_str(name, fmt_str)
    except Exception:  # pylint: disable=broad-except
        # Never let a name-formatting corner case crash the gramplet
        # -- fall back to Gramps' own (possibly gap-affected)
        # resolution rather than showing nothing at all.
        LOG.exception("PhotoTagging: could not apply Name.display_as")
        return name_displayer.display_name(name)


def display_placeholder_name(name_text):
    """
    Renders a placeholder name string -- an unlinked region's
    effective_placeholder_name() (see REGION_DATA_ATTR_TYPE) -- in the
    user's own Name Display format (Preferences' Surname/Given order,
    Given/Surname, or whatever else it's set to), the same way a
    linked row's Person name is rendered via
    display_name_respecting_format().

    A placeholder is just a plain string, not a Gramps Name -- typed
    into an XMP/MWG region, an Xmp.dc.subject keyword, or directly
    into this gramplet's own Name cell -- so it's parsed with
    split_placeholder_name() into given/surname first, then wrapped in
    a throwaway Name(), the same construction add_person_clicked()
    already uses to prefill a new Person's primary name from the same
    source, purely so it can be handed to the same formatter a linked
    row already uses. A fresh Name() has no display_as of its own
    (Name.DEF), so display_name_respecting_format() falls back to
    whatever the user's current default format is -- exactly the
    "whatever it's set to" behaviour wanted here.

    :param name_text: The placeholder text, e.g. from
        effective_placeholder_name().
    :returns: The formatted name string, or "" if `name_text` is
        empty or doesn't split into any given/surname at all.
    """
    if not name_text:
        return ""
    given, surname = split_placeholder_name(name_text)
    if not given and not surname:
        return name_text
    name = Name()
    name.set_first_name(given)
    if surname:
        surname_obj = Surname()
        surname_obj.set_surname(surname)
        name.set_surname_list([surname_obj])
    return display_name_respecting_format(name)


def get_name_at_date(person, target_date):
    """
    Return the Name instance that was actually in use by a person as
    of a given date, i.e. the name display should reflect who they
    were called *at that point in their life* -- their birth name in
    a childhood photo, a married name in a later one -- rather than
    always their current primary name.

    Chooses among the primary name and every alternate name (each a
    Name, which -- like Person's birth/death events elsewhere in this
    file -- carries its own optional DateBase date) for the one with
    the latest date that is still on or before target_date, the same
    get_sort_value()-based comparison already used by
    is_media_date_suspicious()/get_person_age() above. Falls back to
    the primary name when no name has a usable date at all (by far
    the common case) or when target_date predates every dated name
    (e.g. a childhood photo, before any later name was adopted).

    Requires date_has_value(name_date), not name_date.get_valid(): per
    Gramps' own gen/lib/date.py, get_valid() is true for almost any
    Date, including a completely empty, never-set one -- which is what
    get_date_object() returns (never None) for a Name with no date
    entered at all, the overwhelmingly common case for a primary name
    in particular. With that check, an empty primary name's date
    competed at sort value 0 rather than being excluded, so a
    *dated* alternate name -- even one with an early, otherwise
    perfectly reasonable date -- would beat an *undated* primary
    outright, every time, since 0 read as "older than everything" for
    comparison purposes despite meaning "no date entered" rather than
    "the earliest possible date". A dated alternate now only wins when
    it genuinely has date information recorded on it; an undated
    primary is no longer treated as if it had one, at year zero.

    :param person: The Person whose Name to select.
    :param target_date: The Date to select a Name as of -- typically
        the media's own date, or Today() when it has none.
    :returns: A Name instance.
    """
    primary_name = person.get_primary_name()
    target_sort = target_date.get_sort_value() if target_date else 0

    best_name = primary_name
    best_sort = -1
    for name in [primary_name] + list(person.get_alternate_names()):
        name_date = name.get_date_object()
        if not date_has_value(name_date):
            continue
        name_sort = name_date.get_sort_value()
        if best_sort < name_sort <= target_sort:
            best_name = name
            best_sort = name_sort
    return best_name
