# Icon List (Photo Tagging Gramplet )
[ReadMe](../../README.md) ● [Change Log](../../CHANGELOG.md) ● [XMP data](../../XMP_Region_Name.md) ● [Icon List](ICONLIST.md) 

![](ClosedCaption.svg) 
![](XMP_logo.svg)
![](gtk-index.svg) 
![](List-add.svg) 
![](List-remove.svg) 
![](gtk-edit.svg) 
![](Gnome-view-sort-ascending.svg) 
![](Gnome-view-sort-ascending (copy).svg) 
![](Gnome-view-sort-descending.svg) 
![](Gnome-view-sort-descending (copy).svg) 
![](gramps-zoom-in.svg) 
![](gramps-zoom-out.svg) 
![](gramps-face-detection.svg) 


### Not used
![](Emblem-equal.svg) 

