#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026  <Author Name>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Add an "Insert Symbols" item to the native GTK context menu of a text
entry or text view, next to the built-in "Insert Emoji" item.

Clicking a symbol inserts it and closes the popover immediately, the
same way GTK's own Cut/Copy/Paste/Insert Emoji menu items behave. For
inserting several symbols in a row, the popover offers a single
"undock" button that hands off to a caller-supplied factory -- for
example one that opens a persistent Virtual Keyboard window.
"""

# ------------------------
# Python modules
# ------------------------
from __future__ import annotations

import logging
from typing import Callable

# ------------------------
# GTK modules
# ------------------------
import gi

gi.require_version("Gtk", "3.0")

# pylint: disable=wrong-import-position,no-name-in-module
from gi.repository import Gtk

# ------------------------
# Gramps modules
# ------------------------
# pylint: disable=wrong-import-position
from gramps.gen.const import GRAMPS_LOCALE as glocale
from gramps.gen.utils.symbols import Symbols
from gramps.gui.widgets.textinsertion import insert_text_at_cursor

_ = glocale.translation.sgettext

LOG = logging.getLogger(".widgets.symbolpopover")

# A category is a name paired with a list of (label, character) pairs.
SymbolCategory = tuple[str, list[tuple[str, str]]]

# An undock factory is called with the target widget when the popover's
# undock button is clicked. It is responsible for opening whatever
# persistent window it wants (e.g. a Virtual Keyboard) and does not
# need to return anything; the popover closes as soon as it is called.
UndockFactory = Callable[[Gtk.Widget], None]


# ------------------------------------------------------------
#
# SymbolPopover
#
# ------------------------------------------------------------
class SymbolPopover(Gtk.Popover):
    """
    A popover offering a grid of insertable symbols.

    Clicking a symbol inserts it into the target widget and closes the
    popover immediately, matching the single-shot behavior of GTK's
    own context-menu actions. An optional undock button hands off to a
    persistent window for inserting several symbols in a row.
    """

    def __init__(
        self,
        relative_to: Gtk.Widget,
        extra_categories: list[SymbolCategory] | None = None,
        undock_label: str | None = None,
        undock_factory: UndockFactory | None = None,
    ) -> None:
        """
        Initialize the popover and build its symbol grid.

        :param relative_to: The entry or text view the popover targets.
        :param extra_categories: Additional (name, symbols) categories,
            appended after the built-in genealogical symbols.
        :param undock_label: Label for the undock button, e.g.
            ``_("Open Virtual Keyboard")``. Omit to hide the button.
        :param undock_factory: Called with the target widget when the
            undock button is clicked. Required if ``undock_label`` is
            given.
        """
        Gtk.Popover.__init__(self)
        self.set_relative_to(relative_to)
        self.set_position(Gtk.PositionType.BOTTOM)
        self._target = relative_to
        self._undock_factory = undock_factory
        self._build_ui(extra_categories or [], undock_label)

    def _build_ui(
        self,
        extra_categories: list[SymbolCategory],
        undock_label: str | None,
    ) -> None:
        """
        Build the notebook of symbol categories and the undock button.

        :param extra_categories: Additional categories supplied by the
            caller, appended after the built-in genealogical symbols.
        :param undock_label: Label for the undock button, or ``None``
            to omit it.
        """
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.set_margin_top(6)
        box.set_margin_bottom(6)
        box.set_margin_start(6)
        box.set_margin_end(6)

        notebook = Gtk.Notebook()
        notebook.set_scrollable(True)
        for name, symbol_list in self._get_categories() + extra_categories:
            notebook.append_page(
                self._build_category_page(symbol_list), Gtk.Label(label=name)
            )
        box.pack_start(notebook, True, True, 0)

        if undock_label is not None:
            button_box = Gtk.ButtonBox(orientation=Gtk.Orientation.HORIZONTAL)
            button_box.set_layout(Gtk.ButtonBoxStyle.END)
            undock_button = Gtk.Button(label=undock_label)
            undock_button.connect("clicked", self.cb_undock_clicked)
            button_box.pack_start(undock_button, False, False, 0)
            box.pack_start(button_box, False, False, 0)

        self.add(box)
        box.show_all()

    def _build_category_page(
        self, symbol_list: list[tuple[str, str]]
    ) -> Gtk.ScrolledWindow:
        """
        Build one scrollable flow-box page of symbol buttons.

        :param symbol_list: A list of (label, character) pairs.
        :returns: A scrolled window containing the flow box of buttons.
        """
        flowbox = Gtk.FlowBox()
        flowbox.set_max_children_per_line(10)
        flowbox.set_selection_mode(Gtk.SelectionMode.NONE)
        flowbox.set_valign(Gtk.Align.START)
        for label, symbol in symbol_list:
            button = Gtk.Button(label=symbol)
            button.set_relief(Gtk.ReliefStyle.NONE)
            button.set_tooltip_text(label)
            button.connect("clicked", self.cb_symbol_clicked, symbol)
            flowbox.add(button)

        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_min_content_width(300)
        scrolled.set_min_content_height(220)
        scrolled.add(flowbox)
        return scrolled

    @staticmethod
    def _get_categories() -> list[SymbolCategory]:
        """
        Return the built-in genealogical symbol categories.

        Symbol data is taken from :class:`gramps.gen.utils.symbols.Symbols`
        instead of duplicating a Unicode table here.

        :returns: A list of (category name, [(label, character), ...]).
        """
        symbols = Symbols()

        general = [
            (symbols.get_symbol_name(i), symbols.get_symbol_for_string(i))
            for i in range(len(symbols.all_symbols))
        ]
        death = [
            (symbols.get_death_symbol_name(i), symbols.get_death_symbol_for_char(i))
            for i in range(len(symbols.get_death_symbols()))
            if symbols.get_death_symbol_for_char(i)
        ]
        return [
            (_("Genealogical symbols"), general),
            (_("Death symbols"), death),
        ]

    def cb_symbol_clicked(self, _button: Gtk.Button, symbol: str) -> None:
        """
        Insert the clicked symbol into the target widget and close.

        Mirrors the single-shot behavior of GTK's own context-menu
        actions (Cut, Copy, Paste, Insert Emoji).

        :param _button: The clicked symbol button (unused).
        :param symbol: The character to insert.
        """
        insert_text_at_cursor(self._target, symbol)
        self.popdown()

    def cb_undock_clicked(self, _button: Gtk.Button) -> None:
        """
        Close the popover and hand off to the undock factory.

        :param _button: The clicked undock button (unused).
        """
        self.popdown()
        if self._undock_factory is not None:
            self._undock_factory(self._target)


def cb_populate_popup(
    widget: Gtk.Widget,
    menu: Gtk.Widget,
    extra_categories: list[SymbolCategory] | None = None,
    undock_label: str | None = None,
    undock_factory: UndockFactory | None = None,
) -> None:
    """
    Add an "Insert Symbols" item to a widget's native context menu.

    Connected to the ``populate-popup`` signal of a :class:`Gtk.Entry`
    or :class:`Gtk.TextView`. Runs alongside GTK's own "Insert Emoji"
    item rather than replacing it.

    :param widget: The entry or text view whose menu is being built.
    :param menu: The context menu GTK is populating.
    :param extra_categories: Additional symbol categories to offer.
    :param undock_label: Label for the popover's undock button.
    :param undock_factory: Called with ``widget`` when the undock
        button is clicked.
    """
    if not isinstance(menu, Gtk.MenuShell):
        LOG.debug("populate-popup did not supply a menu; skipping.")
        return

    menu.append(Gtk.SeparatorMenuItem())
    item = Gtk.MenuItem(label=_("Insert _Symbols…"), use_underline=True)

    def cb_item_activate(_menu_item: Gtk.MenuItem) -> None:
        """Show the symbol popover anchored to the target widget."""
        popover = SymbolPopover(widget, extra_categories, undock_label, undock_factory)
        popover.popup()

    item.connect("activate", cb_item_activate)
    menu.append(item)
    menu.show_all()


def attach_symbol_popup(
    widget: Gtk.Entry | Gtk.TextView,
    extra_categories: list[SymbolCategory] | None = None,
    undock_label: str | None = None,
    undock_factory: UndockFactory | None = None,
) -> None:
    """
    Attach an "Insert Symbols" context-menu item to a widget.

    :param widget: The entry or text view to augment. Must support the
        ``populate-popup`` signal.
    :param extra_categories: Additional (name, symbols) categories.
    :param undock_label: Label for the popover's undock button, e.g.
        ``_("Open Virtual Keyboard")``. Omit to hide the button.
    :param undock_factory: Called with ``widget`` when the undock
        button is clicked. Should load the target addon on demand via
        ``gramps.gui.widgets.addonlookup.load_addon_function`` rather
        than hard-importing it, so this works regardless of whether
        that addon has been loaded yet this session, and degrades
        gracefully if it isn't installed::

            from functools import partial
            from gramps.gui.widgets.addonlookup import load_addon_function

            def open_virtual_keyboard(target, uistate, track=None):
                open_fn = load_addon_function(
                    "VirtualKeyboard",
                    "open_virtual_keyboard_window",
                    uistate,
                    _("Virtual Keyboard"),
                )
                if open_fn is not None:
                    open_fn(target, uistate, track=track)

            attach_symbol_popup(
                entry,
                undock_label=_("Open Virtual Keyboard"),
                undock_factory=partial(
                    open_virtual_keyboard, uistate=self.uistate, track=self.track
                ),
            )
    """
    widget.connect(
        "populate-popup",
        cb_populate_popup,
        extra_categories,
        undock_label,
        undock_factory,
    )
