#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026  <Author Name>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Load a public function from another registered plugin on demand.

One plugin often needs to call into a second, independent plugin's own
window/API without hard-importing it -- hard-importing assumes the
second plugin's module is already on ``sys.path`` and already loaded,
which may not be true if it hasn't been used yet this session. Going
through the plugin registry instead works regardless of load order,
and degrades gracefully (with an on-screen explanation) if the other
plugin isn't installed, fails to load, or is an older version that
doesn't yet expose the expected function.
"""

# ------------------------
# Python modules
# ------------------------
from __future__ import annotations

import logging
from typing import Callable

# ------------------------
# Gramps modules
# ------------------------
from gramps.gen.const import GRAMPS_LOCALE as glocale
from gramps.gen.plug import PluginRegister
from gramps.gui.dialog import OkDialog
from gramps.gui.pluginmanager import GuiPluginManager

_ = glocale.translation.sgettext

LOG = logging.getLogger(".widgets.addonlookup")


def load_addon_function(
    plugin_id: str,
    function_name: str,
    uistate,
    addon_label: str,
) -> Callable | None:
    """
    Look up, load, and return a public function from another plugin.

    Mirrors the on-demand load-and-degrade-gracefully approach used to
    launch the Markdown Dash gramplet's reader window from elsewhere
    in Gramps: look the plugin up in the registry, load its module,
    and fetch the named function -- showing an explanatory
    :class:`~gramps.gui.dialog.OkDialog` and returning ``None`` at
    whichever step fails, rather than raising.

    :param plugin_id: The target plugin's registered ``id``, e.g.
        ``"VirtualKeyboard"``.
    :param function_name: The name of the public, module-level
        function to fetch from the loaded plugin module.
    :param uistate: The Gramps GUI state, used to parent the
        explanatory dialog on failure.
    :param addon_label: The addon's display name, used in dialog text,
        e.g. ``"Virtual Keyboard"``.
    :returns: The requested callable, or ``None`` if the plugin isn't
        registered, fails to load, or doesn't expose that function.
    """
    preg = PluginRegister.get_instance()
    pdata = preg.get_plugin(plugin_id)
    if pdata is None or not pdata.fpath:
        OkDialog(
            _("%s not found") % addon_label,
            _(
                "The %s addon isn't currently registered. Check that "
                "it is installed and enabled."
            )
            % addon_label,
            parent=uistate.window,
        )
        return None

    pmgr = GuiPluginManager.get_instance()
    mod = pmgr.load_plugin(pdata)
    if not mod:
        OkDialog(
            _("Could not load %s") % addon_label,
            _("%s is registered, but its module failed to load.") % addon_label,
            parent=uistate.window,
        )
        return None

    func = getattr(mod, function_name, None)
    if func is None:
        OkDialog(
            _("%s is out of date") % addon_label,
            _(
                "The installed version of %s doesn't provide the "
                "%s() function this needs. Try updating %s."
            )
            % (addon_label, function_name, addon_label),
            parent=uistate.window,
        )
        return None

    return func
