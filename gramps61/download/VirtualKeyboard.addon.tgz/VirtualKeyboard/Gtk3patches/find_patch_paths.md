``` python
# Paste this into the "Python Evaluation" gramplet's Evaluation box and
# click Apply. It finds the real, on-this-machine paths needed for the
# manual install steps in Hacking.md, and displays them using Gramps'
# own SimpleDoc / TextBufDoc mechanism -- the same one Gramps' built-in
# Quick View reports use to show text -- rather than a bespoke window.
#
# Note: the window this opens is titled "Quick View" no matter what --
# that title is hard-coded inside TextBufDoc.open() itself, not
# something this script controls. The heading written below, inside
# the window's content, is the actual report title.
#
# IMPORTANT: this script deliberately avoids defining any function
# (no `def`). PythonEvaluation.apply_clicked() calls exec(text) with
# two separate dicts for globals and locals (eval.py's module globals,
# and apply_clicked's own frame locals). Top-level statements here --
# including `import os` -- bind into that locals dict and resolve
# correctly. But a function defined inside this exec'd code gets its
# __globals__ fixed to the *globals* dict, which never sees anything
# bound only in locals -- so it would raise NameError on `os` the
# moment it tried to use it. Keeping everything flat and top-level
# avoids that trap entirely.
#
# This script also uses one name it does not import: `self`, the
# running Python Evaluation gramplet, reachable for the same reason --
# it's a local variable in apply_clicked's frame -- and the Gramplet
# base class already sets self.uistate.

import os

import gramps
import gramps.gui.widgets as widgets_pkg
from gramps.gen.plug import PluginRegister
from gramps.gen.simple import SimpleDoc, make_basic_stylesheet
from gramps.gui.plug.quick import TextBufDoc
from gramps.version import major_version, VERSION_TUPLE

gramps_dir = os.path.dirname(os.path.abspath(gramps.__file__))
widgets_dir = os.path.dirname(os.path.abspath(widgets_pkg.__file__))
monitored_path = os.path.join(widgets_dir, "monitoredwidgets.py")

doc = TextBufDoc(make_basic_stylesheet(), None, track=[], uistate=self.uistate)
doc.open("")
sdoc = SimpleDoc(doc)

sdoc.title("Gtk3 Patch Paths for Gramps 5.2-6.1")

if VERSION_TUPLE < (5, 2, 0) or VERSION_TUPLE >= (6, 2, 0):
    sdoc.header1("Warning: unverified Gramps version")
    sdoc.paragraph(
        "This patch set was checked against Gramps 5.2.0, 6.0.0, and "
        "current master (ahead of 6.0.8 / 6.1.0-beta1). The running "
        "version, " + major_version + ", falls outside that verified "
        "5.2-6.1 range -- proceed with extra caution."
    )

sdoc.header1("Gramps " + major_version + " package folder")
sdoc.paragraph(gramps_dir)

sdoc.header1("Step 2: copy these files into this folder")
sdoc.paragraph("textinsertion.py, symbolpopover.py, addonlookup.py")
sdoc.paragraph(widgets_dir)

sdoc.header1("Step 4: file to patch for Insert Symbols wiring")
sdoc.paragraph(monitored_path)

preg = PluginRegister.get_instance()
pdata = preg.get_plugin("VirtualKeyboard")

sdoc.header1("Step 3: Virtual Keyboard add-on")
if pdata is None:
    sdoc.paragraph("Not installed or not registered.")
    sdoc.paragraph(
        "Install it via Edit -> Addon Manager, with the Audience and "
        "Status filters set to 'All', then search for 'Virtual Keyboard'."
    )
else:
    vk_version = pdata.version or ""
    try:
        vk_version_tuple = tuple(int(part) for part in vk_version.split("."))
    except ValueError:
        vk_version_tuple = None

    if vk_version_tuple is not None and vk_version_tuple >= (1, 4, 0):
        sdoc.paragraph(
            "Installed version " + vk_version + " -- already satisfies "
            "Step 3, nothing further needed here."
        )
    else:
        sdoc.paragraph(
            "Installed version: " + (vk_version or "unknown") + ". Update "
            "to 1.4.0 or later via Edit -> Addon Manager (Audience and "
            "Status filters set to 'All') to get the bundled undock "
            "window without any manual file replacement."
        )

doc.close()
print("Opened the patch-paths report in a Quick View window.")
```
