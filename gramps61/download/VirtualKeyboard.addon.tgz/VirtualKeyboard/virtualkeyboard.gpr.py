#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026 Brian McCullough
#      (prompting Perplexity AI Assistant, Cursor and Copilot)
#      (prompting Claude, Anthropic -- v1.4.0 compatibility/undock update)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#
# Generated: January 17, 2026 - Perplexity AI Assistant v1.0
# Updated: v1.4.0 - Claude, Anthropic (undockable window, Gtk3 5.2-6.1 verify)
# virtualkeyboard.gpr.py
# Virtual Keyboard Gramplet plug-in registration generated for Gramps
# Touch-friendly on-screen keyboard for clipboarded data entry, and for
# typing directly into other Gramps fields via the "Insert Symbols"
# context-menu patch's undock button
# Default: Special (accented) layout

from gramps.gen.const import GRAMPS_LOCALE as glocale
from gramps.gui import plug
from gramps.version import major_version, VERSION_TUPLE

if (5, 2, 0) <= VERSION_TUPLE <= (6, 2, 0):
    register(
        GRAMPLET,
        id="VirtualKeyboard",
        name=_("Virtual Keyboard"),
        description=_(
            "Touch-friendly on-screen keyboard for clipboarding characters, "
            "or typing them directly into another Gramps field"
        ),
        audience=EVERYONE,
        status=BETA,
        authors=["Brian McCullough", "Perplexity AI Assistant, Claude AI"],
        authors_email=["emyoulation@yahoo.com", "", ""],
        maintainers="Brian McCullough",
        maintainers_email="Emyoulation@yahoo.com",
        fname="virtualkeyboard.py",
        height=280,
        expand=False,
        gramplet="VirtualKeyboard",
        gramplet_title=_("Virtual Keyboard"),
        version="1.4.0",
        gramps_target_version=major_version,
        navtypes=[
            "Dashboard",
            "Person",
            "Family",
            "Event",
            "Place",
            "Source",
            "Citation",
            "Repository",
            "Media",
            "Note",
        ],
        # help_url="Addon:Virtual_Keyboard",
        help_url="https://gramps.discourse.group/t/3006/10",
        include_in_listing=True,
    )
