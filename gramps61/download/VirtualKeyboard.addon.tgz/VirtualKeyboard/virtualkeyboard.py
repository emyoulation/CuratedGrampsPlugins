# virtualkeyboard.py
# Virtual Keyboard Gramplet generated for Gramps 5.2
# Touch-friendly on-screen keyboard for clipboarded data entry
# Default: Special (accented) layout
#
# v1.4.0: added an undockable Virtual Keyboard window (VirtualKeyboardPanel /
# VirtualKeyboardWindow / open_virtual_keyboard_window) that types directly
# into an external field, for use with the "Insert Symbols" context-menu
# patch. Verified against Gramps 5.2.0, 6.0.0, and current master.
#
# Copyright (C) 2026 Brian McCullough, wish-coder
#    (ChatGPT, Perplexity and Codex development)
#    (Claude, Anthropic -- v1.4.0 VirtualKeyboardPanel/VirtualKeyboardWindow)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
import os
import csv
import logging

from pathlib import Path
from gi.repository import Gdk, Gtk, GObject
from gramps.gen.const import GRAMPS_LOCALE as glocale
from gramps.gen.plug import Gramplet
from gramps.gen.config import config
from gramps.gui.dialog import OkDialog
from gramps.gui.managedwindow import ManagedWindow

# Requires the companion core patch adding gramps/gui/widgets/textinsertion.py.
# Used by VirtualKeyboardPanel to type directly into an external widget,
# instead of duplicating the cursor-insertion arithmetic here.
#
# This import is intentionally optional: the core patch is unmerged and not
# present on a stock Gramps install. If it's missing, the rest of this
# gramplet -- everything predating v1.4.0 -- must keep working exactly as
# before; only the new undockable-window feature (open_virtual_keyboard_
# window, below) needs to refuse gracefully instead of crashing.
try:
    from gramps.gui.widgets.textinsertion import (
        insert_text_at_cursor,
        backspace_at_cursor,
    )

    _TEXTINSERTION_AVAILABLE = True
except ImportError:
    insert_text_at_cursor = None
    backspace_at_cursor = None
    _TEXTINSERTION_AVAILABLE = False

LOG = logging.getLogger(__name__)
_ = glocale.get_addon_translator(__file__).gettext

# Virtual Keyboard mappings

# Oops keyboard layout failure
OOPS_ROWS = [
    " 😭 @#$%&! 💣 💣 💣 ",
    " See  💡the  Gramps  log  or  statusbar. ",
    " 😠 Fix  or  remove  the ",
    " broken layout! ",
]

# QWERTY (US English)
QWERTY_ROWS = [
    "`1234567890-=  ⌫",
    "⇥ qwertyuiop[]\\",
    "⇪  asdfghjkl;'  ↩",
    "⇧   zxcvbnm,./    ⇧",
]
QWERTY_SHIFT_ROWS = [
    "~!@#$%^&*()_+  ⌦",
    "⇤ QWERTYUIOP{}|",
    '⇫  ASDFGHJKL:"  ⏎',
    "⇧   ZXCVBNM<>?    ⇧",
]

SPECIAL_ROWS = [
    "áàâäéèêëíìîïóòôöúùûü",
    "ÁÀÂÄÉÈÊËÍÌÎÏÓÒÔÖÚÙÛÜ",
    "ñÑçÇßΒðÐþÞæÆœŒøåÿğış",
    "ÑÇŞĞİığş.,!?;:⁂§¶†‡№●°",
    "$¢€c£p¥₹₽кR₱₩元角圓₪₴",
    "©® ⌘⊞⌥⎇≣ ×±÷—–… ⅛¼⅓⅜½⅝⅔¾⅞",
]

MATH_ROWS = [  # https://math.typeit.org/
    "⟨⟩⟦⟧⌊⌈⌋⌉ ↑⇐←↦ ℰℓℒℳ '" "–—",
    "½¼∕∤⊥∥‰ø≪≫~⊢⊨□◇ ℂℕℙℚℝℤ",
    "ΓΔΛΞΠΣΦΨΩ Åℏ ∞∘∂∫∮∯∇ ′″‴",
    "αβγδεζηθκλμνξπρστυφχψω",
    "ΑΒΓΔΕΖΗΘΚΛΜΝΞΠΡΣΤΥΦΧΨΩ",
    "⇒→⇔↔ ∈∉⊂⊆⊄⊈⊃∪∩∖∅ ∏∑ ̅̂⃗̇̈\u201c\u201d",
    "¬∨∧∀∃ −±⊕·×⊗÷²³√∛ ≠≈≡≝≤≥ °∠",
]

COMPOSED_ROWS = [
    "áÁéÉíÍóÓúÚàÀèÈìÌòÒùÙ",
    "äÄëËïÏöÖüÜÿŸżŻċĊġĠıİ",
    "åÅãÃñÑõÕçÇşŞąĄęĘįĮųŲ",
    "âÂêÊîÎôÔûÛ –—…≤≥≠",
    "øØðÐþÞłŁŋŊßẞæÆœŒ",
]

# QWERTZ (Gerrman-style variant)
QWERTZ_ROWS = [
    "^1234567890ß´",
    "qwertzuiopü+",
    "asdfghjklöä#",
    "<yxcvbnm,.- ",
]
QWERTZ_SHIFT_ROWS = [
    '°!"§$%&/()=?`',
    "QWERTZUIOPÜ*",
    "ASDFGHJKLÖÄ'",
    ">YXCVBNM;:_ ",
]
QWERTZ_ALTGR_ROWS = [
    "¦@#{|}\\}",
    "¤¬¦¨´¸ˆ˜",
    "ÆŒœªº¿¡",
    "µ§£¢∞€",
]
QWERTZ_ALTGR_SHIFT_ROWS = [
    "¶©ªº¯\\€",
    "¢¬¶¨¸ˆ˜",
    "æœŒºª¿¡",
    "¶§¥¹∞¥",
]

# AZERTY (French-style variant) — matches layouts/fr.csv
AZERTY_ROWS = [
    "&é\"'(-è_çà)",
    "azertyuiop^$",
    "qsdfghjklmù*",
    "wxcvbn,;:!",
]
AZERTY_SHIFT_ROWS = [
    "1234567890°+",
    "AZERTYUIOP¨£",
    "QSDFGHJKLM%µ",
    "WXCVBN?./§",
]

AZERTY_ALTGR_ROWS = [
    "¦@#{|}\\}",
    "¤¬¦¨´¸ˆ˜",
    "ÆŒœªº¿¡",
    "µ§£¢∞€",
]
AZERTY_ALTGR_SHIFT_ROWS = [
    "¶©ªº¯\\€",
    "¢¬¶¨¸ˆ˜",
    "æœŒºª¿¡",
    "¶§¥¹∞¥",
]

# Layout tuple order:
# (rows, layout_id, button_label, button_tooltip)
LayoutSets = {
    "oops": {  # Error reporting
        "layouts": [
            (
                "OOPS_ROWS",
                "oops",
                _("⚠  Layout Set Invalid"),
                _("The selected keyboard layout set could not be loaded"),
            ),
        ],
        "default_layout": "oops",
    },
    "gb": {  # English (GB and US) keyboard layout button menu
        "id": "GB_QWERTY",
        "language": "en",
        "button": "🇬🇧",
        "labels": {
            "native": "English",
            "en": "English",
        },
        "tooltips": {
            "tooltip_native": "Standard QWERTY keyboard",
            "tooltip_en": "Standard QWERTY keyboard",
        },
        "layouts": [
            (
                "QWERTY_ROWS",
                "qwerty",
                _("QWERTY"),
                _("Most common English-language keyboard layout"),
            ),
            (
                "QWERTY_SHIFT_ROWS",
                "qwerty_shift",
                _("Shift QWERTY"),
                _("Uppercase letters and shifted symbols"),
            ),
            (
                "COMPOSED_ROWS",
                "composed",
                _("Composed / Dead Keys"),
                _("Mashup of diacritics, extended, and composed characters"),
            ),
            (
                "SPECIAL_ROWS",
                "special",
                _("Special"),
                _("Mashup of special characters"),
            ),
            ("MATH_ROWS", "math", _("Math"), _("Mashup of mathematical operators")),
        ],
        "default_layout": "special",
    },
    "fr": {  # French keyboard layout button menu — matches layouts/fr.csv
        "id": "FR_AZERTY",
        "language": "fr",
        "button": "🇫🇷",
        "labels": {
            "native": "Français",
            "en": "French",
        },
        "tooltips": {
            "tooltip_native": "Clavier français AZERTY",
            "tooltip_en": "AZERTY keyboard",
        },
        "layouts": [
            ("AZERTY_ROWS", "azerty", _("azerty"), _("Disposition française standard")),
            (
                "AZERTY_SHIFT_ROWS",
                "azerty_shift",
                _("AZERTY"),
                _("Majuscules et chiffres"),
            ),
            ("SPECIAL_ROWS", "special", _("Special"), _("Caractères spéciaux")),
            (
                "COMPOSED_ROWS",
                "composed",
                _("Compose"),
                _("Caractères composés et diacritiques"),
            ),
        ],
        "default_layout": "azerty",
    },
    "de": {  # German keyboard layout button menu
        "id": "DE_QWERTZ",
        "language": "de",
        "button": "🇩🇪",
        "labels": {
            "native": "Deutsch",
            "en": "German",
        },
        "tooltips": {
            "tooltip_native": "Deutsche QWERTZ-Tastatur",
            "tooltip_en": "German QWERTZ keyboard",
        },
        "layouts": [
            (
                "QWERTZ_ROWS",
                "qwertz",
                _("qwertz"),
                _("Standard German keyboard layout"),
            ),
            (
                "QWERTZ_SHIFT_ROWS",
                "qwertz_shift",
                _("Shift QWERTZ"),
                _("German uppercase letters and shifted symbols"),
            ),
            (
                "QWERTZ_ALTGR_ROWS",
                "qwertz_altgr",
                _("AltGr"),
                _("Alternate characters, symbols, and currency"),
            ),
            (
                "QWERTZ_ALTGR_SHIFT_ROWS",
                "qwertz_altgr_shift",
                _("Shift AltGr"),
                _("Shifted alternate characters, symbols, and currency"),
            ),
            (
                "SPECIAL_ROWS",
                "special",
                _("Special"),
                _("Mashup of special characters"),
            ),
            (
                "COMPOSED_ROWS",
                "composed",
                _("Composed / Dead Keys"),
                _("Mashup of diacritics, extended, and composed characters"),
            ),
        ],
        "default_layout": "qwertz_altgr",
    },
}

LAYOUT_SETS = LayoutSets

# ----------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------

# TODO:
# CONFIG_ID is currently used both for config identity and diagnostics.
# This is intentional for now. A later refactor may separate persistent
# identity from schema/version labeling.
CONFIG_ID = "LocalTerm"
CONFIG_SCHEMA_VERSION = "0.0.1.5"

PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
LAYOUTS_DIR = Path(PLUGIN_DIR) / "layouts"

# IMPORTANT: no ".ini" — Gramps adds it
_config_file = os.path.join(PLUGIN_DIR, CONFIG_ID)

config = config.register_manager(_config_file)

# schema metadata
config.register("VirtualKeyboard.config_id", CONFIG_ID)
# IMPORTANT:
# config_schema MUST NOT default to the current version,
# otherwise Gramps will comment it out and schema mismatch
# detection will never trigger.
# config.register("VirtualKeyboard.config_schema", CONFIG_SCHEMA_VERSION)
config.register("VirtualKeyboard.config_schema", "")
config.register("VirtualKeyboard.layout_id", "fr")
# options
config.register("VirtualKeyboard.show_anchor", False)


def layout_id_from_path(path: Path) -> str:
    return path.stem  # e.g. "fr", "fr-azerty", "en_us"


def iter_layout_csvs():
    if not LAYOUTS_DIR.is_dir():
        return []
    return sorted(LAYOUTS_DIR.glob("*.csv"))


def get_available_layouts():
    return {layout_id_from_path(p): p for p in iter_layout_csvs()}


# Map layout @id (no rows in CSV) -> built-in rows ref name
BUILTIN_LAYOUT_ROWS = {
    "SPECIAL": "SPECIAL_ROWS",
    "COMPOSED": "COMPOSED_ROWS",
    "QWERTY": "QWERTY_ROWS",
    "QWERTY_SHIFT": "QWERTY_SHIFT_ROWS",
    "QWERTZ": "QWERTZ_ROWS",
    "QWERTZ_SHIFT": "QWERTZ_SHIFT_ROWS",
    "QWERTZ_ALTGR": "QWERTZ_ALTGR_ROWS",
    "QWERTZ_ALTGR_SHIFT": "QWERTZ_ALTGR_SHIFT_ROWS",
    "AZERTY": "AZERTY_ROWS",
    "AZERTY_SHIFT": "AZERTY_SHIFT_ROWS",
    "AZERTY_ALTGR": "AZERTY_ALTGR_ROWS",
    "AZERTY_ALTGR_SHIFT": "AZERTY_ALTGR_SHIFT_ROWS",
}


# Directives required by the External Layout Specification v1.2.0,
# Sections 4 and 5. A file missing any of these is rejected as a whole
# (Section 11: "Partial loading is not permitted").
REQUIRED_SET_KEYS = ("id", "language", "button", "default_layout")


def _parse_csv_directive(line: str):
    """Parse '@key,value' into (key, value). Returns None for non-directives."""
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    if not line.startswith("@"):
        return None
    idx = line.find(",")
    if idx < 0:
        return (line[1:].lower(), "")
    return (line[1:idx].lower(), line[idx + 1 :].strip())


def _is_quoted_csv_string(raw_value: str) -> bool:
    """
    Return whether a raw directive value is a properly quoted CSV
    string, per spec Sections 7-8: it must start and end with a
    literal double quote. An unquoted value containing a comma would
    otherwise silently lose everything after the first comma -- this
    check exists so that gets caught as a validation error instead.

    :param raw_value: The raw value text after the directive's comma,
        before any CSV unescaping.
    :returns: True if the value looks like a quoted CSV string.
    """
    return len(raw_value) >= 2 and raw_value.startswith('"') and raw_value.endswith('"')


def load_layout_csv(path: Path, uistate=None):
    """
    Parse a layout CSV per the External Layout Specification v1.2.0.

    The whole file is validated before anything is accepted: an
    unquoted ``@row`` value, a missing required directive, an ``@row``
    outside an ``@layout`` block, or a file with no ``@`` directives at
    all (a strong sign it predates this format, or isn't a layout file)
    all cause the entire file to be rejected -- never a partial or
    silently-truncated result (spec Section 11: "Partial loading is
    not permitted"). Every problem found is logged together, and if
    ``uistate`` is given, also pushed to the Gramps status bar.

    :param path: Path to the .csv layout file.
    :param uistate: Optional Gramps GUI state, used to surface
        validation failures on the status bar in addition to the log.
    :returns: A set_def dict, or None if the file could not be read or
        failed validation. Callers should substitute the built-in
        "oops" layout set when this returns None, so the failure is
        visible in the UI rather than the set silently disappearing.
    """
    try:
        with open(path, encoding="utf-8", newline="") as f:
            lines = f.readlines()
    except (OSError, UnicodeDecodeError) as e:
        _report_layout_error(path, [f"cannot read file: {e}"], uistate)
        return None

    set_data = {}
    layouts = []
    current_layout = None
    current_rows = []
    errors = []
    saw_any_directive = False
    ui_lang = (glocale.language or ["en"])[0][:2] if glocale.language else "en"

    for lineno, raw_line in enumerate(lines, start=1):
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if not stripped.startswith("@"):
            errors.append(
                f"line {lineno}: not a comment or an @directive: {stripped!r}"
            )
            continue

        saw_any_directive = True
        parsed = _parse_csv_directive(raw_line)
        if not parsed:
            continue
        key, val = parsed

        if key == "set":
            continue
        if key in (
            "id",
            "language",
            "button",
            "default_layout",
            "label_native",
            "label_en",
            "label",
            "tooltip_native",
            "tooltip_en",
            "language_iso3",
            "region",
        ):
            if current_layout is None:
                if key == "default_layout":
                    set_data["default_layout"] = val.lower()
                elif key == "id":
                    set_data["id"] = val
                elif key == "language":
                    set_data["language"] = val[:2]
                elif key == "button":
                    set_data["button"] = val
                elif key == "label_native":
                    set_data["_label_native"] = val
                elif key == "label_en":
                    set_data["_label_en"] = val
                elif key == "label":
                    set_data["_label_en"] = set_data.get("_label_en") or val
                elif key == "tooltip_native":
                    set_data["_tooltip_native"] = val
                elif key == "tooltip_en":
                    set_data["_tooltip_en"] = val
            else:
                if key == "id":
                    current_layout["id"] = val
                elif key == "label_native":
                    current_layout["_label_native"] = val
                elif key == "label_en":
                    current_layout["_label_en"] = val
                elif key == "label":
                    current_layout["_label_en"] = current_layout.get("_label_en") or val
                elif key == "tooltip_native":
                    current_layout["_tooltip_native"] = val
                elif key == "tooltip_en":
                    current_layout["_tooltip_en"] = val
            continue
        if key == "layout":
            if current_layout is not None:
                _flush_layout(current_layout, current_rows, layouts, ui_lang, errors)
            current_layout = {
                "id": None,
                "_label_native": "",
                "_label_en": "",
                "_tooltip_native": "",
                "_tooltip_en": "",
            }
            current_rows = []
            continue
        if key == "row":
            if current_layout is None:
                errors.append(f"line {lineno}: @row outside of an @layout block")
                continue
            if not _is_quoted_csv_string(val):
                errors.append(
                    f"line {lineno}: @row value must be a quoted CSV string "
                    f'(e.g. @row,"..."), got: {val!r}'
                )
                continue
            try:
                row_val = next(csv.reader([val]), [val])[0]
            except Exception:
                row_val = val
            current_rows.append(row_val)
            continue
        # Unknown directive: forward-compatible, ignore (spec Section 3).

    if current_layout is not None:
        _flush_layout(current_layout, current_rows, layouts, ui_lang, errors)

    if not saw_any_directive:
        errors.append(
            "no @directive lines found at all -- this does not look like a "
            "v1.2.0 layout file (see the External Layout Specification); it "
            "may be in an older or unrelated format"
        )

    for key in REQUIRED_SET_KEYS:
        if not set_data.get(key):
            errors.append(f"missing required @{key} in the layout-set header")

    if not layouts and not errors:
        errors.append("no valid @layout blocks found")

    if errors:
        _report_layout_error(path, errors, uistate)
        return None

    set_data["layouts"] = layouts
    set_data["labels"] = {
        "native": set_data.pop("_label_native", ""),
        "en": set_data.pop("_label_en", ""),
    }
    set_data["tooltips"] = {
        "tooltip_native": set_data.pop("_tooltip_native", ""),
        "tooltip_en": set_data.pop("_tooltip_en", ""),
    }
    return set_data


def _report_layout_error(path: Path, errors: list[str], uistate=None) -> None:
    """
    Log every validation problem found in a layout file, and push a
    short summary to the Gramps status bar if a uistate is available.

    :param path: The layout file that failed.
    :param errors: One description per problem found.
    :param uistate: Optional Gramps GUI state for a status-bar message.
    """
    LOG.error(
        "VirtualKeyboard: rejecting %s (%d problem%s):\n  %s",
        path,
        len(errors),
        "" if len(errors) == 1 else "s",
        "\n  ".join(errors),
    )
    if uistate is not None:
        uistate.status_text(
            _("Virtual Keyboard: %s failed to load -- see the log for details.")
            % path.name
        )


def _flush_layout(layout_data, rows, layouts, ui_lang, errors):
    """
    Validate and append one parsed @layout block, or record an error.

    Per spec Section 5, a layout requires both @id and @label (the
    latter mapped here to _label_en/_label_native, matching how @label
    is actually consumed elsewhere in this loader).

    :param layout_data: The accumulated directives for this block.
    :param rows: The @row values collected for this block.
    :param layouts: The set's layout list to append to on success.
    :param ui_lang: The current Gramps UI language, for label choice.
    :param errors: Error list to append to on validation failure.
    """
    lid = layout_data.get("id")
    if not lid:
        errors.append("a @layout block is missing its required @id")
        return
    label_nat = layout_data.get("_label_native", "")
    label_en = layout_data.get("_label_en", "")
    if not label_nat and not label_en:
        errors.append(f"@layout {lid} is missing its required @label")
        return

    lid_lower = lid.lower().replace(" ", "_")
    tooltip_nat = layout_data.get("_tooltip_native", "")
    tooltip_en = layout_data.get("_tooltip_en", tooltip_nat)
    label = label_nat if ui_lang != "en" and label_nat else (label_en or lid_lower)
    tooltip = tooltip_nat if ui_lang != "en" and tooltip_nat else (tooltip_en or "")
    if rows:
        rows_ref = rows
    else:
        rows_ref = BUILTIN_LAYOUT_ROWS.get(lid.upper().replace(" ", "_"), "")
    layouts.append((rows_ref, lid_lower, label, tooltip))


def _make_oops_set_def(set_id: str) -> dict:
    """
    Build an "invalid layout" placeholder set_def for a failed CSV.

    Reusing the built-in "oops" set as-is would show a blank button and
    the raw set id in the language selector -- not obviously an error.
    This copies it with a warning icon and a label naming the file, so
    the failure is unmistakable where the user actually looks: the
    selector itself, not just the log.

    :param set_id: The layout set id (CSV filename stem) that failed.
    :returns: A set_def dict suitable for substituting into the
        effective layout sets.
    """
    oops = dict(LAYOUT_SETS["oops"])
    oops["button"] = "⚠"
    oops["labels"] = {"native": "", "en": set_id + " (invalid)"}
    return oops


def get_effective_layout_sets(uistate=None):
    """
    Merge built-in layout sets with CSV overrides.

    CSV definitions supersede built-in for the same set id (path
    stem). A CSV that fails to load or fails validation does not
    silently disappear from the language selector: its slot is filled
    with a labeled "invalid" placeholder instead, so the failure is
    visible in the UI. Full details are always logged; a status-bar
    message is also shown if ``uistate`` is given.

    :param uistate: Optional Gramps GUI state, passed through to
        surface validation failures on the status bar.
    """
    effective = dict(LAYOUT_SETS)
    for set_id, csv_path in get_available_layouts().items():
        loaded = load_layout_csv(csv_path, uistate)
        effective[set_id] = loaded if loaded else _make_oops_set_def(set_id)
    return effective


def get_layout_set_id_for_language(lang_code: str) -> str:
    """Map Gramps GUI language to layout set id. Fallback to gb (English)."""
    if not lang_code:
        return "gb"
    lang = (lang_code.split("_")[0] if "_" in lang_code else lang_code)[:2].lower()
    sets = get_effective_layout_sets()
    if lang in sets:
        return lang
    return "gb"


# ------------------------------------------------------------
#
# VirtualKeyboardPanel
#
# ------------------------------------------------------------
class VirtualKeyboardPanel(Gtk.Box):  # pylint: disable=too-many-instance-attributes
    """
    A standalone, embeddable keyboard widget that types directly into
    a caller-supplied target widget.

    This reuses the same layout-set engine as the ``VirtualKeyboard``
    Gramplet (:data:`LAYOUT_SETS`, :func:`get_effective_layout_sets`,
    and CSV layout loading) but has no display Entry or clipboard step
    of its own: every key press is pushed straight into ``target`` via
    :mod:`gramps.gui.widgets.textinsertion`. Intended for embedding in
    a context-menu popover (see ``gramps.gui.widgets.symbolpopover``),
    where the target is whatever field the user right-clicked.

    The button-reassignment context menu and double-click-to-insert
    features of the full Gramplet are intentionally omitted here to
    keep the popover panel simple; use the Dashboard Gramplet for that
    level of customization.

    The language selector lists every layout set returned by
    :func:`get_effective_layout_sets` -- built-in sets plus any CSV
    layouts the user has dropped into the addon's ``layouts`` folder
    -- and defaults to whichever set matches the Gramps GUI's current
    locale, if a matching set exists.
    """

    def __init__(
        self,
        target: Gtk.Editable | Gtk.TextView,
        initial_layout_set: str | None = None,
        uistate=None,
    ) -> None:
        """
        Build the language selector, layout-toggle row, and keyboard grid.

        :param target: The widget that key presses are inserted into.
        :param initial_layout_set: Layout set id to select initially,
            for example ``"fr"``. When omitted, the set matching the
            current Gramps GUI locale is preferred, if one exists;
            otherwise the English/QWERTY set is used.
        :param uistate: Optional Gramps GUI state. When given, a
            malformed custom layout file surfaces a status-bar message
            in addition to the log entry.
        """
        Gtk.Box.__init__(self, orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.target = target
        self.uistate = uistate
        self.current_layout = None
        self.layout_defs: dict[str, list[str]] = {}
        self.layout_buttons: list[tuple[str, Gtk.ToggleButton]] = []

        if initial_layout_set is None:
            initial_layout_set = self._get_gui_locale_layout_set()
        self.current_layout_set = initial_layout_set

        self._build_ui()

    @staticmethod
    def _get_gui_locale_layout_set() -> str:
        """
        Return the layout set matching the current Gramps GUI locale.

        Falls back to the English/QWERTY set if the GUI locale has no
        matching layout set among the built-in and CSV-defined sets.

        :returns: A layout set id present in :func:`get_effective_layout_sets`.
        """
        lang = (glocale.language or ["en"])[0] if glocale.language else "en"
        return get_layout_set_id_for_language(lang)

    def _build_ui(self) -> None:
        """Build the language selector, layout row, grid, and controls."""
        self.language_combo = self._build_language_selector()
        self.pack_start(self.language_combo, False, False, 0)

        self.layout_hbox = Gtk.Box(spacing=4)
        self.pack_start(self.layout_hbox, False, False, 0)

        self.keyboard_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.pack_start(self.keyboard_vbox, True, True, 0)

        control_hbox = Gtk.Box(spacing=4)
        controls = [
            ("⌫", self.cb_backspace_clicked),
            (_("␣ Space"), self.cb_space_clicked),
            (_("⇥ Tab"), self.cb_tab_clicked),
            ("↵", self.cb_newline_clicked),
        ]
        for label, callback in controls:
            btn = Gtk.Button(label=label)
            btn.connect("clicked", callback)
            control_hbox.pack_start(btn, False, False, 0)
        self.pack_start(control_hbox, False, False, 0)

        self._rebuild_layout_buttons()
        self._select_default_layout()
        if self.current_layout:
            self._build_keyboard(self.current_layout)
        self.show_all()

    def _build_language_selector(self) -> Gtk.ComboBoxText:
        """
        Build a combo box listing every available layout set.

        The set matching ``self.current_layout_set`` is pre-selected,
        which is normally the Gramps GUI's current locale, if a
        matching layout set exists (see :meth:`_get_gui_locale_layout_set`).

        :returns: A populated, pre-selected :class:`Gtk.ComboBoxText`.
        """
        combo = Gtk.ComboBoxText()
        sets = get_effective_layout_sets(self.uistate)
        for set_id in sorted(sets):
            if set_id == "oops":
                continue
            set_def = sets[set_id]
            button = set_def.get("button", "")
            name = set_def.get("labels", {}).get("native") or set_def.get(
                "labels", {}
            ).get("en", set_id)
            combo.append(set_id, f"{button} {name}".strip())

        if combo.set_active_id(self.current_layout_set) is False:
            combo.set_active(0)
            self.current_layout_set = combo.get_active_id() or self.current_layout_set
        combo.connect("changed", self.cb_language_changed)
        return combo

    def cb_language_changed(self, combo: Gtk.ComboBoxText) -> None:
        """
        Switch to the layout set chosen in the language selector.

        :param combo: The language selector combo box.
        """
        set_id = combo.get_active_id()
        if set_id is None or set_id == self.current_layout_set:
            return
        self.current_layout_set = set_id
        self._rebuild_layout_buttons()
        self._select_default_layout()
        if self.current_layout:
            self._build_keyboard(self.current_layout)

    def _rebuild_layout_buttons(self) -> None:
        """Rebuild the row of layout-toggle buttons for the current set."""
        for child in self.layout_hbox.get_children():
            self.layout_hbox.remove(child)
        self.layout_buttons = []
        self.layout_defs = {}

        set_def = get_effective_layout_sets(self.uistate).get(
            self.current_layout_set, {}
        )
        for rows_ref, layout_id, label, tooltip in set_def.get("layouts", []):
            rows = globals().get(rows_ref) if isinstance(rows_ref, str) else rows_ref
            if not isinstance(rows, list):
                LOG.warning(
                    "VirtualKeyboardPanel: layout '%s' has no valid rows", layout_id
                )
                continue
            btn = Gtk.ToggleButton(label=label)
            btn.set_tooltip_text(tooltip)
            btn.connect("toggled", self.cb_layout_toggled, layout_id)
            self.layout_hbox.pack_start(btn, True, True, 0)
            self.layout_buttons.append((layout_id, btn))
            self.layout_defs[layout_id] = rows
        self.layout_hbox.show_all()

    def _select_default_layout(self) -> None:
        """Select the default layout for the current layout set."""
        set_def = get_effective_layout_sets(self.uistate).get(
            self.current_layout_set, {}
        )
        default_id = set_def.get("default_layout")
        if default_id and default_id in self.layout_defs:
            self.current_layout = default_id
        elif self.layout_defs:
            self.current_layout = next(iter(self.layout_defs))
        else:
            self.current_layout = None
        for layout_id, btn in self.layout_buttons:
            btn.set_active(layout_id == self.current_layout)

    def cb_layout_toggled(self, button: Gtk.ToggleButton, layout_id: str) -> None:
        """
        Switch the displayed keyboard grid to another layout.

        :param button: The toggled layout button.
        :param layout_id: The layout id the button represents.
        """
        if not button.get_active():
            return
        self.current_layout = layout_id
        self._build_keyboard(layout_id)
        for _other_id, other_btn in self.layout_buttons:
            if other_btn is not button:
                other_btn.set_active(False)

    def _build_keyboard(self, layout_id: str) -> None:
        """
        Rebuild the grid of character buttons for a layout.

        :param layout_id: The layout id to render.
        """
        for child in self.keyboard_vbox.get_children():
            self.keyboard_vbox.remove(child)

        for row_chars in self.layout_defs.get(layout_id, []):
            hbox = Gtk.Box(spacing=1)
            for ch in row_chars:
                if ch == " ":
                    spacer = Gtk.Box()
                    spacer.set_size_request(10, -1)
                    hbox.pack_start(spacer, False, False, 0)
                    continue
                btn = Gtk.Button(label=ch)
                btn.set_has_tooltip(False)
                btn.connect("clicked", self.cb_char_clicked, ch)
                hbox.pack_start(btn, True, True, 0)
            self.keyboard_vbox.pack_start(hbox, False, False, 0)
        self.keyboard_vbox.show_all()

    def cb_char_clicked(self, _button: Gtk.Button, ch: str) -> None:
        """
        Insert the clicked character into the target widget.

        :param _button: The clicked character button (unused).
        :param ch: The character to insert.
        """
        insert_text_at_cursor(self.target, ch)

    def cb_backspace_clicked(self, _button: Gtk.Button) -> None:
        """
        Delete the character before the cursor in the target widget.

        :param _button: The clicked backspace button (unused).
        """
        backspace_at_cursor(self.target)

    def cb_space_clicked(self, _button: Gtk.Button) -> None:
        """
        Insert a space into the target widget.

        :param _button: The clicked space button (unused).
        """
        insert_text_at_cursor(self.target, " ")

    def cb_tab_clicked(self, _button: Gtk.Button) -> None:
        """
        Insert a tab into the target widget.

        :param _button: The clicked tab button (unused).
        """
        insert_text_at_cursor(self.target, "\t")

    def cb_newline_clicked(self, _button: Gtk.Button) -> None:
        """
        Insert a newline into the target widget.

        :param _button: The clicked newline button (unused).
        """
        insert_text_at_cursor(self.target, "\n")


# ------------------------------------------------------------
#
# VirtualKeyboardWindow
#
# ------------------------------------------------------------
class VirtualKeyboardWindow(ManagedWindow):
    """
    A persistent, undocked window hosting a :class:`VirtualKeyboardPanel`.

    Built on :class:`gramps.gui.managedwindow.ManagedWindow`, the base
    class used for nearly every other floating window in Gramps, so it
    gets the same window-position memory and Windows-menu registration
    as any other Gramps dialog, instead of a bespoke ``Gtk.Window``.

    Unlike the docked ``VirtualKeyboard`` Gramplet, this window has no
    display Entry or clipboard step: it types directly into ``target``
    and can stay open for as long as the user wants, independent of
    the "Insert Symbols" popover that spawned it.
    """

    def __init__(self, uistate, track, target: Gtk.Editable | Gtk.TextView) -> None:
        """
        Build and show the window around a fresh :class:`VirtualKeyboardPanel`.

        :param uistate: The Gramps GUI state, as passed to any other
            ``ManagedWindow`` subclass.
        :param track: The window's parent track, e.g. ``self.track``
            from the calling editor.
        :param target: The widget that key presses are inserted into.
        """
        ManagedWindow.__init__(self, uistate, track, self.__class__)
        self.title = _("Virtual Keyboard")

        dialog = Gtk.Dialog(transient_for=uistate.window, destroy_with_parent=True)
        dialog.add_button(_("_Close"), Gtk.ResponseType.CLOSE)
        dialog.connect("response", self.cb_response)
        self.set_window(dialog, None, self.title)
        self.setup_configs("interface.virtualkeyboard-undocked", 420, 320)

        panel = VirtualKeyboardPanel(target, uistate=uistate)
        dialog.vbox.pack_start(panel, True, True, 0)
        self.show()

    def cb_response(self, _dialog: Gtk.Dialog, response: Gtk.ResponseType) -> None:
        """
        Close the window when its "Close" button is activated.

        :param _dialog: The window's dialog (unused).
        :param response: The response id that triggered this signal.
        """
        if response == Gtk.ResponseType.CLOSE:
            self.close()

    def build_menu_names(self, _obj: object) -> tuple[str, None]:
        """
        Provide the Windows-menu label required by ``ManagedWindow``.

        :param _obj: The object passed to ``ManagedWindow`` (unused).
        :returns: A ``(menu_label, submenu_label)`` pair.
        """
        return (self.title, None)


def open_virtual_keyboard_window(
    target: Gtk.Editable | Gtk.TextView, uistate, track: list | None = None
) -> VirtualKeyboardWindow | None:
    """
    Open a persistent Virtual Keyboard window that types into ``target``.

    This is the public, module-level entry point other plugins should
    load on demand via
    ``gramps.gui.widgets.addonlookup.load_addon_function("VirtualKeyboard",
    "open_virtual_keyboard_window", uistate, ...)`` rather than
    hard-importing this module directly -- see that function's
    docstring for why. A typical caller wires it up as an
    ``undock_factory`` for
    ``gramps.gui.widgets.symbolpopover.attach_symbol_popup``::

        from functools import partial
        from gramps.gui.widgets.addonlookup import load_addon_function
        from gramps.gui.widgets.symbolpopover import attach_symbol_popup

        def open_virtual_keyboard(target, uistate, track=None):
            open_fn = load_addon_function(
                "VirtualKeyboard",
                "open_virtual_keyboard_window",
                uistate,
                _("Virtual Keyboard"),
            )
            if open_fn is not None:
                open_fn(target, uistate, track=track)

        attach_symbol_popup(
            entry,
            undock_label=_("Open Virtual Keyboard"),
            undock_factory=partial(
                open_virtual_keyboard, uistate=self.uistate, track=self.track
            ),
        )

    :param target: The widget that key presses are inserted into.
    :param uistate: The Gramps GUI state.
    :param track: The window's parent track. Defaults to an empty list.
    :returns: The opened window, or ``None`` if the companion core patch
        (``gramps.gui.widgets.textinsertion``) isn't installed -- in
        which case an explanatory dialog is shown instead of crashing.
    """
    if not _TEXTINSERTION_AVAILABLE:
        OkDialog(
            _("Virtual Keyboard: core patch not installed"),
            _(
                "This feature needs gramps.gui.widgets.textinsertion, "
                "part of the unmerged core patch described in Hacking.md. "
                "It isn't installed on this system yet."
            ),
            parent=uistate.window,
        )
        return None
    return VirtualKeyboardWindow(uistate, track or [], target)


class VirtualKeyboard(Gramplet):
    def init(self):
        self.config = config
        # only set if not already configured
        if not self.config.get("VirtualKeyboard.layout_id"):
            self.config.set("VirtualKeyboard.layout_id", "fr")

        self.buffer = ""
        lang = (glocale.language or ["en"])[0] if glocale.language else "en"
        self.current_layout_set = get_layout_set_id_for_language(lang)

        self.current_layout = None
        self.layout_defs = {}

        # Dictionary to store button metadata (replaces set_data/get_data)
        self.button_metadata = {}
        self.double_click_timers = {}

        self.gui.uistate.connect("filter-changed", self.update)
        self.dbstate.connect("database-changed", self.update)
        self.build_interface()

    def build_interface(self):
        top = self.gui.get_container_widget()

        # Suppress Gramps-injected gramplet tooltip
        def _suppress_tooltip(widget, *args):
            GObject.signal_stop_emission_by_name(widget, "query-tooltip")
            return False

        top.set_has_tooltip(True)
        top.connect("query-tooltip", _suppress_tooltip)

        for child in top.get_children():
            top.remove(child)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        vbox.set_border_width(4)

        # ---- Display ----
        self.display = Gtk.Entry()
        self.display.set_editable(False)
        vbox.pack_start(self.display, False, False, 0)

        # ---- Layout buttons ----
        self.layout_hbox = Gtk.Box(spacing=4)
        vbox.pack_start(self.layout_hbox, False, False, 0)

        # ---- Keyboard body (always exists) ----
        self.keyboard_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        vbox.pack_start(self.keyboard_vbox, True, True, 0)

        # ---- Bottom control bar with enhanced layout set buttons ----
        control_hbox = Gtk.Box(spacing=4)

        # Build layout set buttons with context menus
        self.flag_buttons = []
        self.layout_set_buttons = {}  # Map set_id to button widget

        # Initialize with built-in layout sets
        default_sets = ["gb", "fr", "de"]

        for set_id in default_sets:
            btn = self.create_layout_set_button(set_id)
            if btn:
                self.layout_set_buttons[set_id] = btn
                self.flag_buttons.append((set_id, btn))
                control_hbox.pack_start(btn, False, False, 0)

        # Add spacer
        spacer = Gtk.Box()
        control_hbox.pack_start(spacer, True, True, 0)

        # Original control buttons
        btns = [
            ("⌫", self.on_backspace),
            (_("⌧ Clear"), self.on_clear),
            (_("␣ Space"), self.on_space),
            (_("⇥ Tab"), self.on_tab),
            ("↵", self.on_newline),
            (_("📋 Copy"), self.on_copy_clipboard),
        ]

        for label, callback in btns:
            btn = Gtk.Button(label=label)
            btn.connect("clicked", callback)
            control_hbox.pack_start(btn, False, False, 0)

        vbox.pack_start(control_hbox, False, False, 0)

        top.add(vbox)

        # ---- Initial layout build ----
        self.build_layout_buttons()
        self.select_default_layout()
        if self.current_layout:
            self.set_active_layout(self.current_layout)

        vbox.show_all()
        self.update_flag_buttons()

    def create_layout_set_button(self, set_id):
        """
        Create a button for a layout set with:
        - Left-click: activate that layout set
        - Right-click: show context menu with all available layout sets
        - Double-click: insert button text into buffer
        """
        # Get the layout set definition
        sets = get_effective_layout_sets()
        set_def = sets.get(set_id)

        if not set_def:
            return None

        # Get button label from metadata (default to set_id)
        button_label = set_def.get("button", set_id)

        # Create button
        btn = Gtk.Button(label=button_label)

        # Store button metadata in dictionary
        self.button_metadata[id(btn)] = {
            "set_id": set_id,
            "button_label": button_label,
            "click_count": 0,
        }

        # Set tooltip from metadata
        tooltip = set_def.get("tooltips", {}).get("tooltip_en", set_id)
        btn.set_tooltip_text(tooltip)

        # Connect signals
        btn.connect("clicked", self.on_layout_set_button_clicked, set_id)
        btn.connect("button-press-event", self.on_layout_set_button_press, set_id)
        btn.connect(
            "button-release-event", self.on_layout_set_button_release, set_id, id(btn)
        )

        return btn

    def on_layout_set_button_clicked(self, btn, set_id):
        """
        Handle left-click on layout set button.
        Activate the layout set (but not on double-click).
        """
        btn_id = id(btn)

        # Skip if this is part of a double-click
        if (
            btn_id in self.button_metadata
            and self.button_metadata[btn_id]["click_count"] == 2
        ):
            return

        if set_id == self.current_layout_set:
            return

        self.current_layout_set = set_id
        self.update_flag_buttons()
        self.build_layout_buttons()
        self.select_default_layout()

        if self.current_layout:
            for layout_id, layout_btn in self.layout_buttons:
                layout_btn.set_active(layout_id == self.current_layout)
            self.build_keyboard(self.current_layout)
        else:
            for child in self.keyboard_vbox.get_children():
                self.keyboard_vbox.remove(child)

    def on_layout_set_button_press(self, btn, event, set_id):
        """
        Handle right-click to show context menu of available layout sets.
        """
        if event.button == 3:  # Right-click
            self.show_layout_set_menu(btn, event, set_id)
            return True
        return False

    def on_layout_set_button_release(self, btn, event, set_id, btn_id):
        """
        Handle double-click to insert button text into buffer.
        """
        if event.button == 1:  # Left-click
            if btn_id not in self.button_metadata:
                return False

            metadata = self.button_metadata[btn_id]
            metadata["click_count"] += 1

            # Check for double-click (2 clicks within short time)
            if metadata["click_count"] == 2:
                # Insert button text at cursor position
                button_label = metadata["button_label"]
                cursor_pos = self.display.get_position()
                current_text = self.display.get_text()
                new_text = (
                    current_text[:cursor_pos] + button_label + current_text[cursor_pos:]
                )
                self.buffer = new_text
                self.display.set_text(self.buffer)
                # Move cursor to after the inserted text
                self.display.set_position(cursor_pos + len(button_label))
                metadata["click_count"] = 0
                return True
            else:
                # Reset counter after timeout
                if btn_id in self.double_click_timers:
                    GObject.source_remove(self.double_click_timers[btn_id])

                timer_id = GObject.timeout_add(300, self._reset_click_count, btn_id)
                self.double_click_timers[btn_id] = timer_id
        return False

    def _reset_click_count(self, btn_id):
        """Reset click count for double-click detection."""
        if btn_id in self.button_metadata:
            self.button_metadata[btn_id]["click_count"] = 0
        if btn_id in self.double_click_timers:
            del self.double_click_timers[btn_id]
        return False

    def show_layout_set_menu(self, btn, event, current_set_id):
        """
        Show a context menu of all available layout sets.
        Menu items show: button : tooltip_native

        Menu items must be unique. In case of duplicates, CSVs supersede built-ins.
        """
        menu = Gtk.Menu()

        sets = get_effective_layout_sets()

        # Exclude "oops" set (error fallback only)
        available_sets = [s for s in sorted(sets.keys()) if s != "oops"]

        # Separate built-in and CSV layout sets
        builtin_sets = []
        csv_sets = []

        for set_id in available_sets:
            # Check if this is a CSV layout (exists in available_layouts)
            csv_layouts = get_available_layouts()
            if set_id in csv_layouts:
                csv_sets.append(set_id)
            else:
                builtin_sets.append(set_id)

        # Build menu labels: button : tooltip_native
        # Track unique labels, with CSV superseding built-in
        menu_items = {}  # label -> set_id

        # Add built-in sets first
        for set_id in builtin_sets:
            set_def = sets[set_id]
            button_symbol = set_def.get("button", set_id)
            tooltip_native = set_def.get("tooltips", {}).get("tooltip_native", set_id)
            menu_label = f"{button_symbol} : {tooltip_native}"

            if menu_label not in menu_items:
                menu_items[menu_label] = set_id

        # Add CSV sets (these override built-ins with same label)
        for set_id in csv_sets:
            set_def = sets[set_id]
            button_symbol = set_def.get("button", set_id)
            tooltip_native = set_def.get("tooltips", {}).get("tooltip_native", set_id)
            menu_label = f"{button_symbol} : {tooltip_native}"

            # CSV supersedes built-in
            menu_items[menu_label] = set_id

        # Add unique menu items to menu
        for menu_label in sorted(menu_items.keys()):
            set_id = menu_items[menu_label]

            menu_item = Gtk.MenuItem(label=menu_label)
            # Capture btn with default parameter to avoid closure issues
            menu_item.connect(
                "activate",
                lambda mi, sid=set_id, clicked_button=btn: self.on_layout_set_menu_selected(
                    sid, clicked_button
                ),
            )
            menu.append(menu_item)

        menu.show_all()
        menu.popup_at_pointer(event)

        return True

    def on_layout_set_menu_selected(self, set_id, clicked_btn):
        """
        Handle menu selection to change layout set.
        The clicked button adopts the new set's button metadata.
        """
        sets = get_effective_layout_sets()
        set_def = sets.get(set_id)

        if not set_def:
            return

        # Get the old set_id that this button was mapped to
        btn_id = id(clicked_btn)
        old_set_id = None

        if btn_id in self.button_metadata:
            old_set_id = self.button_metadata[btn_id]["set_id"]

        # Update button label with new set's button metadata
        new_button_label = set_def.get("button", set_id)
        clicked_btn.set_label(new_button_label)

        # Update button metadata
        if btn_id in self.button_metadata:
            self.button_metadata[btn_id]["button_label"] = new_button_label
            self.button_metadata[btn_id]["set_id"] = set_id

        # Update tooltip
        tooltip = set_def.get("tooltips", {}).get("tooltip_en", set_id)
        clicked_btn.set_tooltip_text(tooltip)

        # Update the button mapping in layout_set_buttons
        if old_set_id and old_set_id in self.layout_set_buttons:
            del self.layout_set_buttons[old_set_id]
        self.layout_set_buttons[set_id] = clicked_btn

        # Update flag_buttons list
        self.flag_buttons = [(s, b) for s, b in self.flag_buttons if b != clicked_btn]
        self.flag_buttons.append((set_id, clicked_btn))

        # DISCONNECT old signal handlers and RECONNECT with new set_id
        clicked_btn.disconnect_by_func(self.on_layout_set_button_clicked)
        clicked_btn.disconnect_by_func(self.on_layout_set_button_press)
        clicked_btn.disconnect_by_func(self.on_layout_set_button_release)

        # Reconnect with the NEW set_id
        clicked_btn.connect("clicked", self.on_layout_set_button_clicked, set_id)
        clicked_btn.connect(
            "button-press-event", self.on_layout_set_button_press, set_id
        )
        clicked_btn.connect(
            "button-release-event", self.on_layout_set_button_release, set_id, btn_id
        )

        # Activate the layout set
        self.current_layout_set = set_id
        self.update_flag_buttons()
        self.build_layout_buttons()
        self.select_default_layout()

        if self.current_layout:
            for layout_id, layout_btn in self.layout_buttons:
                layout_btn.set_active(layout_id == self.current_layout)
            self.build_keyboard(self.current_layout)
        else:
            for child in self.keyboard_vbox.get_children():
                self.keyboard_vbox.remove(child)

    def select_default_layout(self):
        sets = get_effective_layout_sets()
        set_def = sets.get(self.current_layout_set, {})
        default_id = set_def.get("default_layout")

        if default_id and default_id in self.layout_defs:
            self.current_layout = default_id
        elif self.layout_defs:
            self.current_layout = next(iter(self.layout_defs))
        else:
            self.current_layout = None

    def build_layout_buttons(self):
        # Clear existing buttons
        for child in self.layout_hbox.get_children():
            self.layout_hbox.remove(child)

        self.layout_buttons = []
        self.layout_defs = {}

        sets = get_effective_layout_sets()
        set_def = sets.get(self.current_layout_set, {})
        layouts = set_def.get("layouts", [])

        set_invalid = False
        resolved_layouts = []

        # ---- Pass 1: validate and resolve ----
        for rows_ref, layout_id, label, tooltip in layouts:
            # structural sanity
            assert isinstance(layout_id, str), "layout_id must be a string"
            assert isinstance(label, str), f"{layout_id}: label must be a string"
            assert tooltip is None or isinstance(
                tooltip, str
            ), f"{layout_id}: tooltip must be a string or None"

            # resolve rows
            if isinstance(rows_ref, str):
                rows = globals().get(rows_ref)
                if rows is None:
                    LOG.warning(
                        "VirtualKeyboard: layout set '%s' invalid: "
                        "layout '%s' references undefined rows '%s'",
                        self.current_layout_set,
                        layout_id,
                        rows_ref,
                    )
                    set_invalid = True
                    continue
            else:
                rows = rows_ref

            if not isinstance(rows, list):
                LOG.warning(
                    "VirtualKeyboard: layout set '%s' invalid: "
                    "layout '%s' rows must be a list",
                    self.current_layout_set,
                    layout_id,
                )
                set_invalid = True
                continue

            resolved_layouts.append((rows, layout_id, label, tooltip))

        # ---- Abort entire set if anything was wrong ----
        if set_invalid:
            LOG.warning(
                "VirtualKeyboard: layout set '%s' is invalid; falling back to 'error keyboard layout'",
                self.current_layout_set,
            )
            self.current_layout_set = "oops"
            return self.build_layout_buttons()

        # ---- Pass 2: build buttons ----
        for rows, layout_id, label, tooltip in resolved_layouts:
            btn = Gtk.ToggleButton(label=label)
            btn.set_tooltip_text(tooltip)
            btn.connect("toggled", self.on_layout_toggled, layout_id)

            self.layout_hbox.pack_start(btn, True, True, 0)
            self.layout_buttons.append((layout_id, btn))
            self.layout_defs[layout_id] = rows

        self.layout_hbox.set_visible(True)
        self.layout_hbox.show_all()
        return True

    def set_active_layout(self, layout_id):
        """Activate a layout button and build its keyboard."""
        if layout_id not in self.layout_defs:
            return

        self.current_layout = layout_id

        for other_id, btn in self.layout_buttons:
            btn.set_active(other_id == layout_id)

        self.build_keyboard(layout_id)

    def on_layout_toggled(self, btn, layout_id):
        if not btn.get_active():
            return
        self.current_layout = layout_id
        self.build_keyboard(layout_id)

        for other_id, other_btn in self.layout_buttons:
            if other_btn is not btn:
                other_btn.set_active(False)

    def build_keyboard(self, layout_id):
        if not hasattr(self, "keyboard_vbox"):
            return

        for child in self.keyboard_vbox.get_children():
            self.keyboard_vbox.remove(child)

        rows = self.layout_defs.get(layout_id)
        if not rows:
            return

        for row_chars in rows:
            hbox = Gtk.Box(spacing=1)
            for ch in row_chars:
                if ch == " ":
                    spacer = Gtk.Box()
                    spacer.set_size_request(10, -1)  # half-key or fixed width
                    spacer.set_has_tooltip(False)
                    hbox.pack_start(spacer, False, False, 0)
                    continue
                btn = Gtk.Button(label=ch)
                btn.set_has_tooltip(False)
                btn.connect("clicked", self.on_char_clicked, ch)
                hbox.pack_start(btn, True, True, 0)

            self.keyboard_vbox.pack_start(hbox, False, False, 0)

        self.keyboard_vbox.show_all()

    def update_flag_buttons(self):
        """
        Update flag button sensitivity based on current layout set.
        """
        for set_id, btn in self.flag_buttons:
            # Make all buttons sensitive (they can be right-clicked to switch)
            btn.set_sensitive(True)

    def on_char_clicked(self, btn, ch):
        """Insert character at cursor position in display field."""
        # Get current cursor position
        cursor_pos = self.display.get_position()
        # Get current text
        current_text = self.display.get_text()
        # Insert character at cursor position
        new_text = current_text[:cursor_pos] + ch + current_text[cursor_pos:]
        # Update buffer and display
        self.buffer = new_text
        self.display.set_text(self.buffer)
        # Move cursor to after the inserted character
        self.display.set_position(cursor_pos + 1)

    def on_backspace(self, btn):
        """Delete character before cursor position."""
        cursor_pos = self.display.get_position()
        current_text = self.display.get_text()
        if cursor_pos > 0:
            new_text = current_text[: cursor_pos - 1] + current_text[cursor_pos:]
            self.buffer = new_text
            self.display.set_text(self.buffer)
            self.display.set_position(cursor_pos - 1)

    def on_clear(self, btn):
        self.buffer = ""
        self.display.set_text(self.buffer)

    def on_space(self, btn):
        """Insert space at cursor position."""
        cursor_pos = self.display.get_position()
        current_text = self.display.get_text()
        new_text = current_text[:cursor_pos] + " " + current_text[cursor_pos:]
        self.buffer = new_text
        self.display.set_text(self.buffer)
        self.display.set_position(cursor_pos + 1)

    def on_tab(self, btn):
        """Insert tab at cursor position."""
        cursor_pos = self.display.get_position()
        current_text = self.display.get_text()
        new_text = current_text[:cursor_pos] + "\t" + current_text[cursor_pos:]
        self.buffer = new_text
        self.display.set_text(self.buffer)
        self.display.set_position(cursor_pos + 1)

    def on_newline(self, btn):
        """Insert newline at cursor position."""
        cursor_pos = self.display.get_position()
        current_text = self.display.get_text()
        new_text = current_text[:cursor_pos] + "\n" + current_text[cursor_pos:]
        self.buffer = new_text
        self.display.set_text(self.buffer)
        self.display.set_position(cursor_pos + 1)

    def on_copy_clipboard(self, btn):
        clip = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        clip.set_text(self.buffer, -1)
