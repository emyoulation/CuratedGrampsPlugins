# Virtual Keyboard (ReadMe)
[ReadMe.md](README.md) ● [Change Log](ChangeLog.md) ● [Adding a custom Virtual Keyboard layout](CustomLayouts.md) ● [hacking](Hacking.md) 

> **Status: proposed, not yet available.** "Insert Symbols" is a change to Gramps' own core text-editing menus that has been designed and written, but has not been submitted to or merged into Gramps. It is not part of any released version of Gramps, and it is not something you can currently download or install — a future update to Gramps itself would need to include it first. This document describes how it's intended to work once (if) that happens. The **Virtual Keyboard** add-on mentioned throughout is a separate, already-real add-on you can install today (see below) — but its "Open Virtual Keyboard" button described here only appears once "Insert Symbols" itself is present, so installing Virtual Keyboard alone won't give you that button yet. 

Ever need to type a currency symbol, a fraction, or a letter with an accent — into a Gramps field, but your keyboard doesn't have a key for it? "Insert Symbols" is meant to add a quick way to insert characters like that without leaving the field you're typing in. 

## Setting it up 

**Insert Symbols** itself has no setup, because there's currently nothing to set up — see the status note above. Once it ships as part of a Gramps update, it will simply appear in the right-click menu of text fields, the same way Cut, Copy, and Paste do, with nothing to turn on. 

The **Virtual Keyboard** add-on, separately, is real and installable today: 

1. In Gramps' menu bar, go to **Edit → Addon Manager** — or click the green jigsaw-puzzle-piece icon on the toolbar, which opens the same dialog. 2. Virtual Keyboard won't show up under the Addon Manager's default filters. Change the **Audience** filter from "Everyone" to **All**, and the **Status** filter from "Stable" to **All** — Virtual Keyboard is marked Expert / Experimental, so the defaults hide it. 3. Type "Virtual" or "Keyboard" into the search box. 4. Select it in the list and click **Install**. 5. If Gramps asks you to restart, do so. 

A note on those labels: **Expert** means it's aimed at people comfortable with a bit of extra complexity, not at first-time users. **Experimental** means it's still under active development and hasn't had the same real-world testing as Gramps' long-established add-ons. Neither label means it's broken — just that it's newer and more specialized than most. 

Once "Insert Symbols" itself does ship, having Virtual Keyboard installed this way will be enough — you won't need to add it to your Dashboard, sidebar, or bottom bar. The **Open Virtual Keyboard** button described below is meant to load it directly, wherever you're typing. 

## Where to find it 

Right-click inside almost any text box in Gramps — a place name, a note, a person's title, and so on. Alongside the usual **Cut**, **Copy**, **Paste** options, there will be a new item: 

> **Insert Symbols…** 

Clicking it opens a small popup right where your cursor is. 

## Inserting one symbol 

The popup has two tabs: 

- **Genealogical symbols** — the standard symbols genealogists use, like birth, marriage, and death markers. - **Death symbols** — a focused set of the different ways a death can be marked. 

Hovering over a symbol shows its name; clicking it inserts it right where your cursor was, and the popup closes automatically — the same way clicking **Paste** would. If you only need one symbol, that's the whole process. 

## Typing several symbols, or a different alphabet 

Sometimes one symbol isn't enough — maybe you're typing several accented letters in a row, or need characters your keyboard just doesn't have. The Virtual Keyboard is a general-purpose on-screen keyboard, not a genealogy-specific one; it's suited to things like: 

- Accented and diacritical letters (é, ñ, ü, and others), for names and places in other languages - Currency symbols - Fractions - Special annotation marks used in transcription, such as ⁂ § ¶ ‡ № ● ° © ® 

For any of that, the popup has a button at the bottom: 

> **Open Virtual Keyboard** 

This opens a separate, full-size on-screen keyboard window. Unlike the quick popup, this window **stays open**, so you can click as many characters as you like, one after another, and each one appears in your original field immediately. 

A few things about this window: 

- **It remembers your language.** It opens already set to match the language Gramps itself is running in, if a matching layout exists. A dropdown near the top lets you switch to any other available layout at any time. - **It types where you were.** Everything you click goes straight into the field you started from — no copying and pasting. - **It has its own Backspace, Space, Tab, and Enter keys**, so you can correct mistakes or add spacing without switching back to your regular keyboard. - **You can leave it open** while you keep working, and close it whenever you're done — just like any other Gramps window. Gramps will remember its size and position for next time. 

## Why two separate tools? 

The quick popup is for the common case: you need one symbol, right now, without breaking your typing flow. The Virtual Keyboard is for more sustained typing — several accented letters, or other characters your keyboard lacks. Keeping them separate means the everyday case (one click, done) stays fast, while the more involved case still has a proper, comfortable window to work in. 

## If "Open Virtual Keyboard" doesn't work 

Once "Insert Symbols" is available and you see a message saying Virtual Keyboard couldn't be found, loaded, or is out of date: open **Edit → Addon Manager** (or the toolbar's jigsaw-puzzle icon), set the Audience and Status filters to **All** (see above — Virtual Keyboard won't appear otherwise), search for "Virtual Keyboard", and install or update it from there. 

## Frequently asked questions 

**Can I add my own custom symbols?** Not through the "Insert Symbols" popup itself — its two tabs list Gramps' own fixed, built-in set of genealogical and death symbols, and that list isn't tied to whatever you may have chosen under Preferences' "Genealogical Symbols" settings elsewhere in Gramps; the two aren't connected. 

The **Virtual Keyboard** is a different story: you genuinely can add your own layout, with your own favorite characters, by dropping in a plain text file — no genealogy focus required, and none exists today (though someone could compose one in the future). See [Adding a custom Virtual Keyboard layout](CustomLayouts.md) for how. 

**Does this work in every field?** It's meant to work in any standard Gramps text field that supports right-click menus — names, places, notes, titles, and similar. A few specialized fields elsewhere in Gramps may not have it. 

**Should I use this or "Insert Emoji" for a symbol I need?** For a single well-known symbol — a heart, a checkmark, a star — "Insert Emoji" (also in the right-click menu) is usually the faster choice: it lets you search by name and browse by category, which makes finding one specific symbol among thousands quick. "Insert Symbols" doesn't try to compete with that. Reach for it instead for characters Insert Emoji doesn't have — for example the Virtual Keyboard's accented letters, currency symbols, fractions, or transcription marks. The two tools aren't mutually exclusive — they're just aimed at different jobs.
