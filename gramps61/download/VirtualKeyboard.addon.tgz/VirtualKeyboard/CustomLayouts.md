# Adding a custom Virtual Keyboard layout
[ReadMe.md](README.md) ● [Change Log](ChangeLog.md) ● [Adding a custom Virtual Keyboard layout](CustomLayouts.md) ● [hacking](Hacking.md) 

This is a guide for moderately technical users — comfortable editing a
plain text file and finding a folder on disk, but not necessarily
Python programmers. If you want a Virtual Keyboard layout with your own
favorite set of characters (a different language, a specialized symbol
set, whatever you like), you can add one without touching any code, by
dropping a `.csv` file into the addon's `layouts` folder.

**The `@directive,value` format below is intentional, not a mistake.**
It's the normative, frozen "VirtualKeyboard External Layout
Specification v1.2.0" — a real design document, not something an AI
tool introduced by accident. Despite the `.csv` extension, this is a
line-directive format, not spreadsheet-style columns; if that surprised
you on first look, that reaction is reasonable, but it's how the format
has always been meant to work.

As of the v1.4.0 update, files are also validated against that
specification before anything is accepted — see
["When a file fails to load"](#when-a-file-fails-to-load) below for
what changed and why.

## Where the file goes

Find the folder where `virtualkeyboard.py` itself is installed — this
is wherever Gramps put the addon when you installed it (typically
somewhere under your Gramps user data directory; the Addon Manager
doesn't show this path directly, but it's the same place any other
Gramps add-on's `.py` file lives on your system). Inside that folder,
look for (or create) a subfolder named exactly:

```
layouts/
```

Any file ending in `.csv` inside that folder is picked up automatically
— there's nothing to register or declare elsewhere. Three working
examples ship with v1.4.0 in this folder already: `dvorak.csv`,
`fr.csv`, and `pl.csv` — open any of them alongside this guide.

## The filename is the identifier

This is the single most important, least obvious rule: **the file's own
name (without `.csv`) is what the addon uses to identify the layout
set** — not the `@id` field written inside the file. If you name your
file `es.csv`, its set id is `es`, regardless of what `@id` says inside
it. The filename is also what's compared against Gramps' own current
interface language to decide which layout set opens by default — name
a set to match a real two-letter language code (`es`, `de`, `pt`, ...)
if you want that automatic behavior; any other name still works, it
just won't be auto-selected by language.

## File format

Every meaningful line starts with `@`, followed by a directive name, a
comma, and a value:

```
@directive,value
```

- Blank lines are ignored.
- Lines starting with `#` are treated as comments and ignored.
- **Any other line — one that isn't blank, isn't a `#` comment, and
  doesn't start with `@` — is now treated as an error**, not silently
  skipped. A whole file with no `@` lines at all (for example, a plain
  spreadsheet-style CSV) is flagged specifically as not looking like a
  v1.2.0 layout file, rather than just quietly producing nothing.

A file has two kinds of sections: **set-level** directives (before the
first `@layout` line) describing the layout set as a whole, and one or
more **`@layout` blocks**, each describing one page of the on-screen
keyboard (what shows up as one of the toggle buttons above the key
grid).

### Set-level directives

Written before the first `@layout` line. `@id`, `@language`, `@button`,
and `@default_layout` are now all **required** — a file missing any of
them is rejected in full.

| Directive | Meaning |
|---|---|
| `@id,<text>` | **Required.** An identifying label for the set. Informational only for lookup purposes — the filename is what actually identifies the set (see above) — but its presence is still checked. |
| `@language,<code>` | **Required.** A language code, for your own documentation. Not currently used for the automatic language-matching described above — that match is done on the filename, not this field. |
| `@button,<text>` | **Required.** Short label shown in the language selector (an emoji flag like `🇪🇸`, or any short text). |
| `@default_layout,<layout id>` | **Required.** Which `@layout` (by its own `@id`, see below) is shown first when this set is selected. |
| `@label_native,<text>` | The set's display name in its own language, e.g. `Español`. |
| `@label_en,<text>` | The set's display name in English, e.g. `Spanish`. |
| `@label,<text>` | Shorthand for `@label_en` if you don't need a separate native-language name. |
| `@tooltip_native,<text>` / `@tooltip_en,<text>` | Accepted and stored, but not currently displayed anywhere in the language selector. Harmless to include; just don't expect to see them yet. |
| `@set` | Marks the start of the header. Currently a no-op beyond that. |

### `@layout` blocks

Each `@layout` line starts a new page of the keyboard. Everything after
it, up to the next `@layout` or the end of the file, belongs to that
layout.

| Directive | Meaning |
|---|---|
| `@id,<text>` | **Required.** The layout's own id, e.g. `qwerty`, `accents`. A layout without an `@id` fails validation. |
| `@label_native,<text>` / `@label_en,<text>` / `@label,<text>` | **At least one required.** The text shown on this layout's own toggle button. |
| `@tooltip_native,<text>` / `@tooltip_en,<text>` | The tooltip shown when hovering that toggle button — these **are** actively displayed. |
| `@row,"<characters>"` | One row of the on-screen key grid. Repeat for each row, top to bottom. **Must be quoted** — see below. |

## Row contents and quoting

Each `@row` line becomes one row of buttons — one button per character
in the string. A literal space character becomes a small visual gap,
not a clickable space key (there's already a dedicated Space key below
the grid for that).

**Every `@row` value must be wrapped in double quotes, with no
exceptions** — not just rows containing a comma:

```
@row,ab           <- invalid: fails validation, whole file rejected
@row,"ab"         <- correct
@row,ab,cd        <- invalid: looks like it should mean "ab,cd", but
                     isn't quoted, so it's rejected rather than
                     silently keeping only "ab" and losing ",cd"
@row,"ab,cd"      <- correct: keeps "ab,cd" as one row
```

If a row's own characters include a literal double quote, double it,
per standard CSV escaping: `@row,"she said ""hi"""`.

## When a file fails to load

**This changed in v1.4.0.** Previously, a malformed file (or one row
with a quoting mistake) could silently lose data or vanish from the
language selector with nothing but a log entry to explain why. Now:

- **The whole file is rejected if anything is wrong with it** — a
  missing required directive, an unquoted `@row`, an `@row` outside an
  `@layout` block, or content that doesn't look like this format at
  all. Partial loading never happens; either the whole file is valid,
  or none of it is used.
- **Every problem is listed together**, with line numbers, in the
  Gramps log — not just the first one found.
- **The failure is visible in the language selector itself**, not just
  the log: a broken file's slot shows up labeled `⚠ <filename>
  (invalid)` instead of silently disappearing, so you know something
  needs fixing even if you never look at the log.
- **When available**, a summary also appears on the Gramps status bar.

To see the full details, run Gramps from a terminal or command prompt
rather than double-clicking its icon — entries starting with
`VirtualKeyboard:` will print there.

## Worked example

A minimal two-page Spanish layout, saved as `layouts/es.csv`:

```
@set
@id,ES_QWERTY
@language,es
@button,🇪🇸
@label_native,Español
@label_en,Spanish
@default_layout,qwerty

@layout
@id,qwerty
@label_en,QWERTY
@tooltip_en,Standard Spanish keyboard layout
@row,"1234567890'¡"
@row,"qwertyuiop`+"
@row,"asdfghjklñ´"
@row,"zxcvbnm,.-"

@layout
@id,accents
@label_en,Accents
@tooltip_en,Spanish accented letters
@row,"áéíóúÁÉÍÓÚñÑ¿¡"
```

Save the file as UTF-8 (most modern text editors default to this; if
your editor offers an encoding choice, pick UTF-8 explicitly).

## Trying it out

Open the Virtual Keyboard (via the "Insert Symbols" popup's **Open
Virtual Keyboard** button, once that feature is available — see the
main README's status note). Your new set appears in the language
dropdown by its filename, e.g. `es`. There's no need to restart Gramps
or reinstall anything — the addon re-reads every `.csv` file in the
`layouts` folder each time the keyboard window opens, so editing the
file and reopening the window is enough to see your changes.

## Reference

The bundled `dvorak.csv`, `fr.csv`, and `pl.csv` are working, validated
examples — when in doubt, compare your file against one of these rather
than this guide's prose. The full normative specification is the
"VirtualKeyboard External Layout Specification v1.2.0" document; this
guide is a walkthrough of it, not a replacement for it.
