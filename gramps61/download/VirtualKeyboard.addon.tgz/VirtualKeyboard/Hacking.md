# Installing the Insert Symbols patch (unofficial, do-it-yourself)
[ReadMe.md](README.md) ● [Change Log](ChangeLog.md) ● [Adding a custom Virtual Keyboard layout](CustomLayouts.md) ● [hacking](Hacking.md) 

This is for moderately technical users: comfortable finding files on disk, editing plain text files, and undoing a mistake by restoring from a backup. It is **not** an officially supported Gramps installation procedure. Nothing described here has been submitted to or accepted by the Gramps project. You're installing a personal patch on top of your own Gramps install, not a real add-on — there's no uninstaller, no update mechanism, and no guarantee it survives your next Gramps upgrade.

If that's more than you want to take on, the honest alternative is to wait until (if) this is accepted into a real Gramps release, at which point none of this will be necessary.

**One-time, not per-dialog.** Everything in Steps 2 and 4 is a single edit to a single shared file, done once. It is not something you redo for every editor, every dialog, or every text field — patching a base class that dozens of dialogs are built from patches all of them at once, because they all run the same code. The only thing that's ever done per-field is the *optional* extra button described in Step 4c, and that's clearly its own separate, skippable step.

## Before you touch anything: back up

Find and copy the entire `gramps` application package folder somewhere safe before making any change below. If something goes wrong, you restore that copy and you're back to a working, unmodified Gramps.

## Step 1: Find your exact paths

The easiest and most reliable way to find every path this guide refers to is to run this script from inside Gramps itself, using the **Python Evaluation** gramplet — it reports the paths your own, currently-running Gramps is actually using, rather than guessing from a separate terminal that might have a different Python or a different Gramps install in view (this matters especially for the Windows all-in-one installer and macOS app bundles).

If you don't already have the Python Evaluation gramplet added to a sidebar, bottombar, or the Dashboard, add it first (right-click an empty area of one of those and choose **Add a Gramplet → Python Evaluation**). Then paste the whole [find files script](Gtk3patches/find_patch_paths.md) script into its "Evaluation" box and click **Apply**:

> ### Gtk3 Patch Paths for Gramps 5.2-6.1
> **Gramps 5.2 package folder**
> /home/districtsupport/.local/lib/python3.11/site-packages/gramps
>
> **Step 1: install the 1.4.0+ Virtual Keyboard add-on**
> Installed version 1.4.0 -- already satisfies Step 1, nothing further needed here.
> **Step 2: copy these files into the following folder:**
> /home/districtsupport/.local/lib/python3.11/site-packages/gramps/gui/widgets
> * addonlookup.py
> * symbolpopover.py
> * textinsertion.py
> **Step 4: file to patch for Insert Symbols wiring**
> /home/districtsupport/.local/lib/python3.11/site-packages/gramps/gui/widgets/monitoredwidgets.py


- **If you're on the Windows all-in-one installer**, Gramps bundles its own Python; look under wherever you installed Gramps (commonly something like `C:\Program Files\GrampsAIO64-<version>\`) for a `lib` or similar folder containing the same `gramps` package structure.

- **On macOS**, if you installed via the `.dmg` app bundle, the `gramps` package is inside the app bundle's contents; if you installed via Homebrew or `pip` instead, use the same `python3` command as above.

The rest of this guide assumes you now have: the `gramps/gui/widgets` folder (for Step 2), the `monitoredwidgets.py` path (for Step 4), and whether Virtual Keyboard needs updating (for Step 3).

## Step 4: Install Virtual Keyboard v1.4.0 or later

As of v1.4.0 beta version of Virtual Keyboard, the patches to the core are bundled with the addon.

Install or update Virtual Keyboard the normal way: Edit → Addon Manager (or the toolbar's jigsaw-puzzle icon), with the Status filters set to "All" (see the main README — Virtual Keyboard is still marked Expert/Experimental), search for "Virtual Keyboard", and install or update to v1.4.0 or later. No manual file replacement, no backup of `virtualkeyboard.py` needed, and no re-doing this step after future Virtual Keyboard updates the way the old Step 3 required.

## Step 2: Install the three new core files

Copy these three files into the `gui/widgets` folder from Step 1 (alongside existing files like `monitoredwidgets.py`):

- `textinsertion.py`
- `symbolpopover.py`
- `addonlookup.py`

These are new files — nothing exists there yet to overwrite or back up. This is a one-time copy; it doesn't need repeating per editor or per dialog.

## Step 4: Wire "Insert Symbols" into Gramps' editors

Nothing calls the new `symbolpopover.py` yet — it's a capability, not a behavior, until something asks a text field to use it. Steps 4a and 4b below are each a **single edit, made once**, to one shared file: `monitoredwidgets.py`, in the `gui/widgets` folder from Step 1. They are not done per dialog or per editor — every Gramps dialog that uses a standard text field is already built on the two classes these steps patch, so patching the class patches every dialog that uses it, automatically, everywhere, in one pass.

**Back up `monitoredwidgets.py` before editing it.**

### 4a. Single-line fields (names, titles, place names, and similar)

One edit, made once, in `monitoredwidgets.py`. Find `class MonitoredEntry:` and its `__init__` method. Near the top of the file, add an import; inside `__init__`, add one line:

```python
from gramps.gui.widgets.symbolpopover import attach_symbol_popup

class MonitoredEntry:
    def __init__(
        self, obj, set_val, get_val, read_only=False, autolist=None, changed=None
    ):
        self.obj = obj
        self.set_val = set_val
        self.get_val = get_val
        self.changed = changed

        attach_symbol_popup(self.obj)   # <-- add this line

        if get_val():
            self.obj.set_text(get_val())
        ...
```

This one edit gives you the "Insert Symbols" popup — single click, insert, close — on essentially every single-line text field across every Gramps editor and dialog, immediately, with nothing further to repeat anywhere. It does **not** include the "Open Virtual Keyboard" button, because that needs `uistate`/`track`, which `MonitoredEntry` doesn't have access to (see 4c below for that, which — unlike this step — genuinely is done per field).

### 4b. Multi-line fields (notes and similar)

Also one edit, made once, in the same file. Find `class MonitoredText:` and add the same call in its `__init__`, using `obj`
directly (it's already the raw `Gtk.TextView`):

```python
class MonitoredText:
    def __init__(self, obj, set_val, get_val, read_only=False):
        attach_symbol_popup(obj)   # <-- add this line
        self.buf = obj.get_buffer()
        ...
```

Same effect as 4a, for multi-line fields (notes and similar) instead of single-line ones: one edit, every dialog with such a field gets it.

### 4c. Optional, and genuinely per-field: adding the "Open Virtual Keyboard" button

Unlike 4a and 4b, **this step is done separately for each specific field** where you want the extra button — there's no single shared hook point for it the way there is for the plain popup above, because the undock button needs `uistate` and `track`, which `MonitoredEntry` and `MonitoredText` don't have access to. Skip this section entirely if the plain "Insert Symbols" popup from 4a/4b is all you want; it already works everywhere without this.

To add it to a particular field, go into a specific editor (one of the files under `gramps/gui/editors/`) that already has `self.uistate` and `self.track` — every editor built on `gramps.gui.managedwindow.ManagedWindow` does. Wherever that editor builds a `MonitoredEntry(...)` or `MonitoredText(...)` for the field you want the button on, add a call right after it:

```python
from functools import partial
from gramps.gui.widgets.addonlookup import load_addon_function
from gramps.gui.widgets.symbolpopover import attach_symbol_popup

def _open_virtual_keyboard(target, uistate, track=None):
    open_fn = load_addon_function(
        "VirtualKeyboard",
        "open_virtual_keyboard_window",
        uistate,
        _("Virtual Keyboard"),
    )
    if open_fn is not None:
        open_fn(target, uistate, track=track)

# after the field's MonitoredEntry/MonitoredText is created:
attach_symbol_popup(
    the_entry_widget,
    undock_label=_("Open Virtual Keyboard"),
    undock_factory=partial(
        _open_virtual_keyboard, uistate=self.uistate, track=self.track
    ),
)
```

Repeat this in each editor where you specifically want the button — there's no way to get it everywhere in one edit the way 4a/4b do for the plain popup.

## Reverting

Restore the backups you made in each step:

- Delete the three files you added in Step 2.
- Uninstall or downgrade Virtual Keyboard from Step 3, if desired, the normal way — through the Addon Manager.
- Restore your backed-up `monitoredwidgets.py` from Step 4.

A normal Gramps reinstall or update will **not** automatically undo any of this — hand-copied files aren't tracked by Gramps' own installer, so restoring your backups is the only reliable way back for Steps 2 and 4.
Step 3 alone is safe to manage through the Addon Manager as usual.

## Known limitations

- **This won't survive a Gramps upgrade.** A future Gramps update will ship its own `monitoredwidgets.py` (and possibly its own `gui/widgets/` files generally), overwriting your patched versions.
  You'll need to redo Steps 2 and 4 after every Gramps update — once each, not per dialog, same as the original install.
- **This is unreviewed, personal-use code.** It hasn't gone through Gramps' own review process, isn't tested the way an accepted add-on or core change would be, and shouldn't be redistributed to others as if it were.
