# Installing the Insert Symbols patch (unofficial, do-it-yourself)

This is for moderately technical users: comfortable finding files on
disk, editing plain text files, and undoing a mistake by restoring from
a backup. It is **not** an officially supported Gramps installation
procedure. Nothing described here has been submitted to or accepted by
the Gramps project. You're installing a personal patch on top of your
own Gramps install, not a real add-on — there's no uninstaller, no
update mechanism, and no guarantee it survives your next Gramps upgrade.

If that's more than you want to take on, the honest alternative is to
wait until (if) this is accepted into a real Gramps release, at which
point none of this will be necessary.

## Before you touch anything: back up

Find and copy the entire `gramps` package folder somewhere safe before
making any change below. If something goes wrong, you restore that
copy and you're back to a working, unmodified Gramps.

## Step 1: Find your Gramps installation folder

You need the folder containing Gramps' own Python code — the one with
subfolders like `gui`, `gen`, `plugins`, and so on.

- **If Gramps runs from a normal Python install** (common on Linux, and
  for Gramps installed via `pip`), open a terminal and run:

  ```
  python3 -c "import gramps, os; print(os.path.dirname(gramps.__file__))"
  ```

  That prints the folder you need.

- **If you're on the Windows all-in-one installer**, Gramps bundles its
  own Python; look under wherever you installed Gramps (commonly
  something like `C:\Program Files\GrampsAIO64-<version>\`) for a `lib`
  or similar folder containing the same `gramps` package structure.

- **On macOS**, if you installed via the `.dmg` app bundle, the
  `gramps` package is inside the app bundle's contents; if you
  installed via Homebrew or `pip` instead, use the same `python3`
  command as above.

If you're not sure which of these applies to you, this is a reasonable
place to stop and ask for help rather than guess — the rest of this
guide assumes you can find this folder correctly.

## Step 2: Install the three new core files

Copy these three files into `<your gramps folder>/gui/widgets/`
(alongside existing files like `monitoredwidgets.py`):

- `textinsertion.py`
- `symbolpopover.py`
- `addonlookup.py`

These are new files — nothing exists there yet to overwrite or back up.

## Step 3: Install Virtual Keyboard v1.4.0 or later

Earlier versions of this guide had you manually swap in a patched
`virtualkeyboard.py`. As of v1.4.0, that patch is bundled into the
add-on itself — `VirtualKeyboardPanel`, `VirtualKeyboardWindow`, and
`open_virtual_keyboard_window` all ship as part of the add-on, so
there's nothing to hand-copy here anymore.

Install or update Virtual Keyboard the normal way: Edit → Addon
Manager (or the toolbar's jigsaw-puzzle icon), with the Audience and
Status filters set to "All" (see the main README — Virtual Keyboard is
still marked Expert/Experimental), search for "Virtual Keyboard", and
install or update to v1.4.0 or later. No manual file replacement, no
backup of `virtualkeyboard.py` needed, and no re-doing this step after
future Virtual Keyboard updates the way the old Step 3 required.

## Step 4: Wire "Insert Symbols" into Gramps' editors

Nothing calls the new `symbolpopover.py` yet — it's a capability, not a
behavior, until something asks a text field to use it. The most
efficient way to enable it broadly is to patch the two shared base
classes nearly every Gramps editor field is built from, in
`<your gramps folder>/gui/widgets/monitoredwidgets.py`.

**Back up `monitoredwidgets.py` before editing it.**

### 4a. Single-line fields (names, titles, place names, and similar)

Find `class MonitoredEntry:` and its `__init__` method. Near the top,
add an import and one line:

```python
from gramps.gui.widgets.symbolpopover import attach_symbol_popup

class MonitoredEntry:
    def __init__(
        self, obj, set_val, get_val, read_only=False, autolist=None, changed=None
    ):
        self.obj = obj
        self.set_val = set_val
        self.get_val = get_val
        self.changed = changed

        attach_symbol_popup(self.obj)   # <-- add this line

        if get_val():
            self.obj.set_text(get_val())
        ...
```

This alone gives you the "Insert Symbols" popup — single click, insert,
close — on essentially every single-line text field across Gramps. It
does **not** include the "Open Virtual Keyboard" button, because that
needs `uistate`/`track`, which `MonitoredEntry` doesn't have access to
(see 4c below for that).

### 4b. Multi-line fields (notes and similar)

Find `class MonitoredText:` in the same file and add the same call in
its `__init__`, using `obj` directly (it's already the raw
`Gtk.TextView`):

```python
class MonitoredText:
    def __init__(self, obj, set_val, get_val, read_only=False):
        attach_symbol_popup(obj)   # <-- add this line
        self.buf = obj.get_buffer()
        ...
```

### 4c. Optional: adding the "Open Virtual Keyboard" button to one field

The undock button needs `uistate` and `track`, which aren't available
inside `monitoredwidgets.py`. To add it, you have to go into a specific
editor (one of the files under `gramps/gui/editors/`) that already has
`self.uistate` and `self.track` — every editor built on
`gramps.gui.managedwindow.ManagedWindow` does.

Wherever that editor builds a `MonitoredEntry(...)` or
`MonitoredText(...)` for a field you want the button on, add a call
right after it:

```python
from functools import partial
from gramps.gui.widgets.addonlookup import load_addon_function
from gramps.gui.widgets.symbolpopover import attach_symbol_popup

def _open_virtual_keyboard(target, uistate, track=None):
    open_fn = load_addon_function(
        "VirtualKeyboard",
        "open_virtual_keyboard_window",
        uistate,
        _("Virtual Keyboard"),
    )
    if open_fn is not None:
        open_fn(target, uistate, track=track)

# after the field's MonitoredEntry/MonitoredText is created:
attach_symbol_popup(
    the_entry_widget,
    undock_label=_("Open Virtual Keyboard"),
    undock_factory=partial(
        _open_virtual_keyboard, uistate=self.uistate, track=self.track
    ),
)
```

Do this per field, in whichever specific editors you actually want the
button on — there's no single shared hook point for it the way there is
for the plain popup in step 4a/4b.

## Reverting

Restore the backups you made in each step:

- Delete the three files you added in Step 2.
- Uninstall or downgrade Virtual Keyboard from Step 3, if desired,
  the normal way — through the Addon Manager.
- Restore your backed-up `monitoredwidgets.py` from Step 4.

A normal Gramps reinstall or update will **not** automatically undo any
of this — hand-copied files aren't tracked by Gramps' own installer, so
restoring your backups is the only reliable way back for Steps 2 and 4.
Step 3 alone is safe to manage through the Addon Manager as usual.

## Known limitations

- **This won't survive a Gramps upgrade.** A future Gramps update will
  ship its own `monitoredwidgets.py` (and possibly its own
  `gui/widgets/` files generally), overwriting your patched versions.
  You'll need to redo Steps 2 and 4 after every Gramps update.
- **This is unreviewed, personal-use code.** It hasn't gone through
  Gramps' own review process, isn't tested the way an accepted add-on
  or core change would be, and shouldn't be redistributed to others as
  if it were.
