#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2025  Phonetic Matching Gramplet contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Unit tests for :mod:`encoders.nysiis`.

The reference vectors below are transcribed from Apache Commons
Codec's own ``NysiisTest.java`` (the same reference implementation
``encoders/nysiis.py`` was ported from), covering every documented
rule and edge case, not just a handful of hand-picked names:
https://github.com/apache/commons-codec/blob/master/src/test/java/org/apache/commons/codec/language/NysiisTest.java
"""

# ------------------------
# Python modules
# ------------------------
import os
import sys
import unittest

# ------------------------
# Gramps specific
# ------------------------
# See the note in test/phonetic_codes_test.py: this addon is not an
# installed package, so "encoders" cannot be reached with a
# package-relative import from two directories down.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))

from encoders import nysiis

# (input, expected full/untruncated NYSIIS code) pairs from
# NysiisTest.java, using its `fullNysiis` (non-strict) encoder for
# every case except the one specifically marked strict-mode below.
REFERENCE_VECTORS = [
    # testBran
    ("Brian", "BRAN"),
    ("Brown", "BRAN"),
    ("Brun", "BRAN"),
    # testCap
    ("Capp", "CAP"),
    ("Cope", "CAP"),
    ("Copp", "CAP"),
    ("Kipp", "CAP"),
    # testDad
    ("Dent", "DAD"),
    # testDan
    ("Dane", "DAN"),
    ("Dean", "DAN"),
    ("Dionne", "DAN"),
    # testDropBy
    ("MACINTOSH", "MCANT"),
    ("KNUTH", "NAT"),
    ("KOEHN", "CAN"),
    ("PHILLIPSON", "FALAPSAN"),
    ("PFEISTER", "FASTAR"),
    ("SCHOENHOEFT", "SANAFT"),
    ("MCKEE", "MCY"),
    ("MACKIE", "MCY"),
    ("HEITSCHMIDT", "HATSNAD"),
    ("BART", "BAD"),
    ("HURD", "HAD"),
    ("HUNT", "HAD"),
    ("WESTERLUND", "WASTARLAD"),
    ("CASSTEVENS", "CASTAFAN"),
    ("VASQUEZ", "VASG"),
    ("FRAZIER", "FRASAR"),
    ("BOWMAN", "BANAN"),
    ("MCKNIGHT", "MCNAGT"),
    ("RICKERT", "RACAD"),
    ("DEUTSCH", "DAT"),
    ("WESTPHAL", "WASTFAL"),
    ("SHRIVER", "SRAVAR"),
    ("KUHL", "CAL"),
    ("RAWSON", "RASAN"),
    ("JILES", "JAL"),
    ("CARRAWAY", "CARY"),
    ("YAMADA", "YANAD"),
    # testFal
    ("Phil", "FAL"),
    # testOthers
    ("O'Daniel", "ODANAL"),
    ("O'Donnel", "ODANAL"),
    ("Cory", "CARY"),
    ("Corey", "CARY"),
    ("Kory", "CARY"),
    ("FUZZY", "FASY"),
    # testRule1
    ("MACX", "MCX"),
    ("KNX", "NX"),
    ("KX", "CX"),
    ("PHX", "FX"),
    ("PFX", "FX"),
    ("SCHX", "SX"),
    # testRule2
    ("XEE", "XY"),
    ("XIE", "XY"),
    ("XDT", "XD"),
    ("XRT", "XD"),
    ("XRD", "XD"),
    ("XNT", "XD"),
    ("XND", "XD"),
    # testRule4Dot1
    ("XEV", "XAF"),
    ("XAX", "XAX"),
    ("XEX", "XAX"),
    ("XIX", "XAX"),
    ("XOX", "XAX"),
    ("XUX", "XAX"),
    # testRule4Dot2
    ("XQ", "XG"),
    ("XZ", "X"),
    ("XM", "XN"),
    # testRule5
    ("XS", "X"),
    ("XSS", "X"),
    # testRule6
    ("XAY", "XY"),
    ("XAYS", "XY"),
    # testRule7
    ("XA", "X"),
    ("XAS", "X"),
    # testSnad
    ("Schmidt", "SNAD"),
    # testSnat
    ("Smith", "SNAT"),
    ("Schmit", "SNAT"),
    # testSpecialBranches
    ("Kobwick", "CABWAC"),
    ("Kocher", "CACAR"),
    ("Fesca", "FASC"),
    ("Shom", "SAN"),
    ("Ohlo", "OL"),
    ("Uhu", "UH"),
    ("Um", "UN"),
    # testTranan
    ("Trueman", "TRANAN"),
    ("Truman", "TRANAN"),
]


# ------------------------------------------------------------
#
# NysiisEncodeTest
#
# ------------------------------------------------------------
class NysiisEncodeTest(unittest.TestCase):
    """Tests for :func:`encoders.nysiis.encode` against the full
    Apache Commons Codec reference vector set."""

    def test_reference_vectors(self) -> None:
        """encode() must match every reference (input, code) pair."""
        for name, expected in REFERENCE_VECTORS:
            with self.subTest(name=name):
                self.assertEqual(nysiis.encode(name), {expected})

    def test_empty_name_is_handled(self) -> None:
        """An empty name must not raise and returns an empty code."""
        self.assertEqual(nysiis.encode(""), {""})

    def test_non_letter_characters_are_stripped(self) -> None:
        """Punctuation must not cause a crash or leak into the code."""
        self.assertEqual(nysiis.encode("O'Daniel"), {"ODANAL"})


# ------------------------------------------------------------
#
# NysiisContractTest
#
# ------------------------------------------------------------
class NysiisContractTest(unittest.TestCase):
    """Confirms the module declares the encoder contract correctly."""

    def test_algorithm_id(self) -> None:
        """ALGORITHM_ID must be the stable registry key for this encoder."""
        self.assertEqual(nysiis.ALGORITHM_ID, "nysiis")

    def test_algorithm_label_is_a_string(self) -> None:
        """ALGORITHM_LABEL must be a display-ready string."""
        self.assertIsInstance(nysiis.ALGORITHM_LABEL, str)
        self.assertTrue(nysiis.ALGORITHM_LABEL)

    def test_encode_is_callable(self) -> None:
        """encode must be callable, per the encoder contract."""
        self.assertTrue(callable(nysiis.encode))


if __name__ == "__main__":
    unittest.main()
