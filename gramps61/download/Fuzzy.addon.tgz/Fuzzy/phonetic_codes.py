#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2025  Phonetic Matching Gramplet contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Phonetic algorithm registry used by the Fuzzy Matching Gramplet.

This module deliberately has no dependency on Gtk or on the Gramps
database layer, so the encoding logic can be unit tested in isolation
and reused independently of the GUI.

Rather than hand-editing a single shared dict for every new phonetic
algorithm - a synchronization headache once more than one contributor
is adding encoders at the same time - this module auto-discovers
encoders by scanning the :mod:`encoders` package (a plain subfolder
alongside this file) for modules that satisfy a small contract (see
the :mod:`encoders` package docstring, and :func:`_register_encoders`
below). Adding a new algorithm means adding one new file to
``encoders/``; nothing in this file, ``FuzzyMatchingGramplet.py``, or
anywhere else needs to change.

Only the standard Soundex algorithm ships in this release
(``encoders/soundex.py``). See ``encoders/__init__.py`` for the exact
contract a new encoder module must satisfy, and ``FuzzyDev.md`` for a
worked walkthrough of adding one, including why an earlier
Daitch-Mokotoff Soundex attempt was dropped rather than shipped after
it failed validation against the standard reference vectors (e.g.
"Peters" should encode to {"739400", "734000"}).
"""

# Deferred annotation evaluation (PEP 563), required for Python 3.8/3.9
# compatibility: this module's type hints use `list[X]`, `dict[K, V]`,
# `X | None`, etc. (PEP 585/604 syntax), which those Python versions
# cannot evaluate at runtime even though they parse it fine - Gramps
# 5.2's own official minimum is Python 3.8, which predates both PEPs
# (585 needs 3.9+, 604 needs 3.10+). This import makes every
# annotation in this file a deferred string, never evaluated at
# runtime at all, restoring compatibility with the full (5.2.0,
# 6.2.0) Gramps range this addon's own .gpr.py declares, without
# giving up the modern annotation syntax itself.
from __future__ import annotations

# ------------------------
# Python modules
# ------------------------
import importlib
import logging
import pkgutil
from types import ModuleType
from typing import Callable, Iterable

# ------------------------
# Gramps specific
# ------------------------
import encoders as _encoders_package

LOG = logging.getLogger(__name__)

#: Preferred default algorithm id: used if an encoder module of this
#: id is actually found; otherwise the first id found, sorted for a
#: stable choice across runs, becomes the default - so the gramplet
#: always has *some* default even if this particular one is missing
#: (for example, while developing a fork that drops Soundex).
PREFERRED_DEFAULT_ALGORITHM = "soundex"


def _discover_encoder_modules() -> list[ModuleType]:
    """
    Import every top-level module in the :mod:`encoders` package,
    except ones whose own filename starts with an underscore (shared
    helper code, not itself an encoder - see the :mod:`encoders`
    package docstring).

    :returns: The list of successfully imported candidate encoder
        modules. A module that raises on import is logged and omitted
        rather than aborting discovery of the rest.
    """
    modules = []
    for module_info in pkgutil.iter_modules(
        _encoders_package.__path__, _encoders_package.__name__ + "."
    ):
        if module_info.ispkg:
            continue
        basename = module_info.name.rpartition(".")[-1]
        if basename.startswith("_"):
            continue
        try:
            modules.append(importlib.import_module(module_info.name))
        except Exception:  # pylint: disable=broad-except
            LOG.exception(
                "Fuzzy Matching: could not import encoder module %r, skipping",
                module_info.name,
            )
    return modules


def _register_encoders(
    modules: Iterable[ModuleType],
) -> tuple[dict[str, Callable[[str], set[str]]], dict[str, str]]:
    """
    Validate each already-imported candidate module against the
    encoder contract and register the ones that satisfy it.

    Split out from :func:`_discover_encoder_modules` so the
    contract-checking and duplicate-handling logic can be unit tested
    directly with in-memory fake modules, without needing real files
    on disk - see ``test/phonetic_codes_test.py``.

    :param modules: Already-imported candidate encoder modules.
    :returns: A ``(algorithms, labels)`` pair: ``algorithms`` maps
        algorithm id to encode function; ``labels`` maps the same id
        to its display label. A module missing any required attribute,
        whose ``encode`` isn't callable, or that reuses an id an
        earlier module in ``modules`` already claimed, is logged and
        skipped - the rest are still registered.
    """
    algorithms: dict[str, Callable[[str], set[str]]] = {}
    labels: dict[str, str] = {}

    for module in modules:
        module_name = getattr(module, "__name__", repr(module))
        try:
            algorithm_id = module.ALGORITHM_ID
            algorithm_label = module.ALGORITHM_LABEL
            encode = module.encode
        except AttributeError as err:
            LOG.warning(
                "Fuzzy Matching: encoder module %r is missing %s, skipping",
                module_name,
                err,
            )
            continue

        if not callable(encode):
            LOG.warning(
                "Fuzzy Matching: encoder module %r has a non-callable "
                "encode, skipping",
                module_name,
            )
            continue

        if algorithm_id in algorithms:
            LOG.warning(
                "Fuzzy Matching: duplicate encoder id %r from module %r, "
                "keeping the first one found",
                algorithm_id,
                module_name,
            )
            continue

        algorithms[algorithm_id] = encode
        labels[algorithm_id] = algorithm_label

    return algorithms, labels


def _load_encoders() -> tuple[dict[str, Callable[[str], set[str]]], dict[str, str]]:
    """
    Discover and register every encoder module in :mod:`encoders`.

    :returns: See :func:`_register_encoders`.
    """
    return _register_encoders(_discover_encoder_modules())


def _choose_default(algorithms: dict[str, Callable[[str], set[str]]]) -> str | None:
    """
    Pick the default algorithm id from whatever :func:`_load_encoders`
    found.

    :param algorithms: The discovered ``{id: encode}`` mapping.
    :returns: :data:`PREFERRED_DEFAULT_ALGORITHM` if it was found,
        otherwise the first id found (sorted, for a stable choice
        across runs), or ``None`` if no encoders were found at all.
    """
    if PREFERRED_DEFAULT_ALGORITHM in algorithms:
        return PREFERRED_DEFAULT_ALGORITHM
    if algorithms:
        return sorted(algorithms)[0]
    return None


#: Registry of available algorithms, keyed by the identifier stored in
#: the gramplet's UI, auto-populated from ``encoders/`` - see the
#: module docstring above. Each entry maps to a function that takes a
#: name and returns a set of codes (a set, rather than a single code,
#: because some phonetic algorithms legitimately produce more than one
#: valid code for a single spelling). Adding a future algorithm needs
#: no change here: drop a new module into ``encoders/`` instead.
ALGORITHMS: dict[str, Callable[[str], set[str]]]

#: Display labels for :data:`ALGORITHMS`, keyed the same way, kept
#: separate so callers can build UI without importing translation
#: machinery into this module.
ALGORITHM_LABELS: dict[str, str]

ALGORITHMS, ALGORITHM_LABELS = _load_encoders()

#: The algorithm id the gramplet selects by default. See
#: :func:`_choose_default`.
DEFAULT_ALGORITHM = _choose_default(ALGORITHMS)

if not ALGORITHMS:
    LOG.error(
        "Fuzzy Matching: no phonetic encoders could be loaded from the "
        "encoders/ package; the gramplet's Encoding system list will be empty"
    )
