# Fuzzy Matching Gramplet
[ReadMe](README.md) ● [Change Log](CHANGELOG.md) ● [adding Phonetic systems (for developers)](FuzzyDev.md)

Type a surname and find every person in the Family Tree whose surname phonetically matches it — spelling variants, transcription differences, the "Smith vs. Smythe" problem — instead of just being told a code. 

The **Fuzzy Matching** gramplet grew out of the **SoundEx** gramplet [[SOURCE CODE](https://github.com/gramps-project/gramps/blob/maintenance/gramps60/gramps/plugins/gramplet/soundgen.py)] bundled with Gramps. Originally introduced in Gramps 4.1 as the [SoundEx code generator](https://www.gramps-project.org/wiki/index.php/Gramps_4.1_Wiki_Manual_-_Gramplets#SoundEx_Gramplet) gramplet. Relabelled as the [*Soundex gramplet*](https://www.gramps-project.org/wiki/index.php/Gramps_4.2_Wiki_Manual_-_Gramplets#SoundEx) in Gramps 4.2, it merely computed *a single Soundex code* for *one typed surname*. Unfortunatley, it also rebuilt its surname list in a way that visibly slowed down on large trees. 

This gramplet keeps the same basic idea but makes it usable with large trees. Then grows it into an actual search tool.

## Features
* [Matching people, not just a code](#matching-people-not-just-a-code) — see every surname and every person that phonetically matches what you type
* [Working with a match](#working-with-a-match) — click a person to make them active, double-click to edit them
* [Staying in sync](#staying-in-sync) — the gramplet follows along as you navigate the tree elsewhere
* [Creating a filter from a match](#creating-a-filter-from-a-match) — turn a code into a reusable People filter
* [Finding a surname to search](#finding-a-surname-to-search) — nearby-relative suggestions, or browse anyone in the tree
* [Staying fast on large trees](#staying-fast-on-large-trees) — indexes in the background with visible progress
* [Adjusting the layout](#adjusting-the-layout) — resizable results panel that remembers your layout
* [Help](#help) — one click to this document, or to the online guide
* [Encoding systems](#encoding-systems) — Soundex today, with room to add more
* [What is inherited from the original gramplet](#whats-inherited-from-the-original-gramplet) — the name field and code display still work the way they always did

## Matching people, not just a code
Type a surname into the **Surname** field and pick an **Encoding system** (Soundex today — see [Encoding systems](#encoding-systems)). The **Code(s)** list shows the phonetic code(s) for what you typed, and **Matches** shows the results in two columns: every surname in the tree sharing that code on the left, and every person who has whichever surname you select on the right, as `Display Name (birth year–death year) [Gramps ID]`.
![undocked Fuzzy Matching gramplet](media/screenshot.png)

## Working with a match
Click a person in the right-hand column to make them the [Active Person](https://gramps-project.org/wiki/index.php/Gramps_Glossary#active_person) everywhere in Gramps. 
Double-click (or press Enter on) a row to open that person directly in the standard **Edit Person** [object editor](https://gramps-project.org/wiki/index.php/Gramps_Glossary#object_editor) dialog.
![Double-click: Edit Person object editor dialog](media/edit_person.png)

## Staying in sync
The gramplet is not just a one-way search box: [when the active person changes](https://gramps-project.org/wiki/index.php/Gramps_6.0_Wiki_Manual_-_Navigation#Setting_the_Active_Person) — from this gramplet, the Home button, another view, or another gramplet — their surname and their own row are automatically selected and scrolled into view in both columns, so you can always see where the active person sits among their phonetic namesakes.

## Creating a filter from a match
Double-click a code in the **Code(s)** list to open a "Define filter" dialog and create a new [custom filter](https://gramps-project.org/wiki/index.php/Gramps_Glossary#filter).
When using the Soundex encoding system, it will be pre-filled with a People filter using the `Soundex match of People with the <name>` People:[General rule](https://gramps-project.org/wiki/index.php/Gramps_6.0_Wiki_Manual_-_Filters#General_filters) for whatever surname is currently typed, named `Fuzzy match: <surname> (<encoding system>)` with a dated comment. 
![Double-click: Define Filter dialog](media/define_filter.png)
Different filter rules can be associated with different encoding systems. 

No custom filter is saved automatically — the dialog opens exactly as if you had built it by hand. It is ready to be renamed and saved but will only be saved if you click <kbd>OK</kbd>.
## Finding a surname to search
The dropdown menu for the Surname field suggests surnames from people adjacent to the Active Person in the Tree. Surnames of those closely related to the active person, as a shortcut. To search for the surname of anyone in the whole tree instead, use the ![](gramps:icon:gtk-index:24) index button beside the field. This opens the standard unfiltered Person selector dialog.
![adjacent surnames menu](media/adjacent_surnames.png)

## Staying fast on large trees
Opening the gramplet or changing the encoding system rebuilds its lookups in the background rather than freezing the interface, with a spinner and a running count while it works. On a very large tree you may briefly see this indexing step; typing and browsing results otherwise stay instant.

## Adjusting the layout
Drag the divider between the two Matches columns to resize them; your chosen split is remembered the next time you open the gramplet.

## Help
The Help button (lower-left) opens this document — in the Markdown Dash gramplet if it is installed, otherwise in your browser — or the online guide if this file is not available.

## Encoding systems
A limited assortment of Phonetic encoding systems are bundled with the Gramplet. The encoding-system list is a registry, and adding another phonetic algorithm does not require touching the gramplet's UI code — see [FuzzyDev.md](FuzzyDev.md) for the first extensible approach. This system is in flux. We are exploring if the system could be based on Gramps "Rule" type plug-ins.

### Soundex
Soundex (4-character "Russell", aka "NARA") is the phonetic encoding system bundled with Gramps (`gramps.gen.soundex.soundex`), and the only one this gramplet ships with. `phonetic_codes.soundex_codes` wraps it rather than reimplementing it.

### Match Rating Approach (MRA) codex encoder .
MRA is a Western Airlines-developed algorithm (hence its other name, "Personal Numeric Identifier"/PNI) commonly used for genealogical name matching. Its encoding step ("codex") is simple: drop every vowel except one that begins the word, collapse repeated consonants, and keep only the first and last three characters if that leaves more than six. See the :mod:`encoders` package docstring for the contract this module implements.

This is a from-scratch Python implementation, ported from - and validated against 48 names run through - the real `match_rating_codex` function in the `[jellyfish](https://github.com/jamesturk/jellyfish)_ library (version 0.8.9), a mature, widely-used reference: https://github.com/jamesturk/jellyfish/blob/v0.8.9/jellyfish/_jellyfish.py

Unlike `jellyfish.match_rating_codex`, this module strips non-letter characters before encoding (matching the other encoders in this package) instead of raising on them - real surnames routinely contain apostrophes, hyphens, and accented letters, and this gramplet's `encode` contract must never raise.

Important limitation, worth knowing before picking this as an Encoding system: MRA's real matching power comes from its own *comparison* algorithm, which tolerates codexes that are similar but not identical (within a length- and sum-dependent threshold - see the [Match rating approach](https://en.wikipedia.org/wiki/Match_rating_approach)_ article for the exact rules). This gramplet, like the other encoders in this package, groups surnames by exact code equality, the same way it does for Soundex and NYSIIS - it does not implement MRA's threshold-based comparison. Under plain equality, MRA's codex is comparatively literal: for example, "SMITH" and "SMYTH" encode to different codexes here (`SMTH` vs `SMYTH`) and so would not be grouped together, even though MRA's own comparison algorithm is often cited as successfully matching that exact pair.

### NYSIIS (New York State Identification and Intelligence System) encoder
Devised in 1970, NYSIIS keeps more information about vowel position and sequence than Soundex does, at the cost of being a longer code - see the :mod:`encoders` package docstring for the contract this module implements, and `FuzzyDev.md` for how it compares to the other bundled encoders.

This is a from-scratch Python implementation (Gramps itself has no built-in NYSIIS to wrap, unlike Soundex), ported faithfully from - and validated against every one of the roughly 85 test cases in - Apache Commons Codec's `Nysiis` class and its test suite, a mature, widely-used reference implementation:
* [Nysiis.java](https://github.com/apache/commons-codec/blob/master/src/main/java/org/apache/commons/codec/language/Nysiis.java)
* [NysiisTest.java](https://github.com/apache/commons-codec/blob/master/src/test/java/org/apache/commons/codec/language/NysiisTest.java)

Unlike that library's default ("strict") mode, this module returns the full, untruncated code rather than truncating to 6 characters: NYSIIS' own advantage over Soundex is retaining more information, and nothing here needs the fixed-width-database-field constraint that motivated the original 6-character limit in 1970. `encoders/nysiis_test.py` covers both the full code this module returns and the truncated 6-character form, so a future contributor who wants strict-mode truncation back has a validated starting point.

Note this encoder treats "Y" as a consonant throughout (matching the reference implementation exactly), except where the specific suffix rules below say otherwise. That is a real, deliberate characteristic of NYSIIS, not a bug: it is part of why NYSIIS and Soundex group surnames differently (e.g. NYSIIS does not consider "Smith" and "Smyth" a match, unlike Soundex) rather than one simply being a more correct version of the other.

## What is inherited from the original gramplet
Typing a surname and seeing its phonetic code, and having the field pre-filled from the active person when a tree loads, both come from the original SoundEx gramplet and still work the same way — they are just no longer the whole feature.

## Files
| File | Purpose |
|---|---|
| `FuzzyMatchingGramplet.gpr.py` | Plugin registration |
| `FuzzyMatchingGramplet.py` | Gtk gramplet UI, background indexing, and active-person sync |
| `FuzzyMatchingGramplet.ini` | Generated on first use to remember your layout choices; not shipped |
| `phonetic_codes.py` | Pure-Python phonetic algorithm registry (no Gtk/db dependency, unit-testable) |
| `test/__init__.py` | Empty; required so `unittest discover` (see below) actually finds `test/` |
| `test/phonetic_codes_test.py` | `unittest` tests for `phonetic_codes.py` |

## Running the tests
```bash
GRAMPS_RESOURCES=. python3 -m unittest discover -p "*_test.py"
```

Run this from the addon's root directory. See [FuzzyDev.md](FuzzyDev.md) if this reports "NO TESTS RAN" or an import error — there are a couple of non-obvious setup requirements specific to testing a Gramps addon this way.

## AI-assisted contribution disclosure
#### Generated-by: Claude Sonnet 5 medium
Portions of this addon were generated with AI assistance, per the Gramps project's [AI-generated code guidelines](https://www.gramps-project.org/wiki/index.php/Howto:_Contribute_to_Gramps#AI_generated_code). Suggested commit-message trailers for whoever lands this as a real commit:



