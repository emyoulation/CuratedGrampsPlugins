#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2025  Phonetic Matching Gramplet contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Soundex encoder for the Fuzzy Matching Gramplet.

Wraps the existing, already-tested :func:`gramps.gen.soundex.soundex`
function rather than duplicating it, per Gramps' guidance to reuse
core engine code instead of reinventing it. See the :mod:`encoders`
package docstring for the contract this module implements, and for
this file as a template for adding another algorithm.
"""

# Deferred annotation evaluation (PEP 563), required for Python 3.8/3.9
# compatibility: `encode`'s `-> set[str]` return type uses PEP 585
# syntax, which needs Python 3.9+ to evaluate at runtime even though
# it parses fine on older versions - Gramps 5.2's own official minimum
# is Python 3.8. This import makes the annotation a deferred string,
# never evaluated at runtime, restoring compatibility with Gramps 5.2
# without giving up the modern annotation syntax itself.
from __future__ import annotations

# ------------------------
# Python modules
# ------------------------
import logging

# ------------------------
# Gramps modules
# ------------------------
from gramps.gen.soundex import soundex

LOG = logging.getLogger(__name__)

#: Registry key. See the contract in the :mod:`encoders` package
#: docstring for why this should be treated as stable once shipped.
ALGORITHM_ID = "soundex"

#: Display label shown in the gramplet's "Encoding system" dropdown.
ALGORITHM_LABEL = "Soundex"


def encode(name: str) -> set[str]:
    """
    Return the (single-element) Soundex code set for ``name``.

    :param name: The surname (or any word) to encode.
    :returns: A one-element set containing the four-character Soundex
        code, matching the value that
        :func:`gramps.gen.soundex.soundex` would return.
    """
    try:
        return {soundex(name)}
    except UnicodeEncodeError:
        LOG.debug("Soundex encoding failed for %r, falling back to empty", name)
        return {soundex("")}
