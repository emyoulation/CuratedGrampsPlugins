#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2025  Phonetic Matching Gramplet contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
Match Rating Approach (MRA) codex encoder for the Fuzzy Matching
Gramplet.

MRA is a Western Airlines-developed algorithm (hence its other name,
"Personal Numeric Identifier"/PNI) commonly used for genealogical name
matching. Its encoding step ("codex") is simple: drop every vowel
except one that begins the word, collapse repeated consonants, and
keep only the first and last three characters if that leaves more
than six. See the :mod:`encoders` package docstring for the contract
this module implements.

This is a from-scratch Python implementation, ported from - and
validated against 48 names run through - the real ``match_rating_codex``
function in the `jellyfish <https://github.com/jamesturk/jellyfish>`_
library (version 0.8.9), a mature, widely-used reference:
https://github.com/jamesturk/jellyfish/blob/v0.8.9/jellyfish/_jellyfish.py

Unlike ``jellyfish.match_rating_codex``, this module strips
non-letter characters before encoding (matching the other encoders in
this package) instead of raising on them - real surnames routinely
contain apostrophes, hyphens, and accented letters, and this
gramplet's ``encode`` contract must never raise.

Important limitation, worth knowing before picking this as an
Encoding system: MRA's real matching power comes from its own
*comparison* algorithm, which tolerates codexes that are similar but
not identical (within a length- and sum-dependent threshold - see the
`Match rating approach <https://en.wikipedia.org/wiki/Match_rating_approach>`_
article for the exact rules). This gramplet, like the other encoders
in this package, groups surnames by exact code equality, the same way
it does for Soundex and NYSIIS - it does not implement MRA's
threshold-based comparison. Under plain equality, MRA's codex is
comparatively literal: for example, "SMITH" and "SMYTH" encode to
different codexes here (``SMTH`` vs ``SMYTH``) and so would not be
grouped together, even though MRA's own comparison algorithm is
often cited as successfully matching that exact pair.
"""

# Deferred annotation evaluation (PEP 563), required for Python 3.8/3.9
# compatibility: `encode`'s `-> set[str]` return type uses PEP 585
# syntax, which needs Python 3.9+ to evaluate at runtime even though
# it parses fine on older versions - Gramps 5.2's own official minimum
# is Python 3.8. This import makes the annotation a deferred string,
# never evaluated at runtime, restoring compatibility with Gramps 5.2
# without giving up the modern annotation syntax itself.
from __future__ import annotations

# ------------------------
# Python modules
# ------------------------
import logging

LOG = logging.getLogger(__name__)

#: Registry key. See the contract in the :mod:`encoders` package
#: docstring for why this should be treated as stable once shipped.
ALGORITHM_ID = "match_rating"

#: Display label shown in the gramplet's "Encoding system" dropdown.
ALGORITHM_LABEL = "Match Rating Approach"

_VOWELS = "AEIOU"


def _clean(name: str) -> str:
    """
    Keep only letters from ``name``, uppercased.

    :param name: The raw input.
    :returns: ``name`` with every non-letter character removed,
        uppercased.
    """
    return "".join(char for char in name if char.isalpha()).upper()


def _match_rating_codex(name: str) -> str:
    """
    Compute the Match Rating Approach codex for ``name``.

    :param name: The surname (or any word) to encode.
    :returns: The codex: every consonant, with immediate repeats
        collapsed to one, plus a leading vowel if the word starts with
        one, reduced to the first and last three characters if that
        would otherwise be longer than six.
    """
    cleaned = _clean(name)
    if not cleaned:
        return ""

    codex_chars = []
    prev = None
    for index, char in enumerate(cleaned):
        is_vowel = char in _VOWELS
        keep_as_leading_vowel = index == 0 and is_vowel
        keep_as_new_consonant = (not is_vowel) and char != prev
        if keep_as_leading_vowel or keep_as_new_consonant:
            codex_chars.append(char)
        prev = char

    if len(codex_chars) > 6:
        return "".join(codex_chars[:3] + codex_chars[-3:])
    return "".join(codex_chars)


def encode(name: str) -> set[str]:
    """
    Return the (single-element) Match Rating Approach codex set for
    ``name``.

    :param name: The surname (or any word) to encode.
    :returns: A one-element set containing the codex.
    """
    try:
        return {_match_rating_codex(name)}
    except Exception:  # pylint: disable=broad-except
        LOG.debug(
            "Match Rating Approach encoding failed for %r, falling back to empty",
            name,
        )
        return {_match_rating_codex("")}
