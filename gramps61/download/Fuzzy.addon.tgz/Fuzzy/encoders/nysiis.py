#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2025  Phonetic Matching Gramplet contributors
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
#

"""
NYSIIS (New York State Identification and Intelligence System) encoder
for the Fuzzy Matching Gramplet.

Devised in 1970, NYSIIS keeps more information about vowel position
and sequence than Soundex does, at the cost of being a longer code -
see the :mod:`encoders` package docstring for the contract this module
implements, and ``FuzzyDev.md`` for how it compares to the other
bundled encoders.

This is a from-scratch Python implementation (Gramps itself has no
built-in NYSIIS to wrap, unlike Soundex), ported faithfully from - and
validated against every one of the roughly 85 test cases in - Apache
Commons Codec's ``Nysiis`` class and its test suite, a mature,
widely-used reference implementation:
https://github.com/apache/commons-codec/blob/master/src/main/java/org/apache/commons/codec/language/Nysiis.java
https://github.com/apache/commons-codec/blob/master/src/test/java/org/apache/commons/codec/language/NysiisTest.java

Unlike that library's default ("strict") mode, this module returns the
full, untruncated code rather than truncating to 6 characters: NYSIIS'
own advantage over Soundex is retaining more information, and nothing
here needs the fixed-width-database-field constraint that motivated
the original 6-character limit in 1970. ``encoders/nysiis_test.py``
covers both the full code this module returns and the truncated
6-character form, so a future contributor who wants strict-mode
truncation back has a validated starting point.

Note this encoder treats "Y" as a consonant throughout (matching the
reference implementation exactly), except where the specific suffix
rules below say otherwise. That is a real, deliberate characteristic
of NYSIIS, not a bug: it is part of why NYSIIS and Soundex group
surnames differently (e.g. NYSIIS does not consider "Smith" and
"Smyth" a match, unlike Soundex) rather than one simply being a more
correct version of the other.
"""

# Deferred annotation evaluation (PEP 563), required for Python 3.8/3.9
# compatibility: `encode`'s `-> set[str]` return type uses PEP 585
# syntax, which needs Python 3.9+ to evaluate at runtime even though
# it parses fine on older versions - Gramps 5.2's own official minimum
# is Python 3.8. This import makes the annotation a deferred string,
# never evaluated at runtime, restoring compatibility with Gramps 5.2
# without giving up the modern annotation syntax itself.
from __future__ import annotations

# ------------------------
# Python modules
# ------------------------
import logging

LOG = logging.getLogger(__name__)

#: Registry key. See the contract in the :mod:`encoders` package
#: docstring for why this should be treated as stable once shipped.
ALGORITHM_ID = "nysiis"

#: Display label shown in the gramplet's "Encoding system" dropdown.
ALGORITHM_LABEL = "NYSIIS"

_VOWELS = "AEIOU"


def _is_vowel(char: str) -> bool:
    """
    :param char: A single character.
    :returns: True if ``char`` is one of A, E, I, O, U.
    """
    return char in _VOWELS


def _clean(name: str) -> str:
    """
    Keep only letters from ``name``, uppercased, matching the input
    normalization Apache Commons Codec's ``SoundexUtils.clean`` uses
    ahead of its own NYSIIS implementation.

    :param name: The raw input.
    :returns: ``name`` with every non-letter character removed,
        uppercased.
    """
    return "".join(char for char in name if char.isalpha()).upper()


def _transcode_remaining(prev: str, curr: str, nxt: str, after_next: str) -> str:
    """
    Transcode one character of the "remaining characters" pass (rule 4
    in the class docstring), given a 4-character sliding window
    ``[i-1, i, i+1, i+2]`` centered on the character being transcoded.

    :param prev: The character before ``curr`` (already transcoded, if
        an earlier step changed it).
    :param curr: The character being transcoded.
    :param nxt: The character after ``curr``, or a space if ``curr``
        is the last character.
    :param after_next: The character after ``nxt``, or a space if
        unavailable.
    :returns: The one-or-more-character replacement for ``curr``.
    """
    # pylint: disable=too-many-return-statements
    # A faithful, sequential port of the reference implementation's own
    # rule list; each rule is independent, so splitting this further
    # would make it harder, not easier, to audit against the source
    # this was ported from (see the module docstring).
    if curr == "E" and nxt == "V":
        return "AF"
    if _is_vowel(curr):
        return "A"
    if curr == "Q":
        return "G"
    if curr == "Z":
        return "S"
    if curr == "M":
        return "N"
    if curr == "K":
        return "NN" if nxt == "N" else "C"
    if curr == "S" and nxt == "C" and after_next == "H":
        return "SSS"
    if curr == "P" and nxt == "H":
        return "FF"
    if curr == "H" and (not _is_vowel(prev) or not _is_vowel(nxt)):
        return prev
    if curr == "W" and _is_vowel(prev):
        return prev
    return curr


def _transcode_prefix_and_suffix(cleaned: str) -> str:
    """
    Apply NYSIIS rules 1 and 2: transcode the first and last characters
    of the name before the main, per-character pass.

    :param cleaned: The already-cleaned (letters only, uppercased) name.
    :returns: ``cleaned`` with its first/last characters transcoded.
    """
    # 1. Transcode first characters of name.
    if cleaned.startswith("MAC"):
        cleaned = "MCC" + cleaned[3:]
    if cleaned.startswith("KN"):
        cleaned = "NN" + cleaned[2:]
    elif cleaned.startswith("K"):
        cleaned = "C" + cleaned[1:]
    if cleaned.startswith("PH") or cleaned.startswith("PF"):
        cleaned = "FF" + cleaned[2:]
    if cleaned.startswith("SCH"):
        cleaned = "SSS" + cleaned[3:]

    # 2. Transcode last characters of name.
    if cleaned.endswith("EE") or cleaned.endswith("IE"):
        cleaned = cleaned[:-2] + "Y"
    if cleaned.endswith(("DT", "RT", "RD", "NT", "ND")):
        cleaned = cleaned[:-2] + "D"

    return cleaned


def _build_key(cleaned: str) -> str:
    """
    Apply NYSIIS rules 3 and 4: build the key from ``cleaned``'s first
    character, followed by the transcoded remaining characters.

    :param cleaned: The name after :func:`_transcode_prefix_and_suffix`.
    :returns: The key before the trailing cleanup in rules 5-7.
    """
    # 3. First character of key = first character of name.
    chars = list(cleaned)
    length = len(chars)
    key_chars = [chars[0]]

    # 4. Transcode remaining characters, incrementing by one character
    # each time. This mutates `chars` in place (matching the reference
    # implementation exactly), so later iterations see already
    # transcoded characters as their "previous"/"next" context, not
    # the original ones.
    i = 1
    while i < length:
        prev = chars[i - 1]
        curr = chars[i]
        nxt = chars[i + 1] if i < length - 1 else " "
        after_next = chars[i + 2] if i < length - 2 else " "
        transcoded = _transcode_remaining(prev, curr, nxt, after_next)
        chars[i : i + len(transcoded)] = list(transcoded)
        if chars[i] != chars[i - 1]:
            key_chars.append(chars[i])
        i += 1

    return "".join(key_chars)


def _strip_trailing(key: str) -> str:
    """
    Apply NYSIIS rules 5-7: clean up the trailing characters of an
    already-built key.

    :param key: The key from :func:`_build_key`.
    :returns: ``key`` with its trailing S/AY/A handled per rules 5-7.
    """
    if len(key) <= 1:
        return key

    # 5. If last character is S, remove it.
    last_char = key[-1]
    if last_char == "S":
        key = key[:-1]
        last_char = key[-1]

    # 6. If last characters are AY, replace with Y.
    if len(key) > 2 and key[-2] == "A" and last_char == "Y":
        key = key[:-2] + last_char

    # 7. If last character is A, remove it.
    if last_char == "A":
        key = key[:-1]

    return key


def _nysiis(name: str) -> str:
    """
    Compute the full (untruncated) NYSIIS code for ``name``.

    :param name: The surname (or any word) to encode.
    :returns: The NYSIIS code, or an empty string if ``name`` contains
        no letters at all.
    """
    cleaned = _clean(name)
    if not cleaned:
        return ""

    cleaned = _transcode_prefix_and_suffix(cleaned)
    key = _build_key(cleaned)
    return _strip_trailing(key)


def encode(name: str) -> set[str]:
    """
    Return the (single-element) NYSIIS code set for ``name``.

    :param name: The surname (or any word) to encode.
    :returns: A one-element set containing the full NYSIIS code.
    """
    try:
        return {_nysiis(name)}
    except Exception:  # pylint: disable=broad-except
        LOG.debug("NYSIIS encoding failed for %r, falling back to empty", name)
        return {_nysiis("")}
