#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026  Brian McCullough <emyoulation@yahoo.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, see <https://www.gnu.org/licenses/>.

"""
Tests for make_addon.py's in-process packaging engine (run_command()
and friends), added as part of the refactor that replaced
AddonPackShip.py's subprocess-based invocation with a direct,
in-process module import.

These tests focus on two things the refactor specifically needed to
get right:

  1. ``run_command()`` and everything it calls must NEVER call
     ``sys.exit()``. Doing so used to be safe (it only ended a
     throwaway subprocess), but now that this module is imported
     directly into the running Gramps process, ``sys.exit()`` there
     would tear down the whole application.
  2. The ``(success, stdout, stderr)`` shape callers depend on (in
     particular AddonPackShip.py's own result parsing) must be
     preserved even though there is no longer a real subprocess and
     no real return code behind it.

Development: AI-assisted using Claude (Anthropic); see the commit
message for full AI-generated-code disclosure per
https://www.gramps-project.org/wiki/index.php/Howto:_Contribute_to_Gramps#AI_generated_code
"""

# ------------------------
# Python modules
# ------------------------
import os
import shutil
import tempfile
import unittest
import importlib.util
from unittest.mock import patch


def _load_make_addon():
    """
    Import make_addon.py the same way AddonPackShip.py does at
    runtime: as a standalone module loaded from its file path, since
    it lives alongside AddonPackShip.py rather than inside a package.

    :returns: The imported ``make_addon`` module.
    """
    module_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "make_addon.py",
    )
    spec = importlib.util.spec_from_file_location("make_addon_under_test", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


make_addon = _load_make_addon()


# ------------------------------------------------------------
#
# RunCommandNeverExitsTest
#
# ------------------------------------------------------------
class RunCommandNeverExitsTest(unittest.TestCase):
    """
    Guards against the sys.exit() landmine this refactor removed:
    every code path run_command() can take must return a plain
    (success, stdout, stderr) tuple, never call sys.exit().
    """

    def setUp(self) -> None:
        """Create a scratch addon directory and output directory."""
        self.tmp_dir = tempfile.mkdtemp(prefix="make_addon_test_")
        self.addon_path = os.path.join(self.tmp_dir, "MyAddon")
        self.output_dir = os.path.join(self.tmp_dir, "out", "gramps52")
        os.makedirs(self.addon_path)
        os.makedirs(self.output_dir)

    def tearDown(self) -> None:
        """Remove the scratch directories created in setUp()."""
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def _assert_never_exits(self, command: str) -> tuple:
        """
        Run ``command`` with sys.exit() patched to raise instead of
        exiting, so an accidental call fails the test loudly instead
        of killing the test runner.

        :param command: The make_addon.py command to run.
        :returns: The (success, stdout, stderr) tuple from
            run_command(), for further assertions by the caller.
        """
        with patch.object(make_addon.sys, "exit") as mock_exit:
            result = make_addon.run_command(command, self.addon_path, self.output_dir)
        mock_exit.assert_not_called()
        return result

    def test_missing_addon_path_does_not_exit(self) -> None:
        """A nonexistent addon path must fail cleanly, not raise/exit."""
        with patch.object(make_addon.sys, "exit") as mock_exit:
            success, _stdout, stderr = make_addon.run_command(
                "build", "/no/such/addon/path", self.output_dir
            )
        mock_exit.assert_not_called()
        self.assertFalse(success)
        self.assertIn("does not exist", stderr)

    def test_unknown_command_does_not_exit(self) -> None:
        """An unrecognised command must fail cleanly, not raise/exit."""
        success, _stdout, _stderr = self._assert_never_exits("bogus-command")
        self.assertFalse(success)

    def test_build_does_not_exit(self) -> None:
        """A normal 'build' run must not call sys.exit()."""
        with open(
            os.path.join(self.addon_path, "MyAddon.gpr.py"),
            "w",
            encoding="utf-8",
        ) as fh:
            fh.write("register(TOOL)\n")
        with open(
            os.path.join(self.addon_path, "MyAddon.py"), "w", encoding="utf-8"
        ) as fh:
            fh.write("# addon body\n")

        success, _stdout, _stderr = self._assert_never_exits("build")
        self.assertTrue(success)

    def test_listing_with_missing_tgz_does_not_exit(self) -> None:
        """
        This is the specific line that used to call sys.exit(0):
        'listing' requested before 'build' has ever produced a .tgz.
        It must now return True (a workflow reminder, not a fault)
        without calling sys.exit().
        """
        with open(
            os.path.join(self.addon_path, "MyAddon.gpr.py"),
            "w",
            encoding="utf-8",
        ) as fh:
            fh.write("register(TOOL)\n")

        success, stdout, _stderr = self._assert_never_exits("listing")
        self.assertTrue(success)
        self.assertIn("run Build first", stdout)

    def test_clean_does_not_exit(self) -> None:
        """A normal 'clean' run must not call sys.exit()."""
        success, _stdout, _stderr = self._assert_never_exits("clean")
        self.assertTrue(success)

    def test_compile_does_not_exit(self) -> None:
        """A normal 'compile' run must not call sys.exit()."""
        success, _stdout, _stderr = self._assert_never_exits("compile")
        self.assertTrue(success)


# ------------------------------------------------------------
#
# RunCommandResultShapeTest
#
# ------------------------------------------------------------
class RunCommandResultShapeTest(unittest.TestCase):
    """
    Confirms run_command() still returns the same (success, stdout,
    stderr) shape AddonPackShip.py's result-parsing code depends on,
    now that there is no real subprocess or exit code behind it.
    """

    def setUp(self) -> None:
        """Create a scratch addon directory and output directory."""
        self.tmp_dir = tempfile.mkdtemp(prefix="make_addon_test_")
        self.addon_path = os.path.join(self.tmp_dir, "MyAddon")
        self.output_dir = os.path.join(self.tmp_dir, "out", "gramps52")
        os.makedirs(self.addon_path)
        os.makedirs(self.output_dir)
        with open(
            os.path.join(self.addon_path, "MyAddon.gpr.py"),
            "w",
            encoding="utf-8",
        ) as fh:
            fh.write("register(TOOL)\n")
        with open(
            os.path.join(self.addon_path, "MyAddon.py"), "w", encoding="utf-8"
        ) as fh:
            fh.write("# addon body\n")

    def tearDown(self) -> None:
        """Remove the scratch directories created in setUp()."""
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_build_returns_three_tuple_of_correct_types(self) -> None:
        """success is bool; stdout/stderr are str, matching the old
        subprocess.run(capture_output=True, text=True) contract."""
        result = make_addon.run_command("build", self.addon_path, self.output_dir)
        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 3)
        success, stdout, stderr = result
        self.assertIsInstance(success, bool)
        self.assertIsInstance(stdout, str)
        self.assertIsInstance(stderr, str)

    def test_build_actually_creates_the_tgz(self) -> None:
        """The whole point of the fix: a 'build' that reports success
        must have actually written the .addon.tgz to disk."""
        success, _stdout, _stderr = make_addon.run_command(
            "build", self.addon_path, self.output_dir
        )
        self.assertTrue(success)
        tgz_path = os.path.join(self.output_dir, "download", "MyAddon.addon.tgz")
        self.assertTrue(
            os.path.exists(tgz_path),
            f"Expected build artifact not found: {tgz_path}",
        )

    def test_build_mode_is_read_from_parameter_not_environment(self) -> None:
        """
        build_mode must come from the explicit parameter now, not
        from a BUILD_MODE environment variable -- the whole point of
        removing the subprocess/env-var boundary. Set a contradictory
        BUILD_MODE in the environment and confirm it is ignored.
        """
        with patch.dict(os.environ, {"BUILD_MODE": "release"}):
            success, stdout, _stderr = make_addon.run_command(
                "build", self.addon_path, self.output_dir, build_mode="beta"
            )
        self.assertTrue(success)
        self.assertIn("Beta", stdout)


# ------------------------------------------------------------
#
# CreateListingTest
#
# ------------------------------------------------------------
class CreateListingTest(unittest.TestCase):
    """Direct tests of create_listing()'s parameter-driven language
    handling, which replaced its previous ADDON_LANGUAGES env lookup."""

    def setUp(self) -> None:
        """Create a scratch addon directory and output directory."""
        self.tmp_dir = tempfile.mkdtemp(prefix="make_addon_test_")
        self.addon_path = os.path.join(self.tmp_dir, "MyAddon")
        self.output_dir = os.path.join(self.tmp_dir, "out", "gramps52")
        os.makedirs(self.addon_path)
        os.makedirs(self.output_dir)

    def tearDown(self) -> None:
        """Remove the scratch directories created in setUp()."""
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_missing_gpr_file_returns_false(self) -> None:
        """No .gpr.py present is a real error, unlike the missing-tgz
        case, and must still return False (not raise or exit)."""
        with patch.object(make_addon.sys, "exit") as mock_exit:
            result = make_addon.create_listing(self.addon_path, self.output_dir)
        mock_exit.assert_not_called()
        self.assertFalse(result)

    def test_missing_tgz_returns_true_not_sys_exit(self) -> None:
        """The specific line this refactor fixed: create_listing()
        used to call sys.exit(0) here instead of returning."""
        with open(
            os.path.join(self.addon_path, "MyAddon.gpr.py"),
            "w",
            encoding="utf-8",
        ) as fh:
            fh.write("register(TOOL)\n")

        with patch.object(make_addon.sys, "exit") as mock_exit:
            result = make_addon.create_listing(self.addon_path, self.output_dir)
        mock_exit.assert_not_called()
        self.assertTrue(result)


if __name__ == "__main__":
    unittest.main()
