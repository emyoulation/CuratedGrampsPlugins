# -*- coding: utf-8 -*-
#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026       Brian McCullough
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, see <https://www.gnu.org/licenses/>.
#

"""
DoroTree Importer Plugin for Gramps.
Parses legacy Borland Paradox database files packed inside a .dte ZIP archive,
handling bilingual English/Hebrew string conversions natively.
"""

import os
import struct
import zipfile
from io import BytesIO

# Gramps API Imports
from gramps.gen.db import DbTxn
from gramps.gen.lib import Person, Name, NameType, Gender, Family
from gramps.gen.plug import User

def import_data(database, filename, user_interface):
    """
    Main entry point called by the Gramps plugin framework.
    """
    user_interface.info(_("Opening DoroTree backup archive..."))

    try:
        with zipfile.ZipFile(filename, 'r') as z:
            # 1. Load the core database files into memory buffers
            # DoroTree bundles data across specific Paradox tables
            people_bytes = z.read('People.db')
            families_bytes = z.read('Families.db')

            user_interface.info(_("Parsing Paradox tables and extracting records..."))

            # 2. Parse the Paradox binary structures
            raw_people = parse_paradox_db(people_bytes)
            raw_families = parse_paradox_db(families_bytes)

            # 3. Commit data to Gramps database inside a single transaction context
            # Using DbTxn handles multi-stage rollbacks safely if errors occur
            with DbTxn(_("Import DoroTree Data"), database, batch=True) as trans:

                # Maps to link DoroTree IDs to Gramps internal Handles
                person_map = {} # DoroTree_ID -> Gramps_Person_Handle

                # --- Step A: Import Individuals ---
                for record in raw_people:
                    # Paradox record offsets depend on your DoroTree version layout.
                    # Adjust dictionary string lookups based on table schemas.
                    dt_id = record.get('ID')
                    first_name = record.get('FirstName', '')
                    last_name = record.get('LastName', '')
                    gender_raw = record.get('Gender', 'M')

                    if not dt_id:
                        continue

                    gramps_person = Person()

                    # Set Name
                    name = Name()
                    name.set_type(NameType.BIRTH)
                    name.set_first_name(first_name)
                    name.set_last_name(last_name)
                    gramps_person.add_alternate_name(name)

                    # Set Gender
                    if gender_raw == 'F' or gender_raw == 2:
                        gramps_person.set_gender(Gender.FEMALE)
                    elif gender_raw == 'M' or gender_raw == 1:
                        gramps_person.set_gender(Gender.MALE)
                    else:
                        gramps_person.set_gender(Gender.UNKNOWN)

                    # Save to Gramps database backend
                    person_handle = database.add_person(gramps_person, trans)
                    person_map[dt_id] = person_handle

                # --- Step B: Import Family Relationships ---
                for fam_record in raw_families:
                    fam_id = fam_record.get('ID')
                    husband_id = fam_record.get('HusbandID')
                    wife_id = fam_record.get('WifeID')
                    children_ids = fam_record.get('ChildrenIDs', []) # Extracted if listed as comma-sep or child table

                    gramps_family = Family()

                    # Attach Spouses if they exist in our imported map
                    if husband_id in person_map:
                        gramps_family.set_father_handle(person_map[husband_id])
                    if wife_id in person_map:
                        gramps_family.set_mother_handle(person_map[wife_id])

                    # Attach Children
                    for child_id in children_ids:
                        if child_id in person_map:
                            gramps_family.add_child_handle(person_map[child_id])

                    database.add_family(gramps_family, trans)

        user_interface.info(_("DoroTree import completed successfully."))
        return True

    except Exception as e:
        user_interface.error(_("Failed to parse DoroTree database: %s") % str(e))
        return False


def parse_paradox_db(db_bytes):
    """
    Natively dissects a Borland Paradox .db table header and payload blocks.
    Translates raw string arrays into usable dictionaries.
    """
    records = []
    if len(db_bytes) < 0x78:
        return records

    # Read Paradox File Header (Standard layout for v3/v4/v5/v7 Paradox DBs)
    # Offset 0x00: Record Size (unsigned short)
    # Offset 0x06: Number of records (unsigned long)
    # Offset 0x21: Number of fields (unsigned char)
    record_size, = struct.unpack('<H', db_bytes[0:2])
    num_records, = struct.unpack('<I', db_bytes[6:10])
    num_fields = db_bytes[0x21]
    header_size, = struct.unpack('<H', db_bytes[0x0c:0x0e])

    # Process the field specifications directly past the main header block
    field_spec_offset = 0x78
    fields = []

    for i in range(num_fields):
        offset = field_spec_offset + (i * 2)
        if offset + 2 > len(db_bytes):
            break
        f_type = db_bytes[offset]
        f_size = db_bytes[offset + 1]
        fields.append({'type': f_type, 'size': f_size})

    # Data records are block-allocated beginning after the overall header length
    current_offset = header_size

    # Simple table block iterator loop
    for _ in range(num_records):
        if current_offset + record_size > len(db_bytes):
            break

        record_data = db_bytes[current_offset : current_offset + record_size]
        parsed_record = {}

        field_cursor = 0
        for idx, field in enumerate(fields):
            f_size = field['size']
            f_bytes = record_data[field_cursor : field_cursor + f_size]

            # Paradox Strings (Type 1 / 0x01)
            if field['type'] == 0x01:
                # Decode using legacy CP1255 to parse Hebrew + English text elements cleanly
                clean_str = decode_bilingual_string(f_bytes)
                parsed_record[f'Field_{idx}'] = clean_str
            # Paradox Integers / IDs (Type 5 / 0x05 Short Integer or Type 6 Long Integer)
            elif field['type'] in (0x05, 0x06):
                if f_size == 2:
                    parsed_record[f'Field_{idx}'] = struct.unpack('>h', f_bytes)[0] # Paradox uses big-endian values for numbers
                elif f_size == 4:
                    parsed_record[f'Field_{idx}'] = struct.unpack('>i', f_bytes)[0]

            field_cursor += f_size

        # Map fields to semantic dictionary names based on expected positions
        # (e.g., if Field_0 is consistently ID, Field_1 is FirstName, etc.)
        # Here we mock standard mappings for illustration:
        semantic_record = {
            'ID': parsed_record.get('Field_0'),
            'FirstName': parsed_record.get('Field_1', ''),
            'LastName': parsed_record.get('Field_2', ''),
            'Gender': parsed_record.get('Field_3', 'M')
        }
        records.append(semantic_record)
        current_offset += record_size

    return records


def decode_bilingual_string(byte_array):
    """
    Strips trailing null bytes / padding spaces and decodes string blocks
    into standard Python 3 UTF-8 using the legacy Windows Hebrew codepage.
    """
    # Slice out trailing null values or empty padding spaces common in database cells
    stripped_bytes = byte_array.split(b'\x00')[0].strip()
    try:
        # 'windows-1255' supports both native English ASCII and Hebrew ranges flawlessly
        return stripped_bytes.decode('windows-1255')
    except UnicodeDecodeError:
        return stripped_bytes.decode('utf-8', errors='ignore')