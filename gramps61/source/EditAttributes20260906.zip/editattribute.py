#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2000-2006  Donald N. Allingham
#               2009       Gary Burton
# Copyright (C) 2011       Tim G L Lyons
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, see <https://www.gnu.org/licenses/>.
#

"""
The EditAttribute module provides the AttributeEditor class. This provides a
mechanism for the user to edit attribute information.
"""

# Deferred annotation evaluation (PEP 563): required so the TYPE_CHECKING-only
# import of DisplayState below never needs to be resolved at runtime. This
# module is imported very early, as part of gramps.gui.editors, so importing
# gramps.gui.displaystate for real at module scope reintroduces the circular
# import that DisplayState -> navigationview -> pageview -> grampletbar ->
# grampletpane -> gramps.gui.editors used to trigger.
from __future__ import annotations

# -------------------------------------------------------------------------
#
# Python modules
#
# -------------------------------------------------------------------------
from typing import TYPE_CHECKING, Any, Callable

# -------------------------------------------------------------------------
#
# GTK/Gnome modules
#
# -------------------------------------------------------------------------
from gi.repository import Gtk

# -------------------------------------------------------------------------
#
# gramps modules
#
# -------------------------------------------------------------------------
from gramps.gen.const import GRAMPS_LOCALE as glocale

_ = glocale.translation.sgettext
from .editsecondary import EditSecondary
from gramps.gen.dbstate import DbState
from gramps.gen.lib import Attribute, NoteType, SrcAttribute
from ..glade import Glade
from .displaytabs import CitationEmbedList, NoteTab
from ..widgets import (
    MonitoredDataType,
    MonitoredText,
    PrivacyButton,
    UndoableBuffer,
)
from gramps.gen.const import URL_MANUAL_SECT3

if TYPE_CHECKING:
    # Only needed for type hints; see the note on the __future__ import above
    # for why this cannot be a real, top-level import.
    from ..displaystate import DisplayState

# -------------------------------------------------------------------------
#
# Constants
#
# -------------------------------------------------------------------------

WIKI_HELP_PAGE = URL_MANUAL_SECT3
WIKI_HELP_SEC = _("Attribute_Editor_dialog", "manual")


# -------------------------------------------------------------------------
#
# EditAttribute class
#
# -------------------------------------------------------------------------
class EditAttributeRoot(EditSecondary):
    """
    Root baseclass for the root Attribute data editor
    """

    def __init__(
        self,
        state: DbState,
        uistate: DisplayState,
        track: list[Any],
        attrib: Attribute | SrcAttribute,
        title: str,
        data_list: list[str],
        callback: Callable[[Attribute | SrcAttribute], None] | None,
    ) -> None:
        """
        Displays the dialog box.

        :param state: The dbstate.
        :param uistate: The uistate.
        :param track: List of parent windows.
        :param attrib: The attribute that is to be edited.
        :param title: The title of the dialog box.
        :param data_list: List of options for the pop down menu, used to
                          help selection of an attribute type.
        :param callback: Function called with the edited attribute once the
                         user presses OK.
        """
        self.alist = data_list
        EditSecondary.__init__(self, state, uistate, track, attrib, callback)

    def _local_init(self) -> None:
        """
        Load the Glade interface and configure the top-level window.
        """
        self.top = Glade("editattribute.glade")

        self.set_window(
            self.top.toplevel, self.top.get_object("title"), _("Attribute Editor")
        )
        self.setup_configs("interface.attribute", 600, 350)

    def _connect_signals(self) -> None:
        """
        Wire up the dialog's Cancel, OK, and Help buttons.
        """
        self.define_cancel_button(self.top.get_object("cancel"))
        self.define_ok_button(self.top.get_object("ok"), self.cb_save)
        self.define_help_button(
            self.top.get_object("help"), WIKI_HELP_PAGE, WIKI_HELP_SEC
        )

    def _setup_fields(self) -> None:
        """
        Bind the Attribute object's fields to their widgets.
        """
        # UndoableBuffer has no __gtype_name__, so it cannot be
        # instantiated by class name from the Glade XML the way
        # UndoableEntry can; attach a real instance here instead of the
        # plain GtkTextBuffer Glade gave the text view by default.
        value_widget = self.top.get_object("attr_value")
        value_widget.set_buffer(UndoableBuffer())

        self.value_field = MonitoredText(
            value_widget,
            self.obj.set_value,
            self.obj.get_value,
            self.db.readonly,
        )

        self.priv = PrivacyButton(
            self.top.get_object("private"), self.obj, self.db.readonly
        )

        self.type_selector = MonitoredDataType(
            self.top.get_object("attr_menu"),
            self.obj.set_type,
            self.obj.get_type,
            self.db.readonly,
            custom_values=self.alist,
        )

    def _create_tabbed_pages(self) -> None:
        """
        Create an (empty) notebook and add it to the bottom pane of
        ``main_paned``, below the resizable Attribute/Value area.
        """
        notebook = Gtk.Notebook()

        self._setup_notebook_tabs(notebook)
        notebook.show_all()
        self.top.get_object("main_paned").pack2(notebook, resize=True, shrink=True)

    def build_menu_names(self, attrib: Attribute | SrcAttribute | None) -> tuple:
        """
        Return the menu labels used for this editor's window.

        :param attrib: The attribute being edited, or ``None`` for a new
                       attribute.
        :returns: A ``(menu_label, window_label)`` tuple.
        """
        if not attrib:
            label = _("New Attribute")
        else:
            label = str(attrib.get_type())
        if not label.strip():
            label = _("New Attribute")
        label = _("%(str1)s: %(str2)s") % {"str1": _("Attribute"), "str2": label}
        return (label, _("Attribute Editor"))

    def cb_save(self, *obj: Any) -> None:
        """
        Called when the OK button is pressed. Gets data from the
        form and updates the Attribute data structure.
        """
        attr_type = self.obj.get_type()

        if attr_type.is_custom() and str(attr_type) == "":
            from ..dialog import ErrorDialog

            ErrorDialog(
                _("Cannot save attribute"),
                _("The attribute type cannot be empty"),
                parent=self.window,
            )
            return
        if self.callback:
            self.callback(self.obj)
        self.close()


# -------------------------------------------------------------------------
#
# EditSrcAttribute class
#
# -------------------------------------------------------------------------
class EditSrcAttribute(EditAttributeRoot):
    """
    Source attribute are minimal attributes. This Displays the editor to
    edit these.
    """

    def __init__(
        self,
        state: DbState,
        uistate: DisplayState,
        track: list[Any],
        attrib: SrcAttribute,
        title: str,
        data_list: list[str],
        callback: Callable[[SrcAttribute], None] | None,
    ) -> None:
        """
        Displays the dialog box.

        :param state: The dbstate.
        :param uistate: The uistate.
        :param track: List of parent windows.
        :param attrib: The source attribute that is to be edited.
        :param title: The title of the dialog box.
        :param data_list: List of options for the pop down menu, used to
                          help selection of an attribute type.
        :param callback: Function called with the edited attribute once the
                         user presses OK.
        """
        EditAttributeRoot.__init__(
            self, state, uistate, track, attrib, title, data_list, callback
        )


# -------------------------------------------------------------------------
#
# EditAttribute class
#
# -------------------------------------------------------------------------
class EditAttribute(EditAttributeRoot):
    """
    Displays a dialog that allows the user to edit an attribute.
    """

    def __init__(
        self,
        state: DbState,
        uistate: DisplayState,
        track: list[Any],
        attrib: Attribute,
        title: str,
        data_list: list[str],
        callback: Callable[[Attribute], None] | None,
    ) -> None:
        """
        Displays the dialog box.

        :param state: The dbstate.
        :param uistate: The uistate.
        :param track: List of parent windows.
        :param attrib: The attribute that is to be edited.
        :param title: The title of the dialog box.
        :param data_list: List of options for the pop down menu, used to
                          help selection of an attribute type.
        :param callback: Function called with the edited attribute once the
                         user presses OK.
        """
        EditAttributeRoot.__init__(
            self, state, uistate, track, attrib, title, data_list, callback
        )

    def _create_tabbed_pages(self) -> None:
        """
        Create the Citations and Notes tabs and add the notebook to the
        bottom pane of ``main_paned``, below the resizable Attribute/Value
        area.
        """
        notebook = Gtk.Notebook()
        self.srcref_list = CitationEmbedList(
            self.dbstate,
            self.uistate,
            self.track,
            self.obj.get_citation_list(),
            "attribute_editor_citations",
        )
        self._add_tab(notebook, self.srcref_list)
        self.track_ref_for_deletion("srcref_list")

        self.note_tab = NoteTab(
            self.dbstate,
            self.uistate,
            self.track,
            self.obj.get_note_list(),
            "attribute_editor_notes",
            notetype=NoteType.ATTRIBUTE,
        )
        self._add_tab(notebook, self.note_tab)
        self.track_ref_for_deletion("note_tab")

        self._setup_notebook_tabs(notebook)
        notebook.show_all()
        self.top.get_object("main_paned").pack2(notebook, resize=True, shrink=True)


# -------------------------------------------------------------------------
#
# EditFamilyAttribute class
#
# -------------------------------------------------------------------------
class EditFamilyAttribute(EditAttribute):
    """
    Displays a dialog that allows the user to edit an attribute.
    """

    def __init__(
        self,
        state: DbState,
        uistate: DisplayState,
        track: list[Any],
        attrib: Attribute,
        title: str,
        data_list: list[str],
        callback: Callable[[Attribute], None] | None,
    ) -> None:
        """
        Displays the dialog box.

        :param state: The dbstate.
        :param uistate: The uistate.
        :param track: List of parent windows.
        :param attrib: The attribute that is to be edited.
        :param title: The title of the dialog box.
        :param data_list: List of options for the pop down menu, used to
                          help selection of an attribute type.
        :param callback: Function called with the edited attribute once the
                         user presses OK.
        """
        EditAttribute.__init__(
            self, state, uistate, track, attrib, title, data_list, callback
        )
