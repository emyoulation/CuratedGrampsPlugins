# PR2388 Example Tree Prompt
<!-- undocked=false -->
[README.md](README.md) ● [CHANGELOG.md](CHANGELOG.md)

# This addon is a field-test package of pull request #2388
[Gramps pull request #2388](https://github.com/gramps-project/gramps/pull/2388) by Doug Blank ([@dsblank](https://github.com/dsblank)): "Prompt new users to import the Example Family Tree on startup"

The feature design, the dialog, the import logic, map tiles, and starter helper features all come from that pull request. This addon repackages the work so that testers can try it in Gramps 5.2, 6.0, and 6.1 without patching Gramps core files. Please leave feedback about the core feature on [the pull request](https://github.com/gramps-project/gramps/pull/2388).

Welcome! A brand-new Gramps can feel like an empty room. This addon offers to fill it with a starter family tree, allowing you to explore people, events, places, media, and maps before entering your own family history.
![First dialog](media/screenshot.png)  ![PR version of the dialog](media/orig_screenshot.png) 

When you start Gramps and no practice tree exists yet, a friendly **Getting Started** dialog asks whether you would like to import it. Choosing **Import Practice Tree** automatically sets up the tree, seeds the map tile cache, bookmarks the media folder, configures a helpful **To Do** gramplet on your Dashboard, and opens the tree ready for exploration.

---

## What the Dialog Offers
* **Import Practice Tree**: Creates a new practice tree called *sample tree data*, imports the bundled sample records into it, adds a starter To Do note, sets up the Dashboard To Do gramplet, and opens it immediately. If you later delete or rename this tree, the prompt will reappear on your next startup.
* **Skip**: Closes the prompt for the current session. 
* **Don't ask again**: Permanently disables the startup prompt by updating your local addon configuration.

The prompt appears automatically after the Family Tree manager closes (if applicable) and intelligently suppresses the Tip of the Day window for that launch to prevent overlapping splash windows.

---

## Exploring the New Practice Tree & Dashboard
Once imported, the addon automatically guides your first steps:
* **Dashboard & To Do Gramplet**: The addon switches to your **Dashboard** view and inserts a **To Do** gramplet if your dashboard is empty or using the default layout[cite: 3]. 
* **Sample To Do Note**: An introductory To Do note is automatically created and attached to the Home Person[cite: 3]. It provides handy links to learn more about the sample tree and start exploring right away[cite: 3].

![Dashboard with To Do Gramplet](media/dashboard_sample.png)

* **Media Folder Bookmark**: A labeled GTK bookmark (`Gramps example data`) is added automatically to your file chooser bookmarks, making it effortless to browse the sample media files.
* **Geography Starter Tiles**: Low-zoom OpenStreetMap tiles are seeded locally so that world maps load instantly in the Geography view.

---

## Installing
1. Install **PR2388 Example Tree Prompt** from the Emyoulation experimental addons project via your Gramps Addon Manager.
2. Select Family Trees -> Close to release the currently loaded tree
3. Quit Gramps
4. Find and remove the Dashboard `Gramplets_dashboardview_gramplets.ini` file in your Gramps User Data folder

## Using
1. Restart Gramps.
2. Cancel the the Tree selection dialog (without opening  if it appears

---

## Resetting the Prompt (For Testers)
When a **sample tree data** tree exists, the helper dialog is suppressed. Use the **Family Trees -> Manage Family Trees** dialog to "Delete" the `sample tree data`. 
The addon configuration is stored in `PR2388_ExampleTreePrompt.ini` inside the addon folder. To make the startup dialog appear again after choosing **Skip** or **Don't ask again**:
* Delete `PR2388_ExampleTreePrompt.ini`, or
* Open it in a text editor and change `show-example-prompt = False` to `show-example-prompt = True`.

*(Note: The prompt will only appear if a tree named "sample tree data" does not already exist.)*

---

## Credits
* **Doug Blank ([@dsblank](https://github.com/dsblank))**: Created [Gramps pull request #2388](https://github.com/gramps-project/gramps/pull/2388) containing the core feature, dialog layout, import routines, and map tile mechanisms.
* **Claude AI & Brian McCullough**: Developed and maintained the field-test addon port for Gramps 5.2–6.1.
* **OpenStreetMap contributors**: Map tiles © [OpenStreetMap](https://www.openstreetmap.org/copyright) contributors.
