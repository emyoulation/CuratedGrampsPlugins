# PR2388 Example Tree Prompt Changelog
<!-- undocked=false -->
[README.md](README.md) ● [CHANGELOG.md](CHANGELOG.md)

This addon is a field-test package of [Gramps pull request #2388](https://github.com/gramps-project/gramps/pull/2388) by Doug Blank ([@dsblank](https://github.com/dsblank)). Entries below note where the addon follows the pull request and where it intentionally differs.

## 0.1.0
- At startup, when no sample tree exists, a dialog offers to import the sample tree data that comes with Gramps (`data.gramps`). Choosing **Import Practice Tree** creates the tree, imports the data and opens it. (From the pull request.)
- The dialog no longer competes with a tree or file given at startup. When Gramps starts with something to open or import (for example `gramps file.ged`, opening a file from a file manager, or the `-O`, `-C`, `-i`, `-e` or `-a` options), the dialog does not appear. (The pull request shows the dialog anyway, and importing would close the tree the user asked to open.)
- After the import, Gramps switches to the Dashboard. If the Dashboard is empty or still shows only the default gramplets, the To Do gramplet is added.
- If the imported data has no To Do notes, one To Do note is added and attached to the Home Person. It links "Read more about this sample tree" to the addon help page, "Home Person" to the [Gramps Glossary entry](https://gramps-project.org/wiki/index.php/Gramps_Glossary#home_person), and the name to the Home Person. If the tree has no Home Person, the note says so and uses the person with the lowest Gramps ID instead.
- Importing adds a "Gramps example data" bookmark for the sample media folder to the file chooser sidebar, unless a bookmark for that folder already exists.
- Only the **Don't ask again** checkbox turns the dialog off for good. **Skip**, the Esc key and the window close button skip it for this launch only. (In the pull request, Skip also turns it off for good, so the checkbox only matters together with Import.)
- The imported tree is named "sample tree data" instead of "Example Family Tree". Gramps also includes the much larger `example.gramps`, and `data.gramps` has no name of its own, so the generic name avoids confusion and still fits a replacement or localized `data.gramps`.
- The dialog uses the Tip of the Day layout (Gramps picture on the left, text on the right) with the title "Getting Started", so it does not share a name with the Welcome to Gramps gramplet. The Tip of the Day is skipped for any launch where this dialog appears, so two similar windows never open together.
- Media in the sample tree is found in installed Gramps packages, because the `{GRAMPS_RESOURCES}` value used in its Base media path is now known to Gramps. (From the pull request.)
- Starter world map pictures for the Geography view (zoom levels 0 to 2) are copied into the map cache after the import, when the optional `maps` folder is present in the addon folder. (From the pull request.)
- Works with Gramps 5.2, 6.0 and 6.1. If a future Gramps already includes the feature, the addon does nothing.
- The dialog setting is kept in `PR2388_ExampleTreePrompt.ini` in the addon folder instead of `gramps.ini`.

## Outstanding issues
### Planned / NYI
- The map pictures are not yet included in the addon package; testers download them with the command in the README.
- Preferences options to keep file chooser bookmarks for the current Base media path, the backup path and other useful folders.

### Needs discussion
- Which of the differences above should be proposed on [the pull request](https://github.com/gramps-project/gramps/pull/2388): the startup-file conflict, the checkbox behavior, the tree name and skipping the Tip of the Day.
- In the pull request, `gramps/gui/exampleimport.py` raises a `NameError` when it is imported on Python 3.13 and older, because the `ViewManager` type annotation is only imported for type checking.
- Some Linux packages may leave out `data.gramps`; in that case the dialog never appears (a warning is logged with the path that was checked).
- Confirm that the "Getting Started" title is visible in the window title bar on macOS and Windows.

### Beyond scope
- Offering the large `example.gramps` tree as a second choice.
- Providing localized sample data.
