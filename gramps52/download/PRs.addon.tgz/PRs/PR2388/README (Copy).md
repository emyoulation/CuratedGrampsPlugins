# PR2388 Example Tree Prompt
<!-- undocked=false -->
[README.md](README.md) ● [CHANGELOG.md](CHANGELOG.md)

# This addon is a field-test package of pull request #2388
[Gramps pull request #2388](https://github.com/gramps-project/gramps/pull/2388) by Doug Blank ([@dsblank](https://github.com/dsblank)): "Prompt new users to import the Example Family Tree on startup"
The feature design, the dialog, the import logic and the bundled map tiles all come from that pull request. This addon only repackages the work so that people can try it in Gramps 5.2, 6.0 and 6.1 without patching Gramps itself. Please leave feedback about the feature itself on [the pull request](https://github.com/gramps-project/gramps/pull/2388).

Welcome! A brand-new Gramps can feel like an empty room. This addon offers to fill it with the Example Family Tree, a sample family that comes with Gramps, so you can explore people, events, places, media and maps before you type in a single name of your own.
![First dialog](media/screenshot.png) ● ![First dialog](media/orig_screenshot.png) 

When you start Gramps and there is no tree named "Example Family Tree", a small "Welcome to Gramps" dialog asks whether you would like to import it. Choose **Import Practice Tree** and Gramps creates the tree, fills it with the sample data and opens it for you. The Geography view also gets a starter set of world map pictures, so the maps work right away, even without an internet connection.

## What the dialog offers
- **Import Practice Tree** creates a new tree called "sample tree data", imports the sample data into it and opens it. If you later delete or rename that tree, the dialog appears again at the next startup.
- **Skip** closes the dialog and the dialog does not appear again. Closing the dialog with the Esc key or the window close button does the same thing.
- **Don't ask again** stops the dialog from appearing in the future, even if you choose to import.

The dialog appears instead of the Tip of the Day window (if you have Tip of the Day turned on), and after the Family Trees manager closes (if that opens at startup).

## Installing
1. Install **PR2388 Example Tree Prompt** from the Emyoulation addons in the Gramps Addon Manager.
2. Optional: add the starter map pictures. Open a terminal, go to the folder where the addon was installed and run the command below. For Gramps 6.0 the folder is usually `~/.local/share/gramps/gramps60/plugins/PR2388_ExampleTreePrompt` (use `gramps52` or `gramps61` for those versions).

```bash
for z in 0 1 2; do n=$((1<<z)); for x in $(seq 0 $((n-1))); do for y in $(seq 0 $((n-1))); do curl -sf --create-dirs -o maps/openstreetmap/$z/$x/$y.png https://raw.githubusercontent.com/gramps-project/gramps/5bef5c3081616c59559d3c21203ab42b9212421b/data/maps/openstreetmap/$z/$x/$y.png; done; done; done
```

This downloads 21 small map pictures (about 170 KB) from the pull request into a `maps` folder inside the addon folder. Without them, the addon still works, and the Geography view downloads map pictures from the internet as usual.

3. Restart Gramps.

## Seeing the dialog again (for testers)
The addon keeps its one setting in a file named `PR2388_ExampleTreePrompt.ini` in the addon folder. To bring the dialog back after choosing **Skip** or **Don't ask again**, do one of these while Gramps is closed:

- Delete `PR2388_ExampleTreePrompt.ini`, or
- Open it in a text editor and change `show-example-prompt = False` to `show-example-prompt = True`.

The dialog also needs the "Example Family Tree" to be missing, so rename or delete that tree in the Family Trees manager if you imported it before.

## If the dialog does not appear
- **The sample data is not installed.** Some Linux packages and minimal installs leave out the example files. Start Gramps from a terminal and look for a line from PR2388 Example Tree Prompt that says the example data was not found, along with the place it looked.
- **A tree named "Example Family Tree" already exists.** The dialog only appears when that tree is missing.
- **The setting is turned off.** See "Seeing the dialog again" above.
- **Your Gramps already includes this feature.** If a future Gramps version contains the pull request, this addon steps aside and does nothing, so you never see two dialogs.

## Things testers may want to watch for
- Do the pictures in the Example Family Tree media show up correctly after the import?
- Does the Geography view show the world map at the widest zoom without a network connection?

Please report what you find on [the pull request](https://github.com/gramps-project/gramps/pull/2388).

## Credits
- **Doug Blank ([@dsblank](https://github.com/dsblank))** wrote [Gramps pull request #2388](https://github.com/gramps-project/gramps/pull/2388): the feature, the dialog, the import and map tile logic, and the bundled OpenStreetMap tiles. The pull request notes that it was written with Claude Code.
- **Claude AI** (wish coding by Brian McCullough) repackaged the pull request as this addon.
- **Brian McCullough** maintains the addon.
- Map tiles © [OpenStreetMap](https://www.openstreetmap.org/copyright) contributors.

## Technical note for developers
The pull request adds a call in `Gramps.__init__` right after the Tip of the Day. An addon cannot change that code, so this addon uses `load_on_reg` (which runs while plugins register, inside `ViewManager.__init__`) to wrap `ViewManager.post_init_interface` one time. After the original method returns, the wrapper puts the original back and queues the prompt with `GLib.idle_add`, so the dialog appears once the main loop starts, which matches the order in the pull request.

The other parts of the pull request are handled like this:

- The `GRAMPS_RESOURCES` key is added to `gramps.gen.const.ENV` at runtime. `gramps.gen.utils.file` imports the same dictionary object, so `{GRAMPS_RESOURCES}` in the example media path expands correctly.
- `DOC_DIR` is not exported by `const.py` in Gramps 5.2 and 6.0, so the addon derives it from `LICENSE_FILE`, which is built from the same resource path.
- The map tiles live in the addon folder instead of the Gramps data folder.
- The setting `behavior.show-example-prompt` lives in `PR2388_ExampleTreePrompt.ini` (a Gramps `ConfigManager` with a `[meta]` block) instead of `gramps.ini`, so the pull request command-line override `--config=behavior.show-example-prompt:True` does not apply to the addon.
- The addon does nothing if `gramps.gui.exampleimport` already exists in Gramps core.

Small differences from the pull request: the button and checkbox labels have no keyboard mnemonics, the addon logs a warning when the sample data is missing instead of staying silent, and type annotations were removed so the code runs on older Python versions. (In the pull request, the `ViewManager` annotation in `exampleimport.py` raises a `NameError` at import time on Python 3.13 and older.)

## Assumptions I made (draft review)
- The intended audience is testers first, newcomers second, so the "Seeing the dialog again" and "Things testers may want to watch for" sections are near the top half of the document.
- The map tiles are an optional manual step until the addon package includes the `maps` folder.
- The addon folder names for Gramps 5.2 and 6.1 follow the usual `gramps52` and `gramps61` pattern.
- Feedback about the feature goes to the pull request, and feedback about the packaging goes to you (no separate link given yet).
- Line 2 uses `<!-- undocked=false -->` as the interface directive; change it if this addon should use a different one.
- No screenshots yet; a picture of the "Welcome to Gramps" dialog would be a good addition after the next test run.
