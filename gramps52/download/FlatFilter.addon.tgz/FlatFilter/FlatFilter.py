#
# Gramps - a GTK+/GNOME based genealogy program
#
# FlatFilter.py - Gramps 5.2 compatible
#
# Changes from the 6.0 port:
#   - Rule.apply() (not apply_to_one())
#   - Rule.requestprepare() / Rule.requestreset()
#   - Added None-handle guards to avoid HandleError("Handle is None")
#   - Added "given" / "surname" placeholders
#   - Added "2nd Sibling" / "2nd Child" labels
#

from gi.repository import Gtk

from gramps.gen.const import GRAMPS_LOCALE as glocale
from gramps.gen.datehandler import displayer
from gramps.gen.filters import GenericFilter
from gramps.gen.filters.rules import Rule
from gramps.gen.filters.rules.person import ProbablyAlive
from gramps.gen.lib import Date
from gramps.gen.lib.person import Person
from gramps.gen.plug import Gramplet
from gramps.gui import widgets
from gramps.gui.filters.sidebar import SidebarFilter

_ = glocale.translation.gettext


# ------------------------------------------------------------
# Name matching helpers
# ------------------------------------------------------------

class _RegExpNameList(Rule):

    labels = [_("Text:")]
    name = _("People with a name matching <text>")
    description = _("Matches people's names containing a substring or matching a regular expression")
    category = _("General filters")
    allow_regex = True

    def field_list(self, name):
        raise NotImplementedError

    def apply(self, db, person):
        for name in [person.get_primary_name()] + person.get_alternate_names():
            for field in self.field_list(name):
                if self.match_substring(0, field):
                    return True
        return False


class RegExpPersonal(_RegExpNameList):

    def field_list(self, name):
        return [name.first_name, name.title, name.nick]


class RegExpFamily(_RegExpNameList):

    def field_list(self, name):
        return [name.get_surname(), name.suffix, name.title, name.famnick, name.call]


# ------------------------------------------------------------
# Relation rules
# ------------------------------------------------------------

class _HasNamedRelation(Rule):

    labels = [_("Filter name:")]
    name = _("Children of name match")
    category = _("Family filters")
    description = _("Matches children of anybody with a given name")

    def __init__(self, arg, name_matcher, use_regex=False):
        Rule.__init__(self, arg, use_regex)
        self.name_matcher = name_matcher(arg, use_regex)

    def requestprepare(self, db, user):
        self.name_matcher.requestprepare(db, user)

    def requestreset(self):
        self.name_matcher.requestreset()

    def get_rel_list(self, db, person):
        raise NotImplementedError

    def get_spouse_list(self, db, person):
        result = []
        for fam_id in person.get_family_handle_list():
            if not fam_id:
                continue
            fam = db.get_family_from_handle(fam_id)
            if not fam:
                continue
            for spouse_id in (fam.get_father_handle(), fam.get_mother_handle()):
                if spouse_id and spouse_id != person.handle:
                    result.append(spouse_id)
        return result

    def apply(self, db, person):
        for rel_id in self.get_rel_list(db, person):
            if not rel_id:
                continue
            rel = db.get_person_from_handle(rel_id)
            if rel and self.name_matcher.apply(db, rel):
                return True
        return False


class _HasNamedParent(_HasNamedRelation):

    def get_parent_families(self, db, person):
        result = []
        for fam_id in person.get_parent_family_handle_list():
            if not fam_id:
                continue
            fam = db.get_family_from_handle(fam_id)
            if fam:
                result.append(fam)
        return result


class HasNamedFather(_HasNamedParent):

    def get_rel_list(self, db, person):
        return [fam.get_father_handle() for fam in self.get_parent_families(db, person)]


class HasNamedMother(_HasNamedParent):

    def get_rel_list(self, db, person):
        return [fam.get_mother_handle() for fam in self.get_parent_families(db, person)]


class IsSiblingofNamedSibling(_HasNamedRelation):

    def get_rel_list(self, db, person):
        result = []
        fam_id = person.get_main_parents_family_handle()
        if not fam_id:
            return result

        fam = db.get_family_from_handle(fam_id)
        if not fam:
            return result

        for child_ref in fam.get_child_ref_list():
            if child_ref and child_ref.ref != person.handle:
                result.append(child_ref.ref)

        return result


class HasNamedChild(_HasNamedRelation):

    def get_rel_list(self, db, person):
        result = []
        for fam_id in person.get_family_handle_list():
            if not fam_id:
                continue
            fam = db.get_family_from_handle(fam_id)
            if not fam:
                continue
            for child_ref in fam.get_child_ref_list():
                if child_ref:
                    result.append(child_ref.ref)
        return result


class HasNamedSpouse(_HasNamedRelation):

    def get_rel_list(self, db, person):
        return self.get_spouse_list(db, person)


class HasName(_HasNamedRelation):

    def get_rel_list(self, db, person):
        if person.gender == Person.FEMALE and isinstance(self.name_matcher, RegExpFamily):
            result = self.get_spouse_list(db, person)
            result.append(person.handle)
            return result
        return [person.handle]


# ------------------------------------------------------------
# UI
# ------------------------------------------------------------

class SearchableNamePair(object):

    def __init__(self, label, rule_class):
        self.widget_personal = widgets.BasicEntry()
        self.widget_family = widgets.BasicEntry()
        self.label = label
        self.rule_class = rule_class

    def place(self, sidebar):
        sidebar.grid.attach(widgets.BasicLabel(self.label), 1, sidebar.position, 1, 1)

        self.widget_personal.set_hexpand(True)
        self.widget_personal.set_placeholder_text(_("given"))
        sidebar.grid.attach(self.widget_personal, 2, sidebar.position, 1, 1)
        self.widget_personal.connect("key-press-event", sidebar.key_press)

        self.widget_family.set_hexpand(True)
        self.widget_family.set_placeholder_text(_("surname"))
        sidebar.grid.attach(self.widget_family, 3, sidebar.position, 1, 1)
        self.widget_family.connect("key-press-event", sidebar.key_press)

        sidebar.position += 1

    def clear(self):
        self.widget_personal.set_text("")
        self.widget_family.set_text("")

    def _add_to_filter(self, generic_filter, regex, widget, search_class):
        value = str(widget.get_text().strip())
        if value:
            generic_filter.add_rule(
                self.rule_class([value], search_class, use_regex=regex)
            )

    def add_to_filter(self, generic_filter, regex):
        self._add_to_filter(generic_filter, regex, self.widget_personal, RegExpPersonal)
        self._add_to_filter(generic_filter, regex, self.widget_family, RegExpFamily)


class PersonSidebarFilter2(SidebarFilter):

    def __init__(self, dbstate, uistate, clicked):

        self.clicked_func = clicked

        self.names = [
            SearchableNamePair(_("Father"), HasNamedFather),
            SearchableNamePair(_("Mother"), HasNamedMother),
            SearchableNamePair(_("Name"), HasName),
            SearchableNamePair(_("Spouse"), HasNamedSpouse),
            SearchableNamePair(_("Sibling"), IsSiblingofNamedSibling),
            SearchableNamePair(_("2nd Sibling"), IsSiblingofNamedSibling),
            SearchableNamePair(_("Child"), HasNamedChild),
            SearchableNamePair(_("2nd Child"), HasNamedChild),
        ]

        self.filter_alive = widgets.DateEntry(uistate, [])
        self.filter_regex = Gtk.CheckButton(label=_("Use regular expressions"))

        SidebarFilter.__init__(self, dbstate, uistate, "Person")

    def create_widget(self):

        exdate1 = Date()
        exdate2 = Date()

        exdate1.set(Date.QUAL_NONE, Date.MOD_RANGE, Date.CAL_GREGORIAN,
                    (0, 0, 1800, False, 0, 0, 1900, False))

        exdate2.set(Date.QUAL_NONE, Date.MOD_BEFORE, Date.CAL_GREGORIAN,
                    (0, 0, 1850, False))

        msg1 = displayer.display(exdate1)
        msg2 = displayer.display(exdate2)

        for w in self.names:
            w.place(self)

        self.add_text_entry(
            _("Probably Alive"),
            self.filter_alive,
            _('example: "%(msg1)s" or "%(msg2)s"') %
            {"msg1": msg1, "msg2": msg2},
        )

        self.add_regex_entry(self.filter_regex)

    def clear(self, obj):
        for w in self.names:
            w.clear()
        self.filter_alive.set_text("")

    def get_filter(self):

        regex = self.filter_regex.get_active()
        generic_filter = GenericFilter()

        for w in self.names:
            w.add_to_filter(generic_filter, regex)

        alive = str(self.filter_alive.get_text().strip())
        if alive:
            generic_filter.add_rule(ProbablyAlive([alive]))

        return generic_filter


# ------------------------------------------------------------
# Gramplet
# ------------------------------------------------------------

class Filter2(Gramplet):

    FILTER_CLASS = None

    def init(self):

        self.filter = self.FILTER_CLASS(
            self.dbstate, self.uistate, self.__filter_clicked)

        self.widget = self.filter.get_widget()

        self.gui.get_container_widget().remove(self.gui.textview)
        self.gui.get_container_widget().add(self.widget)

        self.widget.show_all()

    def __filter_clicked(self):

        self.gui.view.generic_filter = self.filter.get_filter()
        self.gui.view.build_tree()


class FlatFilter(Filter2):

    FILTER_CLASS = PersonSidebarFilter2
