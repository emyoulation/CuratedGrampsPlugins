# What's Next? - Changelog

[README.md](README.md) ● [CHANGELOG.md](CHANGELOG.md)

All notable differences between Beta What's Next and the built-in "What's Next" gramplet in Gramps.

Baseline for comparison: "What's Next" version 1.0.0, as registered in [gramplet.gpr.py](https://github.com/gramps-project/gramps/blob/5cebb2c55fdbb0a92428625d409918216409db70/gramps/plugins/gramplet/gramplet.gpr.py#L445), using the source file [whatsnext.py on maintenance/gramps61](https://github.com/gramps-project/gramps/blob/maintenance/gramps61/gramps/plugins/gramplet/whatsnext.py) (fetched October 2026). The `maintenance/gramps52` copy, also registered as 1.0.0, has the same behavior; it differs only in the license header wording and one tuple-unpacking style change.

## [0.1.10] (current beta)
### Added
- Separate registration (`id="Beta What's Next"`, class `BetaWhatNextGramplet`) so the beta can run beside the built-in gramplet. Registers on Gramps 5.2.0 through 6.2.0 only, using `VERSION_TUPLE` and `major_version` from `gramps.version`.
- Guidance message when no Family Tree is loaded, with steps for creating, loading, or importing a tree. Upstream showed only "No Family Tree loaded."
- Guidance message when the tree contains no people, with steps for adding a family or importing people. Upstream gave no message for an empty tree and showed "No Home Person set." instead.
- Guidance message when no Home Person is set, with steps for setting one. Upstream showed only "No Home Person set."
- A first line naming the Home Person, so the starting point of the search is visible.
- 👣 next-step suggestion for a missing Birth event ("Add via the Events tab of the Edit Person dialog.").
- Automatic refresh on `event-add`, `event-update`, `event-delete`, `event-rebuild`, `person-rebuild`, and `family-rebuild`. Upstream did not refresh when an event was edited, so fixing a birth date or place left the old problem in the list.
- `_no_db()` override so the "no tree loaded" guidance reappears after a tree is closed.
- A `verbose_suggestions` module switch (on by default) to turn the guidance text and 👣 suggestions off.
- A `show_diagnostic` module switch (off by default) that prints quota-counter trace lines for debugging the search loop.
- Extra quota check inside the "families of children" loop, so the search stops sooner once the Search Quota is reached.

### Changed
- Option labels shortened:
  - "Minimum number of items to display" is now "Search Quota".
  - "Descendant generations per ancestor generation" is now "Depth per loop".
  - "Delay before descendants of an ancestor is processed" is now "Pause search expansion".
  - "Tag to indicate that a person is complete" is now "Completed Person".
  - "Tag to indicate that a family is complete" is now "Completed offspring Families".
  - "Tag to indicate that a person or family should be ignored" is now "Ignore Person or Family".
- Default "Depth per loop" lowered from 2 to 1, and default "Pause search expansion" raised from 1 to 5. The search stays closer to direct ancestors for longer.
- Maximum "Depth per loop" lowered from 20 to 15.
- Problem descriptions reworded to be more explicit:
  - "birth event missing" is now "Birth event missing."
  - "relation type unknown" is now "relationship type unknown".
  - "place unknown" is now "place unknown for the Event".
  - "spouse missing" is now "A partner relationship exists but the spouse is missing".
  - "father missing" / "mother missing" are now "Father missing from the parent family" / "Mother missing from the parent family".
- Tooltip changed from "Double-click name for details" to a pointer to the gramplet options while no list is shown, then "Double-click color text to edit details" once the list is built.
- Default gramplet height raised from 230 to 300.
- Help link points to the beta repository instead of the Gramps wiki manual.
- License header changed from "version 2 or (at your option) any later version" to "version 2" only. The header also keeps the older Free Software Foundation postal address, where the 1.0.0 baseline now points to https://www.gnu.org/licenses/.

### Removed
- The "parents missing" report. `__missing_parents()` now builds a message but never displays it, so people with no parent family are no longer listed. See Known issues.

### Known issues
- People with no parent family are silently skipped (see Removed). This looks unintentional.
- Debugging line numbers leak into two user-visible messages: "591 family not complete" and "<line number> person not complete".
- The 👣 suggestions for missing spouse, father, mother, parents, and marriage event are written but not yet displayed.
- The Birth event suggestion adds an extra blank line after the entry, which can look like a round separator.
