# What's Next?

[README.md](README.md) ● [CHANGELOG.md](CHANGELOG.md)

**Beta What's Next** is a Gramps gramplet that suggests the next research or documentation tasks for a family tree. It starts at the Home Person, works outward through ancestors, descendants, and their partners, and lists people and families with missing or incomplete information. It is a beta-test fork of the "What's Next" gramplet that is built into Gramps.
![Next steps when the Example Tree is loaded](media/screenshot.png)

The changes from the built-in gramplet focus on new users: plain-language guidance when the tree cannot be checked yet, clearer descriptions of each problem, suggested next steps, and a list that refreshes when Events change. See CHANGELOG.md for a detailed comparison.

## Requirements
- Gramps 5.2.0 through 6.2.0.
- A loaded Family Tree with a Home Person set.

## Installation
Copy `Betawhatsnext.gpr.py` and `Betawhatsnext.py` into a folder inside the Gramps user plugins folder, then restart Gramps. The gramplet appears in the gramplet list as "Beta What's Next?".
The built-in "What's Next?" gramplet is not replaced. Both gramplets can be used at the same time, which makes side-by-side comparison easy.

## Adding the gramplet
- Dashboard: right-click the Dashboard background and choose "Add a gramplet", then "Beta What's Next?".
![Adding a gramplet to the Dashboard](media/AddDashboardGramplet.png)
- Sidebar or Bottombar: click the small down-arrow button in the gramplet bar and choose "Add a gramplet", then "Beta What's Next?".

## Getting started messages
When the gramplet cannot build a list yet, it explains why and what to do next. Each message starts with a ⛔ symbol, and the suggested next steps start with a 👣 symbol.
- No Family Tree loaded: explains how to create or load a tree from the "Family Trees" menu, and how to import a backup or GEDCOM file into a new empty tree.
![Next steps when no Tree is loaded](media/NoTreeLoaded.png)
- The tree has no people: explains how to add a Family and people, or how to import people from a file.
![Next steps when the Tree is empty](media/BlankTree.png)
- No Home Person: explains how to choose a person in the People view and use "Set Home Person" from the Edit menu or the right-click menu.
![Next steps when no Home Person has been set](media/NoHomePerson.png)

## Reading the list
The first line names the Home Person, so it is clear where the search started. Each following line names a person or a family and then lists the problems found.
- Single-click a colored name to make that person or family the Active one.
- Double-click a colored name to open the Edit Person or Edit Family dialog.
- A line that starts with 👣 suggests what "next steps" should be taken to fix the problem.
- A blank line separates each round of the search. Each round moves one generation further away from the Home Person.

The list refreshes automatically when people, families, or events are added, changed, or deleted, and when the Home Person changes.


- The person does not have the "Completed Person" tag (only when that option is set).
- The family does not have the "Completed offspring Families" tag (only when that option is set).

## What the gramplet checks
### For each person:
- First name or surname is unknown.
- The Birth event is missing.
- The Birth or Death event has no date, an incomplete date, or no place.

### For each family:
- The relationship type is "Married" but there is no Marriage event.
- The relationship type is "Unknown".
- The Marriage or Divorce event has no date, an incomplete date, or no place.

### For links between people:
- A partner relationship exists but the spouse is missing.
- The father or the mother is missing from the parent family.

## Options
Open the gramplet options with "Configure..." in the View menu (Sidebar and Bottombar), or with the gramplet properties on the Dashboard.

| Option | Range | Default | What it does |
|---|---|---|---|
| Search Quota | 1 to 300 | 10 | The minimum number of lines to show. The search stops when this many problems are found. |
| Depth per loop | 1 to 15 | 1 | How many generations of descendants to check before going up one more generation of ancestors. |
| Pause search expansion | 1 to 10 | 5 | How many extra rounds to wait after checking an ancestor before checking the descendants of that ancestor. |
| Completed Person | any tag | (none) | People without this tag are reported as "person not complete". Use it to mark people whose partners are all known. |
| Completed offspring Families | any tag | (none) | Families without this tag are reported as "family not complete". Use it to mark families whose children are all known. |
| Ignore Person or Family | any tag | (none) | People and families with this tag are skipped, and the search does not continue through them. Use it for dead ends that would otherwise fill the list. |

The defaults differ from the built-in gramplet (which uses 2 for "Depth per loop" and 1 for the pause). The new defaults keep the search closer to direct ancestors for longer.

## Tips
- Create the tags first (for example "Complete", "Children complete", and "Ignore") with "Organize Tags..." in the Edit menu, then choose them in the options.
- Use the Ignore tag sparingly. Everyone reached only through an ignored person or family is also left out of the list.
- Raise the Search Quota for a longer to-do list. Large values can make the list slow to build in big trees.

## Feedback
This is a beta version. Please report problems and suggestions at https://github.com/emyoulation/_BetaDashboards

## Credits and license
- Original "What's Next" gramplet: Reinhard Mueller (2008), maintained by Jakim Friant (2010) and the Gramps project.
- Beta changes: Brian McCullough (2023 to 2024).

Distributed under the GNU General Public License. See the license header in the source files.

## Assumptions I made
These are notes for review during the draft phase. Remove this section before release.
- The "Parent family is unknown" check is meant to stay active. In the current code it builds its message but never shows it, so people with no parents are not listed at all. This README describes the check as working (under "missing from the parent family"), which may need to change.
- The 👣 suggestions for missing spouses, fathers, mothers, and marriage events are planned but not finished. Only the missing Birth event suggestion appears today, so the README only promises 👣 lines in general terms.
- Installation is by manual copy. If the gramplet will ship through the Gramps addon listing or the Plugin Manager, the Installation section should change.
- The "Completed Person" tag means "all partners of this person are known", matching the comment in the code. The option name alone could suggest "all research on this person is done".
- The help link (the GitHub repository) is the right place for feedback.
