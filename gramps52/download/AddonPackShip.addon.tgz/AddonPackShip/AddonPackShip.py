#!/usr/bin/python
# -*- coding: utf-8 -*-

#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026  Brian McCullough <emyoulation@yahoo.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, see <https://www.gnu.org/licenses/>.

"""
Addon Pack and Ship Tool - GUI for packaging and publishing Gramps addons

Author: Brian McCullough
Development: AI-assisted using Claude (Anthropic)
Created: February 2026
Version: 1.9.0

A graphical tool for Gramps addon developers to simplify packaging and
distribution. Provides checkbox selection, MANIFEST file support, complete
metadata extraction, and ready-to-publish GitHub output structure.
"""

#------------------------------------------------------------------------
#
# Python modules
#
#------------------------------------------------------------------------
import ast
import io
import os
import re
import sys
import contextlib
import copy
import glob
import json
import types
import shutil
import logging
import datetime
import importlib.util
import inspect
import subprocess
import configparser
import urllib.request
import urllib.error

#------------------------------------------------------------------------
#
# GTK modules
#
#------------------------------------------------------------------------
from gi.repository import Gtk, GObject, GLib, Gdk, GdkPixbuf, Pango

#------------------------------------------------------------------------
#
# Gramps modules
#
#------------------------------------------------------------------------
from gramps.gen.const import GRAMPS_LOCALE as glocale
_ = glocale.translation.gettext


class _KeepUnknownFields(dict):
    """format_map() mapping that leaves an unknown {field} as it is."""

    def __missing__(self, key):
        return "{" + key + "}"


def fill_names(text, **names):
    """
    Fill the {name} fields of an already translated message.

    File, folder and command names (addons-en.json, listings/,
    MANIFEST, .gpr.py, xgettext ...) must stay in English, because the
    code and the Addon Manager use exactly those names. They are kept
    out of the translatable text as {fields}, so a translator sees
    "{listing}" and cannot change the name itself::

        fill_names(_("Open {listing} for editing"),
                   listing="addons-en.json")

    A field a translator misspelled is shown as "{field}" instead of
    raising an error, and any other formatting problem returns the text
    unfilled, so a bad translation can never stop a dialog from opening.

    :param text: The translated message, with {name} fields.
    :param names: The values for the fields.
    :returns: The filled message.
    """
    try:
        return text.format_map(_KeepUnknownFields(names))
    except (IndexError, ValueError, AttributeError):
        return text

from gramps.version import major_version
from gramps.gui.plug import tool
from gramps.gui.dialog import OkDialog, ErrorDialog
from gramps.gui.managedwindow import ManagedWindow
from gramps.gui.utils import open_file_with_default_application, ProgressMeter
from gramps.gen.simple import SimpleDoc, SimpleTable
# Import directly from _pluginreg so VIEW is always present (same as PluginManager Enhanced)
from gramps.gen.plug._pluginreg import PluginRegister, PTYPE_STR
from gramps.gui.pluginmanager import GuiPluginManager
try:
    from gramps.gen.plug import PTYPE_STR as _PTYPE_STR_PUB
except ImportError:
    _PTYPE_STR_PUB = PTYPE_STR

LOG = logging.getLogger(__name__)

#------------------------------------------------------------------------
#
# Constants
#
#------------------------------------------------------------------------
GRAMPS_VERSION = "gramps52"  # Fallback used only if no make<NN>.py is found

# This tool only supports Gramps 5.2+, since that's when the addon
# listing format switched from a legacy line-based addons-<lang>.txt to
# proper addons-<lang>.json. Versions below this are never offered by
# "Update Scripts…" or the "Gramps Versions" checkboxes, even if an
# old make<NN>.py happens to already exist on disk from a prior run.
MIN_SUPPORTED_VERSION_DIGITS = 52

# Recognises bundled build engines like make52.py (Gramps 5.2) or
# make60.py (Gramps 6.0). Deliberately does not match make_addon.py.
MAKE_SCRIPT_RE = re.compile(r'^make(\d{2,3})\.py$')

# Where this tool's bundled make<NN>.py copies come from upstream, used
# by on_update_make_scripts() to fetch/refresh them on demand. The file
# is always named "make.py" on each maintenance/gramps<NN> branch.
GITHUB_ADDONS_SOURCE_RAW = (
    "https://raw.githubusercontent.com/gramps-project/addons-source"
    "/maintenance/gramps{digits}/make.py"
)
GITHUB_ADDONS_SOURCE_BRANCHES_API = (
    "https://api.github.com/repos/gramps-project/addons-source/branches"
    "?per_page=100"
)

# Flathub app ID for the community-maintained GitHub Desktop Flatpak
# (https://github.com/flathub/io.github.shiftey.Desktop), used as a
# fallback by _find_github_desktop_linux() when no "github-desktop"
# command is found on PATH.
GITHUB_DESKTOP_LINUX_FLATPAK_ID = 'io.github.shiftey.Desktop'

# Reserved APS.ini section name (not a real named configuration) used to
# remember which configuration was active when the tool was last closed,
# so it can be restored automatically next time it's opened.
LAST_USED_CONFIG_SECTION = '__LastUsed__'

# Icon shown on the "save current configuration" button, and briefly
# swapped for a checkmark (see _animate_config_save_feedback()) as
# visual confirmation right after a save.
CONFIG_SAVE_ICON_NAME = 'gramps-preferences'

# Plugin type to number mapping (for JSON output)
PTYPE_TO_NUM = {
    'REPORT': 0,
    'QUICKREPORT': 1,
    'TOOL': 2,
    'IMPORT': 3,
    'EXPORT': 4,
    'DOCGEN': 5,
    'GENERAL': 6,
    'MAPSERVICE': 7,
    'VIEW': 8,
    'RELCALC': 9,
    'GRAMPLET': 10,
    'SIDEBAR': 11,
    'PERSIST': 12,
    'RULE': 13,
    'CITE': 14,
}

# GTK themes normally pad a Gtk.Button/Gtk.LinkButton's hit area out
# beyond its label glyphs. Left alone, that padding is what makes the
# space between a checkbox and a neighbouring hotlink (see
# rebuild_addon_list()) still register as part of the hotlink, making
# the checkbox fussy to click accurately. This CSS class, applied via
# _tighten_hotlink_hit_area(), zeroes that padding so a plain spacer
# widget (see _new_dead_space()) placed next to the hotlink is
# genuinely dead space rather than being swallowed by the link's own
# oversized hit area.
HOTLINK_CSS = b"""
.aps-tight-hotlink {
    padding: 0px;
    margin: 0px;
    border-width: 0px;
}
"""

# Cross-fades media/icons/github-desktop-dev.svg in over
# media/icons/github-desktop-prod.svg on hover/press, for the GitHub
# Desktop icon button built by _build_github_desktop_icon_button().
# The two icons are stacked in a Gtk.Overlay; the top (dev) image
# starts fully transparent and fades to opaque on :hover/:active using
# a plain CSS opacity transition -- opacity is one of the properties
# GTK's own CSS engine animates, so this needs no hand-rolled timer.
GITHUB_DESKTOP_BUTTON_CSS = b"""
.aps-github-hover-icon {
    opacity: 0;
    transition: opacity 500ms ease-in-out;
}
button.aps-github-desktop-btn:hover .aps-github-hover-icon,
button.aps-github-desktop-btn:active .aps-github-hover-icon {
    opacity: 1;
}
"""

#------------------------------------------------------------------------
#
# Helper functions
#
#------------------------------------------------------------------------

def _new_dead_space(width: int = 8) -> Gtk.Widget:
    """
    Return a fixed-width, non-interactive spacer widget, for use
    between a checkbox/icon-button and a neighbouring Gtk.LinkButton
    (see rebuild_addon_list() and the "Output location:" row) so the
    visual gap between them is genuinely un-clickable rather than
    being swallowed by either widget's own themed hit area. Pair with
    :func:`_tighten_hotlink_hit_area` on the neighbouring hotlink for
    this to be reliable across GTK themes.

    :param width: spacer width in pixels.
    :returns: a plain, childless Gtk.Box sized to ``width``.
    """
    spacer = Gtk.Box()
    spacer.set_size_request(width, -1)
    return spacer


def _tighten_hotlink_hit_area(link_button: Gtk.LinkButton) -> None:
    """
    Shrink ``link_button``'s clickable hit area down to just its
    label, by zeroing the padding/margin/border GTK's theme normally
    adds around a button (see :data:`HOTLINK_CSS`). Used alongside
    :func:`_new_dead_space` so a spacer placed next to a hotlink is
    genuinely dead space instead of still activating the link.

    :param link_button: the Gtk.LinkButton to tighten.
    """
    provider = Gtk.CssProvider()
    try:
        provider.load_from_data(HOTLINK_CSS)
    except GLib.Error:
        return
    style_context = link_button.get_style_context()
    style_context.add_class('aps-tight-hotlink')
    style_context.add_provider(provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)


def _load_scaled_svg_pixbuf(svg_path: str, size: int = 32) -> GdkPixbuf.Pixbuf | None:
    """
    Load an SVG file scaled to a square ``size`` x ``size`` pixbuf,
    for crisp rendering of a small toolbar-style icon regardless of
    the SVG's own native size.

    :param svg_path: path to the ``.svg`` file.
    :param size: target width and height, in pixels.
    :returns: a GdkPixbuf.Pixbuf, or ``None`` if the file is missing,
        unreadable, or not a valid image.
    """
    try:
        return GdkPixbuf.Pixbuf.new_from_file_at_scale(svg_path, size, size, True)
    except GLib.Error:
        return None


# Cache for _get_make_addon_module(): make_addon.py never changes
# mid-session (only the upstream make<NN>.py copies it delegates to
# can be refreshed, via "Update make.py Scripts", and those are still
# run as a subprocess rather than imported -- see run_make_command()),
# so it is safe, and much cheaper, to import it once per process.
_MAKE_ADDON_MODULE = None


def _get_make_addon_module() -> types.ModuleType | None:
    """
    Import make_addon.py (bundled alongside this tool) as a regular
    Python module and cache it for the life of this process, so its
    packaging functions can be called directly in-process instead of
    launched as a subprocess.

    Calling the packaging engine in-process removes the need to
    locate a standalone Python interpreter to shell out to. That
    matters because, under a frozen (cx_Freeze) Windows build,
    ``sys.executable`` is the Gramps application executable itself
    rather than a usable interpreter -- launching it as a subprocess
    used to start a second instance of Gramps, which Gramps' own
    single-instance guard immediately terminated with a
    "Gramps is already running!" dialog, all while reporting a clean
    exit code that made the caller believe packaging had succeeded.

    :returns: The imported ``make_addon`` module, or ``None`` if
        ``make_addon.py`` could not be found alongside this file.
    :rtype: types.ModuleType | None
    """
    global _MAKE_ADDON_MODULE
    if _MAKE_ADDON_MODULE is not None:
        return _MAKE_ADDON_MODULE

    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    module_path = os.path.join(scripts_dir, 'make_addon.py')
    if not os.path.exists(module_path):
        return None

    spec = importlib.util.spec_from_file_location(
        'gramps_addonpackship_make_addon', module_path)
    if spec is None or spec.loader is None:
        return None

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _MAKE_ADDON_MODULE = module
    return module


def _get_logs_dir():
    """
    Return this plugin's session-log directory: <this file's own
    directory>/logs -- the same path make_addon.py's
    _log_session_command() writes to. Not guaranteed to exist yet;
    callers that need it to (e.g. before opening it in a file
    manager) should create it first.

    :returns: Absolute path to the logs/ directory.
    """
    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(scripts_dir, 'logs')



#------------------------------------------------------------------------
#
# AddonPackShip Tool
#
#------------------------------------------------------------------------
class AddonPackShip(tool.Tool, ManagedWindow):
    """
    GUI Tool for packaging Gramps addons with checkbox selection
    """

    def __init__(self, dbstate, user, options_class, name, callback=None):
        """
        Initialize the Addon Pack and Ship tool
        """
        tool.Tool.__init__(self, dbstate, options_class, name)
        ManagedWindow.__init__(self, user.uistate, [], self)

        self.user = user
        self.addon_info = {}  # Maps addon_dir_name to metadata
        self.checkboxes = {}       # plugin_id → CheckButton
        self.plugin_to_dir = {}    # plugin_id → addon_dir_name
        self.all_selections = {}   # plugin_id → bool (persists across filter changes)
        self._gang_in_progress = False  # re-entrancy guard for gang-select
        self.metadata_cache = {}   # Cache metadata to avoid re-reading files
        self.version_checkboxes = {}   # version code -> Gtk.CheckButton
        self.pending_version_bumps = set()  # plugin ids flagged to bump
        self.version_bump_widgets = {}      # plugin id -> widget info dict
        self._listing_filter_names = None   # addon names to show, or None

        # One session ID per tool window, used to group every
        # make_addon.py/make<NN>.py command run during this session
        # into a single logs/<session_id>.log teaching transcript,
        # stored right next to make_addon.py itself (this plugin's
        # own install folder) so it's always in one fixed, easy-to-
        # find place (see run_make_command()) -- so a developer can
        # see, and directly reuse, the equivalent CLI commands for
        # everything the GUI just did.
        self.session_id = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')

        # Scan for installed addons
        self.scan_installed_addons()

        # Detect which Gramps versions can be targeted (which make<NN>.py
        # scripts are bundled). Listing languages are no longer a separate
        # setting here -- delegated listing runs automatically pick up
        # every language the addon itself has a po/<lang>-local.po for.
        self.available_versions = self.detect_available_versions()

        if not self.addon_info:
            ErrorDialog(
                _("No Addons Found"),
                _("No third-party addons found. Install some addons first."),
                parent=user.uistate.window
            )
            return

        # Build the GUI
        self.build_interface()
        self.show()

    def scan_installed_addons(self):
        """
        Scan for installed addons using GuiPluginManager + PluginRegister.

        Addon directory resolution
        ──────────────────────────
        Gramps provides USER_PLUGINS (e.g. ~/.gramps/gramps52/plugins) as the
        authoritative root for user-installed addons.  Every user plugin has:
            pdata.fpath  — directory containing the .py file
            pdata.fname  — the .py filename

        Resolution:
          rel  = os.path.relpath(fpath, USER_PLUGINS)
          addon_dir_name = rel.split(os.sep)[0]

        This works for all layouts:
          CardView/src/card_view_person.py  →  rel='CardView/src'  →  'CardView'
          SomeAddon.py (flat)               →  rel='.'             →  fname stem

        Previous approaches using '/plugins/' string-splitting or multiple
        candidate roots all had edge cases that lost ~18 directories.
        Using USER_PLUGINS alone is unambiguous.

        CLI diagnostics
        ───────────────
        Set APS_DEBUG=1 to write a full trace to ~/aps_debug.log.
        The log is always overwritten on each scan.
        """
        from gramps.gen.const import USER_PLUGINS

        debug_path = os.path.expanduser('~/aps_debug.log')
        debug      = os.environ.get('APS_DEBUG', '').strip() not in ('', '0')
        _log       = open(debug_path, 'w', encoding='utf-8') if debug else None

        def _dbg(*args):
            if _log:
                print(*args, file=_log, flush=True)

        def _close_log():
            if _log:
                _log.close()

        up_norm = os.path.normpath(USER_PLUGINS)
        _dbg(f'USER_PLUGINS = {up_norm}')

        pgr  = PluginRegister.get_instance()
        pmgr = GuiPluginManager.get_instance()
        addon_dirs = {}

        def _register_pdata(pdata, ptype_label, source=''):
            fpath = getattr(pdata, 'fpath', None)
            fname = getattr(pdata, 'fname', None)
            pid   = getattr(pdata, 'id',    '?')

            if not fpath:
                _dbg(f'SKIP no-fpath  id={pid}  src={source}')
                return

            fpath_norm = os.path.normpath(fpath)
            fpath_fwd  = fpath_norm.replace('\\', '/')

            # ── Exclude built-in Gramps plugins ──────────────────────────
            if 'gramps/plugins' in fpath_fwd:
                _dbg(f'BUILTIN  id={pid}  fpath={fpath}')
                return

            # ── Determine addon_dir_name using USER_PLUGINS as root ───────
            if (fpath_norm == up_norm
                    or fpath_norm.startswith(up_norm + os.sep)):
                # Standard user plugin location
                rel = os.path.relpath(fpath_norm, up_norm)
                if rel == '.':
                    # fpath IS the plugins root → flat addon
                    addon_dir_name = os.path.splitext(fname or '')[0]
                    addon_path     = up_norm
                else:
                    addon_dir_name = rel.split(os.sep)[0]
                    addon_path     = os.path.join(up_norm, addon_dir_name)
            else:
                # Non-standard install: fall back to /plugins/ string heuristic
                if '/plugins/' in fpath_fwd:
                    after = fpath_fwd.rsplit('/plugins/', 1)[1]
                    addon_dir_name = after.split('/')[0].strip()
                    if not addon_dir_name:
                        addon_dir_name = os.path.splitext(fname or '')[0]
                    base = fpath_fwd.rsplit('/plugins/', 1)[0]
                    addon_path = (base + '/plugins/' + addon_dir_name
                                  ).replace('/', os.sep)
                    _dbg(f'NONSTANDARD  id={pid}  fpath={fpath}')
                else:
                    _dbg(f'SKIP not-under-USER_PLUGINS  id={pid}  fpath={fpath}')
                    return

            if not addon_dir_name:
                _dbg(f'SKIP no-dir-name  id={pid}  fpath={fpath}')
                return

            _dbg(f'ACCEPT  id={pid}  dir={addon_dir_name}'
                 f'  path={addon_path}  type={ptype_label}  src={source}')

            if addon_dir_name not in addon_dirs:
                addon_dirs[addon_dir_name] = {
                    'path':    addon_path,
                    'has_gpr': False,
                    'plugins': [],
                    'types':   set(),
                }
            if pdata not in addon_dirs[addon_dir_name]['plugins']:
                addon_dirs[addon_dir_name]['plugins'].append(pdata)
            addon_dirs[addon_dir_name]['types'].add(ptype_label)

        # ── Pass 1: GuiPluginManager success list ─────────────────────────
        try:
            success = pmgr.get_success_list()
            _dbg(f'Pass1 success_list: {len(success)} entries')
            for entry in success:
                try:
                    pdata   = entry[2]
                    typestr = PTYPE_STR.get(pdata.ptype, str(pdata.ptype))
                    _register_pdata(pdata, typestr, 'success_list')
                except Exception as e:
                    _dbg(f'Pass1 entry error: {e}')
        except Exception as e:
            _dbg(f'Pass1 failed: {e}')

        # ── Pass 2: PluginRegister type scan ──────────────────────────────
        for ptype, typestr in PTYPE_STR.items():
            try:
                for pdata in pgr.type_plugins(ptype):
                    _register_pdata(pdata, typestr,
                                    f'pgr.type_plugins({typestr})')
            except Exception as e:
                _dbg(f'Pass2 type={typestr} error: {e}')

        # ── Pass 3: ViewManager pages (belt-and-suspenders for VIEW) ──────
        # Gramps 5.2 vm.pages structure varies: it may be a flat list of
        # view objects OR a list-of-lists.  Handle both.
        try:
            vm = self.user.uistate.viewmanager
            raw_pages = vm.pages
            # Normalise to a flat iterable of view objects
            views_flat = []
            for item in raw_pages:
                try:
                    # Try iterating — works if item is a list/tuple of views
                    for v in item:
                        views_flat.append(v)
                except TypeError:
                    # item itself is a view object (flat list case)
                    views_flat.append(item)
            for view in views_flat:
                pdata = None
                for attr in ('_viewinfo', 'view_info', '_view_info',
                             'viewinfo'):
                    pdata = getattr(view, attr, None)
                    if pdata is not None:
                        break
                if pdata is None:
                    continue
                _register_pdata(pdata, 'VIEW', 'viewmanager')
        except Exception as e:
            _dbg(f'Pass3 failed: {e}')

        # ── gpr detection ─────────────────────────────────────────────────
        # Search order for each addon directory:
        #  1. addon_path/AddonDirName.gpr.py   (exact case)
        #  2. addon_path/adondirname.gpr.py    (lowercase)
        #  3. any *.gpr.py directly in addon_path   (e.g. card_view.gpr.py)
        #  4. any *.gpr.py in the fpath of each registered plugin
        #     — this catches addons like CardView where source files AND
        #       the .gpr.py are in a subdirectory (CardView/src/card_view.gpr.py)
        for addon_dir_name, info in addon_dirs.items():
            addon_path = info['path']

            # 1. Exact-case top-level
            if os.path.exists(os.path.join(addon_path,
                                           f'{addon_dir_name}.gpr.py')):
                info['has_gpr'] = True
                continue
            # 2. Lowercase top-level
            if os.path.exists(os.path.join(addon_path,
                                           f'{addon_dir_name.lower()}.gpr.py')):
                info['has_gpr'] = True
                continue
            # 3. Any .gpr.py in the top-level directory
            try:
                if any(f.endswith('.gpr.py')
                       for f in os.listdir(addon_path)):
                    info['has_gpr'] = True
                    continue
            except Exception:
                pass
            # 4. Any .gpr.py in the fpath of each registered plugin
            #    (handles layouts like CardView/src/card_view.gpr.py)
            found_in_subdir = False
            for pdata in info.get('plugins', []):
                fpth = getattr(pdata, 'fpath', None)
                if not fpth or os.path.normpath(fpth) == os.path.normpath(addon_path):
                    continue   # already checked this dir above
                try:
                    if any(f.endswith('.gpr.py')
                           for f in os.listdir(fpth)):
                        info['has_gpr'] = True
                        _dbg(f'GPR_IN_SUBDIR  dir={addon_dir_name}  subdir={fpth}')
                        found_in_subdir = True
                        break
                except Exception:
                    pass
            if found_in_subdir:
                continue

            _dbg(f'NO_GPR  dir={addon_dir_name}  path={addon_path}'
                 f'  fpaths_checked={list(set(getattr(p,"fpath","?") for p in info.get("plugins",[])))}')

        self.addon_info = {
            name: info for name, info in addon_dirs.items()
            if info['has_gpr']
        }
        _dbg(f'FINAL: {len(addon_dirs)} dirs, '
             f'{len(self.addon_info)} with gpr, '
             f'{sum(len(i["plugins"]) for i in self.addon_info.values())} plugins')
        _close_log()
        if debug:
            print(f'APS: debug log written to {debug_path}', flush=True)

    @staticmethod
    def _version_label(digits):
        """
        Format version digits like '52' as a human label like '5.2'.

        :param digits: Version digit string, e.g. '52' or '60'.
        :returns: formatted label.
        """
        return f"{digits[0]}.{digits[1:]}" if len(digits) >= 2 else digits

    @staticmethod
    def _is_supported_version(digits):
        """
        Return True if `digits` (e.g. '52', '60') is at or above
        MIN_SUPPORTED_VERSION_DIGITS -- i.e. Gramps 5.2+, the versions
        this tool generates JSON listings for.

        :param digits: Version digit string.
        :returns: bool.
        """
        try:
            return int(digits) >= MIN_SUPPORTED_VERSION_DIGITS
        except ValueError:
            return False

    @staticmethod
    def _running_gramps_version_code():
        """
        Return the version code (e.g. 'gramps52') for the Gramps major
        version currently running this tool, in the same
        'gramps<digits>' format used for :attr:`available_versions`
        codes and the "Gramps Versions" checkboxes.

        Derived from :data:`gramps.version.major_version` (e.g.
        '5.2'), the same value Gramps' own .gpr.py registration files
        use for `gramps_target_version`, rather than any bundled
        make<NN>.py script -- this is about which Gramps release is
        actually running the tool right now, independent of which
        packaging scripts happen to be present.

        :returns: version code string, e.g. 'gramps52'.
        """
        return f"gramps{major_version.replace('.', '')}"

    def detect_available_versions(self):
        """
        Detect which Gramps versions can be targeted for packaging by
        scanning this tool's own directory for bundled make<NN>.py build
        engines (e.g. make52.py -> Gramps 5.2, make60.py -> Gramps 6.0).
        Only versions with a matching script are offered, since the
        presence of that script is what documents which Gramps release
        packaging support has been prepared for. Versions below
        MIN_SUPPORTED_VERSION_DIGITS are skipped even if their script
        is present on disk (e.g. from a prior "Update Scripts…" run),
        since this tool only generates JSON listings.

        :returns: list of dicts with 'code' (e.g. 'gramps52'), 'label'
            (e.g. '5.2') and 'script' (e.g. 'make52.py'), sorted by code.
        """
        builder_dir = os.path.dirname(os.path.abspath(__file__))
        versions = []
        try:
            entries = os.listdir(builder_dir)
        except OSError:
            entries = []
        for fname in sorted(entries):
            match = MAKE_SCRIPT_RE.match(fname)
            if not match:
                continue
            digits = match.group(1)
            if not self._is_supported_version(digits):
                continue
            versions.append({
                'code': f'gramps{digits}',
                'label': self._version_label(digits),
                'script': fname,
            })
        return versions

    def get_selected_versions(self):
        """
        Return the Gramps version codes (e.g. ['gramps52']) currently
        checked in the "Gramps Versions" row. Falls back to whatever
        version was auto-detected (or the module default) when nothing
        is checked, so build/listing operations always have a target.

        :returns: list of version codes.
        """
        selected = [
            code for code, checkbox in self.version_checkboxes.items()
            if checkbox.get_active()
        ]
        if not selected:
            if self.available_versions:
                selected = [self.available_versions[0]['code']]
            else:
                selected = [GRAMPS_VERSION]
        return selected

    def _get_single_selected_version(self):
        """
        Return the one checked "Gramps Versions" code, if exactly one
        is checked -- otherwise None.

        Unlike :meth:`get_selected_versions`, this has no fallback to
        "the first available version" when nothing is checked: the
        addon-list context menu's listing actions need to know
        unambiguously whether the user has picked exactly one version,
        not have one guessed for them, since there's no single
        addons-en.json to act on when zero or several are checked.

        :returns: a single version code (e.g. 'gramps52'), or None.
        """
        selected = [
            code for code, checkbox in self.version_checkboxes.items()
            if checkbox.get_active()
        ]
        return selected[0] if len(selected) == 1 else None

    def _listing_json_path(self, version):
        """
        Return the path to the addons-en.json listing file for the
        given Gramps version, under the current Output Location.

        This is the file the addon list's right-click "Filter list to
        addons in this listing" and "Open addons-en.json for editing"
        actions both act on -- it may or may not exist yet.

        :param version: a Gramps version code, e.g. 'gramps52'.
        :returns: the addons-en.json path.
        """
        return os.path.join(
            self.get_output_parent_dir(), version, 'listings',
            'addons-en.json')

    def _config_ini_path(self):
        """
        Return the path to APS.ini, where named configurations are
        stored -- alongside this tool's own .py files, not in the
        addon being packaged.
        """
        return os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 'APS.ini')

    def _list_saved_configs(self):
        """
        Return the names of every real named configuration currently
        saved in APS.ini, sorted alphabetically. Excludes the reserved
        [__LastUsed__] bookkeeping section.
        """
        ini_path = self._config_ini_path()
        if not os.path.isfile(ini_path):
            return []
        parser = configparser.ConfigParser()
        try:
            parser.read(ini_path, encoding='utf-8')
        except configparser.Error:
            return []
        return sorted(
            name for name in parser.sections()
            if name != LAST_USED_CONFIG_SECTION)

    def _save_last_used_config_name(self):
        """
        Remember whichever name is currently in the "Configuration"
        combo's entry, in APS.ini's reserved [__LastUsed__] section,
        so it can be restored automatically next time this tool opens.
        """
        if not hasattr(self, 'config_combo'):
            return
        entry = self.config_combo.get_child()
        name = entry.get_text().strip() if entry else ''
        if not name:
            return

        ini_path = self._config_ini_path()
        parser = configparser.ConfigParser()
        if os.path.isfile(ini_path):
            try:
                parser.read(ini_path, encoding='utf-8')
            except configparser.Error:
                pass
        if not parser.has_section(LAST_USED_CONFIG_SECTION):
            parser.add_section(LAST_USED_CONFIG_SECTION)
        parser.set(LAST_USED_CONFIG_SECTION, 'name', name)
        try:
            with open(ini_path, 'w', encoding='utf-8') as fh:
                parser.write(fh)
        except OSError:
            pass  # remembering the last-used name is a convenience only

    def _get_last_used_config_name(self):
        """
        Return the configuration name remembered from the previous
        session (APS.ini's [__LastUsed__] section), or '' if none.
        """
        ini_path = self._config_ini_path()
        if not os.path.isfile(ini_path):
            return ''
        parser = configparser.ConfigParser()
        try:
            parser.read(ini_path, encoding='utf-8')
        except configparser.Error:
            return ''
        return parser.get(LAST_USED_CONFIG_SECTION, 'name', fallback='')

    def _refresh_config_combo(self, select=None):
        """
        Repopulate the "Configuration" combo's dropdown list from
        APS.ini, without disturbing whatever name is currently typed
        into its entry (unless `select` is given).
        """
        if not hasattr(self, 'config_combo'):
            return
        entry = self.config_combo.get_child()
        current_text = entry.get_text() if entry else None

        self.config_combo.remove_all()
        for name in self._list_saved_configs():
            self.config_combo.append_text(name)

        if entry is not None:
            entry.set_text(select if select is not None
                            else (current_text or ''))

    def _collect_config_state(self):
        """
        Gather the current state of every saveable control -- build
        mode, Gramps version checkboxes, output location, filters,
        which addons/plugins are selected, and the Options tab's
        Multilingual and version-coverage-override checkboxes -- into
        a plain dict, ready to write to one section of APS.ini.

        :returns: dict of state.
        """
        # Flush current visible checkbox states into self.all_selections
        # first, the same way rebuild_addon_list() does at its own start.
        for pid, checkbox in self.checkboxes.items():
            self.all_selections[pid] = checkbox.get_active()

        # Only plugin ids from the current scan are meaningful to save;
        # anything else in self.all_selections is left over from a
        # previous scan (e.g. an addon since removed) and would just
        # be dead weight in APS.ini.
        current_selections = {
            pid: checked for pid, checked in self.all_selections.items()
            if pid in self.plugin_to_dir
        }

        return {
            'build_mode': self.get_build_mode(),
            'versions': {code: checkbox.get_active()
                         for code, checkbox in self.version_checkboxes.items()},
            'output_dir': self.get_output_parent_dir(),
            'filter_text': (self.author_filter_entry.get_text()
                            if hasattr(self, 'author_filter_entry') else ''),
            'type_filter': (self.type_filter_combo.get_active_text()
                            if hasattr(self, 'type_filter_combo') else ''),
            'selected_plugins': current_selections,
            'multilingual': (self.multilingual_check.get_active()
                             if hasattr(self, 'multilingual_check') else False),
            'force_uncovered': (self.force_uncovered_check.get_active()
                                if hasattr(self, 'force_uncovered_check')
                                else False),
        }

    def save_named_config(self, name):
        """
        Save the current UI state under `name` in APS.ini, overwriting
        that section if a configuration with this name already exists.

        :param name: Configuration name (from the combo's entry).
        """
        name = name.strip()
        if not name or name == LAST_USED_CONFIG_SECTION:
            return

        ini_path = self._config_ini_path()
        parser = configparser.ConfigParser()
        if os.path.isfile(ini_path):
            try:
                parser.read(ini_path, encoding='utf-8')
            except configparser.Error:
                pass

        state = self._collect_config_state()
        if not parser.has_section(name):
            parser.add_section(name)
        parser.set(name, 'build_mode', state['build_mode'])
        parser.set(name, 'versions', json.dumps(state['versions']))
        parser.set(name, 'output_dir', state['output_dir'])
        parser.set(name, 'filter_text', state['filter_text'])
        parser.set(name, 'type_filter', state['type_filter'] or '')
        # Only the checked plugin IDs are worth storing -- unchecked is
        # already the default, so a full True/False dict just duplicates
        # every known plugin ID for no benefit.
        checked_plugins = sorted(
            pid for pid, checked in state['selected_plugins'].items()
            if checked)
        parser.set(name, 'selected_plugins', json.dumps(checked_plugins))
        parser.set(name, 'multilingual', str(state['multilingual']))
        parser.set(name, 'force_uncovered', str(state['force_uncovered']))

        try:
            with open(ini_path, 'w', encoding='utf-8') as fh:
                parser.write(fh)
        except OSError as exc:
            ErrorDialog(
                _("Could Not Save Configuration"), str(exc), parent=self.window)
            return

        self._refresh_config_combo(select=name)

    def load_named_config(self, name):
        """
        Apply the saved UI state for `name` from APS.ini to every
        control it covers (build mode, version checkboxes, output
        location, filters, addon/plugin selection, and the Options
        tab's Multilingual and version-coverage-override checkboxes).

        :param name: Configuration name to load.
        """
        ini_path = self._config_ini_path()
        if not os.path.isfile(ini_path):
            return
        parser = configparser.ConfigParser()
        try:
            parser.read(ini_path, encoding='utf-8')
        except configparser.Error:
            return
        if not parser.has_section(name):
            return

        if parser.get(name, 'build_mode', fallback='beta') == 'release':
            self.radio_release.set_active(True)
        else:
            self.radio_beta.set_active(True)

        try:
            versions = json.loads(parser.get(name, 'versions', fallback='{}'))
        except ValueError:
            versions = {}
        for code, checkbox in self.version_checkboxes.items():
            checkbox.set_active(bool(versions.get(code, checkbox.get_active())))

        output_dir = parser.get(name, 'output_dir', fallback='')
        if output_dir and os.path.isdir(output_dir):
            self.output_dir_chooser.set_filename(output_dir)

        if hasattr(self, 'author_filter_entry'):
            self.author_filter_entry.set_text(
                parser.get(name, 'filter_text', fallback=''))

        if hasattr(self, 'type_filter_combo'):
            wanted_type = parser.get(name, 'type_filter', fallback='')
            model = self.type_filter_combo.get_model()
            matched = False
            for idx, row in enumerate(model):
                if row[0] == wanted_type:
                    self.type_filter_combo.set_active(idx)
                    matched = True
                    break
            if not matched:
                self.type_filter_combo.set_active(0)

        try:
            checked_plugins = json.loads(
                parser.get(name, 'selected_plugins', fallback='[]'))
        except ValueError:
            checked_plugins = []
        self.all_selections = {pid: True for pid in checked_plugins}

        if hasattr(self, 'multilingual_check'):
            self.multilingual_check.set_active(
                parser.getboolean(name, 'multilingual', fallback=False))

        if hasattr(self, 'force_uncovered_check'):
            self.force_uncovered_check.set_active(
                parser.getboolean(name, 'force_uncovered', fallback=False))
        # rebuild_addon_list() normally flushes live checkboxes into
        # self.all_selections at its own start, which would immediately
        # overwrite what was just loaded -- clear it first so that
        # flush has nothing to clobber.
        self.checkboxes = {}
        self.rebuild_addon_list()

    def on_config_combo_changed(self, combo):
        """
        Handle the "Configuration" combo: loading only triggers when an
        existing entry is picked from the dropdown list (get_active()
        returns its index, >= 0) -- never while the user is still
        typing a name into the entry, which leaves get_active() at -1.

        The actual load is deferred to a GLib idle callback: running it
        synchronously here, while this combo's own dropdown popup is
        still closing, can trigger a GDK "Tried to map a popup with a
        non-top most parent" warning as soon as load_named_config()
        touches another popup-capable widget (the folder chooser) or
        rebuilds the addon list. Deferring runs it just after the
        dropdown has fully closed.
        """
        index = combo.get_active()
        if index < 0:
            return
        name = combo.get_active_text()
        if name:
            GLib.idle_add(self._load_named_config_idle, name)

    def _load_named_config_idle(self, name):
        """GLib.idle_add callback wrapper for load_named_config()."""
        self.load_named_config(name)
        return False

    def _seed_default_config_idle(self):
        """
        GLib.idle_add callback: save the current settings as a
        "default" named configuration -- see the call site in
        build_interface() for why this only runs on a genuinely fresh
        install, and why it's deferred this way.

        Re-checks for an existing "default" configuration at call
        time rather than trusting the check made when this was
        scheduled, in case one was created in the interim (e.g. the
        user typed "default" into the Configuration box and saved it
        manually before this idle callback got a turn to run).

        :returns: False, so GLib.idle_add doesn't repeat this call.
        """
        if 'default' not in self._list_saved_configs():
            self.save_named_config('default')
        return False

    def on_config_combo_activate(self, entry):
        """
        Handle pressing Enter in the "Configuration" name entry: save
        the current settings under whatever name is typed there,
        overwriting a configuration of the same name if it exists.
        """
        name = entry.get_text().strip()
        if name:
            self.save_named_config(name)
            self._animate_config_save_feedback()

    def on_config_save_button_clicked(self, _button):
        """
        Handle clicking the "Configuration" save icon: save the current
        settings under whatever name is typed in the combo's entry,
        exactly like pressing Enter there.
        """
        entry = self.config_combo.get_child()
        if entry is None:
            return
        name = entry.get_text().strip()
        if name:
            self.save_named_config(name)
            self._animate_config_save_feedback()

    def _animate_config_save_feedback(self):
        """
        Briefly swap the "save configuration" icon to a checkmark, with
        a fade transition, then fade back to its normal icon -- visual
        confirmation that a save just happened. Total round trip is
        about 2 seconds.

        Uses Gtk.Widget.set_opacity() stepped via a handful of
        GLib.timeout_add() calls, since GTK3 has no simpler built-in
        way to cross-fade a Gtk.Image's content.
        """
        icon_widget = getattr(self, 'config_icon', None)
        if icon_widget is None:
            return

        theme = Gtk.IconTheme.get_default()
        confirm_icon_name = (
            'gtk-apply' if theme.has_icon('gtk-apply')
            else 'emblem-ok-symbolic')

        fade_step_ms = 25
        fade_steps = 6
        hold_ms = 1200

        def _fade(start, end, on_done):
            delta = (end - start) / fade_steps
            state = {'step': 0, 'value': start}

            def _tick():
                state['step'] += 1
                state['value'] += delta
                icon_widget.set_opacity(max(0.0, min(1.0, state['value'])))
                if state['step'] >= fade_steps:
                    if on_done:
                        on_done()
                    return False
                return True

            GLib.timeout_add(fade_step_ms, _tick)

        def _show_confirm():
            icon_widget.set_from_icon_name(
                confirm_icon_name, Gtk.IconSize.BUTTON)
            _fade(0.0, 1.0, _hold_then_fade_back)

        def _hold_then_fade_back():
            GLib.timeout_add(hold_ms, _fade_out_confirm)

        def _fade_out_confirm():
            _fade(1.0, 0.0, _restore_original)
            return False

        def _restore_original():
            icon_widget.set_from_icon_name(
                CONFIG_SAVE_ICON_NAME, Gtk.IconSize.BUTTON)
            _fade(0.0, 1.0, None)

        # Fade the current icon out first, swap to the checkmark, fade
        # it in, hold briefly, then reverse the whole sequence.
        _fade(1.0, 0.0, _show_confirm)

    def get_output_parent_dir(self):
        """
        Return the parent folder under which this run's <version>/
        output folders (download/, listings/) should be created:
        whatever is chosen in the "Output Location" folder picker, or
        this tool's own folder if nothing has been chosen yet.

        This is independent of where the tool itself (and its
        make<NN>.py scripts) are installed -- see run_make_command(),
        which resolves those separately.

        :returns: absolute directory path.
        """
        chooser = getattr(self, 'output_dir_chooser', None)
        if chooser is not None:
            chosen = chooser.get_filename()
            if chosen:
                return chosen
        return os.path.dirname(os.path.abspath(__file__))

    def cb_open_output_folder(self, linkbutton: Gtk.LinkButton) -> bool:
        """
        Open the current "Output location:" folder in the OS file
        browser.

        Connected to the "Output location:" Gtk.LinkButton's
        "activate-link" signal (see :meth:`build_interface`). The
        folder is re-resolved fresh on every click, via
        :meth:`get_output_parent_dir`, so this always reflects
        whatever is currently chosen rather than whatever was chosen
        when the window was built.

        :param linkbutton: the Gtk.LinkButton that was clicked.
        :returns: ``True``, to stop GTK's default handler (which
                  would otherwise also try to open an empty URI in a
                  web browser).
        """
        folder = self.get_output_parent_dir()
        if folder and os.path.isdir(folder):
            open_file_with_default_application(folder, self.user.uistate)
        else:
            ErrorDialog(
                _("Folder Not Found"),
                _("Output location folder does not exist yet:\n{}")
                .format(folder),
                parent=self.window)
        return True

    def cb_open_addon_folder(
        self, linkbutton: Gtk.LinkButton, folder_path: str
    ) -> bool:
        """
        Open an addon's own folder in the OS file browser.

        Connected to each plugin-name Gtk.LinkButton's
        "activate-link" signal in the addon list (see
        :meth:`build_interface`'s addon list construction). Used
        purely for the built-in link click/hover styling -- there is
        no real URI to follow, so this always returns ``True`` to
        stop GTK's default handler from also trying to open one in a
        web browser.

        :param linkbutton: the Gtk.LinkButton that was clicked.
        :param folder_path: absolute path of the addon's folder.
        :returns: ``True``, to stop the default handler.
        """
        if folder_path and os.path.isdir(folder_path):
            open_file_with_default_application(
                folder_path, self.user.uistate)
        else:
            ErrorDialog(
                _("Folder Not Found"),
                _("Addon folder does not exist:\n{}").format(folder_path),
                parent=self.window)
        return True

    def on_output_suggestion_changed(self, combo):
        """
        Apply the folder selected in the "Suggested" combo (detected
        local Git repo clones) to the "Output Location" folder chooser.
        The combo's first entry is a non-selectable placeholder.

        Deferred via GLib.idle_add for the same reason as
        on_config_combo_changed() -- avoids a GDK "non-top most
        parent" warning from touching the folder chooser while this
        combo's own dropdown popup is still closing.
        """
        index = combo.get_active()
        if index <= 0:
            return
        path = combo.get_active_text()
        if path and os.path.isdir(path):
            GLib.idle_add(self._apply_output_suggestion_idle, path)

    def _apply_output_suggestion_idle(self, path):
        """GLib.idle_add callback wrapper for applying a suggested folder."""
        self.output_dir_chooser.set_filename(path)
        return False

    def detect_local_git_repo_roots(self, max_results=25):
        """
        Suggest destination folders by scanning common GitHub-Desktop-
        style clone locations for existing local Git repositories (any
        directory containing a .git subdirectory).

        This deliberately does NOT read GitHub Desktop's own internal
        database. That data lives in an undocumented, version-fragile
        Chromium "Local Storage" LevelDB store under GitHub Desktop's
        own userData folder (not IndexedDB, despite what some AI
        assistants suggest) -- it uses Chromium's plain key/value
        Local Storage log format, locks while the app is running, and
        has no supported read API, so parsing it is liable to break on
        any GitHub Desktop update. Scanning the filesystem for real
        .git directories under GitHub Desktop's own default clone
        locations is slightly less exhaustive (it can't see a repo
        cloned somewhere unusual) but needs no extra dependencies and
        can't be broken by an app update.

        :param max_results: Cap on how many repo roots to return.
        :returns: sorted list of absolute directory paths.
        """
        home = os.path.expanduser('~')
        # GitHub Desktop's own default clone locations, plus a few other
        # common developer folders, across Windows/macOS/Linux.
        candidate_bases = [
            os.path.join(home, 'Documents', 'GitHub'),  # GH Desktop default
            os.path.join(home, 'GitHub'),
            os.path.join(home, 'Documents', 'Source', 'Repos'),
            os.path.join(home, 'source', 'repos'),
            os.path.join(home, 'Projects'),
            os.path.join(home, 'repos'),
            os.path.join(home, 'dev'),
        ]

        found = set()
        for base in candidate_bases:
            if not os.path.isdir(base):
                continue
            try:
                for entry in os.scandir(base):
                    if entry.is_dir() and os.path.isdir(
                            os.path.join(entry.path, '.git')):
                        found.add(entry.path)
                        if len(found) >= max_results:
                            break
            except OSError:
                continue
            if len(found) >= max_results:
                break
        return sorted(found)[:max_results]

    # ------------------------------------------------------------
    # GitHub Desktop integration -- intentionally read-only and
    # narrow in scope. This tool asks GitHub Desktop for exactly
    # four things: whether it's installed, whether it's running,
    # the names of locally-detected repositories, and each one's
    # folder path. It does not inspect repository contents, decide
    # what counts as "changed", or drive GitHub Desktop's UI (no
    # tab-switching, no opening a specific repository) -- all of
    # that is left entirely to GitHub Desktop itself. The one
    # exception is :meth:`launch_or_focus_github_desktop`, which
    # only starts/raises the app with no arguments, same as
    # clicking its dock/taskbar icon.
    #
    # GitHub Desktop's own "repository list" and "active
    # repository" (see
    # https://docs.github.com/en/desktop/overview/github-desktop-keyboard-shortcuts,
    # Ctrl+T/Cmd+T) live in an undocumented, version-fragile
    # Dexie/IndexedDB-backed database under its own userData folder,
    # with no supported read API -- parsing it is liable to break on
    # any GitHub Desktop update (and, for "active repository", there
    # is currently no reliable alternative either; see
    # :meth:`get_repository_list`'s docstring). So
    # :meth:`get_repository_list` instead reports the same
    # filesystem-detected local Git clones as
    # :meth:`detect_local_git_repo_roots` -- the closest available
    # proxy to GitHub Desktop's own list, without touching its
    # internals.
    #
    # A feature request asking the GitHub Desktop project for a
    # supported, read-only way to query the repository list, the
    # active repository, and each one's local path -- plus a way to
    # launch/focus a specific repository's Changes view -- has been
    # filed upstream: "CLI/API access to known repositories list +
    # launch to Changes view" --
    # https://github.com/desktop/desktop/issues/22779. If/when that
    # lands, get_repository_list() and the "active repository" gap
    # noted above should be revisited to use it instead of the
    # filesystem heuristic.
    #
    # On Linux, where GitHub Desktop is not an officially supported
    # platform, install/running detection looks for the
    # community-maintained build from
    # https://github.com/shiftkey/desktop (packaged as
    # "github-desktop") and its Flathub Flatpak,
    # "io.github.shiftey.Desktop".
    #
    # Generated-by: Claude (Anthropic), model claude-sonnet-4-6, via
    # claude.ai, in response to a request to detect a GitHub Desktop
    # install/running state and report locally-detected repository
    # names and folder paths, without any analysis of repository
    # contents or changes. See
    # https://www.gramps-project.org/wiki/index.php/Howto:_Contribute_to_Gramps#AI_generated_code
    # ------------------------------------------------------------

    def get_repository_list(self) -> list[dict[str, str]]:
        """
        Return the local Git repository folders this tool can detect
        (see :meth:`detect_local_git_repo_roots`), each paired with
        its folder name, as a stand-in for GitHub Desktop's own
        "repository list" (Ctrl+T/Cmd+T).

        This is a filesystem-based proxy, not GitHub Desktop's actual
        list -- there is no supported way to read that without
        parsing its internal database (see this class's "GitHub
        Desktop integration" banner comment above). For the same
        reason, there is currently no method here for "which
        repository is active": GitHub Desktop doesn't expose that
        outside its own UI either. See
        https://github.com/desktop/desktop/issues/22779 for the
        upstream feature request asking for a supported way to query
        both of these.

        :returns: a list of ``{'name': ..., 'path': ...}`` dicts, one
            per detected repository, in the same order as
            :meth:`detect_local_git_repo_roots`.
        """
        return [
            {
                'name': os.path.basename(repo_root.rstrip(os.sep)) or repo_root,
                'path': repo_root,
            }
            for repo_root in self.detect_local_git_repo_roots()
        ]

    @staticmethod
    def find_github_desktop_executable() -> str | None:
        """
        Locate a GitHub Desktop installation on this machine, without
        relying on any GitHub-Desktop-internal database.

        :returns: something :meth:`launch_or_focus_github_desktop`
            knows how to start GitHub Desktop from -- a command name
            or path on Windows/Linux, an ``.app`` bundle path on
            macOS, or a ``"flatpak:<app-id>"`` marker for a Flatpak
            install -- or ``None`` if no installation was found.
        """
        if sys.platform.startswith('win'):
            return AddonPackShip._find_github_desktop_windows()
        if sys.platform == 'darwin':
            return AddonPackShip._find_github_desktop_macos()
        return AddonPackShip._find_github_desktop_linux()

    @staticmethod
    def _find_github_desktop_windows() -> str | None:
        """
        Locate GitHub Desktop on Windows: prefer the ``github``
        command-line helper if it's on PATH, then fall back to
        scanning the per-user install folder GitHub Desktop's
        installer uses (``%LOCALAPPDATA%\\GitHubDesktop\\app-<ver>``).

        :returns: a launchable path/command, or ``None`` if not found.
        """
        cli = (
            shutil.which('github')
            or shutil.which('github.cmd')
            or shutil.which('github.bat')
        )
        if cli:
            return cli
        local_app_data = os.environ.get('LOCALAPPDATA', '')
        base = os.path.join(local_app_data, 'GitHubDesktop')
        if local_app_data and os.path.isdir(base):
            matches = sorted(
                glob.glob(os.path.join(base, 'app-*', 'GitHubDesktop.exe'))
            )
            if matches:
                return matches[-1]  # highest "app-<version>" folder
        return None

    @staticmethod
    def _find_github_desktop_macos() -> str | None:
        """
        Locate GitHub Desktop on macOS: prefer the ``github``
        command-line helper (installed via GitHub Desktop's own
        "Install Command Line Tool" menu item) if it's on PATH,
        otherwise look for the ``.app`` bundle in the usual
        Applications folders.

        :returns: a launchable command/bundle path, or ``None`` if
            not found.
        """
        cli = shutil.which('github')
        if cli:
            return cli
        for base in (
            '/Applications',
            os.path.join(os.path.expanduser('~'), 'Applications'),
        ):
            bundle = os.path.join(base, 'GitHub Desktop.app')
            if os.path.isdir(bundle):
                return bundle
        return None

    @staticmethod
    def _find_github_desktop_linux() -> str | None:
        """
        Locate GitHub Desktop on Linux. GitHub Desktop is not an
        officially supported platform here, so this looks for the
        community-maintained build from
        https://github.com/shiftkey/desktop (packaged as the
        ``github-desktop`` command) and for its Flathub Flatpak,
        ``io.github.shiftey.Desktop``.

        :returns: a launchable command, or ``"flatpak:<app-id>"`` for
            a Flatpak install, or ``None`` if neither was found.
        """
        for command in ('github-desktop', 'GitHubDesktop'):
            found = shutil.which(command)
            if found:
                return found
        try:
            result = subprocess.run(
                ['flatpak', 'info', GITHUB_DESKTOP_LINUX_FLATPAK_ID],
                capture_output=True,
                check=False,
                timeout=5,
            )
            if result.returncode == 0:
                return 'flatpak:' + GITHUB_DESKTOP_LINUX_FLATPAK_ID
        except (OSError, subprocess.SubprocessError):
            pass
        return None

    @staticmethod
    def is_github_desktop_running() -> bool:
        """
        Best-effort check for whether a GitHub Desktop process is
        currently running, using each platform's own process-listing
        tool (``tasklist`` / ``pgrep``) rather than adding a
        third-party dependency such as ``psutil``.

        :returns: ``True`` if a matching process was found. ``False``
            otherwise, including when the check itself can't be
            performed (e.g. the platform tool isn't on PATH) -- which
            is indistinguishable from "not running" for our purposes.
        """
        try:
            if sys.platform.startswith('win'):
                result = subprocess.run(
                    ['tasklist', '/FI', 'IMAGENAME eq GitHubDesktop.exe'],
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=5,
                )
                return 'GitHubDesktop.exe' in result.stdout
            if sys.platform == 'darwin':
                result = subprocess.run(
                    ['pgrep', '-f', 'GitHub Desktop'],
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=5,
                )
                return bool(result.stdout.strip())
            result = subprocess.run(
                ['pgrep', '-f', 'github-desktop'],
                capture_output=True,
                text=True,
                check=False,
                timeout=5,
            )
            return bool(result.stdout.strip())
        except (OSError, subprocess.SubprocessError):
            return False

    def launch_or_focus_github_desktop(self) -> tuple[bool, str]:
        """
        Start GitHub Desktop, or -- on platforms where the OS launch
        mechanism already does this for a running app -- bring it to
        the front. Equivalent to clicking its dock/taskbar icon: it
        does not open, select, or otherwise touch any particular
        repository or tab. Deciding what to show is left entirely to
        GitHub Desktop itself (see this class's "GitHub Desktop
        integration" banner comment above).

        :returns: ``(True, '')`` once the launch command has been
            issued, or ``(False, message)`` if GitHub Desktop could
            not be found or started.
        """
        target = self.find_github_desktop_executable()
        if target is None:
            return False, _(
                "GitHub Desktop was not found on this computer. Install"
                " it from https://desktop.github.com/ (on Linux, the"
                " community-maintained build at"
                " https://github.com/shiftkey/desktop)."
            )

        try:
            if target.startswith('flatpak:'):
                args = ['flatpak', 'run', target[len('flatpak:') :]]
            elif sys.platform == 'darwin' and target.endswith('.app'):
                args = ['open', '-a', target]
            else:
                args = [target]
            # GitHub Desktop is an Electron (Chromium) app and prints
            # its own startup diagnostics -- e.g. D-Bus connection
            # warnings on a system with no session bus, or missing
            # optional GTK modules -- straight to its inherited
            # stdout/stderr. Those are GitHub Desktop's own messages,
            # not ours, and Gramps has no use for them, so they're
            # discarded here rather than left to spill into whatever
            # terminal launched Gramps.
            with open(os.devnull, 'wb') as devnull:
                subprocess.Popen(  # pylint: disable=consider-using-with
                    args, stdout=devnull, stderr=devnull
                )
        except OSError as exc:
            return False, _("Could not start GitHub Desktop: {}").format(exc)
        return True, ""

    def cb_activate_github_desktop(self, _button) -> None:
        """
        GTK "clicked" callback: start GitHub Desktop, or bring it to
        the front if it's already running (see
        :meth:`launch_or_focus_github_desktop`). Does not open a
        specific repository or tab.
        """
        success, message = self.launch_or_focus_github_desktop()
        if not success:
            ErrorDialog(_("Could Not Open GitHub Desktop"), message, parent=self.window)
            return
        self.bottom_status_label.set_text(_("Launched GitHub Desktop."))

    def _build_github_desktop_icon_button(self) -> Gtk.Widget:
        """
        Build the 32x32 icon button used to start/focus GitHub
        Desktop (see :meth:`cb_activate_github_desktop`), using
        ``media/icons/github-desktop-prod.svg`` (bundled alongside
        this tool) for its resting state, cross-faded on hover/press
        with ``media/icons/github-desktop-dev.svg`` via CSS opacity
        transitions (see :data:`GITHUB_DESKTOP_BUTTON_CSS` and
        :meth:`_install_github_desktop_button_css`).

        Only called when GitHub Desktop has actually been detected
        (see :meth:`find_github_desktop_executable`) -- callers
        should not show this button, or the dead space next to it,
        otherwise.

        :returns: a Gtk.Button showing the icon(s), or a small text
            Gtk.Button fallback if ``github-desktop-prod.svg`` can't
            be loaded, so a missing/broken icon file doesn't also
            lose the button's functionality.
        """
        icons_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 'media', 'icons'
        )
        prod_pixbuf = _load_scaled_svg_pixbuf(
            os.path.join(icons_dir, 'github-desktop-prod.svg')
        )

        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.get_style_context().add_class('aps-github-desktop-btn')

        if prod_pixbuf is None:
            LOG.warning(
                "GitHub Desktop icon not found under %s -- falling"
                " back to a text button.",
                icons_dir,
            )
            btn.set_label(_("GitHub Desktop"))
        else:
            overlay = Gtk.Overlay()
            overlay.add(Gtk.Image.new_from_pixbuf(prod_pixbuf))

            dev_pixbuf = _load_scaled_svg_pixbuf(
                os.path.join(icons_dir, 'github-desktop-dev.svg')
            )
            if dev_pixbuf is not None:
                hover_image = Gtk.Image.new_from_pixbuf(dev_pixbuf)
                hover_image.get_style_context().add_class('aps-github-hover-icon')
                overlay.add_overlay(hover_image)
                if hasattr(overlay, 'set_overlay_pass_through'):
                    overlay.set_overlay_pass_through(hover_image, True)
            btn.add(overlay)
            self._install_github_desktop_button_css(btn)

        repo_names = [repo['name'] for repo in self.get_repository_list()]
        if repo_names:
            tooltip = _(
                "Start GitHub Desktop, or bring it to the front if"
                " it's already running.\nDetected local"
                " repositories: {}"
            ).format(", ".join(repo_names))
        else:
            tooltip = _(
                "Start GitHub Desktop, or bring it to the front if"
                " it's already running."
            )
        btn.set_tooltip_text(tooltip)
        btn.connect("clicked", self.cb_activate_github_desktop)
        return btn

    @staticmethod
    def _install_github_desktop_button_css(widget: Gtk.Widget) -> None:
        """
        Install :data:`GITHUB_DESKTOP_BUTTON_CSS` -- the hover/press
        icon cross-fade for the GitHub Desktop button (see
        :meth:`_build_github_desktop_icon_button`) -- on ``widget``'s
        screen.

        :param widget: any realized-or-about-to-be-realized widget in
            the same top-level window as the GitHub Desktop button,
            used only to reach a Gdk.Screen to install the provider
            on.
        """
        screen = widget.get_screen()
        if screen is None:
            return
        provider = Gtk.CssProvider()
        try:
            provider.load_from_data(GITHUB_DESKTOP_BUTTON_CSS)
        except GLib.Error:
            return
        Gtk.StyleContext.add_provider_for_screen(
            screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    def _fetch_make_script_source(self, digits, timeout=15):
        """
        Download the current make.py from the gramps-project/
        addons-source 'maintenance/gramps<digits>' branch on GitHub.

        :param digits: Version digit string, e.g. '52'.
        :param timeout: Network timeout in seconds.
        :returns: (content_str, error_message) -- exactly one is None.
        """
        url = GITHUB_ADDONS_SOURCE_RAW.format(digits=digits)
        try:
            with urllib.request.urlopen(url, timeout=timeout) as response:
                if response.status != 200:
                    return None, f"HTTP {response.status}"
                return response.read().decode('utf-8'), None
        except urllib.error.HTTPError as exc:
            return None, f"HTTP {exc.code}"
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            return None, str(exc)

    def _discover_upstream_versions(self, timeout=15):
        """
        Query the GitHub API for maintenance/gramps<NN> branches on
        gramps-project/addons-source, so newly released Gramps versions
        can be offered even before a local make<NN>.py exists for them.
        Only versions at or above MIN_SUPPORTED_VERSION_DIGITS (5.2+,
        which use JSON listings) are returned.

        :param timeout: Network timeout in seconds.
        :returns: sorted list of version digit strings (e.g. ['52',
            '60', '61']), or [] if the API could not be reached (no
            network, rate-limited, etc.) -- callers should treat that
            as "nothing new found", not as an error.
        """
        request = urllib.request.Request(
            GITHUB_ADDONS_SOURCE_BRANCHES_API,
            headers={'Accept': 'application/vnd.github+json'})
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                data = json.loads(response.read().decode('utf-8'))
        except (urllib.error.URLError, OSError, ValueError, TimeoutError):
            return []
        digits = []
        for branch in data if isinstance(data, list) else []:
            match = re.match(r'^maintenance/gramps(\d{2,3})$',
                              branch.get('name', ''))
            if match and self._is_supported_version(match.group(1)):
                digits.append(match.group(1))
        return sorted(set(digits))

    def on_update_make_scripts(self, _widget):
        """
        Download the current make.py for every known (and newly
        discoverable) Gramps version from gramps-project/addons-source
        on GitHub, overwriting this tool's bundled make<NN>.py copies
        so upstream fixes are picked up on demand rather than requiring
        a manual re-port. Existing files are backed up with a timestamp
        before being overwritten. Restricted to Gramps 5.2+ (see
        MIN_SUPPORTED_VERSION_DIGITS), since that's when the addon
        listing format switched to JSON.
        """
        builder_dir = os.path.dirname(os.path.abspath(__file__))

        known_digits = sorted({
            entry['code'][len('gramps'):] for entry in self.available_versions
        })
        new_digits = [d for d in self._discover_upstream_versions()
                      if d not in known_digits]

        if not known_digits and not new_digits:
            OkDialog(
                _("No Versions Found"),
                _("Could not find any local make<NN>.py to update, and "
                  "the GitHub branch list could not be reached (check "
                  "your network connection)."),
                parent=self.window
            )
            return

        lines = []
        if known_digits:
            lines.append(_("Update existing scripts:"))
            lines.extend(
                f"  \u2022 make{d}.py  (Gramps {self._version_label(d)})"
                for d in known_digits)
        if new_digits:
            lines.append("")
            lines.append(_("Add newly available scripts:"))
            lines.extend(
                f"  \u2022 make{d}.py  (Gramps {self._version_label(d)})"
                for d in new_digits)
        lines.append("")
        lines.append(_(
            "Existing files are backed up (.bak) before being "
            "overwritten. Continue?"))

        from gramps.gui.dialog import QuestionDialog2
        question = QuestionDialog2(
            _("Update Scripts from GitHub?"),
            "\n".join(lines),
            _("Yes, Update"),
            _("Cancel"),
            parent=self.window
        )
        if not question.run():
            return

        results = []
        for digits in known_digits + new_digits:
            content, error = self._fetch_make_script_source(digits)
            script_name = f"make{digits}.py"
            script_path = os.path.join(builder_dir, script_name)

            if error:
                results.append(f"\u2717 {script_name}: {error}")
                continue

            if os.path.exists(script_path):
                with open(script_path, 'r', encoding='utf-8',
                          errors='replace') as fh:
                    current = fh.read()
                if current == content:
                    results.append(f"= {script_name}: already up to date")
                    continue
                timestamp = datetime.datetime.now().strftime(
                    '%Y%m%d-%H%M%S')
                backup_path = f"{script_path}.{timestamp}.bak"
                shutil.copy2(script_path, backup_path)
                note = f"backup: {os.path.basename(backup_path)}"
            else:
                note = "new file"

            try:
                with open(script_path, 'w', encoding='utf-8',
                          newline='') as fh:
                    fh.write(content)
                results.append(f"\u2713 {script_name}: updated ({note})")
            except OSError as exc:
                results.append(f"\u2717 {script_name}: could not write ({exc})")

        # Re-detect since new/updated scripts may have appeared
        self.available_versions = self.detect_available_versions()

        self.show_scrollable_dialog(
            _("Update Scripts Results"),
            _("Checked gramps-project/addons-source on GitHub:") + "\n\n"
            + "\n".join(results) + "\n\n"
            + _("Restart Addon Pack and Ship (or re-open this tool) to "
                "see any newly added Gramps version checkboxes.")
        )

    def build_interface(self):
        """
        Build the GTK interface
        """
        self.set_window(
            Gtk.Window(),
            Gtk.Label(_("Addon Pack and Ship")),
            _("Addon Pack and Ship")
        )

        window = self.window
        window.set_default_size(800, 650)
        window.set_border_width(12)

        # Two tabs: "Build" (day-to-day actions, changes every run) and
        # "Options" (infrequently-changed settings -- Build Mode,
        # Multilingual, Update Scripts, the version-coverage override,
        # and the logs folder icon -- moved out of the main view to
        # reduce clutter as the tool grew). Both are actually built
        # into by the rest of this function; the Gtk.Notebook that
        # holds them is only assembled at the very end, once both are
        # complete.
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        options_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        options_vbox.set_border_width(12)

        # Checked before anything below can create APS.ini (the
        # "default" configuration is seeded later, on idle): with no
        # APS.ini yet, this is a first run, so the window opens on the
        # Options tab to show a new user the settings that shape every
        # build before they start one.
        first_run = not os.path.exists(self._config_ini_path())

        # No separate title/info labels here -- the window titlebar
        # (set via set_window() above) already shows the tool name, and
        # the "Found N bundles…" summary moves to the bottom status row
        # (see update_selection_count()) so it's replaced by the live
        # "Selected bundles: …" readout as soon as something is checked.
        # "Select installed addons to package and publish" becomes a
        # tooltip on the addon list itself (see below) instead of taking
        # up a permanent line.
        total_plugins = sum(
            len(info['plugins']) for info in self.addon_info.values())
        self._total_bundles = len(self.addon_info)
        self._total_plugins = total_plugins

        # ── Filter Addons frame — contains select/mode row, filter row, action buttons ──
        filter_frame = Gtk.Frame(label=_("Filter Addons:"))
        filter_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        filter_box.set_border_width(6)
        filter_frame.add(filter_box)

        # Row 1: Select All / Deselect All  +  Build Mode radio buttons
        select_mode_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

        select_all_btn = Gtk.Button(label=_("Select All Visible"))
        select_all_btn.connect("clicked", self.on_select_all)
        select_mode_box.pack_start(select_all_btn, False, False, 0)

        deselect_all_btn = Gtk.Button(label=_("Deselect All"))
        deselect_all_btn.connect("clicked", self.on_deselect_all)
        select_mode_box.pack_start(deselect_all_btn, False, False, 0)

        select_mode_box.pack_start(
            Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 6)

        # Type filter combo — at the end of the mode row, no label needed
        self.type_filter_combo = Gtk.ComboBoxText()
        self.type_filter_combo.append_text(_("All Types"))
        # Not a plugin type: shows only the plugins that are checked now
        self.type_filter_combo.append_text(_("Selected"))
        all_types = sorted(set(
            t for info in self.addon_info.values()
            for t in info['types']
            if t and t != 'UNKNOWN'
        ))
        for t in all_types:
            self.type_filter_combo.append_text(t)
        self.type_filter_combo.set_active(0)
        self.type_filter_combo.set_tooltip_text(
            _("Filter list by plugin type.\n"
              "Selected = only the plugins that are checked now\n"
              "VIEW = views/panels  GRAMPLET = dashboard gramplets\n"
              "TOOL = tools  REPORT = reports  GENERAL = utilities"))
        self.type_filter_combo.connect("changed", self.on_filter_changed)
        select_mode_box.pack_start(self.type_filter_combo, False, False, 0)

        # SearchEntry with built-in magnifier and ✕ clear button, in the
        # free space at the end of row 1 (it used to take a row of its own)
        self.author_filter_entry = Gtk.SearchEntry()
        self.author_filter_entry.set_placeholder_text(
            _("Search bundles and plugins…"))
        self.author_filter_entry.set_tooltip_text(
            _("Search across all plugin fields: name, type, id, path, "
              "authors, version, category, and more.\n"
              "All words must match (order ignored, case-insensitive)."))
        self.author_filter_entry.connect("search-changed", self.on_filter_changed)
        select_mode_box.pack_start(self.author_filter_entry, True, True, 0)

        filter_box.pack_start(select_mode_box, False, False, 0)

        # Row 2: individual operation buttons (always visible — outside scroll area)
        action_btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

        build_btn = Gtk.Button(label=_("Build Selected"))
        build_btn.connect("clicked", self.on_build)
        action_btn_box.pack_start(build_btn, False, False, 0)

        compile_btn = Gtk.Button(label=_("Compile Translations"))
        compile_btn.connect("clicked", self.on_compile)
        missing_tool = self._missing_gettext_tool()
        if missing_tool:
            # Without xgettext no template.pot can be made, and without
            # msgfmt no .po can be compiled, so the button could only
            # fail. Checked once, when the window opens.
            compile_btn.set_label(fill_names(
                _("{tool} missing"), tool=missing_tool))
            compile_btn.set_sensitive(False)
            compile_btn.set_tooltip_text(fill_names(
                _("The gettext translation tools are not installed, so"
                  " translations cannot be compiled.\n"
                  "Fedora: {fedora}\n"
                  "Debian/Ubuntu: {debian}\n"
                  "macOS: {macos}\n"
                  "Windows: see the {readme} of this tool.\n"
                  "Then close and reopen Addon Pack and Ship"
                  " (on Windows, restart Gramps)."),
                fedora="sudo dnf install gettext",
                debian="sudo apt install gettext",
                macos="brew install gettext",
                readme="README.md"))
        action_btn_box.pack_start(compile_btn, False, False, 0)

        listing_btn = Gtk.Button(label=_("Amend Listings"))
        listing_btn.set_tooltip_text(fill_names(
            _("Create or amend the {listing} listing(s) for"
              " selected addons, for each checked Gramps version above."
              " English plus any language the addon has a"
              " {po_file} for is listed automatically.\n"
              "Adds/updates entries — other entries are preserved.\n"
              "To shrink a listing, delete the {listings_dir} folder of"
              " that version first, then rebuild only the addons you want"
              " listed."),
            listing="addons-<lang>.json", po_file="po/<lang>-local.po",
            listings_dir="listings/"))
        listing_btn.connect("clicked", self.on_listing)
        action_btn_box.pack_start(listing_btn, False, False, 0)

        filter_box.pack_start(action_btn_box, False, False, 0)

        vbox.pack_start(filter_frame, False, False, 0)

        # ── Package Targets frame — which Gramps versions to build/list for ──
        targets_frame = Gtk.Frame(label=_("Package Targets:"))
        targets_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        targets_box.set_border_width(6)
        targets_frame.add(targets_box)

        # Row: which Gramps versions to build/list for
        version_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        version_label = Gtk.Label()
        version_label.set_markup(_("<b>Gramps Versions:</b>"))
        version_row.pack_start(version_label, False, False, 0)

        if self.available_versions:
            running_code = self._running_gramps_version_code()
            for entry in self.available_versions:
                checkbox = Gtk.CheckButton(label=entry['label'])
                # Default: only the Gramps version actually running this
                # tool is pre-checked. A loaded named configuration (see
                # load_named_config()) overrides this immediately after,
                # same as it overrides every other default below.
                checkbox.set_active(entry['code'] == running_code)
                checkbox.set_tooltip_text(fill_names(
                    _("Build and list packages for Gramps {label}"
                      " (using {script}).\nThe same {tgz} is reused"
                      " (duplicated) across every checked version — it"
                      " is only rebuilt once.\nListing entries are"
                      " generated by delegating to the real {script} from"
                      " {repo}, so every language"
                      " the addon has a {po_files} for is listed"
                      " automatically."),
                    label=entry['label'], script=entry['script'],
                    tgz=".addon.tgz", repo="gramps-project/addons-source",
                    po_files="po/*-local.po"))
                self.version_checkboxes[entry['code']] = checkbox
                version_row.pack_start(checkbox, False, False, 0)
        else:
            version_row.pack_start(
                Gtk.Label(_("No make<NN>.py scripts found — using"
                            " default '{}'.").format(GRAMPS_VERSION)),
                False, False, 0)

        targets_box.pack_start(version_row, False, False, 0)

        vbox.pack_start(targets_frame, False, False, 0)

        # ── Output Location row — where <version>/download, listings go,
        # plus named configuration load/save ─────────────────────────────
        output_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

        # Start/focus GitHub Desktop (see "GitHub Desktop
        # integration" above) -- shown only when it's actually
        # detected on this machine, and never opens a specific
        # repository or tab; that's left entirely to GitHub Desktop.
        # Placed to the left of the "Output location:" hotlink, with
        # a dead space (see _new_dead_space()) so aiming for one
        # doesn't accidentally hit the other.
        if self.find_github_desktop_executable() is not None:
            output_box.pack_start(
                self._build_github_desktop_icon_button(), False, False, 0
            )
            output_box.pack_start(_new_dead_space(), False, False, 0)

        # A Gtk.LinkButton is used here purely for its "looks and acts
        # like a hotlink" styling -- there is no real URI to follow,
        # so cb_open_output_folder() (connected below) always returns
        # True to stop GTK's default handler from also trying to open
        # one in a web browser.
        output_icon_label = Gtk.LinkButton.new_with_label("", "")
        output_link_label = output_icon_label.get_child()
        if isinstance(output_link_label, Gtk.Label):
            output_link_label.set_markup(_("<b>Output location:</b>"))
        output_icon_label.set_relief(Gtk.ReliefStyle.NONE)
        output_icon_label.set_tooltip_text(
            _("Open the output location folder in your file browser."))
        output_icon_label.connect("activate-link", self.cb_open_output_folder)
        _tighten_hotlink_hit_area(output_icon_label)
        output_box.pack_start(output_icon_label, False, False, 0)

        # Default folder is this tool's own installation directory; the
        # "Configuration" combo below (backed by APS.ini, not gramps.ini)
        # restores a different one automatically if a last-used named
        # configuration set output_dir to something else.
        default_output_dir = os.path.dirname(os.path.abspath(__file__))

        self.output_dir_chooser = Gtk.FileChooserButton(
            title=_("Choose a parent folder for the generated"
                    " version folders"),
            action=Gtk.FileChooserAction.SELECT_FOLDER)
        self.output_dir_chooser.set_filename(default_output_dir)
        self.output_dir_chooser.set_tooltip_text(fill_names(
            _("Where the {version_dirs} output folders"
              " (each with {download_dir} and {listings_dir} subfolders)"
              " are created. Defaults to the folder of this tool.\nSave a"
              " named configuration (see the icon and box to the"
              " right) to remember a different folder across sessions"
              " -- point it at a local Git repository clone if you"
              " plan to commit and push the generated packages and"
              " listings with GitHub Desktop."),
            version_dirs="gramps52/, gramps60/, gramps61/",
            download_dir="download/", listings_dir="listings/"))

        # GtkFileChooserButton's own compact dropdown only ever shows
        # recently-used folders plus "Other…" -- shortcuts added via
        # add_shortcut_folder() only appear once that "Other…" dialog is
        # open, so they're easy to miss. A separate, always-visible combo
        # makes detected Git repo folders actually discoverable.
        detected_repo_roots = self.detect_local_git_repo_roots()
        if detected_repo_roots:
            self.output_suggestions_combo = Gtk.ComboBoxText()
            self.output_suggestions_combo.append_text(
                _("(pick a detected Git repo folder…)"))
            for repo_root in detected_repo_roots:
                self.output_suggestions_combo.append_text(repo_root)
            self.output_suggestions_combo.set_active(0)
            self.output_suggestions_combo.set_tooltip_text(
                _("Local Git repository clones found under common"
                  " GitHub Desktop / developer folders (e.g."
                  " ~/Documents/GitHub). Selecting one sets the parent"
                  " folder on the right."))
            self.output_suggestions_combo.connect(
                "changed", self.on_output_suggestion_changed)
            output_box.pack_start(
                self.output_suggestions_combo, False, False, 0)

        for repo_root in detected_repo_roots:
            try:
                self.output_dir_chooser.add_shortcut_folder(repo_root)
            except GObject.GError:
                pass  # already a shortcut, or otherwise unavailable

        output_box.pack_start(self.output_dir_chooser, True, True, 0)

        # ── Named configuration load/save, sharing this same line ─────────
        config_icon = Gtk.Image.new_from_icon_name(
            CONFIG_SAVE_ICON_NAME, Gtk.IconSize.BUTTON)
        self.config_icon = config_icon  # kept for the save-feedback animation
        config_save_tooltip = _(
            "Save the current settings under the name typed in the box"
            " to the right (same as pressing Enter there). Overwrites a"
            " configuration of that name if one already exists.")
        config_icon.set_tooltip_text(config_save_tooltip)
        config_save_btn = Gtk.Button()
        config_save_btn.set_image(config_icon)
        config_save_btn.set_relief(Gtk.ReliefStyle.NONE)
        config_save_btn.set_tooltip_text(config_save_tooltip)
        config_save_btn.connect(
            "clicked", self.on_config_save_button_clicked)
        output_box.pack_start(config_save_btn, False, False, 0)

        self.config_combo = Gtk.ComboBoxText.new_with_entry()
        for name in self._list_saved_configs():
            self.config_combo.append_text(name)
        self.config_combo.set_tooltip_text(fill_names(
            _("Named configurations, saved to {ini} in the folder of"
              " this tool. Each one remembers build mode, Gramps"
              " version checkboxes, output location, filters, and"
              " which addons are selected.\nPick one to load it. Type a"
              " name (new or existing) and press Enter -- or click the"
              " icon to the left -- to save the current settings under"
              " that name, overwriting it if it already exists. The"
              " name shown here is also restored automatically the"
              " next time this tool is opened."), ini="APS.ini"))
        self.config_combo.connect("changed", self.on_config_combo_changed)
        config_entry = self.config_combo.get_child()
        if config_entry is not None:
            config_entry.set_placeholder_text(_("Configuration name…"))
            config_entry.connect("activate", self.on_config_combo_activate)
        output_box.pack_start(self.config_combo, False, False, 0)

        vbox.pack_start(output_box, False, False, 0)

        # Restore whichever configuration was active when this tool was
        # last closed. Deferred via idle_add, same as the combo change
        # handlers, so it runs after the window is fully realized.
        last_used = self._get_last_used_config_name()
        if last_used and last_used in self._list_saved_configs():
            if config_entry is not None:
                config_entry.set_text(last_used)
            GLib.idle_add(self._load_named_config_idle, last_used)
        elif not self._list_saved_configs():
            # Genuinely fresh install -- no named configurations saved
            # in APS.ini yet, so nothing above had anything to restore.
            # Persist the defaults just built (Gramps Versions limited
            # to the running major version, plus build mode, output
            # location, and filters as built above) as a "default"
            # named configuration, so there's always at least one
            # saved to load/reuse later. Deferred via GLib.idle_add,
            # for the same reason as the last-used-configuration
            # restore just above: run after the window is fully
            # realized, so the Output location this captures reflects
            # this tool's actual installed location under the running
            # OS's own registered path to it, not whatever
            # get_output_parent_dir() might return before the window
            # is mapped.
            GLib.idle_add(self._seed_default_config_idle)

        # Separator
        vbox.pack_start(Gtk.Separator(), False, False, 0)

        # Scrolled window for addon list
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_vexpand(True)
        scrolled.set_tooltip_text(fill_names(
            _("Select installed addons to package and publish.\n"
              "Right-click for listing actions (filter by / open"
              " {listing})."), listing="addons-en.json"))
        vbox.pack_start(scrolled, True, True, 0)

        # Addon selection area, wrapped in an EventBox so right-clicks
        # anywhere in the list (not just over specific child widgets)
        # reach cb_addon_list_button_press -- the listing filter/open
        # actions it offers apply to the whole list, not to any one
        # addon row, so a list-wide context menu is the right scope.
        self.addon_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.addon_box.set_border_width(6)
        addon_list_event_box = Gtk.EventBox()
        addon_list_event_box.add(self.addon_box)
        addon_list_event_box.connect(
            'button-press-event', self.cb_addon_list_button_press)
        scrolled.add(addon_list_event_box)

        # Build the addon list
        self.rebuild_addon_list()

        # Separator
        vbox.pack_start(Gtk.Separator(), False, False, 0)

        # Bottom row: Help (leftmost) + status + Pack and Ship (centre) + Close
        bottom_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

        # Help icon, leftmost -- prefers opening this tool's own
        # README.md in Markdown Dash's standalone viewer, falling back
        # to this tool's registered help_url in the default browser
        # (see on_help_icon_clicked()).
        icon_theme = Gtk.IconTheme.get_default()
        try:
            help_pixbuf = icon_theme.load_icon("help-browser", 32, 0)
            help_icon = Gtk.Image.new_from_pixbuf(help_pixbuf)
        except GLib.Error:
            help_icon = Gtk.Image.new_from_icon_name(
                "help-browser", Gtk.IconSize.DIALOG)
        help_btn = Gtk.Button()
        help_btn.set_image(help_icon)
        help_btn.set_relief(Gtk.ReliefStyle.NONE)
        help_btn.set_tooltip_text(
            _("Open this tool's documentation."))
        help_btn.connect("clicked", self.on_help_icon_clicked)
        bottom_box.pack_start(help_btn, False, False, 0)

        # Status label on the left of the bottom row
        self.bottom_status_label = Gtk.Label()
        self.bottom_status_label.set_halign(Gtk.Align.START)
        bottom_box.pack_start(self.bottom_status_label, True, True, 0)

        # Pack and Ship centred
        github_btn = Gtk.Button(label=_("📦 Pack and Ship"))
        github_btn.get_style_context().add_class('suggested-action')
        github_btn.connect("clicked", self.on_package_for_github)
        bottom_box.pack_start(github_btn, False, False, 0)

        # Spacer to balance the status label on the left
        bottom_box.pack_start(Gtk.Label(), True, True, 0)

        # Close button on the right
        close_btn = Gtk.Button(label=_("Close"))
        close_btn.connect("clicked", self.close)
        bottom_box.pack_end(close_btn, False, False, 0)

        vbox.pack_start(bottom_box, False, False, 0)

        # ══════════════════════════════════════════════════════════════
        # "Options" tab — settings changed rarely, not every run: Build
        # Mode, Multilingual, Update Scripts, the version-coverage
        # override, and the logs folder icon (now permanently visible,
        # since it has its own room here rather than crowding the main
        # action row). All of these are still part of the same named
        # configuration save/load as the Build tab's own settings (see
        # _collect_config_state()/save_named_config()/
        # load_named_config()).
        # ══════════════════════════════════════════════════════════════
        build_mode_frame = Gtk.Frame(label=_("Build Mode:"))
        build_mode_box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        build_mode_box.set_border_width(6)
        build_mode_frame.add(build_mode_box)

        self.radio_beta = Gtk.RadioButton.new_with_label(None, _("β  Beta"))
        self.radio_beta.set_tooltip_text(fill_names(
            _("Beta build — includes everything for testers and translators:\n"
              "• All core files ({core})\n"
              "• {readme} and all {md} files\n"
              "• {po} translation source files\n"
              "• {pot} translation template\n"
              "• {manifest} and {manifest_beta} files\n"
              "• All subdirectory contents (data, layouts, etc.)\n"
              "• {mo} compiled translations\n\n"
              "Uses {manifest_beta} if present, otherwise auto-includes"
              " all extras."),
            core=".py, .glade, .xml", readme="README.md", md="*.md",
            po="po/*.po", pot="po/template.pot", manifest="MANIFEST",
            manifest_beta="MANIFEST.beta", mo="locale/*.mo"))
        self.radio_beta.connect("toggled", self.on_build_mode_changed)
        build_mode_box.pack_start(self.radio_beta, False, False, 0)

        self.radio_release = Gtk.RadioButton.new_with_label_from_widget(
            self.radio_beta, _("Δ  Release")
        )
        self.radio_release.set_tooltip_text(fill_names(
            _("Release build — clean end-user package:\n"
              "• All core files ({core})\n"
              "• {readme} only (no other {md} files)\n"
              "• {mo} compiled translations only\n"
              "• {manifest} extras (if {manifest} present)\n\n"
              "⚠ Intentionally lossy — {po_dir} source files,\n"
              "{changelog}, dev notes are NOT included.\n"
              "Uses {manifest} if present."),
            core=".py, .glade, .xml", readme="README.md", md=".md",
            mo="locale/*.mo", manifest="MANIFEST", po_dir="po/",
            changelog="CHANGELOG.md"))
        self.radio_release.connect("toggled", self.on_build_mode_changed)
        build_mode_box.pack_start(self.radio_release, False, False, 0)

        options_vbox.pack_start(build_mode_frame, False, False, 0)

        # Listings frame: Multilingual + the version-coverage override
        listings_frame = Gtk.Frame(label=_("Listings:"))
        listings_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL, spacing=6)
        listings_box.set_border_width(6)
        listings_frame.add(listings_box)

        # Deselected by default. Either way, make_addon.py's
        # _reconcile_listing_with_gpr() updates the selected addon in
        # every addons-<lang>.json that already exists, so published
        # language catalogs never keep an old entry. The checkbox only
        # decides whether NEW language files may be created: on, by
        # _apply_multilingual_rules(); off, any file the listing run
        # created is removed by _remove_new_non_english_listings().
        self.multilingual_check = Gtk.CheckButton(label=_("Multilingual"))
        self.multilingual_check.set_active(False)
        self.multilingual_check.set_tooltip_text(fill_names(
            _("Every {listing} that already exists is always updated"
              " with the selected addons (translated where a"
              " translation exists, English otherwise).\n"
              "Off (default): no new {listing} is created.\n"
              "On: a new {listing} is created when the name or"
              " description in the {gpr} of the addon is actually"
              " translated into that language."),
            listing="addons-<lang>.json", gpr=".gpr.py"))
        listings_box.pack_start(self.multilingual_check, False, False, 0)

        # Translation language + "Edit translation…" for translators
        listings_box.pack_start(
            self._build_translation_row(), False, False, 0)

        # Deselected by default: build_for_versions() normally refuses
        # to duplicate a built package into a version its own .gpr.py
        # doesn't support (see check_gpr_version_coverage() and the
        # main tab's per-version red/greyed-out hints when exactly one
        # addon is selected). This is the explicit override for a
        # maintainer who knows better than that check -- it never
        # causes anything to be rewritten; it only widens which
        # versions get a duplicate at all.
        self.force_uncovered_check = Gtk.CheckButton(
            label=_("Duplicate into unverified/incompatible versions anyway"))
        self.force_uncovered_check.set_active(False)
        self.force_uncovered_check.set_tooltip_text(fill_names(
            _("Off (default): an addon with an adaptive {gpr} (one with a"
              " version check) is not packed or listed for a checked"
              " Gramps version that its version check rejects.\n"
              "On: it is packed and listed for every checked version"
              " regardless.\n"
              "Addons whose {gpr} is not adaptive (no version check, or"
              " a hardcoded {target}) are never packed for several"
              " versions silently: Pack and Ship warns and asks first."
              " Nothing about the {gpr} itself is ever changed."),
            gpr=".gpr.py", target="gramps_target_version"))
        listings_box.pack_start(self.force_uncovered_check, False, False, 0)

        # An explicit action, not part of Pack and Ship: comparing
        # every language file costs time on each run, and deleting
        # files nobody asked to delete would surprise a new user.
        remove_untranslated_btn = Gtk.Button(
            label=_("Remove untranslated listings…"))
        remove_untranslated_btn.set_halign(Gtk.Align.START)
        remove_untranslated_btn.set_tooltip_text(fill_names(
            _("For each checked Gramps Version, find every"
              " {listing} whose names and descriptions are all"
              " identical to {en_listing} -- files that only repeat the"
              " English catalog -- and offer to delete them. The Addon"
              " Manager falls back to {en_listing} for any language"
              " without its own file. Files with any translated name or"
              " description are kept, and no {po_dir} or {locale_dir}"
              " translation files are touched."),
            listing="addons-<lang>.json", en_listing="addons-en.json",
            po_dir="po/", locale_dir="locale/"))
        remove_untranslated_btn.connect(
            "clicked", self.on_remove_untranslated_listings)

        # Listing runs never delete a language listing that already
        # exists, so pruning a listings folder back to English only is
        # this explicit, confirmed action.
        remove_all_btn = Gtk.Button(
            label=_("Remove all language listings…"))
        remove_all_btn.set_tooltip_text(fill_names(
            _("For each checked Gramps Version, offer to delete every"
              " {listing} except {en_listing}, including files with"
              " translated names and descriptions. Afterwards the Addon"
              " Manager shows the English catalog in every language."
              " Files that contain translations are marked in the list"
              " before you confirm. No {po_dir} or {locale_dir}"
              " translation files are touched, and a later listing run"
              " with Multilingual on can create the files again."),
            listing="addons-<lang>.json", en_listing="addons-en.json",
            po_dir="po/", locale_dir="locale/"))
        remove_all_btn.connect(
            "clicked", self.on_remove_all_language_listings)

        remove_row = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        remove_row.pack_start(remove_untranslated_btn, False, False, 0)
        remove_row.pack_start(remove_all_btn, False, False, 0)
        listings_box.pack_start(remove_row, False, False, 0)

        options_vbox.pack_start(listings_frame, False, False, 0)

        # Maintenance frame: Update Scripts
        maintenance_frame = Gtk.Frame(label=_("Maintenance:"))
        maintenance_box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        maintenance_box.set_border_width(6)
        maintenance_frame.add(maintenance_box)

        update_scripts_btn = Gtk.Button(label=_("Update Scripts…"))
        update_icon = Gtk.Image.new_from_icon_name(
            "folder-download-symbolic", Gtk.IconSize.BUTTON)
        update_scripts_btn.set_image(update_icon)
        update_scripts_btn.set_always_show_image(True)
        update_scripts_btn.set_image_position(Gtk.PositionType.LEFT)
        update_scripts_btn.set_tooltip_text(
            _("Fetch the current Gramps 5.2+ packaging scripts from"
              " gramps-project/addons-source on GitHub, overwriting this"
              " tool's bundled copies (a timestamped backup is kept)."
              " Also offers to add a script for any newly released"
              " Gramps version not yet bundled here.\nThis is the only"
              " way these files are ever changed — they are never"
              " edited automatically."))
        update_scripts_btn.connect("clicked", self.on_update_make_scripts)
        maintenance_box.pack_start(update_scripts_btn, False, False, 0)

        # Logs-folder icon -- opens this plugin's logs/ directory (see
        # make_addon.py's _log_session_command()) in the OS file
        # manager. Permanently visible here (unlike its previous home
        # squeezed next to Pack and Ship on the main tab, where it
        # stayed hidden until this session's first log entry to avoid
        # clutter): the Options tab has the room, so there's no longer
        # a clutter cost to showing it immediately.
        logs_icon = Gtk.Image.new_from_icon_name(
            "folder-documents", Gtk.IconSize.SMALL_TOOLBAR)
        self.logs_btn = Gtk.Button()
        self.logs_btn.set_image(logs_icon)
        self.logs_btn.set_always_show_image(True)
        self.logs_btn.set_label(_("Session Logs"))
        self.logs_btn.set_tooltip_text(_("Open the session logs folder."))
        self.logs_btn.connect("clicked", self.on_open_logs_folder_clicked)
        maintenance_box.pack_start(self.logs_btn, False, False, 0)

        options_vbox.pack_start(maintenance_frame, False, False, 0)

        notebook = Gtk.Notebook()
        notebook.append_page(vbox, Gtk.Label(_("Build")))
        options_page = notebook.append_page(
            options_vbox, Gtk.Label(_("Options")))
        window.add(notebook)

        window.show_all()
        if first_run:
            # After show_all(): Gtk.Notebook ignores set_current_page()
            # for a page whose child is not yet visible.
            notebook.set_current_page(options_page)

    def get_addon_metadata(self, addon_name, use_cache=True):
        """
        Get metadata from the registered PluginData object for this addon.
        Uses the first plugin entry as the source for shared addon-level fields.
        Note: 'maintainers' / 'maintainers_email' are custom fields not parsed
        by Gramps' PluginRegister; they will be empty until Gramps' register()
        API is extended to support them (see enhancement request).
        """
        if use_cache and addon_name in self.metadata_cache:
            return self.metadata_cache[addon_name]

        metadata = {
            'name': '',
            'authors': [],
            'authors_email': [],
            'maintainers': [],
            'maintainers_email': [],
        }

        if addon_name not in self.addon_info:
            return metadata

        plugins = self.addon_info[addon_name].get('plugins', [])
        if not plugins:
            return metadata

        plugin = plugins[0]

        def _to_list(val):
            if not val:
                return []
            if isinstance(val, list):
                return [v for v in val if v]
            if isinstance(val, str) and val:
                return [val]
            return []

        if hasattr(plugin, 'name') and plugin.name:
            metadata['name'] = plugin.name
        metadata['authors']       = _to_list(getattr(plugin, 'authors', []))
        metadata['authors_email'] = _to_list(getattr(plugin, 'authors_email', []))
        # maintainers/maintainers_email: not standard PluginData fields;
        # will be empty until the Gramps register() API supports them.
        metadata['maintainers']       = _to_list(getattr(plugin, 'maintainers', []))
        metadata['maintainers_email'] = _to_list(getattr(plugin, 'maintainers_email', []))

        self.metadata_cache[addon_name] = metadata
        return metadata

    def extract_string_value(self, line):
        """
        Extract a simple string value like: "maintainers": "Brian McCullough"
        or name = _("Virtual Keyboard")
        Strips translation markers _()
        """
        try:
            if ':' in line:
                value = line.split(':', 1)[1].strip()
            elif '=' in line:
                value = line.split('=', 1)[1].strip()
            else:
                return ""

            value = value.rstrip(',').strip()

            # Remove translation marker _( )
            if value.startswith('_('):
                value = value[2:]  # Remove _( from start
            if value.endswith(')'):
                value = value[:-1]  # Remove ) from end

            # Remove quotes
            value = value.strip('"').strip("'").strip()

            return value
        except:
            return ""

    def extract_list_from_line(self, line):
        """
        Extract list items from a line like: authors = ["Name1", "Name2"]
        Returns all items in the list
        Validates proper formatting
        """
        items = []
        try:
            # Find content between brackets
            start = line.find('[')
            end = line.rfind(']')
            if start != -1 and end != -1:
                list_str = line[start+1:end]

                # Check for malformed entries (comma inside a quoted string)
                # This would indicate ["Name1, Name2"] instead of ["Name1", "Name2"]
                in_quotes = False
                quote_char = None
                has_comma_in_quotes = False

                for i, char in enumerate(list_str):
                    if char in ['"', "'"]:
                        if not in_quotes:
                            in_quotes = True
                            quote_char = char
                        elif char == quote_char:
                            in_quotes = False
                            quote_char = None
                    elif char == ',' and in_quotes:
                        has_comma_in_quotes = True
                        break

                if has_comma_in_quotes:
                    # Return a special error marker
                    return ['__MALFORMED__']

                # Split by comma and clean up
                for item in list_str.split(','):
                    item = item.strip().strip('"').strip("'")
                    if item:  # Only add non-empty items
                        items.append(item)
        except:
            pass
        return items

    def _pdata_search_text(self, pdata, addon_name):
        """
        Build a single lowercase search string for one pdata object.
        Includes all registration key/value pairs plus the addon dir name.
        """
        parts = [addon_name]
        if pdata is None:
            return addon_name.lower()
        for val in (
            getattr(pdata, 'id',                    '') or '',
            getattr(pdata, 'name',                  '') or '',
            getattr(pdata, 'description',           '') or '',
            getattr(pdata, 'version',               '') or '',
            getattr(pdata, 'fname',                 '') or '',
            getattr(pdata, 'fpath',                 '') or '',
            getattr(pdata, 'help_url',              '') or '',
            getattr(pdata, 'gramps_target_version', '') or '',
            getattr(pdata, 'viewclass',             '') or '',
            getattr(pdata, 'optionclass',           '') or '',
            str(getattr(pdata, 'category',          '') or ''),
            str(getattr(pdata, 'load_on_reg',       '') or ''),
            ' '.join(getattr(pdata, 'authors',       []) or []),
            ' '.join(getattr(pdata, 'authors_email', []) or []),
            ' '.join(getattr(pdata, 'requires_mod',  []) or []),
            ' '.join(getattr(pdata, 'requires_exe',  []) or []),
            PTYPE_STR.get(getattr(pdata, 'ptype', None), ''),
        ):
            if val:
                parts.append(str(val))
        return ' '.join(parts).lower()

    def _plugin_matches(self, pdata, addon_name, filter_text, type_filter):
        """
        Return True if this individual plugin matches both filters.

        type_filter  — must match pdata.ptype's string label, or '' for all.
        filter_text  — all words must appear in the plugin's search text.
        """
        # "Selected" filter: keep only plugins that are checked now.
        # all_selections is flushed from the visible checkboxes at the
        # start of every list rebuild, so it is current here.
        if type_filter == _("Selected"):
            if not self.all_selections.get(getattr(pdata, 'id', None)):
                return False
        # Type filter: compare against this plugin's own type
        elif type_filter and type_filter != _("All Types"):
            ptype_num = getattr(pdata, 'ptype', None)
            ptype_str = PTYPE_STR.get(ptype_num, '') if ptype_num is not None else ''
            if ptype_str != type_filter:
                return False

        # Text filter
        if filter_text:
            haystack = self._pdata_search_text(pdata, addon_name)
            for word in filter_text.lower().split():
                if word not in haystack:
                    return False
        return True

    def matches_filter(self, addon_name, filter_text, type_filter=''):
        """
        Return True if any plugin in this addon directory matches both filters.
        Used to decide whether to show the directory group at all.
        """
        info = self.addon_info.get(addon_name, {})
        plugins = info.get('plugins', [])
        if not plugins:
            # No pdata objects — fall back to directory-name text search
            # (such a folder has no checkbox, so "Selected" hides it too)
            if type_filter and type_filter != _("All Types"):
                return False
            return not filter_text or filter_text.lower() in addon_name.lower()
        return any(
            self._plugin_matches(p, addon_name, filter_text, type_filter)
            for p in plugins
        )

    def _get_type_filter(self):
        """Return the currently selected type filter string, or '' for All."""
        if not hasattr(self, 'type_filter_combo'):
            return ''
        text = self.type_filter_combo.get_active_text()
        if not text or text == _("All Types"):
            return ''
        return text

    @staticmethod
    def _bump_patch_version(version_str):
        """
        Return `version_str` with its last dot-separated numeric
        component incremented by one (e.g. '1.8.12' -> '1.8.13'),
        matching the patch-version bump upstream make.py's own 'build'
        command performs automatically (see make_addon.py's module
        docstring for why that's not done automatically here).

        :param version_str: Current version string, or None/empty.
        :returns: the bumped version string.
        """
        if not version_str:
            return '0.0.1'
        parts = version_str.split('.')
        if parts and parts[-1].isdigit():
            parts[-1] = str(int(parts[-1]) + 1)
            return '.'.join(parts)
        return f"{version_str}.1"

    @staticmethod
    def _increment_gpr_plugin_version(gpr_dir, plugin_id):
        """
        Increment the patch version of ONE registration in place: the
        register() call whose id= is plugin_id, in one of the .gpr.py
        files in gpr_dir. Other registrations in the same file (e.g. an
        importer and an exporter registered together) are not touched.

        The call is found with the ast module, and only the characters
        of its version= string are replaced, so formatting, comments
        and quote style stay as they were. A version= that is not a
        plain one-line string (e.g. a variable) is left alone.

        :param gpr_dir: Folder holding the .gpr.py (pdata.fpath).
        :param plugin_id: The id= of the registration to bump.
        :returns: (filename, old_version, new_version), or None when
            nothing was changed.
        """
        for fname in sorted(glob.glob(os.path.join(gpr_dir, '*gpr.py'))):
            try:
                with open(fname, 'r', encoding='utf-8') as fh:
                    content = fh.read()
                tree = ast.parse(content)
            except (OSError, SyntaxError, ValueError):
                continue
            for node in ast.walk(tree):
                if not (isinstance(node, ast.Call)
                        and isinstance(node.func, ast.Name)
                        and node.func.id == 'register'):
                    continue
                kwargs = {kw.arg: kw.value for kw in node.keywords if kw.arg}
                id_node = kwargs.get('id')
                ver_node = kwargs.get('version')
                if not (isinstance(id_node, ast.Constant)
                        and id_node.value == plugin_id):
                    continue
                if not (isinstance(ver_node, ast.Constant)
                        and isinstance(ver_node.value, str)
                        and ver_node.lineno == ver_node.end_lineno):
                    return None
                old = ver_node.value
                parts = old.split('.')
                if not parts[-1].isdigit():
                    return None
                parts[-1] = str(int(parts[-1]) + 1)
                new = '.'.join(parts)
                # ast column offsets count UTF-8 bytes, so edit bytes
                lines = content.splitlines(keepends=True)
                raw = lines[ver_node.lineno - 1].encode('utf-8')
                literal = raw[ver_node.col_offset:ver_node.end_col_offset]
                quote = literal[:1].decode('utf-8')
                raw = (raw[:ver_node.col_offset]
                       + f"{quote}{new}{quote}".encode('utf-8')
                       + raw[ver_node.end_col_offset:])
                lines[ver_node.lineno - 1] = raw.decode('utf-8')
                try:
                    with open(fname, 'w', encoding='utf-8') as fh:
                        fh.write(''.join(lines))
                except OSError:
                    return None
                return (os.path.basename(fname), old, new)
        return None

    def _build_version_increment_widget(self, pdata):
        """
        Build the clickable version control shown at the end of a
        plugin row: a small icon + the current version, which toggles
        to a preview of the bumped version (dark red) when clicked. A
        flagged plugin has the version of its own register() call
        incremented the next time its bundle is built (see
        build_for_versions()).

        :param pdata: The plugin's registration data.
        :returns: a Gtk.ToggleButton.
        """
        plugin_id = getattr(pdata, 'id', None)
        version = getattr(pdata, 'version', None)
        button = Gtk.ToggleButton()
        button.set_relief(Gtk.ReliefStyle.NONE)
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        icon = Gtk.Image.new_from_icon_name(
            "preferences-system-sharing-symbolic", Gtk.IconSize.MENU)
        label = Gtk.Label()
        box.pack_start(icon, False, False, 0)
        box.pack_start(label, False, False, 0)
        button.add(box)

        self.version_bump_widgets[plugin_id] = {
            'button': button, 'icon': icon, 'label': label,
            'version': version,
            'name': getattr(pdata, 'name', None) or plugin_id,
            'gpr_dir': getattr(pdata, 'fpath', None),
        }
        self._refresh_version_bump_widget(plugin_id)

        button.set_active(plugin_id in self.pending_version_bumps)
        button.connect('toggled', self.on_toggle_version_bump, plugin_id)
        return button

    def _refresh_version_bump_widget(self, plugin_id):
        """
        Update an addon's version-control icon/label/tooltip to match
        self.pending_version_bumps, without touching its toggled state
        (used both right after creating the widget and from the toggle
        handler itself).
        """
        widget_info = self.version_bump_widgets.get(plugin_id)
        if not widget_info:
            return
        button = widget_info['button']
        icon, label = widget_info['icon'], widget_info['label']
        current_version = widget_info['version']
        plugin_name = widget_info['name']

        if plugin_id in self.pending_version_bumps:
            bumped = self._bump_patch_version(current_version)
            add_png = os.path.join(
                os.path.expanduser('~'), '.local', 'share', 'gramps',
                'images', 'add.png')
            if os.path.isfile(add_png):
                icon.set_from_file(add_png)
            else:
                icon.set_from_icon_name("list-add", Gtk.IconSize.MENU)
            label.set_markup(
                '<small>\u00a0<span foreground="darkred"><b>{}</b></span>'
                '</small>'.format(bumped))
            button.set_tooltip_text(
                _("Will bump {} to {} on next build. Click to"
                  " cancel.").format(plugin_name, bumped))
        else:
            icon.set_from_icon_name(
                "preferences-system-sharing-symbolic", Gtk.IconSize.MENU)
            label.set_markup(
                '<small>\u00a0{}</small>'.format(current_version or '?'))
            button.set_tooltip_text(
                _("Click to flag {} for a patch version bump ({} →"
                  " {}) on its next build.").format(
                      plugin_name, current_version or '?',
                      self._bump_patch_version(current_version)))

    def on_toggle_version_bump(self, button, plugin_id):
        """
        Handle clicking a plugin's version control: toggle whether the
        version of its registration will be bumped at the next build.
        """
        if button.get_active():
            self.pending_version_bumps.add(plugin_id)
        else:
            self.pending_version_bumps.discard(plugin_id)
        self._refresh_version_bump_widget(plugin_id)

    def rebuild_addon_list(self):
        """
        Rebuild the addon checkbox list.

        Layout per addon directory
        ──────────────────────────
        Single-plugin addon:
            ☐ Plugin Name [TYPE]
              <small>path  •  types</small>

        Multi-plugin addon (e.g. CardView with 11 plugins):
            📁 CardView/   [VIEW, VIEW, ...]   📂
              <small>path</small>
              ☐  Citation Card [VIEW]
              ☐  Event Card [VIEW]
              ☐  Family Card [VIEW]
              …

        The header row for multi-plugin groups is a non-interactive label —
        it shows the directory name, combined type list, and the MANIFEST
        folder button.  Each plugin gets its own indented checkbox.
        Gang-select: checking/unchecking any plugin in a group syncs all
        others in that group.

        Filter behaviour
        ────────────────
        Both the text filter and type combo operate at the PLUGIN level.
        A directory group is shown if any of its plugins match.  Within a
        group, plugins that do NOT match the current filter are hidden while
        matching ones remain visible.

        When self._listing_filter_names is set (via the addon list's
        right-click "Filter list to addons in this listing" menu item),
        it gates at the whole-addon-directory level instead: only
        directories named in that set are shown at all, on top of
        (not instead of) the text/type filters above.
        """
        # Flush current visible checkbox states
        for pid, checkbox in self.checkboxes.items():
            self.all_selections[pid] = checkbox.get_active()

        for child in self.addon_box.get_children():
            self.addon_box.remove(child)
        self.checkboxes = {}

        filter_text  = (self.author_filter_entry.get_text().strip()
                        if hasattr(self, 'author_filter_entry') else '')
        type_filter  = self._get_type_filter()
        build_mode   = self.get_build_mode()
        manifest_fn  = 'MANIFEST.beta' if build_mode == 'beta' else 'MANIFEST'

        try:
            Gtk.Image.new_from_icon_name("color-select-symbolic", Gtk.IconSize.BUTTON)
            use_image = True
        except Exception:
            use_image = False

        filtered_plugin_count = 0

        for addon_name in sorted(self.addon_info.keys()):
            if (self._listing_filter_names is not None
                    and addon_name not in self._listing_filter_names):
                continue
            info    = self.addon_info[addon_name]
            plugins = info.get('plugins', [])

            # Filter at plugin level — keep only matching plugins
            def _pname(p):
                return getattr(p, 'name', '') or ''

            plugins_sorted = sorted(plugins, key=_pname)
            matching = [p for p in plugins_sorted
                        if self._plugin_matches(p, addon_name,
                                                filter_text, type_filter)]
            if not matching:
                # No matching plugins in this directory — skip the whole group
                continue

            is_multi = len(plugins_sorted) > 1  # multi = dir has >1 plugin total

            # ── MANIFEST folder button (shared by whole group) ────────────
            manifest_path   = os.path.join(info['path'], manifest_fn)
            manifest_exists = os.path.exists(manifest_path)

            def _make_folder_btn(aname=addon_name, mp=manifest_path,
                                 me=manifest_exists):
                btn = Gtk.Button()
                btn.set_relief(Gtk.ReliefStyle.NONE)
                if use_image:
                    btn.set_image(Gtk.Image.new_from_icon_name(
                        "color-select-symbolic", Gtk.IconSize.BUTTON))
                else:
                    btn.set_label("📂")
                tip = (_(
                    "Open {} for {}\n\nFile exists — will append a refreshed "
                    "directory listing and open in your text editor.\n\n"
                    "Path: {}"
                ).format(manifest_fn, aname, mp)
                       if me else
                       _(
                    "Create {} for {}\n\nFile does not exist yet — will create "
                    "it with a header and directory listing, then open in your "
                    "text editor.\n\nFolder: {}"
                ).format(manifest_fn, aname, info['path']))
                btn.set_tooltip_text(tip)
                btn.connect('clicked',
                            lambda w, n=aname: self.on_open_manifest_for_addon(n))
                return btn

            if is_multi:
                # ── Group header row (non-interactive) ────────────────────
                # Shows the directory name + combined types + MANIFEST
                # button. A bundle has no version of its own: each
                # plugin row below carries its own version control.
                # The MANIFEST stays here because it belongs to the
                # folder, which becomes one .addon.tgz.
                hdr_hbox = Gtk.Box(
                    orientation=Gtk.Orientation.HORIZONTAL, spacing=4)

                all_types_str = ', '.join(sorted(info['types']))
                hdr_label = Gtk.Label()
                hdr_label.set_markup(
                    '<b>📁 {}/</b>  <small>[{}]</small>'.format(
                        addon_name, all_types_str))
                hdr_label.set_halign(Gtk.Align.START)
                hdr_label.set_hexpand(True)

                path_label = Gtk.Label()
                path_label.set_markup(
                    '<small><i>{}</i></small>'.format(info['path']))
                path_label.set_halign(Gtk.Align.START)

                hdr_vbox = Gtk.Box(
                    orientation=Gtk.Orientation.VERTICAL, spacing=1)
                hdr_vbox.pack_start(hdr_label,  False, False, 0)
                hdr_vbox.pack_start(path_label, False, False, 0)

                hdr_hbox.pack_start(hdr_vbox,          True,  True,  0)
                hdr_hbox.pack_start(_make_folder_btn(), False, False, 0)
                self.addon_box.pack_start(hdr_hbox, False, False, 0)

                # ── One checkbox row per matching plugin ───────────────────
                for pdata in matching:
                    pid = getattr(pdata, 'id', None)
                    if not pid:
                        continue
                    self.plugin_to_dir[pid] = addon_name

                    cb_label = getattr(pdata, 'name', pid) or pid

                    plugin_id_label = getattr(pdata, 'id', '')
                    row = Gtk.Box(
                        orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
                    cb = Gtk.CheckButton()
                    cb.set_margin_start(20)
                    if pid in self.all_selections:
                        cb.set_active(self.all_selections[pid])
                    cb.connect('toggled', self.on_selection_changed, pid)

                    # Hotlink on the plugin name itself -- opens this
                    # addon's own folder (not the checkbox, which is
                    # reserved for selecting it for packaging). The
                    # gap between the checkbox and this hotlink is
                    # made genuinely un-clickable (see
                    # _new_dead_space() and
                    # _tighten_hotlink_hit_area()) so aiming for the
                    # checkbox doesn't accidentally trigger the link.
                    name_link = Gtk.LinkButton.new_with_label("", cb_label)
                    name_link.set_relief(Gtk.ReliefStyle.NONE)
                    name_link.set_halign(Gtk.Align.START)
                    name_link.set_tooltip_text(
                        _("Open the folder for {} in your file"
                          " browser.").format(addon_name))
                    name_link.connect(
                        "activate-link", self.cb_open_addon_folder,
                        info['path'])
                    _tighten_hotlink_hit_area(name_link)

                    name_row = Gtk.Box(
                        orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
                    name_row.pack_start(cb,               False, False, 0)
                    name_row.pack_start(_new_dead_space(), False, False, 0)
                    name_row.pack_start(name_link,        False, False, 0)

                    id_lbl = Gtk.Label()
                    id_lbl.set_markup(
                        '<small><tt>    {}</tt></small>'.format(plugin_id_label))
                    id_lbl.set_halign(Gtk.Align.START)

                    cb_vbox = Gtk.Box(
                        orientation=Gtk.Orientation.VERTICAL, spacing=0)
                    cb_vbox.pack_start(name_row, False, False, 0)
                    cb_vbox.pack_start(id_lbl,   False, False, 0)

                    row.pack_start(cb_vbox, True, True, 0)
                    row.pack_start(
                        self._build_version_increment_widget(pdata),
                        False, False, 0)
                    self.checkboxes[pid] = cb
                    self.addon_box.pack_start(row, False, False, 0)
                    filtered_plugin_count += 1

                # Separator after the group
                sep = Gtk.Separator()
                sep.set_margin_top(3)
                sep.set_margin_bottom(3)
                self.addon_box.pack_start(sep, False, False, 0)

            else:
                # ── Single-plugin addon: one combined row ──────────────────
                pdata = matching[0]
                pid   = getattr(pdata, 'id', None)
                if not pid:
                    continue
                self.plugin_to_dir[pid] = addon_name

                cb_label = getattr(pdata, 'name', pid) or pid

                row_hbox = Gtk.Box(
                    orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
                cb_vbox  = Gtk.Box(
                    orientation=Gtk.Orientation.VERTICAL, spacing=1)

                cb = Gtk.CheckButton()
                if pid in self.all_selections:
                    cb.set_active(self.all_selections[pid])
                cb.connect('toggled', self.on_selection_changed, pid)

                # Hotlink on the plugin name itself -- opens this
                # addon's own folder (not the checkbox, which is
                # reserved for selecting it for packaging). The gap
                # between the checkbox and this hotlink is made
                # genuinely un-clickable (see _new_dead_space() and
                # _tighten_hotlink_hit_area()) so aiming for the
                # checkbox doesn't accidentally trigger the link.
                name_link = Gtk.LinkButton.new_with_label("", cb_label)
                name_link.set_relief(Gtk.ReliefStyle.NONE)
                name_link.set_halign(Gtk.Align.START)
                name_link.set_tooltip_text(
                    _("Open the folder for {} in your file"
                      " browser.").format(addon_name))
                name_link.connect(
                    "activate-link", self.cb_open_addon_folder,
                    info['path'])
                _tighten_hotlink_hit_area(name_link)

                name_row = Gtk.Box(
                    orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
                name_row.pack_start(cb,               False, False, 0)
                name_row.pack_start(_new_dead_space(), False, False, 0)
                name_row.pack_start(name_link,        False, False, 0)
                cb_vbox.pack_start(name_row, False, False, 0)

                detail = Gtk.Label()
                detail.set_markup(
                    '<small><i>   {}  •  {}</i></small>'.format(
                        ', '.join(sorted(info['types'])), info['path']))
                detail.set_halign(Gtk.Align.START)
                cb_vbox.pack_start(detail, False, False, 0)

                version_widget = self._build_version_increment_widget(pdata)

                row_hbox.pack_start(cb_vbox,            True,  True,  0)
                row_hbox.pack_start(version_widget,     False, False, 0)
                row_hbox.pack_start(_make_folder_btn(), False, False, 0)

                self.checkboxes[pid] = cb
                self.addon_box.pack_start(row_hbox, False, False, 0)
                filtered_plugin_count += 1

        self.update_selection_count(filter_text, filtered_plugin_count)
        self.addon_box.show_all()
        self._update_version_compatibility_hints()

    def cb_addon_list_button_press(self, widget, event):
        """
        Right-click handler for the addon list: shows a context menu
        offering two actions on the currently selected Gramps
        Version's addons-en.json listing -- filtering the addon list
        down to just what's already in that listing, and opening the
        file directly for editing.

        Both actions require exactly one "Gramps Versions" checkbox
        to be checked (see :meth:`_get_single_selected_version`) and
        that version's addons-en.json to already exist -- with none
        or several versions checked, or a version that hasn't been
        listed yet, there's no single unambiguous file for either
        action to act on, so both menu items are shown but disabled.

        :param widget: the widget the right-click landed on (the
            addon list's EventBox); used to anchor the menu via
            attach_to_widget() so GDK can resolve its toplevel via
            this widget's ancestry -- without that, popping up a
            freshly created Gtk.Menu can log a GDK-WARNING ("Tried to
            map a popup with a non-top most parent"), since the menu
            otherwise has no widget to walk up from to find its
            transient parent.
        :param event: the Gdk button-press event.
        :returns: True (event handled) for a right-click, False
                  otherwise so other button presses behave normally.
        """
        if event.button != 3:
            return False

        version = self._get_single_selected_version()
        listing_path = self._listing_json_path(version) if version else None
        available = bool(listing_path and os.path.isfile(listing_path))
        label = self._version_label(version[len('gramps'):]) if version \
            else _("selected version")

        menu = Gtk.Menu()
        menu.attach_to_widget(widget, None)

        if self._listing_filter_names is not None:
            filter_item = Gtk.MenuItem(
                label=_("Show all addons (clear listing filter)"))
            filter_item.set_sensitive(True)
        else:
            filter_item = Gtk.MenuItem(
                label=_("Filter list to addons in {}'s listing").format(
                    label))
            filter_item.set_sensitive(available)
        filter_item.connect(
            'activate', self.cb_toggle_listing_filter, listing_path)
        menu.append(filter_item)

        open_item = Gtk.MenuItem(
            label=fill_names(_("Open the {listing} of {version} for editing"),
                             listing="addons-en.json", version=label))
        open_item.set_sensitive(available)
        open_item.connect('activate', self.cb_open_listing_json, listing_path)
        menu.append(open_item)

        menu.show_all()
        menu.popup_at_pointer(event)
        return True

    @staticmethod
    def _load_listing_addon_names(path):
        """
        Return the set of addon (directory) names present in an
        addons-en.json listing file, derived from each entry's 'z'
        field by stripping the '.addon.tgz' suffix -- the same name
        this tool uses as the addon's directory/checkbox key
        elsewhere (see e.g. :meth:`run_make_command`, which builds
        that same '<addon_name>.addon.tgz' filename).

        :param path: path to an addons-en.json listing file.
        :returns: set of addon names, or an empty set if the file
                  can't be read as the expected list of dict entries.
        """
        try:
            with open(path, 'r', encoding='utf-8') as f:
                entries = json.load(f)
        except (OSError, json.JSONDecodeError):
            return set()
        if not isinstance(entries, list):
            return set()
        names = set()
        for entry in entries:
            z = entry.get('z') if isinstance(entry, dict) else None
            if isinstance(z, str) and z.endswith('.addon.tgz'):
                names.add(z[:-len('.addon.tgz')])
        return names

    def cb_toggle_listing_filter(self, _menuitem, listing_path):
        """
        Handle the addon list's "Filter list to addons in this
        listing" / "Show all addons" context menu item: toggles
        self._listing_filter_names between the addon names found in
        ``listing_path`` and None (no filter), then rebuilds the list.

        :param listing_path: path to the addons-en.json listing file
            to filter by, as resolved when the menu was opened.
        """
        if self._listing_filter_names is not None:
            self._listing_filter_names = None
        elif listing_path and os.path.isfile(listing_path):
            self._listing_filter_names = self._load_listing_addon_names(
                listing_path)
        self.rebuild_addon_list()

    def cb_open_listing_json(self, _menuitem, listing_path):
        """
        Handle the addon list's "Open addons-en.json for editing"
        context menu item: opens ``listing_path`` in the OS default
        text editor, the same cross-platform approach used to open
        MANIFEST files (see :meth:`on_edit_manifest`).

        :param listing_path: path to the addons-en.json listing file
            to open, as resolved when the menu was opened.
        """
        if not listing_path or not os.path.isfile(listing_path):
            return
        try:
            if sys.platform.startswith('win'):
                os.startfile(listing_path)
            elif sys.platform.startswith('darwin'):
                subprocess.Popen(['open', listing_path])
            else:
                for editor_cmd in ['xdg-open', 'gedit', 'kate', 'mousepad',
                                    'xed', 'geany', 'nano']:
                    try:
                        subprocess.Popen([editor_cmd, listing_path])
                        break
                    except FileNotFoundError:
                        continue
        except Exception as e:  # pylint: disable=broad-except
            ErrorDialog(
                _("Could Not Open File"),
                _("Could not open {}:\n{}").format(listing_path, e),
                parent=self.window)

    def on_selection_changed(self, widget, pid=None):
        """
        Called when any checkbox is toggled.

        Gang-select: if the toggled plugin belongs to a multi-plugin addon
        directory, all other visible plugins in that same directory are set
        to the same state.  A re-entrancy guard prevents the gang callbacks
        from triggering further gang cascades.
        """
        if self._gang_in_progress:
            return

        # Save the state of the toggled plugin
        if pid is not None:
            self.all_selections[pid] = widget.get_active()

            # Gang-select: find all visible siblings in the same directory
            addon_dir = self.plugin_to_dir.get(pid)
            if addon_dir:
                new_state = widget.get_active()
                self._gang_in_progress = True
                try:
                    for sibling_pid, sibling_cb in self.checkboxes.items():
                        if (sibling_pid != pid
                                and self.plugin_to_dir.get(sibling_pid) == addon_dir):
                            sibling_cb.set_active(new_state)
                            self.all_selections[sibling_pid] = new_state
                finally:
                    self._gang_in_progress = False

        # Save all currently visible checkbox states
        for p, checkbox in self.checkboxes.items():
            self.all_selections[p] = checkbox.get_active()

        filter_text = ""
        if hasattr(self, 'author_filter_entry'):
            filter_text = self.author_filter_entry.get_text().strip()
        self.update_selection_count(filter_text, len(self.checkboxes))
        self._update_version_compatibility_hints()

    def _update_version_compatibility_hints(self):
        """
        When exactly one addon (per :meth:`_get_selected_addon_dirs`,
        the same single source of truth every other selection-driven
        action uses -- addon directories, not individual plugin ids,
        so gang-select's multi-plugin addons still count as one) is
        currently selected, grey out and redden the Gramps-version
        checkboxes its own .gpr.py cannot support, per
        make_addon.check_gpr_version_coverage() (a version-range gate
        that excludes it, or a hardcoded literal
        gramps_target_version naming a different one). This is a
        lightweight, opt-in "proofread before you build" hint -- it
        never rewrites the .gpr.py itself, and it does not change
        what build_for_versions() actually refuses at build time
        (that check runs independently, every time).

        Reverts every version checkbox to its normal, fully-enabled
        state as soon as zero or more than one addon is selected:
        "the incompatible versions" isn't a single, well-defined set
        once more than one addon (potentially with different
        constraints) is in play.
        """
        if not self.version_checkboxes:
            return

        selected_dirs = self._get_selected_addon_dirs()

        coverage = {}
        not_adaptive = False
        if len(selected_dirs) == 1:
            addon_name = next(iter(selected_dirs))
            addon_path = self.addon_info.get(addon_name, {}).get('path')
            make_addon = _get_make_addon_module()
            if make_addon is not None and addon_path:
                coverage = make_addon.check_gpr_version_coverage(
                    addon_path, list(self.version_checkboxes.keys()))
                if hasattr(make_addon, 'gpr_is_adaptive'):
                    not_adaptive = (
                        make_addon.gpr_is_adaptive(addon_path) is False)
        # For a non-adaptive addon with no hardcoded target version,
        # only the running Gramps version is known to be safe: mark
        # the others orange (still selectable -- the warning at build
        # time can be overridden).
        running = self._running_gramps_version_code()
        unsafe_codes = set()
        if not_adaptive and not any(
                value is True for value in coverage.values()):
            unsafe_codes = {code for code in self.version_checkboxes
                            if code != running}
        unsafe_tip = fill_names(
            _("The {gpr} of the selected addon is not adaptive: it has no"
              " version check. Packing it for this Gramps version lists"
              " it there as compatible without any check. Pack and Ship"
              " asks before doing so."),
            gpr=".gpr.py")

        version_labels = {
            entry['code']: entry['label'] for entry in self.available_versions}

        for code, checkbox in self.version_checkboxes.items():
            incompatible = coverage.get(code) is False
            checkbox.set_sensitive(not incompatible)
            if incompatible:
                # Also uncheck -- a disabled-but-still-checked box would
                # otherwise silently stay selected for building.
                checkbox.set_active(False)
            label_widget = checkbox.get_child()
            if label_widget is not None and hasattr(label_widget, 'set_markup'):
                plain_label = version_labels.get(code, code)
                if incompatible:
                    label_widget.set_markup(
                        '<span foreground="red">{}</span>'.format(plain_label))
                elif code in unsafe_codes:
                    label_widget.set_markup(
                        '<span foreground="#d97700">⚠ {}</span>'.format(
                            plain_label))
                else:
                    label_widget.set_text(plain_label)
            # Remember the normal tooltip the first time, so it can be
            # put back when the warning no longer applies.
            if not hasattr(self, '_version_tooltips'):
                self._version_tooltips = {}
            normal_tip = self._version_tooltips.setdefault(
                code, checkbox.get_tooltip_text())
            if code in unsafe_codes:
                checkbox.set_tooltip_text(
                    unsafe_tip + "\n\n" + (normal_tip or ""))
            else:
                checkbox.set_tooltip_text(normal_tip)

    def on_build_mode_changed(self, widget):
        """
        Called when the β/Δ radio button changes — refresh per-row folder button
        tooltips so they always name the correct MANIFEST file.
        """
        # Rebuild the list so folder-button tooltips update to the new filename.
        self.rebuild_addon_list()

    def on_open_manifest_for_addon(self, addon_name):
        """
        Open or create the MANIFEST (or MANIFEST.beta) for a single addon.
        Temporarily selects only this addon's plugins so on_edit_manifest
        can find it, then restores the previous selection state.
        """
        saved_selections = dict(self.all_selections)

        # Temporarily select only plugin_ids belonging to this addon
        for pid in self.all_selections:
            self.all_selections[pid] = (
                self.plugin_to_dir.get(pid) == addon_name)

        # Sync visible checkboxes without firing gang-select
        self._gang_in_progress = True
        try:
            for pid, cb in self.checkboxes.items():
                cb.set_active(self.all_selections.get(pid, False))
        finally:
            self._gang_in_progress = False

        self.on_edit_manifest(None)

        # Restore
        self.all_selections = saved_selections
        self._gang_in_progress = True
        try:
            for pid, cb in self.checkboxes.items():
                cb.set_active(saved_selections.get(pid, False))
        finally:
            self._gang_in_progress = False

        filter_text = ""
        if hasattr(self, 'author_filter_entry'):
            filter_text = self.author_filter_entry.get_text().strip()
        self.update_selection_count(filter_text, len(self.checkboxes))

    def _get_selected_addon_dirs(self):
        """
        Return the set of addon directory names currently selected --
        the single source of truth for "what's selected".

        Both the bottom-bar "Selected bundles: X/Y" readout (see
        :meth:`update_selection_count`) and every action that operates
        on a selection -- Build Selected, Amend Listings, Pack and
        Ship, Clean (all via :meth:`get_selected_addons`) -- are
        derived from this exact same set. That guarantees, by
        construction, that those actions can never act on more (or
        less) than what the status bar is showing as selected at that
        moment: there's only one place selection state is computed
        from, not two computations that could drift apart.

        Flushes every currently rendered checkbox's live state into
        self.all_selections first (a plugin hidden by the current
        filter/search keeps whatever state it last had -- see the
        self.all_selections comment in __init__ -- but nothing
        visible right now can be stale).

        :returns: set of addon directory names.
        """
        for pid, checkbox in self.checkboxes.items():
            self.all_selections[pid] = checkbox.get_active()

        return {
            self.plugin_to_dir[pid]
            for pid, checked in self.all_selections.items()
            if checked and pid in self.plugin_to_dir
            and self.plugin_to_dir[pid] in self.addon_info
        }

    def update_selection_count(self, filter_text, visible_plugin_count):
        """
        When nothing is selected, show the same "Found N bundles (M
        registered plugins) in your Gramps installation" summary that
        used to live in a permanent label at the top of the window.
        As soon as at least one bundle is selected, replace it with
        the live "Selected bundles: X/Y • Plugins: V/T" readout.
        X = selected bundle count, Y = total bundles
        V = visible plugins (after filter), T = total plugins
        The Plugins ratio uses V/T so the user can see filter effect at a glance.
        """
        if not hasattr(self, 'bottom_status_label'):
            return

        selected_count = len(self._get_selected_addon_dirs())
        total_bundles  = getattr(self, '_total_bundles',  len(self.addon_info))
        total_plugins  = getattr(self, '_total_plugins',
                                  sum(len(i['plugins'])
                                      for i in self.addon_info.values()))

        if selected_count == 0:
            self.bottom_status_label.set_markup(
                _("<small>Found <b>{bundle_count}</b> bundles"
                  " (<b>{plugin_count}</b> registered plugins) in your"
                  " Gramps installation.</small>").format(
                      bundle_count=total_bundles, plugin_count=total_plugins))
        else:
            self.bottom_status_label.set_markup(
                f"<small>Selected bundles: <b>{selected_count}/{total_bundles}</b>"
                f"  \u2022  "
                f"Plugins: <b>{visible_plugin_count}/{total_plugins}</b></small>"
            )

    def on_filter_changed(self, widget):
        """
        Handle filter text changes
        """
        self.rebuild_addon_list()

    def on_clear_filter(self, widget=None):
        """
        Clear the search entry and reset the type combo to 'All Types'.
        Called by the type combo reset path; the SearchEntry clears itself
        via its built-in ✕ button which fires search-changed automatically.
        """
        self.author_filter_entry.set_text("")
        if hasattr(self, 'type_filter_combo'):
            self.type_filter_combo.set_active(0)

    def get_selected_addons(self):
        """
        Return a sorted list of (addon_dir_name, addon_path) tuples
        for every addon directory currently selected.

        Built directly from :meth:`_get_selected_addon_dirs` -- the
        same set the bottom-bar "Selected bundles: X/Y" status readout
        counts -- so Build Selected, Amend Listings, Pack and Ship,
        and Clean all act on exactly what that readout shows as
        selected, and nothing else (in particular, never anything
        merely saved as True in some *other* named configuration in
        APS.ini -- named configurations only affect selection when
        actually loaded via the Configuration combo).
        """
        selected_dirs = self._get_selected_addon_dirs()
        return sorted(
            (name, self.addon_info[name]['path']) for name in selected_dirs)

    def on_select_all(self, widget):
        """Select all visible plugin checkboxes (gang-select fires automatically)."""
        self._gang_in_progress = True
        try:
            for checkbox in self.checkboxes.values():
                checkbox.set_active(True)
        finally:
            self._gang_in_progress = False
        self.on_selection_changed(None)

    def on_deselect_all(self, widget):
        """Deselect ALL plugin checkboxes including ones hidden by filter."""
        for pid in list(self.all_selections):
            self.all_selections[pid] = False
        self._gang_in_progress = True
        try:
            for checkbox in self.checkboxes.values():
                checkbox.set_active(False)
        finally:
            self._gang_in_progress = False
        self.on_selection_changed(None)

    def run_make_command(self, addon_path: str, command: str,
                          build_mode: str = 'beta',
                          version: str | None = None
                          ) -> tuple[bool, str, str]:
        """
        Run a make_addon.py packaging command in-process.

        make_addon.py (bundled alongside this tool) is imported once
        as a regular Python module via :func:`_get_make_addon_module`
        and its ``run_command()`` is called directly -- no subprocess
        or external Python interpreter is involved. This works
        identically on Linux, macOS, and Windows, whether Gramps is
        running from source or as a frozen (cx_Freeze) application,
        because it never needs to locate a second interpreter to shell
        out to (see the commit history for the "Gramps is already
        running!" bug this replaced, where ``sys.executable`` turned
        out to be the Gramps application itself under cx_Freeze).

        version:    Gramps version code (e.g. 'gramps52') selecting which
                    output subdirectory to build/list into. Defaults to
                    the module-level GRAMPS_VERSION when not given.
        build_mode: 'beta' or 'release'

        For 'listing', make_addon.py delegates to the matching bundled
        make<NN>.py when present, which generates every language the
        addon has a po/*-local.po for -- no separate language selection
        is needed here. That delegation is the one remaining place
        this tool still runs code as a subprocess: make<NN>.py is
        fetched as-is from gramps-project/addons-source (see "Update
        make.py Scripts"), so it is treated as untrusted, unmodified
        third-party code and kept process-isolated rather than
        imported.

        Every addons-<lang>.json that already exists is updated with
        the addon either way. Whether a run may also create NEW
        language files follows this tool's own "Multilingual"
        checkbox (deselected by default) --
        read fresh on every call, not just once at startup, so
        toggling it takes effect on the very next action.

        Every call also appends the CLI-equivalent command for
        whatever ran to this plugin's own logs/<self.session_id>.log
        -- a plain-text session transcript, always in the same fixed,
        easy-to-find location regardless of where output is
        redirected, that a developer can read (or directly copy
        commands from) to learn how to drive make.py themselves from
        a terminal, without the GUI. See make_addon.py's
        run_command() for the log format.
        """
        addon_name = os.path.basename(addon_path)
        version = version or GRAMPS_VERSION

        # Output directory - create <version> subdirectory (e.g. gramps52)
        # under the chosen output parent folder (defaults to scripts_dir).
        output_dir = os.path.join(self.get_output_parent_dir(), version)
        os.makedirs(output_dir, exist_ok=True)

        make_addon = _get_make_addon_module()
        if make_addon is None:
            return False, "", _("make_addon.py not found in AddonPackShip directory")

        try:
            extra_kwargs = {}
            if command == 'listing':
                # Only 'listing' actually uses this -- see
                # make_addon.run_command()'s docstring. Keeping it out
                # of every other call's kwargs means a make_addon.py
                # that predates this parameter (a version mismatch
                # between this file and that one) only breaks listing,
                # not build/compile/clean too.
                extra_kwargs['multilingual'] = (
                    self.multilingual_check.get_active()
                    if hasattr(self, 'multilingual_check') else False)
            if 'wait_callback' in inspect.signature(
                    make_addon.run_command).parameters:
                # Keeps the window responsive (and the progress window
                # drawn) while make_addon.py waits on a child process
                # -- see _pump_gtk_events(). Checked rather than always
                # passed, so an older make_addon.py still works.
                extra_kwargs['wait_callback'] = self._pump_gtk_events
            success, stdout, stderr = make_addon.run_command(
                command, addon_path, output_dir, build_mode=build_mode,
                session_id=self.session_id, **extra_kwargs)

            # Add output location info to stdout
            if success:
                if command == 'listing':
                    self._normalize_listing_jsons(output_dir)
                location_info = self.get_output_location_info(command, output_dir, addon_name)
                stdout = stdout + "\n" + location_info

            return success, stdout, stderr
        except Exception as e:  # pylint: disable=broad-except
            # Belt-and-braces: run_command() already catches and
            # reports its own internal errors, but this keeps a bad
            # make_addon.py (e.g. after a hand edit) from ever being
            # able to take the whole Gramps process down with it.
            LOG.exception("run_make_command(%s) failed", command)
            return False, "", str(e)

    def _version_label_for(self, code):
        """
        Return the human label (e.g. '6.0') of a version code such as
        'gramps60', falling back to the code itself.
        """
        for entry in self.available_versions:
            if entry['code'] == code:
                return entry['label']
        return code

    def _plan_addon_versions(self, addons, versions):
        """
        Decide, before anything is built or listed, which of the
        checked Gramps `versions` each addon is packed and listed for,
        and object when a non-adaptive addon is about to be packed for
        more than one version.

        An adaptive .gpr.py (see make_addon.gpr_is_adaptive()) has a
        version-range gate, so each Gramps version checks the claim
        itself; it is packed for every checked version its gate
        accepts. Versions its gate rejects are left out, of the
        listing as well as of the package, unless the Options tab
        override "Duplicate into unverified/incompatible versions
        anyway" is on.

        A non-adaptive .gpr.py was written for one Gramps version.
        Packing it for several versions lists it in each of them as
        compatible, without anyone having checked. When that would
        happen, a dialog explains the danger and offers: only the safe
        version (the hardcoded ``gramps_target_version``, or else the
        running Gramps version, where the installed copy is known to
        load), every checked version anyway, or cancel.

        :param addons: list of (addon_name, addon_path) tuples.
        :param versions: the checked version codes.
        :returns: ``(plan, notes, forced)`` -- `plan` maps each addon
            name to its list of version codes (possibly empty),
            `notes` maps addon names to lines for the results window,
            and `forced` is the set of addon names whose versions were
            overridden. ``None`` when the user cancelled.
        """
        plan = {name: list(versions) for name, _path in addons}
        notes = {}
        forced = set()
        if len(versions) <= 1:
            return plan, notes, forced
        make_addon = _get_make_addon_module()
        if make_addon is None or not hasattr(make_addon, 'gpr_is_adaptive'):
            return plan, notes, forced

        force_checkbox = (self.force_uncovered_check.get_active()
                          if hasattr(self, 'force_uncovered_check')
                          else False)
        running = self._running_gramps_version_code()
        objections = []   # (addon_name, reason, safe_versions)
        for name, path in addons:
            adaptive = make_addon.gpr_is_adaptive(path)
            coverage = make_addon.check_gpr_version_coverage(path, versions)
            if adaptive is None:
                continue  # could not be tested: behave as before
            if adaptive:
                rejected = [v for v in versions if coverage.get(v) is False]
                if rejected and not force_checkbox:
                    plan[name] = [v for v in versions if v not in rejected]
                    notes.setdefault(name, []).append(fill_names(
                        _("  Not packed or listed for {versions}: the"
                          " version check in the {gpr} of this addon"
                          " rejects them."),
                        versions=", ".join(rejected), gpr=".gpr.py"))
                continue
            matching = [v for v in versions if coverage.get(v) is True]
            if matching:
                reason = fill_names(
                    _("its {gpr} names one Gramps version in {target}"),
                    gpr=".gpr.py", target="gramps_target_version")
                safe = matching
            else:
                reason = fill_names(
                    _("its {gpr} has no version check"), gpr=".gpr.py")
                safe = [running] if running in versions else []
            objections.append((name, reason, safe))

        if not objections:
            return plan, notes, forced

        choice = self._ask_about_non_adaptive_addons(objections, versions)
        if choice is None:
            return None
        for name, _reason, safe in objections:
            if choice == 'all':
                forced.add(name)
                notes.setdefault(name, []).append(fill_names(
                    _("  ⚠ Packed for every checked Gramps version on"
                      " request, although its {gpr} is not adaptive."
                      " Make sure that the code really works in each"
                      " of them."),
                    gpr=".gpr.py"))
            else:
                plan[name] = safe
                if safe:
                    notes.setdefault(name, []).append(fill_names(
                        _("  Packed and listed only for {versions}: its"
                          " {gpr} is not adaptive."),
                        versions=", ".join(safe), gpr=".gpr.py"))
                else:
                    notes.setdefault(name, []).append(fill_names(
                        _("  Skipped: its {gpr} is not adaptive, and"
                          " the Gramps version it was written for is"
                          " not checked."),
                        gpr=".gpr.py"))
        return plan, notes, forced

    def _ask_about_non_adaptive_addons(self, objections, versions):
        """
        Show the warning about packing non-adaptive addons for several
        Gramps versions, and return the choice.

        :param objections: list of (addon_name, reason, safe_versions).
        :param versions: the checked version codes.
        :returns: ``'safe'``, ``'all'``, or ``None`` for Cancel.
        """
        lines = []
        for name, reason, safe in objections:
            if safe:
                target = ", ".join(self._version_label_for(v) for v in safe)
            else:
                target = _("none of the checked versions")
            lines.append(_("  • {addon}: {reason}. Safe: {target}").format(
                addon=name, reason=reason, target=target))
        checked = ", ".join(self._version_label_for(v) for v in versions)

        dialog = Gtk.MessageDialog(
            transient_for=self.window, modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.NONE,
            text=_("Packing these addons for several Gramps versions"
                   " can break them for users"))
        dialog.format_secondary_text(fill_names(
            _("You checked Gramps {checked}. These addons are not"
              " adaptive:\n\n{addons}\n\n"
              "An adaptive {gpr} checks the running Gramps version"
              " before it registers the addon (for example"
              " {example}). Without that check, the same package is"
              " listed in the Addon Manager of every checked Gramps"
              " version as compatible, although it was written for one"
              " version only. Users of the other versions can then"
              " install an addon that fails to load or does not work"
              " correctly.\n\n"
              "Only the safe versions (recommended): pack and list each"
              " of these addons only for the version shown.\n"
              "All checked versions anyway: only when you have tested"
              " the addon in every checked version."),
            checked=checked, addons="\n".join(lines), gpr=".gpr.py",
            example="if VERSION_TUPLE >= (5, 2, 0):"))
        dialog.add_button(_("Cancel"), Gtk.ResponseType.CANCEL)
        all_button = dialog.add_button(
            _("All checked versions anyway"), 1)
        all_button.get_style_context().add_class("destructive-action")
        safe_button = dialog.add_button(
            _("Only the safe versions"), 2)
        safe_button.get_style_context().add_class("suggested-action")
        dialog.set_default_response(2)
        response = dialog.run()
        dialog.destroy()
        if response == 2:
            return 'safe'
        if response == 1:
            return 'all'
        return None

    def build_for_versions(self, addon_path, build_mode, versions,
                            force_uncovered=None):
        """
        Build the addon package once for the first of `versions`, then
        duplicate the resulting .addon.tgz into the download/ directory
        of every other selected version.

        For every plugin of this bundle flagged in
        self.pending_version_bumps (via its version control in the
        addon list), the version of its own register() call is
        incremented in place *before* building, so the new version
        number is what actually gets packaged -- then the flag is
        cleared and its version control shows the new version.

        The archive's contents (.py, .gpr.py, locale/*.mo, etc.) do not
        depend on which Gramps version is being targeted, so duplicating
        the file avoids rebuilding an identical archive once per version
        -- but only for versions the addon's own .gpr.py actually
        covers. Before duplicating, each of `other_versions` is checked
        via make_addon.check_gpr_version_coverage(): a version whose
        .gpr.py gate would not have registered under it (e.g. a gate
        written as ``if (6, 0, 0) <= VERSION_TUPLE:`` while building
        for gramps52) is skipped rather than shipped as if it were
        compatible. Leaving `force_uncovered` at its default (``None``)
        reads the "Duplicate into unverified/incompatible versions
        anyway" checkbox on the Options tab, read fresh on every call;
        pass ``True``/``False`` explicitly to override that checkbox
        for this call only.

        :returns: (success, stdout, stderr) for the primary build; any
            duplication notes (including skipped/forced versions) are
            appended to stdout.
        """
        if force_uncovered is None:
            force_uncovered = (self.force_uncovered_check.get_active()
                                if hasattr(self, 'force_uncovered_check')
                                else False)

        addon_name = os.path.basename(addon_path)
        primary, *other_versions = versions

        bump_notes = []
        bundle_ids = [
            getattr(p, 'id', None)
            for p in self.addon_info.get(addon_name, {}).get('plugins', [])]
        for plugin_id in [pid for pid in bundle_ids
                          if pid in self.pending_version_bumps]:
            self.pending_version_bumps.discard(plugin_id)
            widget_info = self.version_bump_widgets.get(plugin_id) or {}
            changed = self._increment_gpr_plugin_version(
                widget_info.get('gpr_dir') or addon_path, plugin_id)
            if changed is None:
                bump_notes.append(
                    _("  Version not bumped for {}: no plain version"
                      " string found in its registration").format(plugin_id))
                continue
            fname, old_version, new_version = changed
            bump_notes.append(
                _("  Version bumped in {} ({}): {} → {}").format(
                    fname, plugin_id, old_version, new_version))
            # Reflect the new version directly rather than re-scanning:
            # Gramps' plugin registry may still hold the pre-bump value
            # cached from when Gramps started, so a rescan here isn't
            # guaranteed to see the edit.
            if widget_info:
                widget_info['version'] = new_version
                self._refresh_version_bump_widget(plugin_id)

        success, stdout, stderr = self.run_make_command(
            addon_path, 'build', build_mode=build_mode, version=primary)
        if bump_notes:
            stdout = "\n".join(bump_notes) + "\n" + stdout
        if not success or not other_versions:
            return success, stdout, stderr

        coverage = {}
        make_addon = _get_make_addon_module()
        if make_addon is not None:
            coverage = make_addon.check_gpr_version_coverage(
                addon_path, other_versions)

        duplicate_notes = []
        versions_to_duplicate = []
        for version in other_versions:
            covered = coverage.get(version)
            if covered is False and not force_uncovered:
                duplicate_notes.append(
                    fill_names(
                        _("  Skipped {version}: the {gpr} of this addon"
                          " does not register under that version (its own"
                          " version-range gate excludes it) — not"
                          " duplicating a possibly-incompatible package."
                          " Re-run with the override to duplicate anyway"
                          " if you know it is actually compatible."),
                        version=version, gpr=".gpr.py"))
                continue
            if covered is False and force_uncovered:
                duplicate_notes.append(
                    fill_names(
                        _("  Warning: duplicating for {version} anyway"
                          " (forced) — the {gpr} of this addon does not"
                          " register under that version."),
                        version=version, gpr=".gpr.py"))
            elif covered is None:
                # Most .gpr.py files have no explicit version-range
                # gate at all, so this is the common case, not an
                # error state -- but it genuinely means compatibility
                # with `version` was never verified, only assumed (see
                # check_gpr_version_coverage()'s docstring). Note it
                # rather than duplicating as silently as a confirmed
                # `True`, since "no gate found" and "confirmed
                # compatible" are different claims that were
                # previously conflated.
                duplicate_notes.append(
                    fill_names(
                        _("  Note: the {gpr} of {addon} has no"
                          " version-range gate, so compatibility with"
                          " {version} was not verified — only assumed."
                          " Confirm that the actual code of the addon"
                          " supports that Gramps version before"
                          " publishing."),
                        gpr=".gpr.py", addon=addon_name, version=version))
            versions_to_duplicate.append(version)

        builder_dir = self.get_output_parent_dir()
        src_tgz = os.path.join(
            builder_dir, primary, 'download', f"{addon_name}.addon.tgz")

        if os.path.exists(src_tgz):
            for version in versions_to_duplicate:
                dst_dir = os.path.join(builder_dir, version, 'download')
                os.makedirs(dst_dir, exist_ok=True)
                dst_tgz = os.path.join(dst_dir, f"{addon_name}.addon.tgz")
                try:
                    shutil.copy2(src_tgz, dst_tgz)
                    duplicate_notes.append(
                        _("  Duplicated package for {}").format(version))
                except OSError as exc:
                    duplicate_notes.append(
                        _("  Could not duplicate package for {}: {}").format(
                            version, exc))
        elif versions_to_duplicate:
            duplicate_notes.append(
                _("  Warning: built package not found — nothing to"
                  " duplicate for {}").format(
                    ", ".join(versions_to_duplicate)))

        if duplicate_notes:
            stdout = stdout + "\n" + "\n".join(duplicate_notes)

        return success, stdout, stderr


    def _dedupe_listing_json(self, path):
        """
        Remove exact-duplicate entries from a single addons-<lang>.json
        listing file, keyed by ('i' plugin id, 'z' package filename,
        'g' target Gramps version) -- the combination that uniquely
        identifies one listed plugin's entry. Multiple *different*
        plugins from the same package (e.g. an importer and exporter
        both shipped in one .addon.tgz, each with their own 'i') are
        left alone; only literal repeats of the same plugin's entry
        are collapsed.

        Where a key repeats, the entry with the highest 'v' (version)
        is kept, in the position of the first occurrence. An earlier
        version kept the *last* occurrence, on the assumption that the
        later one was written later -- but make52.py inserts the new
        entry *before* the stale one it fails to remove, so that kept
        the stale version (e.g. Photo Tagging 1.1.3 over 1.2.4). On a
        version tie, the last occurrence is still kept.

        Leaves the file untouched -- rather than raising -- if it
        can't be read as JSON, isn't a list of dict entries, or has
        an entry missing 'i', 'z', or 'g' to key on.

        :param path: path to the addons-<lang>.json file to dedupe.
        :returns: True if the file was rewritten, False if it was
                  left as-is.
        """
        try:
            with open(path, 'r', encoding='utf-8') as f:
                entries = json.load(f)
        except (OSError, json.JSONDecodeError):
            return False

        if not isinstance(entries, list) or not all(
                isinstance(e, dict) and 'i' in e and 'z' in e and 'g' in e
                for e in entries):
            return False

        def version_key(entry):
            parts = []
            for part in str(entry.get('v', '')).split('.'):
                try:
                    parts.append((1, int(part)))
                except ValueError:
                    parts.append((0, part))
            return parts

        by_key = {}
        for entry in entries:
            key = (entry['i'], entry['z'], entry['g'])
            kept = by_key.get(key)
            if kept is None or version_key(entry) >= version_key(kept):
                by_key[key] = entry
        deduped = list(by_key.values())
        if len(deduped) == len(entries):
            return False

        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(deduped, f, indent=2, ensure_ascii=False)
                f.write('\n')
        except OSError:
            return False
        return True

    def _apply_listing_language_fallback(self, listings_dir):
        """
        Ensure every non-English addons-<lang>.json listing file under
        ``listings_dir`` that already has *some* genuinely localized
        content is a *complete* catalog -- one entry per plugin --
        rather than only the subset that happens to have a
        translation for that language.

        addons-en.json is the default/fallback catalog Gramps' Addon
        Manager already falls back to when a requested locale's file
        doesn't exist, not a superset the other languages overlay:
        each language file should carry its own localized entry where
        a translation exists, and fall back to the English entry for
        every plugin that has no translation into that language yet.
        Any plugin ('i') present in addons-en.json but missing from a
        given addons-<lang>.json has its English entry copied in
        verbatim.

        An addons-<lang>.json with *no* entries at all is left alone
        rather than turned into a full English-fallback clone: if a
        language has nothing genuinely translated yet, there's no
        reason to maintain a second catalog that's 100% English
        copies under a different filename -- the Addon Manager's own
        fallback to addons-en.json already covers that reader. (This
        assumes an existing lang file's entries, as written by
        make_addon.py, are genuinely localized rather than pre-filled
        fallback copies -- true of every sample listing seen so far,
        and only ever made false by a previous run of this same
        fallback step, whose fallback-filled entries are exact copies
        of their English counterparts and so don't change this
        emptiness check either way.)

        Note this can't manufacture an English entry that doesn't
        exist: some addons' template.pot originates in a language
        other than English (e.g. Finnish for parts of the Isotammi
        collection, or Esperanto for some other addons), with English
        generated as just one more .po translation among others, not
        guaranteed to exist yet. addons-en.json is only as complete
        as its own translations -- a plugin missing from it stays
        missing from every fallback-filled file too, correctly, since
        no language here actually has content for it yet.

        Does nothing if addons-en.json itself can't be read as the
        expected list of dict entries with an 'i' field.

        :param listings_dir: the ``listings/`` folder to normalize
            (e.g. ``<output_dir>/listings``).
        :returns: True if any file was rewritten, False otherwise.
        """
        en_path = os.path.join(listings_dir, 'addons-en.json')
        try:
            with open(en_path, 'r', encoding='utf-8') as f:
                en_entries = json.load(f)
        except (OSError, json.JSONDecodeError):
            return False
        if not isinstance(en_entries, list) or not all(
                isinstance(e, dict) and 'i' in e for e in en_entries):
            return False

        changed = False
        for fname in os.listdir(listings_dir):
            if not (fname.startswith('addons-') and fname.endswith('.json')
                    and fname != 'addons-en.json'):
                continue
            lang_path = os.path.join(listings_dir, fname)
            try:
                with open(lang_path, 'r', encoding='utf-8') as f:
                    lang_entries = json.load(f)
            except (OSError, json.JSONDecodeError):
                continue
            if not isinstance(lang_entries, list) or not all(
                    isinstance(e, dict) and 'i' in e for e in lang_entries):
                continue
            if not lang_entries:
                # No genuinely localized content for this language at
                # all -- don't manufacture an all-English clone of the
                # default catalog under this filename.
                continue

            existing_ids = {e['i'] for e in lang_entries}
            missing = [copy.deepcopy(e) for e in en_entries
                       if e['i'] not in existing_ids]
            if not missing:
                continue

            try:
                with open(lang_path, 'w', encoding='utf-8') as f:
                    json.dump(lang_entries + missing, f, indent=2,
                               ensure_ascii=False)
                    f.write('\n')
                changed = True
            except OSError:
                continue
        return changed

    def _alphabetize_listing_json(self, path):
        """
        Re-sort a single addons-<lang>.json listing file's entries by
        'n' -- the name the Addon Manager shows -- case-insensitively,
        so a person reading the file finds an addon where the GUI
        lists it. 'i' and 't' break ties between plugins that share a
        name (e.g. a CSV importer and exporter).

        make_addon.py (and the make<NN>.py scripts it delegates to)
        add/update entries in whatever order the selected addons
        happen to be processed in, so re-sorting here keeps the
        listing file stable and easy to diff/review across builds,
        regardless of build order. This is a reading order only:
        make_addon._reconcile_listing_with_gpr() repairs whatever
        make52.py's order-dependent merge leaves behind, so the order
        no longer affects correctness.

        Leaves the file untouched -- rather than raising -- if it
        can't be read as JSON, isn't a list of dict entries, or has
        an entry with no 'n', 'i' or 't' field to sort by; none of
        those are this method's concern to fix, and make_addon.py's own
        error handling covers genuinely malformed listings.

        :param path: path to the addons-<lang>.json file to re-sort.
        :returns: True if the file was rewritten, False if it was
                  left as-is.
        """
        try:
            with open(path, 'r', encoding='utf-8') as f:
                entries = json.load(f)
        except (OSError, json.JSONDecodeError):
            return False

        if not isinstance(entries, list) or not all(
                isinstance(e, dict) and 'n' in e and 'i' in e and 't' in e
                for e in entries):
            return False

        def sort_key(entry):
            try:
                ptype = int(entry['t'])
            except (TypeError, ValueError):
                ptype = 0
            return (str(entry['n']).casefold(),
                    str(entry['i']).casefold(), ptype)

        sorted_entries = sorted(entries, key=sort_key)
        if sorted_entries == entries:
            return False

        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(sorted_entries, f, indent=2, ensure_ascii=False)
                f.write('\n')
        except OSError:
            return False
        return True

    def _normalize_listing_jsons(self, output_dir):
        """
        Bring every addons-<lang>.json listing file under
        ``output_dir/listings/`` into a consistent, correct state
        after a 'listing' command has written or updated them:

        1. Dedupe each file (see :meth:`_dedupe_listing_json`).
        2. Fill in English-fallback entries so every non-English file
           is a complete catalog, not just its translated subset (see
           :meth:`_apply_listing_language_fallback`).
        3. Re-sort every file by name, 'n' (see
           :meth:`_alphabetize_listing_json`) -- last, since step 2
           can add entries that also need sorting into place.

        The legacy .txt listing format (for Gramps versions before
        5.2) is left alone throughout, since it isn't JSON.

        :param output_dir: the version-specific output directory
            (e.g. ``<parent>/gramps52``) that was just listed into.
        """
        listings_dir = os.path.join(output_dir, 'listings')
        if not os.path.isdir(listings_dir):
            return

        json_names = [fname for fname in os.listdir(listings_dir)
                      if fname.startswith('addons-')
                      and fname.endswith('.json')]

        for fname in json_names:
            self._dedupe_listing_json(os.path.join(listings_dir, fname))

        self._apply_listing_language_fallback(listings_dir)

        for fname in json_names:
            self._alphabetize_listing_json(os.path.join(listings_dir, fname))

    def get_output_location_info(self, command, output_dir, addon_name):
        """
        Get information about where output files were created
        """
        info_lines = []

        if command == 'build':
            tgz_path = os.path.join(output_dir, 'download', f"{addon_name}.addon.tgz")
            if os.path.exists(tgz_path):
                info_lines.append(f"📦 Package created: {tgz_path}")

        elif command == 'compile':
            # Compile puts locale in the addon directory, not output_dir
            addon_path = None
            for name, info in self.addon_info.items():
                if name == addon_name:
                    addon_path = info['path']
                    break
            if addon_path:
                locale_path = os.path.join(addon_path, 'locale')
                if os.path.exists(locale_path):
                    info_lines.append(f"🌍 Translations compiled in: {locale_path}")

        elif command == 'listing':
            listings_dir = os.path.join(output_dir, 'listings')
            listing_files = []
            if os.path.isdir(listings_dir):
                listing_files = sorted(
                    fn for fn in os.listdir(listings_dir)
                    if fn.startswith('addons-')
                    and (fn.endswith('.json') or fn.endswith('.txt'))
                )
            if listing_files:
                info_lines.append(
                    f"📋 Listing(s) updated: {', '.join(listing_files)}")
                if any(fn.endswith('.txt') for fn in listing_files):
                    info_lines.append(
                        "   (.txt = legacy listing format used by Gramps"
                        " versions before 5.2 — expected, not an error)")
            else:
                info_lines.append(f"⚠️  Listing file not created - may need to Build first")

        elif command == 'clean':
            info_lines.append(f"🧹 Cleaned temporary files from {addon_name}")

        return "\n".join(info_lines)

    def on_edit_manifest(self, widget):
        """
        Create or edit MANIFEST for the single selected addon.
        - Looks for existing MANIFEST in addon folder
        - Creates it if none exists
        - Appends 4-line spacer + full recursive directory listing
        - Opens in OS default text editor
        """
        selected = self.get_selected_addons()

        if len(selected) != 1:
            OkDialog(
                _("Single Selection Required"),
                fill_names(_("Please select exactly one addon to edit"
                             " its {manifest}."), manifest="MANIFEST"),
                parent=self.window
            )
            return

        addon_name, addon_path = selected[0]
        build_mode = self.get_build_mode()
        manifest_filename = 'MANIFEST.beta' if build_mode == 'beta' else 'MANIFEST'
        manifest_path = os.path.join(addon_path, manifest_filename)
        is_new_file = not os.path.exists(manifest_path)

        # ── Build the annotated directory listing ──────────────────────────────
        # Shows EVERY file in the addon directory, annotated with whether it is
        # already auto-included or needs a MANIFEST entry to be packed.
        # Lines for auto-included files are prefixed with "# [auto]" so the user
        # can see the full package inventory at a glance.
        import datetime
        listing_lines = []
        listing_lines.append(
            f"# Full directory listing of {addon_name}/  —  {datetime.date.today()}"
        )
        listing_lines.append(
            f"# [auto]  = already included automatically in this build mode"
        )
        listing_lines.append(
            f"# [add?]  = NOT yet included — uncomment/copy to entries section above to add"
        )
        listing_lines.append(
            f"# [skip]  = intentionally excluded (temp/cache file)"
        )
        listing_lines.append("")

        # Extensions always auto-included by build_addon()
        always_auto_ext = {'.py', '.glade', '.xml'}
        # .mo files are auto-included after compile; locale/ dir is walked by build_addon
        # .md files auto-included in beta; README.md auto-included in release
        # .po / .pot auto-included in beta
        skip_ext   = {'.pyc', '.pyo'}   # never included
        always_auto_fnames = {'MANIFEST', 'MANIFEST.beta'}  # auto-included in beta

        for root, dirs, files in os.walk(addon_path):
            dirs[:] = sorted(
                d for d in dirs
                if not d.startswith('.')
                and d not in ('__pycache__',)
            )

            rel_root = os.path.relpath(root, os.path.dirname(addon_path))
            rel_root = rel_root.replace(os.sep, '/')

            for fname in sorted(files):
                ext = os.path.splitext(fname)[1].lower()

                # Determine annotation
                if fname.endswith('~') or ext in skip_ext:
                    tag = '[skip]'
                elif fname == manifest_filename:
                    # The MANIFEST file being edited is auto-included in beta,
                    # but don't show it as an entry to copy (it IS the file).
                    tag = '[auto]  ← this file'
                elif ext in always_auto_ext:
                    tag = '[auto]  ← .py/.glade/.xml always packed'
                elif ext == '.mo':
                    tag = '[auto]  ← compiled translation'
                elif rel_root.endswith('/locale') or '/locale/' in rel_root:
                    tag = '[auto]  ← locale/ tree always packed'
                elif fname in always_auto_fnames and build_mode == 'beta':
                    tag = '[auto]  ← included in β Beta builds'
                elif ext == '.md':
                    if build_mode == 'beta':
                        tag = '[auto]  ← *.md auto-included in β Beta'
                    elif fname == 'README.md':
                        tag = '[auto]  ← README.md included in Δ Release'
                    else:
                        tag = '[add?]'
                elif ext in ('.po', '.pot'):
                    if build_mode == 'beta':
                        tag = '[auto]  ← po/ files auto-included in β Beta'
                    else:
                        tag = '[skip]  ← po/ excluded from Δ Release'
                elif rel_root.endswith('/po') or '/po/' in rel_root:
                    if build_mode == 'beta':
                        tag = '[auto]  ← po/ auto-included in β Beta'
                    else:
                        tag = '[skip]  ← po/ excluded from Δ Release'
                else:
                    tag = '[add?]'

                listing_lines.append(f"# {tag}  {rel_root}/{fname}")

        listing_text = "\n".join(listing_lines)

        # ── Read existing MANIFEST for seeding ────────────────────────────────
        # When creating a new MANIFEST.beta, seed the entries section with
        # the content of any existing MANIFEST so nothing already documented
        # for Release is lost or has to be re-entered for Beta.
        existing_manifest_seed = ""
        if is_new_file and build_mode == 'beta':
            release_manifest_path = os.path.join(addon_path, 'MANIFEST')
            if os.path.exists(release_manifest_path):
                with open(release_manifest_path, 'r', encoding='utf-8') as f:
                    existing_manifest_seed = f.read().rstrip('\n')

        # ── Read or create MANIFEST / MANIFEST.beta ───────────────────────────
        if not is_new_file:
            with open(manifest_path, 'r', encoding='utf-8') as f:
                existing = f.read()
            content = existing.rstrip('\n') + "\n\n" + listing_text + "\n"
            action = "updated"
        else:
            if build_mode == 'beta':
                header = (
                    f"# MANIFEST.beta for {addon_name}\n"
                    f"# β Beta/development build — lists additional files beyond auto-includes.\n"
                    f"# Auto-included in β Beta: *.py, *.gpr.py, *.glade, *.xml, locale/*.mo,\n"
                    f"#   *.md, po/*.po, po/template.pot, MANIFEST, MANIFEST.beta,\n"
                    f"#   and all subdirectory contents.\n"
                    f"# Use this file to OVERRIDE that behavior with explicit patterns,\n"
                    f"# or leave it absent to use all auto-includes.\n"
                    f"#\n"
                    f"# Examples:\n"
                    f"#   {addon_name}/data/*\n"
                    f"#   {addon_name}/layouts/*.csv\n"
                    f"#   {addon_name}/README.md\n"
                )
            else:
                header = (
                    f"# MANIFEST for {addon_name}\n"
                    f"# Δ Release build — lists extras beyond the release defaults.\n"
                    f"# Release defaults: *.py, *.gpr.py, *.glade, *.xml,\n"
                    f"#   locale/*.mo, README.md.\n"
                    f"# Add subdirectory contents, data files, etc. here.\n"
                    f"# NOTE: po/ source files are intentionally excluded from Release.\n"
                    f"#\n"
                    f"# Examples:\n"
                    f"#   {addon_name}/data/*\n"
                    f"#   {addon_name}/layouts/*.csv\n"
                )

            # Entry section: seed from existing MANIFEST if available,
            # otherwise leave blank for the user to fill in
            if existing_manifest_seed:
                seed_note = (
                    f"# --- Seeded from existing MANIFEST ---\n"
                    f"{existing_manifest_seed}\n"
                    f"# --- Add your entries below this line ---"
                )
                entries_section = "\n" + seed_note
            else:
                entries_section = "\n# --- Add your entries below this line ---"

            content = header + entries_section + "\n\n" + listing_text + "\n"
            action = "created"

        # Write the file
        with open(manifest_path, 'w', encoding='utf-8') as f:
            f.write(content)

        # ── Open in default OS text editor ───────────────────────────────────
        try:
            if sys.platform.startswith('win'):
                os.startfile(manifest_path)
            elif sys.platform.startswith('darwin'):
                subprocess.Popen(['open', manifest_path])
            else:
                # Linux - try common editors in order
                for editor_cmd in ['xdg-open', 'gedit', 'kate', 'mousepad',
                                   'xed', 'geany', 'nano']:
                    try:
                        subprocess.Popen([editor_cmd, manifest_path])
                        break
                    except FileNotFoundError:
                        continue

            OkDialog(
                manifest_filename,
                fill_names(
                    _("{file} is ready for {addon}.\n\n"
                      "Location:\n  {path}\n\n"
                      "The file has been opened in your default text"
                      " editor.\n\n"
                      "The bottom of the file shows files not yet in the"
                      " {manifest}\n"
                      "(auto-included files like {auto} are omitted).\n"
                      "Copy any lines you want to include into the body"
                      " above."),
                    file=manifest_filename, addon=addon_name,
                    path=manifest_path, manifest="MANIFEST",
                    auto=".py, .glade"),
                parent=self.window
            )
        except Exception as e:
            OkDialog(
                manifest_filename,
                fill_names(
                    _("{file} is ready for {addon}.\n\n"
                      "Location:\n  {path}\n\n"
                      "Could not open editor automatically: {error}\n"
                      "Please open the file manually."),
                    file=manifest_filename, addon=addon_name,
                    path=manifest_path, error=str(e)),
                parent=self.window
            )

    def on_build(self, widget):
        """
        Build selected addons (after validation)
        """
        selected = self.get_selected_addons()
        if not selected:
            OkDialog(
                _("No Selection"),
                _("Please select at least one addon to build."),
                parent=self.window
            )
            return

        # Validate all selected addons first
        malformed = []
        for addon_name, addon_path in selected:
            metadata = self.get_addon_metadata(addon_name)
            if metadata.get('malformed'):
                malformed.append((addon_name, metadata['malformed']))

        if malformed:
            error_msg = fill_names(
                _("Cannot build - the following addon(s) have malformed"
                  " {gpr} files:"), gpr=".gpr.py") + "\n\n"
            for addon_name, fields in malformed:
                error_msg += f"• {addon_name}: {', '.join(fields)}\n"

            error_msg += _("\n\nProblem: These fields contain commas INSIDE quoted strings.\n\n")
            error_msg += _("Wrong:") + '  authors = ["Name1, Name2"]\n'
            error_msg += _("Correct:") + ' authors = ["Name1", "Name2"]\n\n'
            error_msg += fill_names(
                _("Please fix the {gpr} file(s) and try again."),
                gpr=".gpr.py")

            ErrorDialog(
                fill_names(_("Malformed {gpr} File"), gpr=".gpr.py"),
                error_msg,
                parent=self.window
            )
            return

        self.show_operation_results("Build", selected, "build")

    def _build_translation_row(self) -> Gtk.Box:
        """
        Build the "Translation:" row: a language picker (the languages
        Gramps itself is translated into, from GrampsLocale's own
        get_language_dict()) and an "Edit translation…" button that
        opens po/<lang>-local.po of each selected addon.

        The current Gramps language is preselected unless it is
        English, in which case the picker starts on "Choose a language"
        and the button stays dimmed until a language is chosen.
        """
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        row.pack_start(Gtk.Label(label=_("Translation:")), False, False, 0)

        combo = Gtk.ComboBoxText()
        combo.append("", _("Choose a language"))
        languages = sorted(
            ((name, code) for name, code in glocale.get_language_dict().items()
             if not code.startswith("en")),
            key=lambda item: glocale.sort_key(item[0]))
        for name, code in languages:
            combo.append(code, f"{name} ({code})")
        current = (glocale.language[0] if glocale.language else "") or ""
        codes = [code for _name, code in languages]
        default = ""
        if not current.startswith("en"):
            if current in codes:
                default = current
            elif current[:2] in codes:
                default = current[:2]
        combo.set_active_id(default)
        combo.set_tooltip_text(fill_names(
            _("Language of the translation to edit. The file name uses"
              " this code: {po_file}"), po_file="po/<code>-local.po"))
        row.pack_start(combo, False, False, 0)

        edit_btn = Gtk.Button(label=_("Edit translation…"))
        edit_btn.set_tooltip_text(fill_names(
            _("For each selected addon, open {po_file} in the"
              " default editor for {po_ext} files (for example Poedit or a"
              " text editor). The file is created from {pot} when it"
              " does not exist yet, and new strings from {pot} are"
              " merged into an existing file.\n"
              "After saving, click Compile Translations, then restart"
              " Gramps to see the result."),
            po_file="po/<code>-local.po", po_ext=".po",
            pot="template.pot"))
        edit_btn.set_sensitive(bool(default))
        edit_btn.connect("clicked", self.on_edit_translation)
        combo.connect(
            "changed",
            lambda widget: edit_btn.set_sensitive(bool(widget.get_active_id())))
        row.pack_start(edit_btn, False, False, 0)

        self.translation_lang_combo = combo
        return row

    def on_edit_translation(self, _widget):
        """
        Prepare and open po/<lang>-local.po for every selected addon.
        """
        lang = self.translation_lang_combo.get_active_id()
        if not lang:
            return
        selected = self.get_selected_addons()
        if not selected:
            OkDialog(
                _("No Selection"),
                _("Please select at least one addon to translate."),
                parent=self.window)
            return
        if len(selected) > 5:
            from gramps.gui.dialog import QuestionDialog2
            question = QuestionDialog2(
                _("Open Many Files?"),
                _("This opens {count} translation files, one for each"
                  " selected addon.").format(count=len(selected)),
                _("Open them"),
                _("Cancel"),
                parent=self.window)
            if not question.run():
                return

        make_addon = _get_make_addon_module()
        if make_addon is None:
            ErrorDialog(
                _("Missing make_addon.py"),
                _("make_addon.py was not found next to this tool."),
                parent=self.window)
            return

        lines = []
        for addon_name, addon_path in selected:
            buffer = io.StringIO()
            with contextlib.redirect_stdout(buffer):
                po_path, notes = make_addon.prepare_local_po(addon_path, lang)
            if po_path and os.path.exists(po_path):
                open_file_with_default_application(po_path, self.user.uistate)
                lines.append(f"✓ {addon_name}: {po_path}")
            else:
                lines.append(f"✗ {addon_name}")
            lines.extend(f"    {note}" for note in notes)

        lines.append("")
        lines.append(
            _("Next steps: translate and save each file, then click"
              " Compile Translations."))
        lines.append(
            _("⚠ Restart Gramps to see the new translations. Gramps keeps"
              " the translations cached until it restarts. Reloading the"
              " plugin is not enough to see updated strings."))
        self.show_scrollable_dialog(_("Edit Translation"), "\n".join(lines))

    @staticmethod
    def _missing_gettext_tool() -> str | None:
        """
        Return the name of the first gettext tool that Compile
        Translations needs but cannot find on PATH, or None when both
        are available. xgettext makes po/template.pot; msgfmt compiles
        po/<lang>-local.po into locale/<lang>/LC_MESSAGES/addon.mo.
        """
        for tool_name in ("xgettext", "msgfmt"):
            if shutil.which(tool_name) is None:
                return tool_name
        return None

    def on_compile(self, widget):
        """
        Compile translations for selected addons
        """
        selected = self.get_selected_addons()
        if not selected:
            OkDialog(
                _("No Selection"),
                _("Please select at least one addon to compile."),
                parent=self.window
            )
            return

        self.show_operation_results("Compile", selected, "compile")

    def on_listing(self, widget):
        """
        Create listings for selected addons (after validation)
        """
        selected = self.get_selected_addons()
        if not selected:
            OkDialog(
                _("No Selection"),
                _("Please select at least one addon to list."),
                parent=self.window
            )
            return

        # Validate all selected addons first
        malformed = []
        for addon_name, addon_path in selected:
            metadata = self.get_addon_metadata(addon_name)
            if metadata.get('malformed'):
                malformed.append((addon_name, metadata['malformed']))

        if malformed:
            error_msg = fill_names(
                _("Cannot create listing - the following addon(s) have malformed"
                  " {gpr} files:"), gpr=".gpr.py") + "\n\n"
            for addon_name, fields in malformed:
                error_msg += f"• {addon_name}: {', '.join(fields)}\n"

            error_msg += _("\n\nProblem: These fields contain commas INSIDE quoted strings.\n\n")
            error_msg += _("Wrong:") + '  authors = ["Name1, Name2"]\n'
            error_msg += _("Correct:") + ' authors = ["Name1", "Name2"]\n\n'
            error_msg += fill_names(
                _("Please fix the {gpr} file(s) and try again."),
                gpr=".gpr.py")

            ErrorDialog(
                fill_names(_("Malformed {gpr} File"), gpr=".gpr.py"),
                error_msg,
                parent=self.window
            )
            return

        # Get output directories for every selected Gramps version
        builder_dir = self.get_output_parent_dir()
        versions = self.get_selected_versions()

        # Check if the .tgz exists for every selected version
        missing_tgz = []
        for addon_name, addon_path in selected:
            missing_for = [
                v for v in versions
                if not os.path.exists(os.path.join(
                    builder_dir, v, 'download', f"{addon_name}.addon.tgz"))
            ]
            if missing_for:
                missing_tgz.append(addon_name)

        if missing_tgz:
            from gramps.gui.dialog import QuestionDialog2
            question = QuestionDialog2(
                _("Missing Package Files"),
                fill_names(
                    _("The following addons do not have {tgz} files"
                      " yet:\n\n{addons}\n\n"
                      "Listings require built packages. Would you like to:\n"
                      "• Build these addons first (recommended), or\n"
                      "• Try creating listings anyway (may result in empty"
                      " entries)"),
                    tgz=".addon.tgz",
                    addons="\n".join(f"  • {n}" for n in missing_tgz)),
                _("Build First"),
                _("Create Anyway"),
                parent=self.window
            )

            response = question.run()
            if response:  # Build First
                # Build the missing ones
                missing_addons = [(n, p) for n, p in selected if n in missing_tgz]
                self.show_operation_results("Build", missing_addons, "build")
                # Then proceed with listing

        self.show_operation_results("Listing", selected, "listing")

    def on_clean(self, widget):
        """
        Clean selected addons (with confirmation)
        """
        selected = self.get_selected_addons()
        if not selected:
            OkDialog(
                _("No Selection"),
                _("Please select at least one addon to clean."),
                parent=self.window
            )
            return

        # Show confirmation for Clean operation
        from gramps.gui.dialog import QuestionDialog2

        addon_names = [name for name, path in selected]

        question = QuestionDialog2(
            _("Clean Selected Addons?"),
            fill_names(
                _("This will remove Python cache files from:\n\n{addons}\n\n"
                  "═══════════════════════════════════════════\n"
                  "WILL BE REMOVED (Python regenerates these):\n"
                  "═══════════════════════════════════════════\n"
                  "• {pycache} directories\n"
                  "• {pyc} files (bytecode)\n"
                  "• {backup} backup files (editor temps)\n\n"
                  "═══════════════════════════════════════════\n"
                  "WILL BE PRESERVED (your work):\n"
                  "═══════════════════════════════════════════\n"
                  "• {locale_dir} (compiled translations - needed!)\n"
                  "• {pot} (translator reference)\n"
                  "• {po} (translation source files)\n"
                  "• All source code and data files\n\n"
                  "Python will automatically regenerate cache files\n"
                  "when you restart Gramps.\n\n"
                  "Continue with Clean?"),
                addons="\n".join(f"  • {n}" for n in addon_names),
                pycache="__pycache__/", pyc="*.pyc, *.pyo", backup="*~",
                locale_dir="locale/", pot="po/template.pot", po="po/*.po"),
            _("Yes, Clean Cache"),
            _("No, Cancel"),
            parent=self.window
        )

        response = question.run()
        if response:
            self.show_operation_results("Clean", selected, "clean")

    def get_build_mode(self):
        """Returns 'beta' or 'release' based on radio button state"""
        if hasattr(self, 'radio_release') and self.radio_release.get_active():
            return 'release'
        return 'beta'

    def on_package_for_github(self, widget):
        """
        Package selected addons for GitHub (template.pot, .tgz + .json) - after validation
        """
        selected = self.get_selected_addons()
        if not selected:
            OkDialog(
                _("No Selection"),
                _("Please select at least one addon to package."),
                parent=self.window
            )
            return

        # Validate all selected addons first
        malformed = []
        for addon_name, addon_path in selected:
            metadata = self.get_addon_metadata(addon_name)
            if metadata.get('malformed'):
                malformed.append((addon_name, metadata['malformed']))

        if malformed:
            error_msg = fill_names(
                _("Cannot package - the following addon(s) have malformed"
                  " {gpr} files:"), gpr=".gpr.py") + "\n\n"
            for addon_name, fields in malformed:
                error_msg += f"• {addon_name}: {', '.join(fields)}\n"

            error_msg += _("\n\nProblem: These fields contain commas INSIDE quoted strings.\n\n")
            error_msg += _("Wrong:") + '  authors = ["Name1, Name2"]\n'
            error_msg += _("Correct:") + ' authors = ["Name1", "Name2"]\n\n'
            error_msg += fill_names(
                _("Please fix the {gpr} file(s) and try again."),
                gpr=".gpr.py")

            ErrorDialog(
                fill_names(_("Malformed {gpr} File"), gpr=".gpr.py"),
                error_msg,
                parent=self.window
            )
            return

        build_mode = self.get_build_mode()

        # Warn before Release build - it is intentionally lossy
        if build_mode == 'release':
            addon_names = [name for name, path in selected]
            from gramps.gui.dialog import QuestionDialog2
            question = QuestionDialog2(
                _("Δ Release Build — Intentionally Lossy"),
                fill_names(
                _("You are about to create a RELEASE package for:\n\n"
                  "{addons}\n\n"
                  "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                  "WILL BE INCLUDED:\n"
                  "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                  "• All core files ({core})\n"
                  "• {readme} (if present)\n"
                  "• Compiled translations ({mo})\n"
                  "• {manifest} extras (if {manifest} present)\n\n"
                  "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                  "INTENTIONALLY EXCLUDED:\n"
                  "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                  "• {po} translation source files\n"
                  "• {pot}\n"
                  "• {changelog} and other {md} files\n"
                  "• {manifest_beta} and development files\n\n"
                  "⚠  This package is NOT suitable for translators\n"
                  "   or beta testers who need source files.\n\n"
                  "Use β Beta mode for development sharing.\n\n"
                  "Continue with Release build?"),
                    addons="\n".join(f"  • {n}" for n in addon_names),
                    core=".py, .gpr.py, .glade, .xml", readme="README.md",
                    mo="locale/*.mo", manifest="MANIFEST", po="po/*.po",
                    pot="po/template.pot", changelog="CHANGELOG.md",
                    md=".md", manifest_beta="MANIFEST.beta"),
                _("Yes, Build Release"),
                _("No, Cancel"),
                parent=self.window
            )
            if not question.run():
                return

        self.show_combined_results("Pack and Ship", selected, build_mode)

    def _collect_command_result(self, results, details, addon_name,
                                 version_tag, command, addon_path,
                                 success, stdout, stderr, label_prefix=""):
        """
        Append one command invocation's outcome to the running results/
        details lists used by show_operation_results() and
        show_combined_results(). Factored out so 'build' and 'listing'
        can each be run once per selected Gramps version without
        duplicating the formatting logic.

        :param label_prefix: Optional text (e.g. ``"Listing: "``)
            prepended to the addon name in the results line -- used by
            show_combined_results() to distinguish its combined
            build+listing lines; show_operation_results() leaves this
            at its default of "" since each of its dialogs only ever
            shows one kind of line.
        """
        status = "✓" if success else "✗"

        has_manifest = False
        if command == 'build':
            manifest_file = os.path.join(addon_path, 'MANIFEST')
            has_manifest = os.path.exists(manifest_file)

        if has_manifest:
            results.append(
                f"{status} {label_prefix}{addon_name}{version_tag} 🔴 (MANIFEST)")
        else:
            results.append(f"{status} {label_prefix}{addon_name}{version_tag}")

        if success and stdout:
            if 'MANIFEST' in stdout or 'manifest' in stdout:
                details.append("    🔴 Used MANIFEST file for packaging")
            for line in stdout.split('\n'):
                if line.strip():
                    details.append(f"    {line}")
        elif not success and stderr:
            details.append(f"    Error: {stderr[:200]}")

    def on_remove_untranslated_listings(self, _widget):
        """
        Handle the Options tab's "Remove untranslated listings…"
        button: for every checked Gramps Version, find the
        addons-<lang>.json files that only repeat addons-en.json (see
        make_addon.find_untranslated_listings()), list them, and
        delete them only after the user confirms.

        :param _widget: unused (the button itself)
        """
        make_addon = _get_make_addon_module()
        if make_addon is None or not hasattr(
                make_addon, 'find_untranslated_listings'):
            ErrorDialog(
                _("Remove untranslated listings"),
                _("This needs a newer make_addon.py in the"
                  " AddonPackShip folder."),
                parent=self.window)
            return

        builder_dir = self.get_output_parent_dir()
        found = []
        for version in self.get_selected_versions():
            listings_dir = os.path.join(builder_dir, version, 'listings')
            found.extend(make_addon.find_untranslated_listings(listings_dir))

        if not found:
            OkDialog(
                _("Remove untranslated listings"),
                _("No untranslated language listings were found for the"
                  " checked Gramps Versions."),
                parent=self.window)
            return

        names = "\n".join(
            "  • " + os.path.relpath(path, builder_dir) for path in found)
        self._confirm_and_remove_listings(
            found, builder_dir, _("Remove untranslated listings"),
            _("Remove untranslated listings?"),
            fill_names(
                _("These language listings contain no translated names or"
                  " descriptions -- every entry is identical to"
                  " {en_listing}:\n\n{files}\n\nThe Addon Manager uses"
                  " {en_listing} for any language without its own file."
                  " Delete them?"),
                en_listing="addons-en.json", files=names))

    def on_remove_all_language_listings(self, _widget):
        """
        Handle the Options tab's "Remove all language listings…"
        button: for every checked Gramps Version, list every
        addons-<lang>.json except addons-en.json (see
        make_addon.find_non_english_listings()), marking the ones
        that hold translations, and delete them only after the user
        confirms.

        :param _widget: unused (the button itself)
        """
        title = _("Remove all language listings")
        make_addon = _get_make_addon_module()
        if make_addon is None or not hasattr(
                make_addon, 'find_non_english_listings'):
            ErrorDialog(
                title,
                _("This needs a newer make_addon.py in the"
                  " AddonPackShip folder."),
                parent=self.window)
            return

        builder_dir = self.get_output_parent_dir()
        found, untranslated = [], set()
        for version in self.get_selected_versions():
            listings_dir = os.path.join(builder_dir, version, 'listings')
            found.extend(make_addon.find_non_english_listings(listings_dir))
            untranslated.update(
                make_addon.find_untranslated_listings(listings_dir))

        if not found:
            OkDialog(
                title,
                fill_names(
                    _("No language listings other than {en_listing}"
                      " were found for the checked Gramps Versions."),
                    en_listing="addons-en.json"),
                parent=self.window)
            return

        translated_mark = _("contains translations")
        lines = []
        for path in found:
            line = "  • " + os.path.relpath(path, builder_dir)
            if path not in untranslated:
                line += f"  ⚠ {translated_mark}"
            lines.append(line)
        self._confirm_and_remove_listings(
            found, builder_dir, title,
            _("Remove all language listings?"),
            fill_names(
                _("These language listings will be deleted, so that only"
                  " {en_listing} remains:\n\n{files}\n\nTranslated"
                  " names and descriptions in files marked ⚠ are lost"
                  " from the listings (the {po_dir} translation files of"
                  " each addon are kept). Delete them?"),
                en_listing="addons-en.json", files="\n".join(lines),
                po_dir="po/"))

    def _confirm_and_remove_listings(self, found, builder_dir, title,
                                     question_title, question_text):
        """
        Ask for confirmation, then delete the given listing files and
        report what was removed. Shared by the two "Remove … listings"
        buttons on the Options tab.

        :param found: Absolute paths of the files to delete.
        :param builder_dir: The output parent folder, used to show
            short relative paths.
        :param title: Title of the result dialog.
        :param question_title: Title of the confirmation dialog.
        :param question_text: Text of the confirmation dialog.
        """
        from gramps.gui.dialog import QuestionDialog2
        question = QuestionDialog2(
            question_title, question_text,
            _("Delete"),
            _("Cancel"),
            parent=self.window)
        if not question.run():
            return

        removed, failed = [], []
        for path in found:
            try:
                os.remove(path)
                removed.append(os.path.relpath(path, builder_dir))
            except OSError as exc:
                failed.append(f"{os.path.relpath(path, builder_dir)}: {exc}")
        message = _("Removed {} file(s).").format(len(removed))
        if failed:
            message += "\n\n" + _("Could not remove:") + "\n" + "\n".join(
                failed)
        OkDialog(title, message, parent=self.window)

    @staticmethod
    def _pump_gtk_events():
        """
        Process pending GTK events, so the windows stay responsive and
        redraw during a long packaging step instead of freezing until
        it ends (which made the desktop offer to force-quit Gramps as
        "not responding"). Passed to make_addon.run_command() as its
        wait_callback; ProgressMeter itself does the same between
        steps.
        """
        while Gtk.events_pending():
            Gtk.main_iteration()

    def _start_progress(self, operation, total_steps):
        """
        Open Gramps' standard progress window (ProgressMeter) for a
        packaging run. It is modal to this tool's window, so nothing
        else can be clicked while the run is in progress.

        :param operation: Window title, e.g. "Pack and Ship".
        :param total_steps: Number of ``progress.step()`` calls the
            run will make (one per build or listing step).
        :returns: The ProgressMeter; close it with ``.close()``.
        """
        progress = ProgressMeter(operation, "", parent=self.window)
        progress.set_pass(_("Preparing..."), max(1, total_steps))
        return progress

    @staticmethod
    def _progress_note(progress, text):
        """
        Show in the progress window what the next step is doing. Call
        ``progress.step()`` once that step has finished.

        :param progress: The ProgressMeter from :meth:`_start_progress`.
        :param text: e.g. "Listing PhotoTaggingGramplet for gramps52".
        """
        progress.set_header(text)

    def show_operation_results(self, operation, addons, command):
        """
        Show results for a single operation with detailed feedback in
        scrollable dialog.

        'build' is run once per addon and duplicated across every
        selected Gramps version (see build_for_versions()). 'listing'
        is run once per addon per selected version; each run delegates
        to the matching bundled make<NN>.py (when present) which
        generates every language the addon has translations for.
        """
        build_mode = self.get_build_mode()

        if command in ('build', 'listing'):
            versions = self.get_selected_versions()
        else:
            versions = [GRAMPS_VERSION]
        multi_version = len(versions) > 1

        if command in ('build', 'listing'):
            planned = self._plan_addon_versions(addons, versions)
            if planned is None:
                return  # cancelled in the non-adaptive warning
            plan, plan_notes, forced = planned
        else:
            plan = {name: versions for name, _path in addons}
            plan_notes, forced = {}, set()

        results = []
        details = []

        if command == 'listing':
            total_steps = sum(len(plan[name]) for name, _path in addons)
        else:
            total_steps = len(addons)
        progress = self._start_progress(operation, total_steps)
        try:
            for addon_name, addon_path in addons:
                for note in plan_notes.get(addon_name, []):
                    details.append(f"{addon_name}:{note}")
                addon_versions = plan[addon_name]
                if command in ('build', 'listing') and not addon_versions:
                    results.append(
                        _("– {}: skipped (see the notes below)").format(
                            addon_name))
                    if command == 'build':
                        progress.step()
                    continue
                if command == 'build':
                    self._progress_note(
                        progress, _("Building {}").format(addon_name))
                    success, stdout, stderr = self.build_for_versions(
                        addon_path, build_mode, addon_versions,
                        force_uncovered=(
                            True if addon_name in forced else None))
                    progress.step()
                    version_tag = (f" [{', '.join(addon_versions)}]"
                                   if multi_version else "")
                    self._collect_command_result(
                        results, details, addon_name, version_tag, command,
                        addon_path, success, stdout, stderr)
                elif command == 'listing':
                    for version in addon_versions:
                        self._progress_note(
                            progress,
                            _("Listing {} for {}").format(addon_name, version))
                        success, stdout, stderr = self.run_make_command(
                            addon_path, command, version=version)
                        progress.step()
                        version_tag = f" [{version}]" if multi_version else ""
                        self._collect_command_result(
                            results, details, addon_name, version_tag,
                            command, addon_path, success, stdout, stderr)
                else:
                    self._progress_note(
                        progress, "{}: {}".format(operation, addon_name))
                    success, stdout, stderr = self.run_make_command(
                        addon_path, command, build_mode=build_mode)
                    progress.step()
                    self._collect_command_result(
                        results, details, addon_name, "", command, addon_path,
                        success, stdout, stderr)
        finally:
            progress.close()

        # Combine results and details
        message_lines = [_("{} completed:").format(operation), ""]
        message_lines.extend(results)

        if details:
            message_lines.append("")
            message_lines.extend(details)

        message = "\n".join(message_lines)

        # Create custom scrollable dialog
        self.show_scrollable_dialog(_("{} Complete").format(operation), message)

    @staticmethod
    def _highlight_restart_notices(buffer):
        """
        Show every line that starts with "⚠ Restart Gramps" (leading
        spaces allowed) in bold red, so the restart needed after
        compiling translations is hard to miss in a long results text.

        :param buffer: The Gtk.TextBuffer of a results dialog.
        """
        tag = buffer.create_tag(
            "restart-notice", foreground="#c01c28", weight=Pango.Weight.BOLD)
        for line_no in range(buffer.get_line_count()):
            start = buffer.get_iter_at_line(line_no)
            end = start.copy()
            if not end.ends_line():
                end.forward_to_line_end()
            text = buffer.get_text(start, end, False)
            if text.lstrip().startswith("⚠ Restart Gramps"):
                buffer.apply_tag(tag, start, end)

    def show_scrollable_dialog(self, title, message):
        """
        Show a scrollable dialog that fits on screen.
        Uses Gtk.Dialog() without the deprecated flags constructor to avoid
        the GTK-CRITICAL 'gtk_notebook_get_tab_label: assertion list != NULL'
        error that fires when get_content_area() is called on a dialog
        constructed with the old flags-based API.
        """
        dialog = Gtk.Dialog()
        dialog.set_title(title)
        dialog.set_transient_for(self.window)
        dialog.set_modal(True)
        dialog.set_destroy_with_parent(True)
        dialog.add_button(_("OK"), Gtk.ResponseType.OK)
        dialog.set_default_response(Gtk.ResponseType.OK)

        # Set reasonable size - max 80% of screen height
        screen = dialog.get_screen()
        screen_height = screen.get_height()
        max_height = int(screen_height * 0.8)
        dialog.set_default_size(600, min(400, max_height))

        # Create scrolled window
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled.set_size_request(580, min(350, max_height - 100))

        # Create text view
        textview = Gtk.TextView()
        textview.set_editable(False)
        textview.set_wrap_mode(Gtk.WrapMode.WORD)
        textview.set_left_margin(10)
        textview.set_right_margin(10)
        textview.set_top_margin(10)
        textview.set_bottom_margin(10)

        # Set monospace font for better alignment
        from gi.repository import Pango
        font_desc = Pango.FontDescription("Monospace 10")
        textview.override_font(font_desc)

        buffer = textview.get_buffer()
        buffer.set_text(message)
        self._highlight_restart_notices(buffer)

        scrolled.add(textview)

        content_area = dialog.get_content_area()
        content_area.set_border_width(10)
        content_area.pack_start(scrolled, True, True, 0)

        dialog.show_all()
        dialog.run()
        dialog.destroy()

    def _run_combined_steps(self, addons, build_mode, plan, forced,
                            multi_version, all_results, details, progress):
        """
        The build and listing steps of :meth:`show_combined_results`,
        appending each outcome to `all_results`/`details` and
        advancing `progress` after each step.

        :param plan: addon name -> list of version codes to pack and
            list it for (see :meth:`_plan_addon_versions`).
        :param forced: addon names packed for every checked version
            on request, although not adaptive.
        """
        # Build once per addon; the resulting .tgz is duplicated across
        # every other version planned for it (see build_for_versions()).
        for addon_name, addon_path in addons:
            versions = plan[addon_name]
            if not versions:
                all_results.append(
                    _("– Build: {}: skipped (see the notes below)").format(
                        addon_name))
                progress.step()
                continue
            self._progress_note(
                progress, _("Building {}").format(addon_name))
            success, stdout, stderr = self.build_for_versions(
                addon_path, build_mode, versions,
                force_uncovered=True if addon_name in forced else None)
            progress.step()
            status = "✓" if success else "✗"
            version_tag = f" [{', '.join(versions)}]" if multi_version else ""

            # Show which MANIFEST file was used
            manifest_beta = os.path.exists(os.path.join(addon_path, 'MANIFEST.beta'))
            manifest_rel  = os.path.exists(os.path.join(addon_path, 'MANIFEST'))

            if build_mode == 'beta' and manifest_beta:
                all_results.append(f"{status} Build: {addon_name}{version_tag} 🔴 (MANIFEST.beta)")
            elif build_mode == 'beta':
                all_results.append(f"{status} Build: {addon_name}{version_tag} [β auto-includes extras]")
            elif build_mode == 'release' and manifest_rel:
                all_results.append(f"{status} Build: {addon_name}{version_tag} 🔴 (MANIFEST)")
            else:
                all_results.append(f"{status} Build: {addon_name}{version_tag} [Δ release defaults]")

            # Surface *why* — same truncated stdout/stderr detail
            # show_operation_results() already shows via
            # _collect_command_result(), which this loop doesn't call
            # directly (it needs the richer MANIFEST-mode annotations
            # above), so the error/detail capture is duplicated here
            # rather than dropped entirely.
            if success and stdout:
                for line in stdout.split('\n'):
                    if line.strip():
                        details.append(f"    {line}")
            elif not success and stderr:
                details.append(
                    f"    Error (Build: {addon_name}{version_tag}):"
                    f" {stderr[:200]}")

        # Listing — once per addon per selected version; each run
        # delegates to the matching bundled make<NN>.py (when present)
        # which generates every language the addon has translations for.
        for addon_name, addon_path in addons:
            for version in plan[addon_name]:
                self._progress_note(
                    progress,
                    _("Listing {} for {}").format(addon_name, version))
                success, stdout, stderr = self.run_make_command(
                    addon_path, "listing", version=version)
                progress.step()
                version_tag = f" [{version}]" if multi_version else ""
                self._collect_command_result(
                    all_results, details, addon_name, version_tag,
                    'listing', addon_path, success, stdout, stderr,
                    label_prefix="Listing: ")

    def show_combined_results(self, operation, addons, build_mode='beta'):
        """
        Show results for combined operations (build + listing), across
        every selected Gramps version.
        build_mode: 'beta' or 'release'
        """
        versions = self.get_selected_versions()
        multi_version = len(versions) > 1

        all_results = []
        details = []
        mode_label = "β Beta" if build_mode == 'beta' else "Δ Release"

        planned = self._plan_addon_versions(addons, versions)
        if planned is None:
            return  # cancelled in the non-adaptive warning
        plan, plan_notes, forced = planned
        for addon_name, _path in addons:
            for note in plan_notes.get(addon_name, []):
                details.append(f"{addon_name}:{note}")

        progress = self._start_progress(
            operation,
            sum(1 + len(plan[name]) for name, _path in addons))
        try:
            self._run_combined_steps(addons, build_mode, plan, forced,
                                     multi_version, all_results, details,
                                     progress)
        finally:
            progress.close()

        # Build mode is shown once, at the top of the body -- avoid
        # repeating "Pack and Ship Complete" here since the dialog
        # title (below) already says that.
        message_lines = [_("Build mode: {}").format(mode_label), ""]
        message_lines.extend(all_results)

        if details:
            message_lines.append("")
            message_lines.extend(details)

        # Show location of output files for every selected version
        builder_dir = self.get_output_parent_dir()
        message_lines.append("")
        message_lines.append(_("📁 Output location(s):"))
        for version in versions:
            output_dir = os.path.join(builder_dir, version)
            message_lines.append(f"  {output_dir}/download/")
            message_lines.append(f"  {output_dir}/listings/")

        message_lines.append("")
        message_lines.append(_("Your addons are ready to share!"))

        self.show_scrollable_dialog(
            _("{} Complete").format(operation), "\n".join(message_lines))

    def _get_tool_pdata(self):
        """
        Return this tool's own PluginData (from AddonPackShip.gpr.py),
        looked up live via Gramps' plugin registry rather than cached
        here, so it can never drift out of sync with the .gpr.py file.
        Mirrors the same PluginRegister.get_instance() +
        type_plugins() pattern already used in scan_installed_addons().
        Shared by :meth:`_get_tool_help_url` and
        :meth:`_get_tool_readme_path` so both read from a single
        lookup.

        :returns: this tool's own PluginData, or ``None`` if it can't
                  be found in the registry.
        """
        try:
            pgr = PluginRegister.get_instance()
            for ptype in PTYPE_STR:
                for pdata in pgr.type_plugins(ptype):
                    if getattr(pdata, 'id', None) == 'addonpackship':
                        return pdata
        except Exception:  # pylint: disable=broad-except
            pass
        return None

    def _get_tool_help_url(self):
        """
        Return this tool's own registered help_url (from
        AddonPackShip.gpr.py).

        :returns: the help URL string, or '' if it can't be found.
        """
        pdata = self._get_tool_pdata()
        return getattr(pdata, 'help_url', '') or ''

    def _get_tool_readme_path(self):
        """
        Return the path to this tool's own README.md, if this tool is
        registered, its folder is known, and a README.md exists there.

        :returns: the README.md path, or '' if any of the above don't
                  hold.
        """
        pdata = self._get_tool_pdata()
        if pdata is None or not getattr(pdata, 'fpath', None):
            return ''
        readme_path = os.path.join(pdata.fpath, 'README.md')
        return readme_path if os.path.isfile(readme_path) else ''

    def _open_readme_in_markdown_dash(self, readme_path):
        """
        Try to open ``readme_path`` in the Markdown Dash gramplet's
        standalone viewer.

        Loads Markdown Dash (see ``MarkdownDash.gpr.py``,
        ``id="markdowndash"``) on demand via the Gramps plugin
        registry, then calls its public ``open_markdown_file()`` API
        (see ``MarkdownDash.py``'s module docstring). Any failure --
        Markdown Dash not registered, its module failing to load, or
        an older version lacking ``open_markdown_file()`` -- is
        treated as "can't show it this way" rather than an error, so
        the caller can fall back to opening the help_url in a browser
        instead (see :meth:`on_help_icon_clicked`).

        :param readme_path: path of the README.md to open.
        :returns: ``True`` if Markdown Dash opened the file, ``False``
                  if it could not be shown this way.
        """
        preg = PluginRegister.get_instance()
        pmgr = GuiPluginManager.get_instance()

        pdata = preg.get_plugin('markdowndash')
        if pdata is None or not pdata.fpath:
            return False

        mod = pmgr.load_plugin(pdata)
        if not mod:
            return False

        open_markdown_file = getattr(mod, 'open_markdown_file', None)
        if open_markdown_file is None:
            return False

        open_markdown_file(
            readme_path,
            self.user.uistate,
            parent=self.user.uistate.window,
            addon_name=_("Addon Pack and Ship"),
        )
        return True

    def _open_help_url_in_browser(self):
        """
        Open this tool's registered help_url in the default browser.

        This is the fallback help action, used when this tool's own
        README.md can't be shown directly (see
        :meth:`on_help_icon_clicked`).
        """
        url = self._get_tool_help_url()
        if not url:
            ErrorDialog(
                _("No Help URL"),
                fill_names(
                    _("This tool has no {field} registered in its {gpr}."),
                    field="help_url", gpr=".gpr.py"),
                parent=self.window)
            return
        try:
            Gtk.show_uri_on_window(self.window, url, Gdk.CURRENT_TIME)
        except Exception:  # pylint: disable=broad-except
            try:
                import webbrowser
                webbrowser.open(url)
            except Exception:  # pylint: disable=broad-except
                ErrorDialog(
                    _("Could Not Open Browser"),
                    _("Could not open {}").format(url),
                    parent=self.window)

    def on_help_icon_clicked(self, _button):
        """
        Open this tool's own documentation.

        Prefers opening this tool's own README.md directly, in the
        Markdown Dash gramplet's standalone viewer (see
        :meth:`_open_readme_in_markdown_dash`). Falls back to opening
        this tool's registered help_url in the default browser (see
        :meth:`_open_help_url_in_browser`) when no README.md is found
        alongside this tool, or when it can't be shown via Markdown
        Dash for any reason -- Markdown Dash not being registered, its
        module failing to load, or an older version lacking the
        ``open_markdown_file()`` API it needs.
        """
        readme_path = self._get_tool_readme_path()
        if readme_path and self._open_readme_in_markdown_dash(readme_path):
            return
        self._open_help_url_in_browser()

    def on_open_logs_folder_clicked(self, _button):
        """
        Open this plugin's session logs folder in the OS file browser.

        Mirrors :meth:`cb_open_output_folder`: resolves the path fresh
        on every click and delegates to the shared
        ``open_file_with_default_application()`` Gramps GUI utility
        rather than any bespoke per-platform launching.

        :param _button: the button that was clicked (unused).
        """
        logs_dir = _get_logs_dir()
        if logs_dir and os.path.isdir(logs_dir):
            open_file_with_default_application(logs_dir, self.user.uistate)
        else:
            ErrorDialog(
                _("Folder Not Found"),
                _("No session logs yet — nothing has been run in this"
                  " session:\n{}").format(logs_dir),
                parent=self.window)

    def build_menu_names(self, obj):
        """
        Return menu labels
        """
        return (_("Addon Pack and Ship"), _("Addon Pack and Ship"))

    def close(self, *args):
        """
        Close the window. Remembers whichever configuration name is
        currently in the "Configuration" entry (in APS.ini, under a
        reserved [__LastUsed__] section) so it can be restored the
        next time this tool is opened.
        """
        self._save_last_used_config_name()
        ManagedWindow.close(self, *args)

#------------------------------------------------------------------------
#
# AddonPackShipOptions
#
#------------------------------------------------------------------------
class AddonPackShipOptions(tool.ToolOptions):
    """
    Options for Addon Pack and Ship tool
    """
    def __init__(self, name, person_id=None):
        tool.ToolOptions.__init__(self, name, person_id)
