#
# Gramps - a GTK+/GNOME based genealogy program
#
# Copyright (C) 2026  Brian McCullough <emyoulation@yahoo.com>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, see <https://www.gnu.org/licenses/>.

"""
Tests for make_addon.py's in-process packaging engine (run_command()
and friends), added as part of the refactor that replaced
AddonPackShip.py's subprocess-based invocation with a direct,
in-process module import.

These tests focus on two things the refactor specifically needed to
get right:

  1. ``run_command()`` and everything it calls must NEVER call
     ``sys.exit()``. Doing so used to be safe (it only ended a
     throwaway subprocess), but now that this module is imported
     directly into the running Gramps process, ``sys.exit()`` there
     would tear down the whole application.
  2. The ``(success, stdout, stderr)`` shape callers depend on (in
     particular AddonPackShip.py's own result parsing) must be
     preserved even though there is no longer a real subprocess and
     no real return code behind it.

Development: AI-assisted using Claude (Anthropic); see the commit
message for full AI-generated-code disclosure per
https://www.gramps-project.org/wiki/index.php/Howto:_Contribute_to_Gramps#AI_generated_code
"""

# ------------------------
# Python modules
# ------------------------
import os
import sys
import uuid
import shutil
import tempfile
import unittest
import subprocess
import importlib.util
from unittest.mock import patch

_real_copy2 = shutil.copy2


def _load_make_addon():
    """
    Import make_addon.py the same way AddonPackShip.py does at
    runtime: as a standalone module loaded from its file path, since
    it lives alongside AddonPackShip.py rather than inside a package.

    :returns: The imported ``make_addon`` module.
    """
    module_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "make_addon.py",
    )
    spec = importlib.util.spec_from_file_location("make_addon_under_test", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


make_addon = _load_make_addon()


# ------------------------------------------------------------
#
# RunCommandNeverExitsTest
#
# ------------------------------------------------------------
class RunCommandNeverExitsTest(unittest.TestCase):
    """
    Guards against the sys.exit() landmine this refactor removed:
    every code path run_command() can take must return a plain
    (success, stdout, stderr) tuple, never call sys.exit().
    """

    def setUp(self) -> None:
        """Create a scratch addon directory and output directory."""
        self.tmp_dir = tempfile.mkdtemp(prefix="make_addon_test_")
        self.addon_path = os.path.join(self.tmp_dir, "MyAddon")
        self.output_dir = os.path.join(self.tmp_dir, "out", "gramps52")
        os.makedirs(self.addon_path)
        os.makedirs(self.output_dir)

    def tearDown(self) -> None:
        """Remove the scratch directories created in setUp()."""
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def _assert_never_exits(self, command: str) -> tuple:
        """
        Run ``command`` with sys.exit() patched to raise instead of
        exiting, so an accidental call fails the test loudly instead
        of killing the test runner.

        :param command: The make_addon.py command to run.
        :returns: The (success, stdout, stderr) tuple from
            run_command(), for further assertions by the caller.
        """
        with patch.object(make_addon.sys, "exit") as mock_exit:
            result = make_addon.run_command(command, self.addon_path, self.output_dir)
        mock_exit.assert_not_called()
        return result

    def test_missing_addon_path_does_not_exit(self) -> None:
        """A nonexistent addon path must fail cleanly, not raise/exit."""
        with patch.object(make_addon.sys, "exit") as mock_exit:
            success, _stdout, stderr = make_addon.run_command(
                "build", "/no/such/addon/path", self.output_dir
            )
        mock_exit.assert_not_called()
        self.assertFalse(success)
        self.assertIn("does not exist", stderr)

    def test_unknown_command_does_not_exit(self) -> None:
        """An unrecognised command must fail cleanly, not raise/exit."""
        success, _stdout, _stderr = self._assert_never_exits("bogus-command")
        self.assertFalse(success)

    def test_build_does_not_exit(self) -> None:
        """A normal 'build' run must not call sys.exit()."""
        with open(
            os.path.join(self.addon_path, "MyAddon.gpr.py"),
            "w",
            encoding="utf-8",
        ) as fh:
            fh.write("register(TOOL)\n")
        with open(
            os.path.join(self.addon_path, "MyAddon.py"), "w", encoding="utf-8"
        ) as fh:
            fh.write("# addon body\n")

        success, _stdout, _stderr = self._assert_never_exits("build")
        self.assertTrue(success)

    def test_listing_with_missing_tgz_does_not_exit(self) -> None:
        """
        This is the specific line that used to call sys.exit(0):
        'listing' requested before 'build' has ever produced a .tgz.
        It must now return True (a workflow reminder, not a fault)
        without calling sys.exit().
        """
        with open(
            os.path.join(self.addon_path, "MyAddon.gpr.py"),
            "w",
            encoding="utf-8",
        ) as fh:
            fh.write("register(TOOL)\n")

        success, stdout, _stderr = self._assert_never_exits("listing")
        self.assertTrue(success)
        self.assertIn("run Build first", stdout)

    def test_clean_does_not_exit(self) -> None:
        """A normal 'clean' run must not call sys.exit()."""
        success, _stdout, _stderr = self._assert_never_exits("clean")
        self.assertTrue(success)

    def test_compile_does_not_exit(self) -> None:
        """A normal 'compile' run must not call sys.exit()."""
        success, _stdout, _stderr = self._assert_never_exits("compile")
        self.assertTrue(success)


# ------------------------------------------------------------
#
# RunCommandResultShapeTest
#
# ------------------------------------------------------------
class RunCommandResultShapeTest(unittest.TestCase):
    """
    Confirms run_command() still returns the same (success, stdout,
    stderr) shape AddonPackShip.py's result-parsing code depends on,
    now that there is no real subprocess or exit code behind it.
    """

    def setUp(self) -> None:
        """Create a scratch addon directory and output directory."""
        self.tmp_dir = tempfile.mkdtemp(prefix="make_addon_test_")
        self.addon_path = os.path.join(self.tmp_dir, "MyAddon")
        self.output_dir = os.path.join(self.tmp_dir, "out", "gramps52")
        os.makedirs(self.addon_path)
        os.makedirs(self.output_dir)
        with open(
            os.path.join(self.addon_path, "MyAddon.gpr.py"),
            "w",
            encoding="utf-8",
        ) as fh:
            fh.write("register(TOOL)\n")
        with open(
            os.path.join(self.addon_path, "MyAddon.py"), "w", encoding="utf-8"
        ) as fh:
            fh.write("# addon body\n")

    def tearDown(self) -> None:
        """Remove the scratch directories created in setUp()."""
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_build_returns_three_tuple_of_correct_types(self) -> None:
        """success is bool; stdout/stderr are str, matching the old
        subprocess.run(capture_output=True, text=True) contract."""
        result = make_addon.run_command("build", self.addon_path, self.output_dir)
        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 3)
        success, stdout, stderr = result
        self.assertIsInstance(success, bool)
        self.assertIsInstance(stdout, str)
        self.assertIsInstance(stderr, str)

    def test_build_actually_creates_the_tgz(self) -> None:
        """The whole point of the fix: a 'build' that reports success
        must have actually written the .addon.tgz to disk."""
        success, _stdout, _stderr = make_addon.run_command(
            "build", self.addon_path, self.output_dir
        )
        self.assertTrue(success)
        tgz_path = os.path.join(self.output_dir, "download", "MyAddon.addon.tgz")
        self.assertTrue(
            os.path.exists(tgz_path),
            f"Expected build artifact not found: {tgz_path}",
        )

    def test_build_mode_is_read_from_parameter_not_environment(self) -> None:
        """
        build_mode must come from the explicit parameter now, not
        from a BUILD_MODE environment variable -- the whole point of
        removing the subprocess/env-var boundary. Set a contradictory
        BUILD_MODE in the environment and confirm it is ignored.
        """
        with patch.dict(os.environ, {"BUILD_MODE": "release"}):
            success, stdout, _stderr = make_addon.run_command(
                "build", self.addon_path, self.output_dir, build_mode="beta"
            )
        self.assertTrue(success)
        self.assertIn("Beta", stdout)


# ------------------------------------------------------------
#
# CreateListingTest
#
# ------------------------------------------------------------
class CreateListingTest(unittest.TestCase):
    """Direct tests of create_listing()'s parameter-driven language
    handling, which replaced its previous ADDON_LANGUAGES env lookup."""

    def setUp(self) -> None:
        """Create a scratch addon directory and output directory."""
        self.tmp_dir = tempfile.mkdtemp(prefix="make_addon_test_")
        self.addon_path = os.path.join(self.tmp_dir, "MyAddon")
        self.output_dir = os.path.join(self.tmp_dir, "out", "gramps52")
        os.makedirs(self.addon_path)
        os.makedirs(self.output_dir)

    def tearDown(self) -> None:
        """Remove the scratch directories created in setUp()."""
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_missing_gpr_file_returns_false(self) -> None:
        """No .gpr.py present is a real error, unlike the missing-tgz
        case, and must still return False (not raise or exit)."""
        with patch.object(make_addon.sys, "exit") as mock_exit:
            result = make_addon.create_listing(self.addon_path, self.output_dir)
        mock_exit.assert_not_called()
        self.assertFalse(result)

    def test_missing_tgz_returns_true_not_sys_exit(self) -> None:
        """The specific line this refactor fixed: create_listing()
        used to call sys.exit(0) here instead of returning."""
        with open(
            os.path.join(self.addon_path, "MyAddon.gpr.py"),
            "w",
            encoding="utf-8",
        ) as fh:
            fh.write("register(TOOL)\n")

        with patch.object(make_addon.sys, "exit") as mock_exit:
            result = make_addon.create_listing(self.addon_path, self.output_dir)
        mock_exit.assert_not_called()
        self.assertTrue(result)


# ------------------------------------------------------------
#
# CopyTreeContentsTest
#
# ------------------------------------------------------------
class CopyTreeContentsTest(unittest.TestCase):
    """
    Regression tests for the Windows-only bug where
    run_upstream_command()'s addon copy-back step tried to overwrite
    every file in the addon's directory (via the copy-based staging
    fallback used whenever symlinks are unavailable -- the normal
    case for an unprivileged Windows account), including files
    completely unrelated to translations, and aborted the whole
    'listing' step with an unhandled PermissionError when one of
    those files happened to be locked or read-only (in practice, a
    live, currently-running Gramps plugin file).
    """

    def setUp(self) -> None:
        """Create scratch source/destination directory trees."""
        self.tmp_dir = tempfile.mkdtemp(prefix="copy_tree_test_")
        self.src_dir = os.path.join(self.tmp_dir, "src")
        self.dst_dir = os.path.join(self.tmp_dir, "dst")
        os.makedirs(self.src_dir)
        os.makedirs(self.dst_dir)

    def tearDown(self) -> None:
        """Remove the scratch directories created in setUp()."""
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_strict_mode_raises_on_locked_file(self) -> None:
        """Default (non-lenient) behaviour is unchanged: a copy
        failure still raises immediately."""
        with open(
            os.path.join(self.src_dir, "locked.txt"), "w", encoding="utf-8"
        ) as fh:
            fh.write("new content\n")

        def _raise_for_locked(src, dst):
            if os.path.basename(dst) == "locked.txt":
                raise PermissionError(13, "Permission denied", dst)
            _real_copy2(src, dst)

        with patch.object(make_addon.shutil, "copy2", side_effect=_raise_for_locked):
            with self.assertRaises(PermissionError):
                make_addon._copy_tree_contents(self.src_dir, self.dst_dir)

    def test_lenient_mode_warns_instead_of_raising(self) -> None:
        """
        This is the actual fix: with lenient=True, a locked/read-only
        destination file produces a warning string instead of raising
        -- so one unrelated locked file can no longer turn an
        otherwise-successful 'listing' run into a reported failure.
        ``shutil.copy2`` is mocked to raise ``PermissionError`` for
        one specific file, exactly modelling the real Windows failure
        (a locked/read-only file), without depending on OS-level
        permission enforcement -- which does not apply the same way
        to a process running as root.
        """
        with open(
            os.path.join(self.src_dir, "locked.txt"), "w", encoding="utf-8"
        ) as fh:
            fh.write("new content\n")
        with open(os.path.join(self.src_dir, "fine.txt"), "w", encoding="utf-8") as fh:
            fh.write("new content\n")

        def _raise_for_locked(src, dst):
            if os.path.basename(dst) == "locked.txt":
                raise PermissionError(13, "Permission denied", dst)
            _real_copy2(src, dst)

        with patch.object(make_addon.shutil, "copy2", side_effect=_raise_for_locked):
            warnings = make_addon._copy_tree_contents(
                self.src_dir, self.dst_dir, lenient=True
            )

        self.assertEqual(len(warnings), 1)
        self.assertIn("locked.txt", warnings[0])
        # The other file in the same tree must still have been
        # copied: one locked file must not block its siblings.
        self.assertTrue(os.path.exists(os.path.join(self.dst_dir, "fine.txt")))

    def test_copy_back_only_touches_locale_and_po(self) -> None:
        """
        This is the other half of the fix: files outside locale/ and
        po/ -- such as the addon's own .gpr.py/.py source, or an
        unrelated file that happens to share the staging tree because
        the copy-based fallback stages the *entire* addon -- must
        never even be attempted, let alone fail. This directly
        exercises the same locale/po-only scoping pattern used by
        run_upstream_command()'s copy-back step.

        ``shutil.copy2`` is mocked to raise for the unrelated file so
        that, if the scoping regressed and this file were ever
        touched, the test would fail loudly instead of silently
        succeeding (as it would under real OS permission checks when
        the tests happen to run as root).
        """
        # Simulate what _stage_addon()'s copy fallback produces on
        # Windows: a full copy of the whole addon, including files
        # make.py's 'listing' delegation has no reason to touch.
        os.makedirs(os.path.join(self.src_dir, "locale", "fr", "LC_MESSAGES"))
        with open(
            os.path.join(self.src_dir, "locale", "fr", "LC_MESSAGES", "addon.mo"),
            "w",
            encoding="utf-8",
        ) as fh:
            fh.write("compiled translation\n")
        with open(
            os.path.join(self.src_dir, "MyAddon.gpr.py"), "w", encoding="utf-8"
        ) as fh:
            fh.write("register(TOOL)\n")
        # A file that is locked/unwritable in the real addon
        # directory -- e.g. because it is a live, currently-imported
        # plugin file, as happened in practice -- must never be
        # touched, since it is not under locale/ or po/.
        locked_dst = os.path.join(self.dst_dir, "PluginManager.py")
        with open(locked_dst, "w", encoding="utf-8") as fh:
            fh.write("import gramps\n")

        def _raise_if_ever_touched(src, dst):
            if os.path.basename(dst) == "PluginManager.py":
                raise PermissionError(13, "Permission denied", dst)
            _real_copy2(src, dst)

        with patch.object(
            make_addon.shutil, "copy2", side_effect=_raise_if_ever_touched
        ):
            warnings = []
            for subdir in ("locale", "po"):
                staged_subdir = os.path.join(self.src_dir, subdir)
                if os.path.isdir(staged_subdir):
                    warnings.extend(
                        make_addon._copy_tree_contents(
                            staged_subdir,
                            os.path.join(self.dst_dir, subdir),
                            lenient=True,
                        )
                    )

        # No warnings at all: PluginManager.py was never even
        # attempted, because it lives outside locale/ and po/, and
        # the locale/ copy itself succeeded cleanly.
        self.assertEqual(warnings, [])
        self.assertTrue(
            os.path.exists(
                os.path.join(self.dst_dir, "locale", "fr", "LC_MESSAGES", "addon.mo")
            )
        )
        # The unrelated file must be completely untouched.
        with open(locked_dst, encoding="utf-8") as fh:
            self.assertEqual(fh.read(), "import gramps\n")


# ------------------------------------------------------------
#
# ValidatePythonExecutableTest
#
# ------------------------------------------------------------
class ValidatePythonExecutableTest(unittest.TestCase):
    """
    Tests for _validate_python_executable(), added because a bare
    shutil.which('python') hit on Windows can resolve to the
    Microsoft Store's "App Execution Alias" stub rather than a real
    interpreter -- a stub that a naive existence check would have
    accepted, then silently produced no output at all when run.
    """

    def test_real_interpreter_validates(self) -> None:
        """The interpreter actually running this test must validate."""
        self.assertTrue(make_addon._validate_python_executable(sys.executable))

    def test_nonexistent_path_does_not_validate(self) -> None:
        """A path that isn't runnable at all must fail, not raise."""
        self.assertFalse(make_addon._validate_python_executable("/no/such/interpreter"))

    def test_wrong_output_does_not_validate(self) -> None:
        """
        Models the Windows Store alias stub: something is on PATH and
        runs without error, but doesn't behave like a real
        interpreter running our probe script.
        """
        with patch.object(make_addon.subprocess, "run") as mock_run:
            mock_run.return_value = subprocess.CompletedProcess(
                args=["fake"], returncode=0, stdout="", stderr=""
            )
            self.assertFalse(make_addon._validate_python_executable("fake-python"))

    def test_timeout_does_not_validate(self) -> None:
        """A candidate that hangs (e.g. waiting on stdin) must not
        block indefinitely, and must be rejected, not raise."""
        with patch.object(make_addon.subprocess, "run") as mock_run:
            mock_run.side_effect = make_addon.subprocess.TimeoutExpired(
                cmd="fake", timeout=5
            )
            self.assertFalse(make_addon._validate_python_executable("fake-python"))


# ------------------------------------------------------------
#
# PruneNonEnglishListingsTest
#
# ------------------------------------------------------------
class PruneNonEnglishListingsTest(unittest.TestCase):
    """
    Tests for the temporary ENABLE_NON_ENGLISH_LISTINGS gate. Per the
    "do not remove the code, just disable it" requirement, this only
    tests the pruning behaviour -- create_listing()'s and
    _stage_addon()'s own per-language generation logic is untouched
    and continues to be exercised by the other test classes.
    """

    def setUp(self) -> None:
        """Create a scratch listings directory with several language
        files, as either the upstream script or create_listing()
        would leave behind."""
        self.tmp_dir = tempfile.mkdtemp(prefix="prune_test_")
        self.listings_dir = os.path.join(self.tmp_dir, "listings")
        os.makedirs(self.listings_dir)
        for fname in ("addons-en.json", "addons-fr.json", "addons-nl.json"):
            with open(
                os.path.join(self.listings_dir, fname), "w", encoding="utf-8"
            ) as fh:
                fh.write("[]")

    def tearDown(self) -> None:
        """Remove the scratch directory created in setUp()."""
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_prune_removes_non_english_when_disabled(self) -> None:
        """With the flag off (the current default), only the English
        listing must survive."""
        with patch.object(make_addon, "ENABLE_NON_ENGLISH_LISTINGS", False):
            make_addon._prune_non_english_listings(self.listings_dir)
        remaining = sorted(os.listdir(self.listings_dir))
        self.assertEqual(remaining, ["addons-en.json"])

    def test_prune_is_a_no_op_when_enabled(self) -> None:
        """Flipping the flag back on must fully restore behaviour --
        this is the whole point of pruning rather than deleting the
        generation code."""
        with patch.object(make_addon, "ENABLE_NON_ENGLISH_LISTINGS", True):
            make_addon._prune_non_english_listings(self.listings_dir)
        remaining = sorted(os.listdir(self.listings_dir))
        self.assertEqual(
            remaining, ["addons-en.json", "addons-fr.json", "addons-nl.json"]
        )


# ------------------------------------------------------------
#
# RunCommandListingFallbackTest
#
# ------------------------------------------------------------
class RunCommandListingFallbackTest(unittest.TestCase):
    """
    Tests that run_command('listing', ...) falls back to the bundled,
    subprocess-free create_listing() -- and so still actually
    produces addons-en.json -- when run_upstream_command() cannot
    even be attempted (returns the tri-state None), instead of
    reporting a hard failure that silently produces nothing. This is
    the fix for the reported Windows bug: no error, no listings
    folder, no addons-en.json, despite the .tgz having built fine.
    """

    def setUp(self) -> None:
        """Create a scratch addon (already built) and output dir, and
        make find_upstream_script() report a script so run_command()
        takes the delegation branch under test."""
        self.tmp_dir = tempfile.mkdtemp(prefix="listing_fallback_test_")
        self.addon_path = os.path.join(self.tmp_dir, "MyAddon")
        self.output_dir = os.path.join(self.tmp_dir, "out", "gramps52")
        os.makedirs(self.addon_path)
        os.makedirs(self.output_dir)
        with open(
            os.path.join(self.addon_path, "MyAddon.gpr.py"),
            "w",
            encoding="utf-8",
        ) as fh:
            fh.write("register(TOOL)\n")
        with open(
            os.path.join(self.addon_path, "MyAddon.py"), "w", encoding="utf-8"
        ) as fh:
            fh.write("# addon body\n")
        # A prior 'build' step must have already run for create_listing()
        # to proceed past its "run Build first" guard.
        make_addon.run_command("build", self.addon_path, self.output_dir)

    def tearDown(self) -> None:
        """Remove the scratch directories created in setUp()."""
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_falls_back_and_still_produces_english_listing(self) -> None:
        """
        The core regression test: with a make<NN>.py "found" but
        unusable (no working interpreter -- modelled by
        run_upstream_command() returning the tri-state None), the
        overall 'listing' command must still succeed and must still
        produce addons-en.json via the fallback generator.
        """
        with (
            patch.object(
                make_addon, "find_upstream_script", return_value="/fake/make99.py"
            ),
            patch.object(
                make_addon,
                "run_upstream_command",
                return_value=(None, "", "no interpreter found"),
            ),
        ):
            success, stdout, _stderr = make_addon.run_command(
                "listing", self.addon_path, self.output_dir
            )

        self.assertTrue(success)
        self.assertIn("Falling back", stdout)
        self.assertTrue(
            os.path.isfile(os.path.join(self.output_dir, "listings", "addons-en.json"))
        )

    def test_real_upstream_failure_is_not_masked_as_fallback(self) -> None:
        """
        A genuine failure (upstream script ran and failed, tri-state
        False) must NOT trigger the fallback or be silently
        swallowed -- only the "could not even attempt" case (None)
        should fall back.
        """
        with (
            patch.object(
                make_addon, "find_upstream_script", return_value="/fake/make99.py"
            ),
            patch.object(
                make_addon,
                "run_upstream_command",
                return_value=(False, "", "make.py exited with an error"),
            ),
        ):
            success, _stdout, stderr = make_addon.run_command(
                "listing", self.addon_path, self.output_dir
            )

        self.assertFalse(success)
        self.assertIn("make.py exited with an error", stderr)
        self.assertFalse(
            os.path.isfile(os.path.join(self.output_dir, "listings", "addons-en.json"))
        )


# ------------------------------------------------------------
#
# SessionLoggingTest
#
# ------------------------------------------------------------
class SessionLoggingTest(unittest.TestCase):
    """
    Tests for the CLI-teaching session log: a plain-text transcript
    at <output_parent>/logs/<session_id>.log of the CLI-equivalent
    command for everything run_command() does during one AddonPackShip
    GUI session, so a developer can read it (or copy commands
    straight out of it) to learn how to drive make.py by hand.
    """

    def setUp(self) -> None:
        """Create a scratch, already-built addon and output dir. The
        log itself now lives in make_addon.py's own real directory
        (by design -- see _log_session_command()'s docstring), not
        under a scratch temp dir, so a unique per-test session_id and
        thorough tearDown() cleanup are needed to avoid leaving test
        artifacts behind in the actual working tree."""
        self.tmp_dir = tempfile.mkdtemp(prefix="session_log_test_")
        self.addon_path = os.path.join(self.tmp_dir, "MyAddon")
        self.output_dir = os.path.join(self.tmp_dir, "out", "gramps61")
        os.makedirs(self.addon_path)
        os.makedirs(self.output_dir)
        with open(
            os.path.join(self.addon_path, "MyAddon.gpr.py"),
            "w",
            encoding="utf-8",
        ) as fh:
            fh.write("register(TOOL)\n")
        self.session_id = f"unittest_{uuid.uuid4().hex}"
        make_addon_dir = os.path.dirname(os.path.abspath(make_addon.__file__))
        self.logs_dir = os.path.join(make_addon_dir, "logs")
        self.log_path = os.path.join(self.logs_dir, f"{self.session_id}.log")

    def tearDown(self) -> None:
        """Remove the scratch directories created in setUp(), plus
        the real log file/directory this test may have written next
        to make_addon.py."""
        shutil.rmtree(self.tmp_dir, ignore_errors=True)
        if os.path.isfile(self.log_path):
            os.remove(self.log_path)
        if os.path.isdir(self.logs_dir) and not os.listdir(self.logs_dir):
            os.rmdir(self.logs_dir)

    def test_no_session_id_means_no_log_file(self) -> None:
        """The default (session_id=None, used by main()) must not
        create a log at all -- there is no GUI session to teach."""
        make_addon.run_command("build", self.addon_path, self.output_dir)
        self.assertFalse(os.path.isfile(self.log_path))

    def test_build_is_logged_with_correct_command(self) -> None:
        """
        A 'build' run with no make<NN>.py bundled must log this
        tool's own make_addon.py wrapper form -- the only command
        that would actually work in that case.
        """
        with patch.object(make_addon, "find_upstream_script", return_value=None):
            make_addon.run_command(
                "build",
                self.addon_path,
                self.output_dir,
                session_id=self.session_id,
            )
        with open(self.log_path, encoding="utf-8") as fh:
            content = fh.read()
        self.assertIn("make_addon.py build", content)
        self.assertIn(self.addon_path, content)
        self.assertIn(self.output_dir, content)

    def test_release_build_mode_is_noted(self) -> None:
        """A non-default build_mode must be called out in the
        make_addon.py fallback form, since the plain command line
        alone would not reproduce it."""
        with patch.object(make_addon, "find_upstream_script", return_value=None):
            make_addon.run_command(
                "build",
                self.addon_path,
                self.output_dir,
                build_mode="release",
                session_id=self.session_id,
            )
        with open(self.log_path, encoding="utf-8") as fh:
            content = fh.read()
        self.assertIn("BUILD_MODE=release", content)

    def test_build_with_upstream_script_logs_make_addon_as_primary(self) -> None:
        """
        make_addon.py is bundled and distributed with AddonPackShip
        and is fully supported standalone -- for as long as
        AddonPackShip keeps reimplementing 'build' itself rather than
        delegating to make<NN>.py. So the primary, copy-pasteable
        logged command must be the make_addon.py form (what actually
        ran), even when a make<NN>.py happens to be bundled for this
        version -- with the real tool's rough equivalent demoted to a
        secondary FYI note that is explicit it is not a drop-in
        substitute.
        """
        with patch.object(
            make_addon,
            "find_upstream_script",
            return_value="/fake/dir/make61.py",
        ):
            make_addon.run_command(
                "build",
                self.addon_path,
                self.output_dir,
                session_id=self.session_id,
            )
        with open(self.log_path, encoding="utf-8") as fh:
            content = fh.read()
        # Primary line: the real, executable, supported command.
        primary_line = next(
            line for line in content.splitlines() if line.startswith("[")
        )
        self.assertIn("make_addon.py build", primary_line)
        self.assertIn(self.addon_path, primary_line)
        # Secondary: the upstream tool mentioned, but not as a
        # substitute, and with the concrete way it differs spelled out.
        self.assertIn("python3 make61.py gramps61 build MyAddon", content)
        self.assertIn("NOT a drop-in substitute", content)
        self.assertIn("bumps the version", content)

    def test_compile_and_clean_with_upstream_script_mention_real_tool(
        self,
    ) -> None:
        """The same FYI-note treatment must apply to 'compile' and
        'clean', not just 'build' -- make_addon.py primary, upstream
        mentioned as a non-substitute FYI."""
        with patch.object(
            make_addon,
            "find_upstream_script",
            return_value="/fake/dir/make61.py",
        ):
            make_addon.run_command(
                "compile",
                self.addon_path,
                self.output_dir,
                session_id=self.session_id,
            )
            make_addon.run_command(
                "clean",
                self.addon_path,
                self.output_dir,
                session_id=self.session_id,
            )
        with open(self.log_path, encoding="utf-8") as fh:
            content = fh.read()
        self.assertIn('make_addon.py compile "', content)
        self.assertIn('make_addon.py clean "', content)
        self.assertIn("python3 make61.py gramps61 compile MyAddon", content)
        self.assertIn("python3 make61.py gramps61 clean MyAddon", content)
        self.assertIn("deletes MyAddon/locale/ entirely", content)

    def test_build_mode_note_still_shown_when_upstream_also_bundled(self) -> None:
        """
        The BUILD_MODE note describes the primary (make_addon.py)
        command, which is now always logged regardless of whether a
        make<NN>.py happens to be bundled -- so this note must always
        appear for a non-default build_mode, not just when no
        make<NN>.py is present.
        """
        with patch.object(
            make_addon,
            "find_upstream_script",
            return_value="/fake/dir/make61.py",
        ):
            make_addon.run_command(
                "build",
                self.addon_path,
                self.output_dir,
                build_mode="release",
                session_id=self.session_id,
            )
        with open(self.log_path, encoding="utf-8") as fh:
            content = fh.read()
        self.assertIn("BUILD_MODE=release", content)
        self.assertIn("no beta/release distinction", content)

    def test_log_lives_next_to_make_addon_py(self) -> None:
        """
        The log must be written next to make_addon.py itself (this
        plugin's own install folder), not under the (possibly
        user-redirected) output directory -- so it's always in one
        fixed, discoverable place regardless of where a given run's
        output was sent.
        """
        make_addon.run_command(
            "build",
            self.addon_path,
            self.output_dir,
            session_id=self.session_id,
        )
        self.assertTrue(os.path.isfile(self.log_path))
        # And specifically NOT under the (scratch, redirectable)
        # output directory used for this test.
        self.assertFalse(os.path.exists(os.path.join(self.tmp_dir, "out", "logs")))

    def test_blank_line_separates_entries(self) -> None:
        """Each command's entry must be preceded by a blank line, so
        entries are visually distinct blocks when reading the log."""
        make_addon.run_command(
            "build",
            self.addon_path,
            self.output_dir,
            session_id=self.session_id,
        )
        make_addon.run_command(
            "clean",
            self.addon_path,
            self.output_dir,
            session_id=self.session_id,
        )
        with open(self.log_path, encoding="utf-8") as fh:
            content = fh.read()
        # The file starts with a blank line (before the very first
        # entry too), and each subsequent timestamped line is also
        # immediately preceded by one.
        self.assertTrue(content.startswith("\n"))
        entry_lines = [line for line in content.splitlines() if line.startswith("[")]
        self.assertEqual(len(entry_lines), 2)
        for entry_line in entry_lines:
            idx = content.index(entry_line)
            self.assertEqual(content[idx - 1], "\n")

    def test_multiple_commands_append_to_same_session_log(self) -> None:
        """Every command run under the same session_id must land in
        the same file, in order -- one transcript per GUI session,
        not per command."""
        make_addon.run_command(
            "build",
            self.addon_path,
            self.output_dir,
            session_id=self.session_id,
        )
        make_addon.run_command(
            "listing",
            self.addon_path,
            self.output_dir,
            session_id=self.session_id,
        )
        make_addon.run_command(
            "clean",
            self.addon_path,
            self.output_dir,
            session_id=self.session_id,
        )
        with open(self.log_path, encoding="utf-8") as fh:
            lines = [
                line
                for line in fh.read().splitlines()
                if line.strip() and not line.startswith("#")
            ]
        self.assertEqual(len(lines), 3)
        self.assertIn("build", lines[0])
        self.assertIn("listing", lines[1])
        self.assertIn("clean", lines[2])

    def test_listing_fallback_is_logged_as_make_addon_not_upstream(self) -> None:
        """
        With no make<NN>.py bundled (the normal state in this test
        environment), the logged command must be the bundled
        make_addon.py fallback, not a fabricated upstream one.
        """
        make_addon.run_command(
            "listing",
            self.addon_path,
            self.output_dir,
            session_id=self.session_id,
        )
        with open(self.log_path, encoding="utf-8") as fh:
            content = fh.read()
        self.assertIn("make_addon.py listing", content)

    def test_log_write_failure_does_not_break_the_command(self) -> None:
        """A log write failure must never take down the actual
        packaging operation -- it's a teaching aid, not required for
        correctness."""
        real_makedirs = make_addon.os.makedirs

        def _fail_only_for_logs(path, *args, **kwargs):
            if os.path.basename(os.path.normpath(path)) == "logs":
                raise OSError("disk full")
            return real_makedirs(path, *args, **kwargs)

        with patch.object(make_addon.os, "makedirs", side_effect=_fail_only_for_logs):
            success, _stdout, _stderr = make_addon.run_command(
                "build",
                self.addon_path,
                self.output_dir,
                session_id=self.session_id,
            )
        self.assertTrue(success)
        # This test's own log entry must never have been written --
        # note this checks the specific file, not whether the shared
        # logs/ directory exists at all, since sibling tests using
        # this same real, on-disk location may legitimately have
        # created (and since cleaned up) it independently.
        self.assertFalse(os.path.isfile(self.log_path))


if __name__ == "__main__":
    unittest.main()
